# KwikLogPro: Formal Developer Handoff and System Architecture Manual

* **Project Designation**: KwikLogPro (KwikLog Cross-Platform Air-Gapped System Health Auditor and Deterministic Remediation Engine)
* **Physical Standalone Project Directory**: `/home/auxk0rd/Desktop/KwikLogPro`
* **Target Runtime Environments**: Pop!_OS (22.04 LTS / 24.04 LTS with COSMIC) and Microsoft Windows (10 / 11 Pro and Enterprise)
* **Architecture Paradigm**: Local-First Air-Gapped Polyglot Pipeline (Go + Rust + Python 3.10+ + POSIX/Batch Probes + SQLite3 WAL + HTMX)
* **Presentation Standard**: Brutalist Cybercore (Zero-JS Framework, Vendored Local HTMX, 0px Border-Radius Geometry)
* **Principal Architect and Sign-Off Authority**: Auxk0rd

---

## 1. Document Purpose and Scope

This Developer Handoff Manual (`/home/auxk0rd/Desktop/KwikLogPro/Handoff.md`) serves as the authoritative architectural specification, operational runbook, and engineering onboarding reference for maintaining, auditing, and extending **KwikLogPro** (referred to operationally within internal tooling and CLI subsystems as **KwikLog**).

### 1.1 Physical Location and Standalone Directory Isolation

KwikLogPro resides inside its dedicated standalone project directory at `/home/auxk0rd/Desktop/KwikLogPro`. In strict accordance with standalone project isolation standards, all source trees, compiled native binaries (`bin/kwiklogd`, `bin/kwikparse`), vendored client assets (`web/static/htmx.min.js`), local time-series SQLite databases (`kwiklog.db`), and exported offline audit archives (`exports/`) operate entirely within `/home/auxk0rd/Desktop/KwikLogPro` without external cloud dependencies, remote telemetry beacons, or cross-repository runtime coupling.

### 1.2 Operational Mandate

Heterogeneous workstation fleets running Pop!_OS Linux and Windows 10/11 suffer from diagnostic fragmentation across incompatible utilities (`journalctl`, `smartctl`, `dmesg`, `dpkg`, `dkms`, `timeshift`, Windows Event Viewer `.evtx` binary logs, CIM/WMI providers, and `CBS.log`). KwikLog addresses this fragmentation by executing a deterministic, three-stage polyglot diagnostic pipeline:

1. **Stage 1 (Native OS Telemetry Extraction)**: Executes OS-native shell probes (`probes/probe_pop.sh` on Linux, `probes/probe_win.bat` on Windows) under strict `context.WithTimeout` supervision to harvest CPU thermal/load telemetry, RAM and Swap saturation, NVMe SMART health attributes, filesystem mount capacities, and package/service state into a normalized JSON contract on `STDOUT`.
2. **Stage 2 (High-Speed Log Ingestion and Deduplication)**: Executes the compiled Rust engine (`kwikparse`) using memory-mapped file I/O (`memmap2`), parallel work-stealing iterators (`rayon`), linear-time regular expression automata (`regex`), and SHA-256 signature normalization (`sha2`) to parse multi-gigabyte Linux kernel/systemd logs and Windows `.evtx` binary chunks in milliseconds, collapsing recurring error storms into frequency-bucketed signature hashes.
3. **Stage 3 (Historical OLS Regression and Rule Evaluation)**: Executes the zero-dependency Python 3.10+ diagnostic engine (`kwikdiag/kwikdiag.py`), which queries the local SQLite3 Write-Ahead Logging (`WAL`) database (`kwiklog.db`) across the last $N$ historical runs (default $N = 10$), computes Ordinary Least Squares (OLS) linear regression slopes ($m$) to expose progressive hardware degradation prior to static threshold failure, evaluates 38 deterministic rules across Pop!_OS (`POP_*`), Windows (`WIN_*`), and Cross-Platform Hardware (`HW_*`) matrices, and synthesizes copy-ready CLI remediation commands alongside physical hardware intervention directives.

---

## 2. Complete Codebase Directory Tree

```text
/home/auxk0rd/Desktop/KwikLogPro/               # Root standalone project directory for KwikLogPro
├── Handoff.md                                  # Formal developer handoff and system architecture manual
├── README.md                                   # Operator quick-start guide, architecture overview, and CLI runbook
├── Makefile                                    # Unified multi-language build, test, CLI, serve, and release bundler
├── dev.sh                                      # POSIX automation runner script (setup, build, run, serve, cli, simulate, test, fmt)
├── dev.bat                                     # Windows 10/11 Native Batch runner (CN-DIR-2026-004 Bi-Launcher Specification)
├── launcher.sh                                 # Standardized POSIX entrypoint wrapper delegating to dev.sh
├── launcher.bat                                # Standardized Windows 10/11 entrypoint wrapper delegating to dev.bat
├── schema.sql                                  # SQLite3 WAL relational and time-series DDL schema definition
├── go.mod                                      # Go 1.22 module manifest defining kwiklogpro and sqlite3 driver dependency
├── go.sum                                      # Cryptographic checksum ledger for Go module verification
├── kwiklog.db                                  # Local SQLite3 WAL time-series database generated at runtime
├── Docs/                                       # Engineering design documentation directory
│   ├── KwikLogProEDD.md                        # Production Engineering Design Document and functional specification
│   └── Handoff.md                              # Synchronized copy of this formal developer handoff manual
├── Code/                                       # Symbolic workspace mirror linking all active codebase modules
├── bin/                                        # Compiled native executable output directory
│   ├── kwiklogd                                # Compiled Go core orchestrator, CLI table reporter, and HTMX HTTP server
│   └── kwikparse                               # Compiled Rust multi-threaded mmap and SIMD regex log ingestion binary
├── exports/                                    # Offline archive output directory for standalone Markdown and HTML reports
│   ├── kwiklog_run_2.md                        # Generated standalone Markdown diagnostic audit report
│   └── kwiklog_run_2.html                      # Generated self-contained Brutalist HTML diagnostic audit report
├── cmd/                                        # Go command package directory
│   └── kwiklogd/                               # Main package for the kwiklogd daemon and CLI orchestrator
│       ├── main.go                             # Entrypoint, CLI flag parser, ANSI TrueColor table renderer, and server bootstrap
│       ├── orchestrator.go                     # Subprocess pipeline supervisor, timeout enforcer, and privilege detector
│       ├── db.go                               # SQLite3 WAL connection manager, transaction writer, and export generator
│       ├── server.go                           # Loopback HTMX HTTP router, view model builder, and SSE progress broadcaster
│       └── kwiklogd_test.go                    # Automated Go integration test suite for SQLite WAL and HTMX HTTP handlers
├── probes/                                     # OS-native hardware and software telemetry extractor scripts
│   ├── probe_pop.sh                            # Pop!_OS and Linux Bash/Python telemetry probe emitting normalized JSON
│   └── probe_win.bat                           # Windows 10/11 Batch and PowerShell CIM/WMI/SMART telemetry probe
├── kwikparse/                                  # Rust high-speed log ingestion and deduplication crate
│   ├── Cargo.toml                              # Rust package manifest (memmap2, rayon, regex, serde, serde_json, sha2, chrono)
│   ├── Cargo.lock                              # Exact dependency graph lockfile for deterministic offline compilation
│   └── src/                                    # Rust crate source directory
│       ├── main.rs                             # CLI argument parser, OS dispatcher, simulation injector, and JSON serializer
│       ├── dedup.rs                            # Dynamic token stripper, SHA-256 signature hasher, and frequency bucketer
│       ├── linux_logs.rs                       # Parallel mmap scanner for /var/log/* and journalctl JSON streams
│       └── windows_evtx.rs                     # Cross-platform binary ElfFile/ElfChnk .evtx parser and UTF-16LE extractor
├── kwikdiag/                                   # Python 3.10+ deterministic diagnostic and prescription synthesis engine
│   ├── kwikdiag.py                             # Main stdin JSON consumer, rule aggregator, health scorer, and stdout emitter
│   ├── trends.py                               # SQLite historical time-series loader and OLS linear regression calculator
│   ├── rules_pop.py                            # Pop!_OS software, package, DKMS, Timeshift, systemd, and GPU rule evaluators
│   ├── rules_win.py                            # Windows CBS, NTFS, Kernel-Power, WHEA, BugCheck, WMI, and Winsock evaluators
│   ├── rules_hw.py                             # Cross-platform CPU thermal, NVMe SMART, OLS slope, and swap thrash evaluators
│   └── test_kwikdiag.py                        # Automated Python unittest suite verifying OLS math, sanitization, and rules
└── web/                                        # Brutalist Cybercore local web frontend assets and Go embed package
    ├── embed.go                                # Go //go:embed directive bundling static/* and templates/* into kwiklogd
    ├── static/                                 # Static client assets served from memory via go:embed
    │   ├── brutalist.css                       # Strict 0px border-radius high-contrast dark stylesheet
    │   └── htmx.min.js                         # Vendored local HTMX binary (zero external CDN requests)
    └── templates/                              # Go html/template hypermedia views and swappable fragments
        ├── index.html                          # Master Brutalist dashboard container, privilege banner, and clipboard script
        ├── report_fragment.html                # Swappable report view, ASCII gauges, OLS table, and prescription queue
        └── progress_sse.html                   # Real-time Server-Sent Events (SSE) 3-phase scan progress listener component
```

---

## 3. Deep File-by-File Breakdown

### 3.1 Core Orchestration and Storage Layer (`cmd/kwiklogd/` and `schema.sql`)

#### `schema.sql`
* **Role**: Relational and time-series SQLite3 database definition script enforcing Write-Ahead Logging (`WAL`) and foreign-key integrity.
* **What It Does**:
  1. Configures connection-level pragmas required for concurrent read/write access between background diagnostic scans and live HTMX UI queries: `PRAGMA journal_mode = WAL;`, `PRAGMA synchronous = NORMAL;`, `PRAGMA foreign_keys = ON;`, and `PRAGMA busy_timeout = 5000;`.
  2. Defines `diagnostic_runs`: Master execution ledger storing `run_id` (`INTEGER PRIMARY KEY AUTOINCREMENT`), `timestamp_utc`, `os_family` (`CHECK(os_family IN ('linux', 'windows'))`), `os_distro`, `kernel_version`, `health_score` (`CHECK(health_score BETWEEN 0 AND 100)`), `overall_status` (`CHECK(overall_status IN ('OPTIMAL', 'DEGRADED', 'CRITICAL'))`), `scan_duration_ms`, and the complete serialized `raw_telemetry_json` bundle. Indexed descending on `timestamp_utc` via `idx_runs_timestamp`.
  3. Defines `telemetry_metrics`: Flattened numerical time-series table storing `metric_id`, `run_id` (`ON DELETE CASCADE`), `component_type` (such as `'CPU'`, `'RAM'`, `'SWAP'`, `'DISK:/dev/nvme0n1'`), `metric_name` (such as `'temp_celsius'`, `'media_errors'`, `'used_pct'`), and `metric_value` (`REAL`). Indexed via composite B-tree index `idx_metrics_lookup(component_type, metric_name, run_id)` to guarantee sub-millisecond historical window lookups for OLS slope calculations.
  4. Defines `log_anomalies`: Stores deduplicated log signatures emitted by `kwikparse`, including `signature_hash`, `source`, `event_id`, `severity`, `category`, `first_seen_utc`, `last_seen_utc`, `occurrence_count`, and `sample_message`. Indexed on `signature_hash` via `idx_anomalies_hash`.
  5. Defines `prescriptions`: Stores triggered remediation directives per `run_id`, enforcing `CHECK` constraints on `severity` (`'LOW'`, `'MEDIUM'`, `'HIGH'`, `'CRITICAL'`), `domain` (`'SOFTWARE'`, `'HARDWARE'`), and `remediation_type` (`'CLI_COMMAND'`, `'PHYSICAL_INTERVENTION'`), alongside `action_payload_json`, `verification_cmd`, `risk_level`, and `acknowledged` (`INTEGER NOT NULL DEFAULT 0`).
* **How to Modify**: Append new tables or columns using `CREATE TABLE IF NOT EXISTS` and `CREATE INDEX IF NOT EXISTS`. Whenever a new flattened hardware metric is added, update `DBStore.SaveDiagnosticRun()` in `cmd/kwiklogd/db.go` and `load_historical_trends()` in `kwikdiag/trends.py`.

#### `cmd/kwiklogd/main.go`
* **Role**: Application entrypoint, CLI flag dispatcher, ANSI TrueColor Brutalist table renderer, and HTTP server lifecycle initializer.
* **What It Does**:
  1. Parses command-line flags: `--cli` (executes a single diagnostic sweep and prints the Brutalist ASCII report table to `STDOUT`), `--serve` (starts the loopback HTMX HTTP server), `--port` (default `8484`), `--db` (custom path to `kwiklog.db`), `--simulate` (enables deterministic fault injection across probes and parser), and `--export` (writes standalone Markdown and HTML reports to `./exports/`).
  2. Resolves the standalone project root directory via `resolveRootDir()`, checking `KWIKLOG_ROOT`, the current working directory for `schema.sql`, and the parent directory of the running executable.
  3. Invokes `CheckPrivileges()` to verify Root UID `0` (Linux) or Administrator SID (Windows). If unprivileged, logs a security guardrail notice and activates Degraded Unprivileged Mode rather than aborting.
  4. Implements `printCLIReport(runID, bundle, isPrivileged)`: Renders an 84-column Brutalist ASCII table utilizing 24-bit ANSI TrueColor escape sequences (`#00FF66` Optimal Green, `#FFB000` Warning Amber, `#FF0033` Critical Crimson) displaying the masthead, 12-segment ASCII bar gauges (`buildASCIIGauge`), OLS historical regression trajectories, the prioritized remediation queue, and deduplicated log anomalies.
  5. Ensures at least one baseline run exists in `kwiklog.db` before binding `http.ListenAndServe` strictly to `127.0.0.1:<port>`.
* **How to Modify**: Add new CLI flags in `main()` prior to `flag.Parse()`. To customize CLI column widths or add new telemetry rows to the terminal table, modify `printCLIReport()`.

#### `cmd/kwiklogd/orchestrator.go`
* **Role**: Subprocess execution supervisor, privilege inspector, IPC data contract definition module, and timeout boundary controller.
* **What It Does**:
  1. Declares strongly typed Go structs mapping the three JSON IPC contracts: `TelemetryPayload`, `HardwareTelemetry`, `DiskTelemetry`, `MountPoint`, `SoftwareState`, `TimeshiftStatus` (Contract 1); `ParserOutput`, `LogAnomaly` (Contract 2); `DiagOutput`, `TriggeredPrescription`, `MetricTrendItem`, and `CombinedScanBundle` (Contract 3).
  2. Implements `CheckPrivileges()`: Checks `os.Geteuid() == 0` on POSIX systems or executes a non-interactive PowerShell `WindowsPrincipal.IsInRole(Administrator)` check on Windows.
  3. Implements `Orchestrator.resolveKwikparseBinary()`: Searches `./bin/kwikparse`, `./kwikparse/target/release/kwikparse`, and `./kwikparse/target/debug/kwikparse` (appending `.exe` on Windows).
  4. Implements `Orchestrator.ExecutePipeline(store, simulateDegraded, onPhase)`:
     * Wraps each of the three pipeline stages in an independent `context.WithTimeout(context.Background(), o.ProbeTimeout)` (default 30 seconds per stage) so a hung `smartctl` ioctl on a failing NVMe bus cannot deadlock the daemon.
     * **Phase 1**: Spawns `bash probes/probe_pop.sh` or `cmd.exe /C probes/probe_win.bat` with separate `Stdout` and `Stderr` buffers. Unmarshals `Stdout` into `TelemetryPayload` while routing `Stderr` diagnostics to the application logger.
     * **Phase 2**: Spawns `kwikparse --os <os_family>`. If `kwikparse` fails or is absent, degrades gracefully to an empty `ParserOutput` slice rather than aborting the scan.
     * **Phase 3**: Serializes `{"telemetry": telemetry, "log_parser": parserOut}` into memory and pipes it directly to `python3 kwikdiag/kwikdiag.py --db <dbPath>` via `Stdin`. Unmarshals `Stdout` into `DiagOutput`, normalizes `ActionSteps` from either `PhysicalSteps` or `Commands`, and commits the resulting `CombinedScanBundle` to SQLite via `store.SaveDiagnosticRun()`.
     * Invokes the `onPhase` callback at each transition to feed live Server-Sent Events (SSE) to connected web clients.
* **How to Modify**: Adjust per-stage timeout ceilings by modifying `ProbeTimeout` in `NewOrchestrator()`. To pass additional CLI flags to `kwikparse` or `kwikdiag.py`, extend `parseArgs` or `diagCmd` inside `ExecutePipeline()`.

#### `cmd/kwiklogd/db.go`
* **Role**: Thread-safe SQLite3 WAL persistence layer, time-series metric flattener, prescription state manager, and offline report exporter.
* **What It Does**:
  1. `NewDBStore(dbPath, schemaPath)`: Opens the SQLite3 database with `_busy_timeout=5000&_journal_mode=WAL&_foreign_keys=on`, caps open connections (`db.SetMaxOpenConns(4)`), executes WAL and foreign-key pragmas, and applies `schema.sql`.
  2. `SaveDiagnosticRun(bundle, scanDurationMs)`: Protected by `s.mu.Lock()` and executed inside an atomic SQL transaction (`tx, err := s.db.Begin()`):
     * Inserts the master record into `diagnostic_runs`.
     * Computes derived percentages (`RAM:used_pct`, `SWAP:used_pct`) and flattens CPU, RAM, Swap, and per-disk SMART metrics (`temp_celsius`, `available_spare_pct`, `percentage_used`, `media_errors`, `unsafe_shutdowns`) into `telemetry_metrics`.
     * Batch-inserts deduplicated log anomalies into `log_anomalies`.
     * Serializes each prescription's command/physical step array into `action_payload_json` and inserts into `prescriptions`.
  3. `GetRun(runID)`, `ListRecentRuns(limit)`, `GetPrescriptions(runID, domain)`, and `AcknowledgePrescription(prescriptionID)`: Provide fast read queries for historical run switching, domain filtering (`SOFTWARE` vs. `HARDWARE`), and directive acknowledgment.
  4. `ExportRunReport(runID, exportDir)`: Synthesizes both a standalone Markdown file (`exports/kwiklog_run_<id>.md`) and a self-contained dark-mode HTML document (`exports/kwiklog_run_<id>.html`) for air-gapped archival.
* **How to Modify**: Add new analytical queries or retention pruning methods on `DBStore`. Always wrap write operations with `s.mu.Lock()` and `defer s.mu.Unlock()`.

#### `cmd/kwiklogd/server.go`
* **Role**: Localhost HTTP server, view-model transformer, HTMX partial renderer, and asynchronous SSE scan broadcaster.
* **What It Does**:
  1. `NewServer(store, orchestrator, isPrivileged)`: Registers custom template functions (`add1` for 1-based physical step numbering) and parses embedded HTML templates from `webassets.EmbeddedFS`.
  2. `buildASCIIGauge(pct)` and `formatBytes(b)`: Format raw numerical telemetry into 12-bar ASCII meters (`[||||||||||..]`) and human-readable byte strings (`GiB`, `MiB`).
  3. `buildViewData(runID, domainFilter)`: Loads the requested run from SQLite and constructs `DashboardViewData`, computing badge severities (`OPT`, `WARN`, `CRIT`) for each telemetry row and formatting the right-hand Historical Degradation OLS regression table (`NVME MEDIA ERRORS`, `CPU IDLE TEMP`, `HEALTH SCORE` trajectory, and `LAST TIMESHIFT`).
  4. Exposes HTTP routes via `Routes()`:
     * `GET /static/*`: Serves embedded `htmx.min.js` and `brutalist.css` directly from binary memory.
     * `GET /`: Renders `index.html` (automatically running an initial baseline scan if `kwiklog.db` has zero runs).
     * `POST /api/scan`: Spawns `ExecutePipeline` in a background goroutine, registers a `ScanJob` channel in `s.jobs`, and returns the `progress_sse.html` fragment.
     * `GET /api/scan/stream`: Streams `text/event-stream` SSE events (`event: phase` and `event: complete`) using `http.Flusher`, replaying any buffered history so fast scans never drop early phase messages.
     * `GET /api/runs/{id}` and `GET /api/runs/select`: Swaps `#report-viewport` with any historical run snapshot.
     * `GET /api/prescriptions`: Filters `#prescription-queue-body` by domain (`ALL`, `SOFTWARE`, `HARDWARE`).
     * `POST /api/prescriptions/{id}/ack`: Marks a prescription directive acknowledged in SQLite and re-renders the partial queue.
     * `POST /api/export/{id}`: Triggers `ExportRunReport()` and returns a confirmation banner with the exported file paths.
* **How to Modify**: Register new HTMX routes inside `Routes()` and add corresponding template blocks in `web/templates/report_fragment.html`.

---

### 3.2 Native OS Telemetry Probes Layer (`probes/`)

#### `probes/probe_pop.sh`
* **Role**: Native Pop!_OS and Linux hardware/software telemetry collector outputting strictly formatted JSON to `STDOUT`.
* **What It Does**:
  1. Enforces `set -uo pipefail` and defines `log_err()` to guarantee all diagnostic warnings write exclusively to `STDERR`.
  2. Checks `id -u` for root elevation (`IS_ROOT`). If `UID != 0`, logs a Degraded Unprivileged Mode warning to `STDERR` and continues without crashing.
  3. Extracts OS release metadata from `/etc/os-release`, kernel version via `uname -r`, uptime from `/proc/uptime`, CPU model from `/proc/cpuinfo` / `lscpu`, CPU temperature in millidegrees from `/sys/class/thermal/thermal_zone*/temp` or `/sys/class/hwmon/hwmon*/temp1_input`, CPU load percentage normalized by `nproc` from `/proc/loadavg`, and byte-exact RAM/Swap counters via `free -b`.
  4. Audits software health: queries failed systemd units (`systemctl list-units --state=failed`), broken packages (`dpkg --audit`), held packages (`apt-mark showhold`), uncommitted dpkg journal updates (`/var/lib/dpkg/updates/[0-9]+` with no active `apt`/`dpkg` PID via `pgrep`), broken DKMS modules (`dkms status`), OSTree corruption (`timeout 5 flatpak repair --dry-run`), Timeshift snapshot counts (`timeshift --list` or `/timeshift/snapshots`), `system76-power profile`, and `/var/run/reboot-required`.
  5. Invokes an inline Python 3 serializer that executes `df -B1` and `lsblk -J -b`, maps LVM/LUKS `/dev/mapper/*` mounts to their parent physical block devices, queries `smartctl -a -j <dev>` with a 6-second timeout to extract NVMe SMART health log attributes (`critical_warning`, `temperature`, `available_spare`, `percentage_used`, `media_errors`, `unsafe_shutdowns`), and emits the validated JSON payload to `STDOUT`.
* **How to Modify**: Add new Linux shell probes before the `export` block, export the resulting environment variable, and include it in the inline Python `payload` dictionary.

#### `probes/probe_win.bat`
* **Role**: Native Windows 10/11 hardware, storage, WMI, and servicing telemetry probe outputting normalized JSON to `STDOUT`.
* **What It Does**:
  1. Invokes `powershell -NoProfile -ExecutionPolicy Bypass` with `$ErrorActionPreference = 'SilentlyContinue'`.
  2. Checks Administrator elevation via `[Security.Principal.WindowsPrincipal]`.
  3. Queries CIM/WMI classes `Win32_OperatingSystem`, `Win32_Processor`, `Win32_PageFileUsage`, and `MSAcpi_ThermalZoneTemperature` (converting tenths of Kelvin to Celsius).
  4. Enumerates physical disks via `Get-PhysicalDisk` paired with `Get-StorageReliabilityCounter` and `Get-Volume` to populate SMART wear, uncorrected read errors, temperature, and drive letter mount utilization.
  5. Queries stopped automatic services (`Get-Service`), checks Registry `Component Based Servicing\RebootPending`, runs `winmgmt /verifyrepository`, inspects the last 200 lines of `C:\Windows\Logs\CBS\CBS.log` for component store corruption, and serializes the schema via `ConvertTo-Json -Depth 6`.
* **How to Modify**: Add additional CIM/WMI or Registry queries inside the PowerShell command block and attach the resulting properties to `$payload.hardware` or `$payload.software_state`.

---

### 3.3 High-Speed Rust Log Ingestion Layer (`kwikparse/`)

#### `kwikparse/Cargo.toml` and `kwikparse/src/main.rs`
* **Role**: Entrypoint and CLI controller for the multi-threaded Rust log ingestion engine (`kwikparse`).
* **What It Does**:
  1. Parses CLI arguments: `--os <linux|windows>`, `--log-dir <path>`, `--no-journalctl`, and `--simulate-degraded` (or `KWIKLOG_SIMULATE_DEGRADED=1`).
  2. Dispatches log ingestion to either `linux_logs::ingest_linux_logs()` or `windows_evtx::ingest_windows_logs()`.
  3. Passes collected `RawAnomalyEvent` structs into `dedup::deduplicate_events()`, measures wall-clock execution time (`Instant::now()`), and serializes `ParseOutput` (`parse_duration_ms`, `bytes_processed`, `total_events_scanned`, `anomalies`) as pretty-printed JSON to `STDOUT`.
  4. Contains unit tests (`tests::test_deduplication_strips_dynamic_tokens`) verifying that dynamic sector numbers and timestamps normalize to identical signature hashes.
* **How to Modify**: Add new CLI flags in the `while i < args.len()` parser loop in `main.rs`.

#### `kwikparse/src/dedup.rs`
* **Role**: Dynamic log token normalizer, SHA-256 signature hasher, and frequency bucket aggregator.
* **What It Does**:
  1. Compiles a thread-safe `OnceLock<Regex>` (`DYNAMIC_TOKEN_RE`) that matches hexadecimal memory addresses (`0x[0-9a-fA-F]+`), disk sector offsets (`sector \d+`), process IDs (`pid=?\d+`, `\[\d+\]`), kernel monotonic timestamps (`\[\s*\d+\.\d+\s*\]`), ISO-8601 timestamps with timezone offsets, and long numeric counters (`\b\d{6,}\b`), replacing them with `<NUM>`.
  2. `compute_signature_hash(source, category, event_id, msg)`: Hashes the normalized tuple `source|category|event_id|stripped_msg` using `sha2::Sha256` and formats the leading 8 bytes as a 16-character lowercase hexadecimal signature.
  3. `deduplicate_events(events)`: Aggregates identical signatures in a `HashMap<String, LogAnomaly>`, incrementing `occurrence_count`, tracking the earliest `first_seen_utc` and latest `last_seen_utc`, sorting descending by `occurrence_count`, and truncating to the top 50 distinct signatures to prevent downstream payload bloat.
* **How to Modify**: Add new volatile token patterns (such as UUIDs or IPv6 addresses) to `DYNAMIC_TOKEN_RE` in `normalize_signature_input()`.

#### `kwikparse/src/linux_logs.rs`
* **Role**: Memory-mapped (`memmap2`) and parallel (`rayon`) Linux log scanner for `/var/log/*` and `journalctl` JSON streams.
* **What It Does**:
  1. Initializes a static vector of pre-compiled `RulePattern` regex automata (`LINUX_PATTERNS`) covering:
     * `STORAGE_IO` (`CRITICAL`): `blk_update_request: I/O error`, `Buffer I/O error`, `nvme*: I/O error`
     * `MEMORY_OOM` (`CRITICAL`): `Out of memory: Killed process`, `oom-kill:`, `invoked oom-killer`
     * `GPU_SUBSYSTEM` (`CRITICAL`): `NVRM: Xid`, `amdgpu:.*ring \w+ timeout`, `drm:.*GPU hang`
     * `FILESYSTEM` (`CRITICAL`): `EXT4-fs error`, `BTRFS: error`, `XFS.*corruption`
     * `PROCESS_CRASH` (`HIGH`): `segfault at [0-9a-fA-F]+ ip`
     * `SERVICE_FAILURE` (`HIGH`): `Failed to start .+`, `Unit .+ entered failed state`
     * `PACKAGE_MANAGER` (`HIGH`): `dpkg: error processing`, `Sub-process /usr/bin/dpkg returned an error code`, `dependency problems - leaving unconfigured`
  2. `scan_mmap_file(path, fallback_now)`: Maps candidate files (`syslog`, `kern.log`, `dpkg.log`, `apt/term.log`, `messages`) into virtual memory via `unsafe { Mmap::map(&file) }` and scans all lines in parallel using Rayon `lines.par_iter()`.
  3. `scan_journalctl(fallback_now)`: Spawns `journalctl -p 0..3 -b -n 2500 --output=json --no-pager` and parses JSON entries in parallel, converting `__REALTIME_TIMESTAMP` microseconds into UTC ISO-8601 timestamps.
* **How to Modify**: Append new `RulePattern` structs to `get_patterns()` or add additional log file paths to `candidate_files` in `ingest_linux_logs()`.

#### `kwikparse/src/windows_evtx.rs`
* **Role**: Native cross-platform Windows `.evtx` binary chunk inspector and event signature matcher.
* **What It Does**:
  1. Verifies the 8-byte file header magic `ElfFile\0` (`EVTX_FILE_MAGIC`) at offset `0` and slices the file body (starting at offset `4096`) into 64KB chunks (`EVTX_CHUNK_SIZE = 65536`).
  2. Processes all 64KB chunks concurrently via `chunks.par_iter()`. Verifies the chunk magic `ElfChnk\0` (`EVTX_CHUNK_MAGIC`) and extracts both ASCII and UTF-16LE strings embedded inside Binary XML (`BinXML`) records via `extract_lossy_strings_from_chunk()`.
  3. Matches extracted chunk payloads against `WIN_SIGNATURES`: Event ID `41` (`Kernel-Power`), Event ID `55` (`Ntfs`), Event ID `153` (`disk`), Event ID `18`/`19` (`WHEA-Logger`), Event ID `1001` (`BugCheck` `0x1A` / `0x50`), and Event ID `10010` (`DistributedCOM` / CBS). Also supports plaintext/XML fallback scanning for exported logs.
* **How to Modify**: Add new `WinEventSignature` definitions to `get_win_signatures()` to detect additional Windows Event IDs.

---

### 3.4 Deterministic Python Diagnostic and Prescription Engine Layer (`kwikdiag/`)

#### `kwikdiag/trends.py`
* **Role**: SQLite time-series query module and Ordinary Least Squares (OLS) linear regression slope calculator.
* **What It Does**:
  1. Implements `calculate_ols_slope(points)` computing the exact OLS linear regression slope $m$ across $N \ge 3$ time-series samples:
     $$m = \frac{N \sum_{i=1}^{N} (t_i \cdot y_i) - \sum_{i=1}^{N} t_i \sum_{i=1}^{N} y_i}{N \sum_{i=1}^{N} t_i^2 - \left(\sum_{i=1}^{N} t_i\right)^2}$$
     Normalizes $t_i$ relative to $t_0$ (`ts = [p[0] - t0 for p in points]`) to eliminate floating-point precision loss over large Unix epoch values.
  2. Implements `load_historical_trends(db_path, telemetry, max_runs=10)`: Queries `diagnostic_runs` and `telemetry_metrics` in `kwiklog.db` for the previous $N - 1$ runs, appends the current run's live telemetry values, and returns a dictionary of `MetricTrend` dataclasses (`sample_count`, `first_value`, `latest_value`, `delta`, `slope_per_day`, `slope_per_run`, `moving_average`) alongside the historical `health_score` trajectory list.
* **How to Modify**: Add additional component/metric keys in `load_historical_trends()` to track new time-series hardware parameters.

#### `kwikdiag/rules_pop.py`
* **Role**: Deterministic Pop!_OS and Linux software remediation ruleset evaluator with strict command-injection sanitization.
* **What It Does**:
  1. Implements `sanitize_identifier(raw, fallback)` enforcing the strict allowlist regular expression `^[a-zA-Z0-9_.@-]+$` (EDD Section 8.3) on all dynamic systemd unit or package identifiers before interpolating them into CLI remediation strings.
  2. Evaluates all 8 Pop!_OS rules (`POP_PKG_001`, `POP_PKG_002`, `POP_BOOT_001`, `POP_BOOT_002`, `POP_SNAP_001`, `POP_FLAT_001`, `POP_SVC_001`, `POP_GPU_001`) and returns structured `CLI_COMMAND` prescriptions with exact verification commands (`verification_cmd`).
* **How to Modify**: Add new rule blocks inside `evaluate_pop_rules(telemetry, anomalies)` and increment `evaluated_count`. Always pass any dynamic string interpolated into `commands` through `sanitize_identifier()`.

#### `kwikdiag/rules_win.py`
* **Role**: Deterministic Windows 10/11 software and hardware diagnostic ruleset evaluator.
* **What It Does**:
  1. Evaluates all 7 Windows rules (`WIN_IMG_001`, `WIN_DSK_001`, `WIN_PWR_001`, `WIN_WHEA_01`, `WIN_MEM_001`, `WIN_WMI_001`, `WIN_NET_001`) by correlating `software_state` flags (`cbs_corrupt`, `wmi_inconsistent`, `dns_timeouts`) with `kwikparse` Windows `.evtx` Event IDs (`41`, `55`, `153`, `18`, `19`, `1001`, `10010`).
* **How to Modify**: Add new Windows rule evaluators inside `evaluate_win_rules(telemetry, anomalies)`.

#### `kwikdiag/rules_hw.py`
* **Role**: Cross-platform hardware threshold and OLS time-series degradation velocity evaluator.
* **What It Does**:
  1. Enforces `sanitize_dev_path()` (`^[a-zA-Z0-9_./\\:-]+$`) on disk device paths.
  2. Evaluates `HW_THM_001`: Triggers on static thermal transfer failure (`cpu_temp >= 80.0` while `cpu_load < 15.0`) OR progressive OLS thermal creep (`slope_per_week > 1.5` C/week over $N \ge 3$ runs with `cpu_temp >= 65.0`).
  3. Evaluates `HW_NVME_001`: Triggers when NVMe `available_spare_pct < 20%` or `percentage_used > 95%`.
  4. Evaluates `HW_NVME_002`: Triggers when SMART `media_errors > 0`, `critical_warning_byte != 0`, `not smart_passed`, or kernel `STORAGE_IO` (`blk_update_request`) errors are present, enriching `historical_context` with the OLS per-run media error slope.
  5. Evaluates `HW_MEM_002`: Triggers when swap usage exceeds `85%` while available RAM is below `5%`, or when kernel `MEMORY_OOM` events are detected.
* **How to Modify**: Add new hardware or SMART threshold checks in `evaluate_hw_rules(telemetry, anomalies, trends)`.

#### `kwikdiag/kwikdiag.py`
* **Role**: Primary Python diagnostic entrypoint orchestrating trend loading, rule matrix evaluation, health score computation, and `STDOUT` JSON serialization.
* **What It Does**:
  1. Reads the combined telemetry and log anomaly JSON payload from `STDIN` (or `--input`).
  2. Calls `load_historical_trends()`, `evaluate_pop_rules()`, `evaluate_win_rules()`, and `evaluate_hw_rules()`.
  3. Sorts triggered prescriptions by severity priority (`CRITICAL` -> `HIGH` -> `MEDIUM` -> `LOW`).
  4. Computes `overall_health_score` (`0..100`) using `SEVERITY_PENALTY` (`CRITICAL: 28`, `HIGH: 15`, `MEDIUM: 8`, `LOW: 3`) and classifies `overall_status` into `OPTIMAL`, `DEGRADED`, or `CRITICAL`.
  5. Emits the complete JSON response (`overall_health_score`, `overall_status`, `evaluated_rules_count`, `triggered_prescriptions`, `historical_trends`, `score_trajectory`) to `STDOUT`.
* **How to Modify**: Register additional domain rule modules inside `evaluate_payload()` or tune `SEVERITY_PENALTY` weights.

---

### 3.5 Presentation and Hypermedia Layer (`web/`)

#### `web/embed.go`
* **Role**: Go `embed.FS` package bundling `static/*` and `templates/*` into the compiled `kwiklogd` binary.
* **What It Does**: Declares `//go:embed static/* templates/* var EmbeddedFS embed.FS`, eliminating runtime path dependency on external web asset directories and guaranteeing single-binary portability.
* **How to Modify**: If a new asset subdirectory is created under `web/`, add its glob pattern to the `//go:embed` directive.

#### `web/static/brutalist.css`
* **Role**: Brutalist Cybercore stylesheet enforcing strict 0px border-radius geometry and terminal color tokens.
* **What It Does**: Defines CSS custom properties `--bg-primary: #0A0A0A`, `--bg-secondary: #121212`, `--text-primary: #EAEAEA`, `--accent-optimal: #00FF66`, `--accent-warning: #FFB000`, `--accent-critical: #FF0033`, and `--border-color: #2A2A2A`. Enforces `* { box-sizing: border-box; border-radius: 0 !important; }` globally and styles `.masthead`, `.split-grid`, `.data-table`, `.ascii-meter`, `.prescription-card`, `.cmd-box`, and `.sse-progress-box`.
* **How to Modify**: Add new component classes while preserving `border-radius: 0 !important` and the defined monospace typography stack.

#### `web/templates/index.html`, `web/templates/report_fragment.html`, and `web/templates/progress_sse.html`
* **Role**: Hypermedia HTML templates driving the local HTMX web interface.
* **What It Does**:
  * `index.html`: Renders the outer document shell, displays the `.privilege-banner` warning if `IsPrivileged` is false, provides the `#scan-status-slot` and `#report-viewport` swap targets, and defines `copyCommand(btn, text)` for 1-click clipboard copying of remediation commands.
  * `report_fragment.html`: Defines `report_fragment.html` and `prescriptions_partial`. Renders the top masthead with the historical run `<select>` (`hx-get="/api/runs/select"`), `[ RUN AUDIT (POST) ]` (`hx-post="/api/scan"`), `[ SIMULATE FAULT AUDIT ]` (`hx-post="/api/scan?simulate=1"`), and `[ EXPORT REPORT ]` (`hx-post="/api/export/{id}"`); the 2-column Telemetry Snapshot and Historical Degradation OLS grid; the filterable Prescribed Remediation Queue (`[ALL]`, `[SOFTWARE]`, `[HARDWARE]`, `[ACK DIRECTIVE]`, `[COPY CMD]`); and the Deduplicated Log Anomalies table.
  * `progress_sse.html`: Opens an `EventSource("/api/scan/stream?job_id=...")` connection, appends live phase messages (`[PHASE 1/3]`, `[PHASE 2/3]`, `[PHASE 3/3]`), and upon receiving `event: complete`, triggers `htmx.ajax("GET", "/api/runs/" + runId, {target: "#report-viewport", swap: "innerHTML"})`.
* **How to Modify**: Add new HTMX controls or data panels inside `report_fragment.html` and populate their corresponding fields in `Server.buildViewData()` (`cmd/kwiklogd/server.go`).

---

## 4. Data Flow and Lifecycle

The following ASCII sequence and data-flow diagram maps the complete execution lifecycle of a KwikLogPro diagnostic scan across CLI and HTMX Web modes:

```text
+--------------------------------------------------------------------------------------------------+
| OPERATOR TRIGGER                                                                                 |
|   Mode A (CLI) : ./bin/kwiklogd --cli [--simulate] [--export]                                    |
|   Mode B (Web) : Browser POST /api/scan -> Spawns Goroutine + Opens GET /api/scan/stream (SSE)   |
+--------------------------------------------------------------------------------------------------+
                                                |
                                                v
+--------------------------------------------------------------------------------------------------+
| GO ORCHESTRATOR (cmd/kwiklogd/orchestrator.go :: ExecutePipeline)                                |
|   1. CheckPrivileges() -> Verifies UID == 0 (Linux) or Admin SID (Windows)                       |
|   2. Broadcasts SSE Event: "[PHASE 1/3: SHELL PROBES]"                                           |
|   3. Creates context.WithTimeout(ctx, 30s)                                                       |
+--------------------------------------------------------------------------------------------------+
                                                |
                                                v
+--------------------------------------------------------------------------------------------------+
| STAGE 1: NATIVE OS TELEMETRY PROBE (probes/probe_pop.sh OR probes/probe_win.bat)                 |
|   - Harvests CPU temp/load, RAM/Swap bytes, lsblk/df mounts, smartctl -a -j NVMe health          |
|   - Audits systemctl failed units, dpkg --audit, dkms status, flatpak, timeshift, reboot flags   |
|   - Writes diagnostics to STDERR; emits normalized Contract 1 JSON to STDOUT                     |
+--------------------------------------------------------------------------------------------------+
                                                | (JSON over STDOUT -> Unmarshaled to TelemetryPayload)
                                                v
+--------------------------------------------------------------------------------------------------+
| STAGE 2: RUST LOG INGESTION ENGINE (bin/kwikparse)                                               |
|   1. Orchestrator broadcasts SSE Event: "[PHASE 2/3: RUST LOG PARSER]"                           |
|   2. Creates context.WithTimeout(ctx, 30s) and invokes bin/kwikparse --os <linux|windows>        |
|   3. Linux : Mmaps /var/log/{syslog,kern.log,dpkg.log} + journalctl JSON stream via Rayon        |
|   4. Win   : Mmaps System.evtx & Application.evtx -> Parses 64KB ElfChnk chunks in parallel      |
|   5. Dedup : Strips dynamic hex/sector/PID/timestamp tokens -> Computes 16-char SHA-256 hash     |
|   6. Emits Contract 2 JSON (parse_duration_ms, bytes_processed, anomalies[]) to STDOUT           |
+--------------------------------------------------------------------------------------------------+
                                                | (JSON over STDOUT -> Unmarshaled to ParserOutput)
                                                v
+--------------------------------------------------------------------------------------------------+
| STAGE 3: PYTHON DIAGNOSTIC & PRESCRIPTION ENGINE (kwikdiag/kwikdiag.py --db kwiklog.db)          |
|   1. Orchestrator broadcasts SSE Event: "[PHASE 3/3: PYTHON DIAGNOSTICS]"                        |
|   2. Pipes combined {"telemetry": ..., "log_parser": ...} JSON to kwikdiag.py over STDIN         |
|   3. trends.py : Queries SQLite telemetry_metrics for last N=10 runs -> Computes OLS slope (m)   |
|   4. Evaluates Rule Matrices:                                                                    |
|        - rules_pop.py (POP_PKG_001..002, POP_BOOT_001..002, POP_SNAP_001, POP_SVC_001, etc.)     |
|        - rules_win.py (WIN_IMG_001, WIN_DSK_001, WIN_PWR_001, WIN_WHEA_01, WIN_MEM_001, etc.)    |
|        - rules_hw.py  (HW_THM_001, HW_NVME_001..002, HW_MEM_002 + OLS velocity triggers)         |
|   5. Sanitizes all interpolated CLI identifiers against ^[a-zA-Z0-9_.@-]+$                       |
|   6. Computes overall_health_score (0..100) and overall_status (OPTIMAL / DEGRADED / CRITICAL)   |
|   7. Emits Contract 3 JSON (triggered_prescriptions[], historical_trends, score_trajectory)      |
+--------------------------------------------------------------------------------------------------+
                                                | (JSON over STDOUT -> Unmarshaled to DiagOutput)
                                                v
+--------------------------------------------------------------------------------------------------+
| STAGE 4: SQLITE3 WAL PERSISTENCE & PRESENTATION RENDER (cmd/kwiklogd/db.go & server.go)          |
|   1. DBStore.SaveDiagnosticRun() commits atomic transaction across:                              |
|        diagnostic_runs -> telemetry_metrics -> log_anomalies -> prescriptions                    |
|   2. Mode A (CLI) : Renders ANSI TrueColor Brutalist table to terminal (+ optional ./exports/)   |
|   3. Mode B (Web) : Emits SSE "event: complete\ndata: <run_id>" -> HTMX swaps #report-viewport   |
+--------------------------------------------------------------------------------------------------+
```

---

## 5. Developer Extension How-To Guides

### 5.1 How to Add a New Diagnostic Rule to `kwikdiag`

Follow these steps to add a new deterministic rule (for example, `POP_ZFS_001` detecting degraded ZFS storage pools):

1. **Extend the Telemetry Probe (`probes/probe_pop.sh`)**:
   Collect the raw metric in Bash and pass it into the Python JSON serializer:
   ```bash
   ZFS_DEGRADED=0
   if command -v zpool >/dev/null 2>&1; then
       if zpool status -x 2>/dev/null | grep -qv "all pools are healthy"; then
           ZFS_DEGRADED=1
       fi
   fi
   export ZFS_DEGRADED
   ```
   Inside the inline Python dictionary in `probes/probe_pop.sh`, add `"zfs_degraded": os.environ.get("ZFS_DEGRADED", "0") == "1"` under `"software_state"`.

2. **Add the Rule Evaluation Logic (`kwikdiag/rules_pop.py`)**:
   Open `/home/auxk0rd/Desktop/KwikLogPro/kwikdiag/rules_pop.py` and append the evaluation block inside `evaluate_pop_rules(telemetry, anomalies)`:
   ```python
   # 9. POP_ZFS_001: Degraded ZFS Pool State
   evaluated_count += 1
   if sw.get("zfs_degraded", False):
       prescriptions.append({
           "rule_id": "POP_ZFS_001",
           "severity": "CRITICAL",
           "domain": "HARDWARE",
           "title": "ZFS Storage Pool Degraded or Faulted VDEV Detected",
           "finding_summary": "zpool status reported one or more degraded or faulted ZFS virtual devices.",
           "historical_context": "First detected in current run.",
           "remediation_type": "CLI_COMMAND",
           "commands": [
               "sudo zpool status -v",
               "sudo zpool scrub rpool",
           ],
           "verification_cmd": "zpool status -x",
           "risk_level": "CRITICAL_HARDWARE",
       })
   ```

3. **Register a Unit Test (`kwikdiag/test_kwikdiag.py`)**:
   Add `"zfs_degraded": True` to the test fixture in `kwikdiag/test_kwikdiag.py` and assert `"POP_ZFS_001" in rule_ids`. Run `./dev.sh test` to verify.

### 5.2 How to Add a New Log Anomaly Pattern to Rust `kwikparse`

1. Open `/home/auxk0rd/Desktop/KwikLogPro/kwikparse/src/linux_logs.rs`.
2. Locate `get_patterns()` and append a new `RulePattern` entry to the `OnceLock<Vec<RulePattern>>` initializer:
   ```rust
   RulePattern {
       regex: Regex::new(r"(?i)(pcieport.*AER:.*Uncorrected|PCIe Bus Error: severity=Uncorrected)").unwrap(),
       source: "kernel",
       severity: "CRITICAL",
       category: "PCIE_BUS",
   },
   ```
3. Recompile the Rust binary and run unit tests:
   ```bash
   cd /home/auxk0rd/Desktop/KwikLogPro && make build-rust && cd kwikparse && cargo test --offline
   ```

### 5.3 How to Track a New Time-Series Metric with OLS Linear Regression

1. **Persist the Flattened Metric in Go (`cmd/kwiklogd/db.go`)**:
   Inside `DBStore.SaveDiagnosticRun()`, call `insertMetric("<COMPONENT>", "<METRIC_NAME>", floatValue)`:
   ```go
   if err := insertMetric("CPU", "load_percent", hw.CPULoadPercent); err != nil {
       return 0, err
   }
   ```
2. **Compute the Historical Trend in Python (`kwikdiag/trends.py`)**:
   Inside `load_historical_trends()`, compute the `MetricTrend` object using `compute_metric_trend()`:
   ```python
   cpu_load = float(hw.get("cpu_load_percent", 0.0))
   trends["CPU:load_percent"] = compute_metric_trend(
       raw_history.get(("CPU", "load_percent"), []),
       now_ts,
       cpu_load,
       "CPU",
       "load_percent",
   )
   ```
3. **Evaluate or Display the Slope**:
   Access `trends.get("CPU:load_percent").slope_per_day` in `kwikdiag/rules_hw.py` or `bundle.Diag.HistoricalTrends["CPU:load_percent"]` in `cmd/kwiklogd/server.go`.

---

## 6. System Architecture and Design Protocols

### 6.1 Polyglot Partitioning Protocol
KwikLog enforces strict runtime responsibility boundaries across its four execution tiers:
* **Go (`kwiklogd`)** handles process supervision, context timeouts, SQLite3 WAL transactions, CLI formatting, and HTTP/SSE concurrency.
* **Shell (`probe_pop.sh`, `probe_win.bat`)** executes direct OS utility introspection without intermediate daemon overhead.
* **Rust (`kwikparse`)** executes CPU-bound and I/O-bound log scanning using zero-cost abstractions, `memmap2` virtual memory mapping, and Rayon data parallelism.
* **Python (`kwikdiag.py`)** executes mathematical OLS regression and declarative rule matrix evaluation using only the Python 3.10+ standard library (`sqlite3`, `json`, `statistics`, `dataclasses`, `re`), ensuring zero external PyPI/pip dependencies in air-gapped environments.

### 6.2 Ordinary Least Squares (OLS) Degradation Protocol
Static threshold monitoring fails to warn operators of gradual hardware decay (such as thermal paste pump-out or slow NAND flash wear) until catastrophic failure occurs. KwikLog's `trends.py` normalizes historical run timestamps into relative epoch days ($t_i - t_0$) and computes the ordinary least squares slope $m$. Even when CPU temperature is below the $80.0^\circ\text{C}$ static ceiling, `HW_THM_001` triggers a proactive warning if $m \times 7 > 1.5^\circ\text{C}/\text{week}$ across $N \ge 3$ runs while temperature exceeds $65.0^\circ\text{C}$.

### 6.3 Security, Privilege, and Safety Guardrails
1. **Read-Only Audit Guarantee**: KwikLog never executes state-mutating or destructive remediation commands (`apt-get`, `dpkg --configure`, `rm`, `dism`, `sfc`, `chkdsk`) automatically. It synthesizes deterministic prescriptions for operator review and explicit execution.
2. **Degraded Unprivileged Fallback**: When launched by a non-root user (`UID != 0` on Linux or non-Administrator SID on Windows), `kwiklogd` and the OS probes log a warning banner and automatically bypass restricted raw device `ioctl` calls rather than crashing.
3. **Allowlist Command Injection Prevention**: Every dynamic identifier extracted from system state (such as failed systemd unit names or disk device nodes) is validated against strict regular expression allowlists (`^[a-zA-Z0-9_.@-]+$` in `rules_pop.py` and `^[a-zA-Z0-9_./\\:-]+$` in `rules_hw.py`) before interpolation into remediation command strings.
4. **Loopback-Only Network Binding**: The Go HTTP server binds exclusively to `127.0.0.1` (`localhost`), preventing LAN exposure of host diagnostic telemetry.

---

## 7. Recent Enhancements and Critical Bug Fixes

### 7.1 LVM/LUKS Mapper Root Mount Resolution in `probe_pop.sh`
* **Problem**: On Pop!_OS workstations configured with full-disk LUKS encryption and LVM (`/dev/mapper/data-root`), matching `df -B1` mount sources strictly by prefix against `/dev/nvme0n1` omitted the root `/` filesystem mount from the disk's `mount_points` array, leaving only `/boot/efi` and `/recovery`.
* **Solution**: Updated the mount-point attribution logic in `/home/auxk0rd/Desktop/KwikLogPro/probes/probe_pop.sh` to associate `/dev/mapper/*` block sources with the primary physical NVMe/block device alongside direct partition children.
* **Impact**: Root (`/`) partition utilization is now accurately captured, displayed in the Telemetry Snapshot table, and evaluated by `POP_BOOT_001`.

### 7.2 Advisory Lock False-Positive Elimination for `POP_PKG_002`
* **Problem**: On Debian, Ubuntu, and Pop!_OS systems, `/var/lib/dpkg/lock-frontend` and `/var/lib/apt/lists/lock` persist as 0-byte files on disk after normal `apt` transactions complete because POSIX `fcntl` advisory locks do not unlink lock files upon process exit. Checking file existence combined with unprivileged `fuser` checks caused false-positive `POP_PKG_002` alerts on healthy systems.
* **Solution**: Refactored stale lock detection in `/home/auxk0rd/Desktop/KwikLogPro/probes/probe_pop.sh` to inspect `/var/lib/dpkg/updates/` for uncommitted numeric transaction journal files (`[0-9]+`) while verifying via `pgrep -x "apt|apt-get|dpkg|unattended-upgr"` that no package manager process is currently active.
* **Impact**: Eliminated false-positive `POP_PKG_002` triggers during unprivileged runs while preserving true interrupted dpkg transaction detection.

### 7.3 DPKG State Transition Log Filtering and Signature Truncation in `kwikparse`
* **Problem**: Normal package installations write routine transient state lines (`status unpacked`, `status half-configured`, `status installed`) to `/var/log/dpkg.log`. Matching `status half-configured` in `kwikparse/src/linux_logs.rs` flagged hundreds of historical normal package upgrades as active dpkg errors, and ISO-8601 timestamps with local timezone offsets (`-04:00`) were not stripped during deduplication.
* **Solution**: Refined the `PACKAGE_MANAGER` regex in `kwikparse/src/linux_logs.rs` to match genuine failure signatures (`dpkg: error processing`, `Sub-process /usr/bin/dpkg returned an error code`, `dependency problems - leaving unconfigured`), updated `DYNAMIC_TOKEN_RE` in `kwikparse/src/dedup.rs` to normalize timezone-offset timestamps (`(?:Z|[+-]\d{2}:\d{2})?`), and capped the deduplicated output slice to the top 50 highest-frequency signatures.
* **Impact**: Reduced live log scan duration on 6.02 MB of system logs to 38ms, eliminated benign dpkg upgrade noise, and raised the live host baseline health score to an accurate `92 / 100`.

### 7.4 Root Elevation (`sudo`) Cargo and Go Cache Resolution in `dev.sh` and `Makefile`
* **Problem**: Executing `sudo ./dev.sh` resets `$HOME` to `/root`, causing `cargo build --release --offline` and `go build` to look for cached crates and Go modules inside `/root/.cargo` and `/root/go` rather than the invoking operator's cache (`/home/auxk0rd/.cargo` and `/home/auxk0rd/go`), resulting in `error: no matching package named memmap2 found`.
* **Solution**: Updated both `dev.sh` and `Makefile` to resolve `REAL_USER` from `SUDO_USER` (via `getent passwd`) and explicitly export `CARGO_HOME`, `RUSTUP_HOME`, `GOPATH`, `GOMODCACHE`, `GOCACHE`, and `PATH` pointing to the operator's home directory, while restoring file ownership on `bin/` and `kwikparse/target/` when compiled under `sudo`.
* **Impact**: Running `sudo ./dev.sh` (for full privileged SMART and kernel log access) now resolves offline Rust crates and Go modules seamlessly without cache misses or root-owned build artifact lockouts.

### 7.5 Defense-Grade Security, Compliance, and Cryptographic Enclave Upgrade
* **CMMC 2.0, FIPS 140-3 & DISA STIG Attestation (`cmd/kwiklogd/security.go`, `kwikparse/src/main.rs`)**: Added `GOFIPS=1 GODEBUG=fips140=on` compilation flags, Rust FIPS 140-3 SHA-256 Known-Answer Self-Test (`fips_140_3_sha256_kat`), AES-256-GCM enclave encryption (`EncryptAESGCM`/`DecryptAESGCM`), and dynamic Ed25519 cryptographic signing (`GetOrCreateEd25519Identity`/`SignPayloadEd25519`) for `GET /api/compliance/cmmc` and `GET /api/compliance/stig`.
* **CWE Hardening Matrix (`CWE-22`, `CWE-114`, `CWE-346`, `CWE-377`, `CWE-400`, `CWE-1333`)**: Enforced multi-stage relative path sanitization (`SanitizeRelativePath`, `SafeResolveUnder`), loopback-only `Host`/`Origin` validation (`SecurityMiddleware`), 64KB request body ceiling (`MaxRequestBodyBytes`), `0600` SQLite WAL database permissions, and symlink-safe `~/.cache/kwiklogpro` logging (`umask 077`, `APP_PID` trap management) in `dev.sh`.
* **IEEE 802.3 / 802.11w Network Sensing, STIX 2.1 / TAXII 2.1 & CISA SBOMs**: Added `GET /api/network-sense`, `GET /api/export/stix`, `GET /api/export/taxii`, and `GET /api/sbom` alongside automated CycloneDX 1.5 (`SBOM.cyclonedx.json`), SPDX 2.3 (`SBOM.spdx.json`), and CISA (`SBOM.md`) manifests and the `SYS.01 // NOCTURNAL SYNTH-LEDGER` UI stylesheet (`web/static/synth-ledger.css`).

### 7.6 `CN-DIR-2026-004` Dual-Native Orchestration Architecture (Bi-Launcher Specification)
* **Dual-Native Launchers (`dev.sh` / `dev.bat` & `launcher.sh` / `launcher.bat`)**: Added native Windows 10/11 Batch orchestration (`dev.bat` and `launcher.bat`) and standardized POSIX wrapper (`launcher.sh`) implementing 100% of the Universal Command Parity Contract (`setup`, `build`, `run`/`serve`, `cli`, `simulate`, `test`, `fmt`).
* **Windows Native `.exe` Compilation & Elevation Guardrails**: `dev.bat` compiles `bin\kwiklogd.exe` (`GOFIPS=1`, `GODEBUG=fips140=on`) and `bin\kwikparse.exe` (`cargo build --release`), preserves user-scoped Cargo/Go caches (`CARGO_HOME`, `RUSTUP_HOME`, `GOPATH`, `GOMODCACHE`, `GOCACHE`) when elevated to Administrator (`System32` fallback resolution), enforces `CWE-377` via `cd /d "%~dp0"`, strict `icacls` ACLs (`%USERNAME%:(OI)(CI)F`) on `%LOCALAPPDATA%\kwiklogpro`, and `fsutil reparsepoint query` symlink/junction rejection on `session.log`, and enforces `CWE-114` via explicit `APP_PID` capture and `taskkill /PID !APP_PID! /T /F` termination.

---

## 8. Maintenance and Operational Commands (`CN-DIR-2026-004` Parity Contract)

| Subcommand | Linux / Pop!_OS (`./dev.sh` or `./launcher.sh`) | Windows 10/11 (`.\dev.bat` or `.\launcher.bat`) | Description |
| :--- | :--- | :--- | :--- |
| `setup` | `./dev.sh setup` | `.\dev.bat setup` | Verify `go`, `cargo`, `python` toolchains and OS probes (`probe_pop.sh` / `probe_win.bat`). |
| `build` | `./dev.sh build` | `.\dev.bat build` | Compile `bin/kwiklogd[.exe]` (`GOFIPS=1`) and `bin/kwikparse[.exe]` + generate CISA SBOMs. |
| `run` / `serve` | `./dev.sh serve` | `.\dev.bat serve` | Start local HTMX Web Server on `http://127.0.0.1:8484` with `CWE-114` PID tracking. |
| `cli` | `./dev.sh cli` | `.\dev.bat cli` | Run live host diagnostic audit and render Brutalist CLI report table. |
| `simulate` | `./dev.sh simulate` | `.\dev.bat simulate` | Run simulated hardware/software fault audit and export Markdown/HTML reports to `./exports/`. |
| `test` | `./dev.sh test` | `.\dev.bat test` | Execute full polyglot automated test suite (Go + Rust + Python unittest). |
| `fmt` | `./dev.sh fmt` | `.\dev.bat fmt` | Format all Go (`go fmt ./...`) and Rust (`cargo fmt`) source files. |

All commands below must be executed from the standalone project root:

```bash
# 1. Verify polyglot toolchain versions and script executable bits
./dev.sh setup        # Windows: .\dev.bat setup

# 2. Compile both release binaries (bin/kwikparse[.exe] in Rust and bin/kwiklogd[.exe] in Go)
./dev.sh build        # Windows: .\dev.bat build (or make build on Linux)

# 3. Execute the full polyglot automated test suite (Rust cargo test + Python unittest + Go test)
./dev.sh test         # Windows: .\dev.bat test

# 4. Run a live host diagnostic audit and render the Brutalist CLI report table
./dev.sh cli          # Windows: .\dev.bat cli

# 5. Run a simulated hardware/software fault audit and export standalone Markdown/HTML reports
./dev.sh simulate     # Windows: .\dev.bat simulate

# 6. Start the local Brutalist HTMX Web Server on http://127.0.0.1:8484
./dev.sh serve        # Windows: .\dev.bat serve

# 7. Assemble a self-contained, air-gapped release distribution in dist/kwiklogpro/
make bundle

# 8. Format all Go and Rust source files
./dev.sh fmt          # Windows: .\dev.bat fmt

# 9. Clean compiled binaries, distribution bundles, and reset the local SQLite3 WAL database
make clean
```

---

**Official Engineering Sign-Off**  
**Prepared and Authorized By**: Auxk0rd  
**Role**: Principal Software Architect  
**Project**: KwikLogPro (`KwikLog`) Standalone Diagnostic and Remediation System
