# KwikLogPro: Production Engineering Design Document & Project Pitch

**Document Version:** 1.0.0-PROD  
**Target Environments:** Pop!_OS (22.04 LTS / 24.04 LTS w/ COSMIC) & Windows (10 / 11 Pro & Enterprise)  
**Architecture Paradigm:** Local-First, Air-Gapped Polyglot Pipeline  
**UI Standard:** Brutalist Cybercore (HTMX, Zero-JS Framework, 0px Border-Radius)

---

## 1. Executive Summary & Project Pitch

### 1.1 Problem Statement
Modern system diagnostics across heterogeneous environments (Linux and Windows) are severely fragmented. Administrators and power users rely on disparate tools—`journalctl`, `smartctl`, `dmesg`, Windows Event Viewer, WMI, and PerfMon—to manually correlate hardware telemetry with software failures. Furthermore, existing commercial monitoring solutions frequently require cloud connectivity, introduce heavy background resource overhead, and stop at *reporting* metrics rather than *prescribing* deterministic fixes.

### 1.2 The KwikLogPro Solution
**KwikLogPro** is a cross-platform, air-gapped system health auditor and remediation engine designed specifically for Pop!_OS and Windows workstations. By unifying a polyglot stack (**Go, Rust, Python, Shell, SQLite, and HTMX**), KwikLogPro executes deep hardware and software telemetry sweeps, parses gigabytes of system logs in milliseconds, and evaluates system state against a deterministic diagnostic ruleset.

Instead of presenting raw, uncontextualized logs, KwikLogPro tracks systemic degradation over time via a local time-series SQLite database and outputs a stark, actionable report:
1. **Software Remediation:** Exact, copy-ready terminal commands (`apt`, `flatpak`, `dism`, `sfc`, `systemctl`) to resolve package corruption, failed daemons, or kernel anomalies.
2. **Hardware Interventions:** Concrete physical maintenance directives (e.g., thermal repasting, NVMe replacement based on SMART critical warnings, DIMM reseating) triggered by hardware telemetry thresholds.

### 1.3 Core Value Propositions
* **100% Air-Gapped & Local-First:** Zero external telemetry, zero cloud dependencies, and zero SaaS subscriptions. Runs entirely from a standalone directory.
* **Polyglot Performance:** Uses the exact right tool for each phase—Go for concurrency and HTTP routing, Rust for zero-cost abstraction log parsing, Shell for native OS probing, and Python for flexible rule evaluation.
* **Historical Degradation Tracking:** Identifies slow-burn hardware failures (e.g., creeping NVMe media errors or gradual thermal paste pump-out) by comparing current snapshots against historical runs stored in SQLite WAL mode.
* **Brutalist Utilitarian Interface:** Dual-mode output featuring a high-contrast CLI reporter and a zero-bloat local HTMX web interface with strict 0px border-radius geometry.

---

## 2. System Architecture & Polyglot Stack

### 2.1 High-Level Data Flow

```
+-------------------------------------------------------------------------+
|                        GO ORCHESTRATOR (kwiklogd)                       |
|      [OS Detection] -> [Process Supervisor] -> [HTMX HTTP Server]       |
+-------------------------------------------------------------------------+
       |                              |                              |
       v (1. Spawn Probes)            v (2. Stream Raw Logs)         v (3. Evaluate)
+--------------+              +---------------+              +----------------+
| SHELL PROBES |              |  RUST PARSER  |              | PYTHON ENGINE  |
| - Bash (Pop) |              |  (kwikparse)  |              |  (kwikdiag.py) |
| - BAT/PS1    |              | - Mmap I/O    |              | - Rule Matrix  |
|   (Windows)  |              | - SIMD Regex  |              | - Trend Calc   |
+--------------+              +---------------+              +----------------+
       |                              |                              |
       +------------------------------+------------------------------+
                                      | (JSON over Stdout / Named Pipes)
                                      v
+-------------------------------------------------------------------------+
|                       SQLITE3 DATABASE (WAL Mode)                       |
|          [runs]  <--  [telemetry_metrics]  <--  [prescriptions]         |
+-------------------------------------------------------------------------+
```

### 2.2 Component Specifications

#### 2.2.1 Go: Core Orchestrator & Web Server (`kwiklogd`)
* **Role:** Application entry point, lifecycle manager, subprocess supervisor, database writer, and local HTTP server.
* **Key Packages:** `os/exec`, `embed` (bundles static assets and scripts), `database/sql` with `modernc.org/sqlite` (CGO-free SQLite driver for clean cross-compilation), `net/http`.
* **Responsibilities:**
  * Detects host OS (`runtime.GOOS`) and privilege elevation status (Root UID `0` on Linux, Administrator SID `S-1-5-32-544` on Windows).
  * Manages worker pools with strict `context.WithTimeout` boundaries (default: 30 seconds per probe) so hung system utilities (e.g., a blocked `smartctl` call on a dying disk) do not freeze the pipeline.
  * Serves the HTMX frontend on `127.0.0.1:8484` and handles Server-Sent Events (SSE) for real-time scan progress telemetry.

#### 2.2.2 Shell: Native OS Telemetry Probes (`probes/`)
* **Role:** Lightweight, native execution of OS-specific system utilities. Outputs strictly formatted JSON blocks or delimiter-separated key-value pairs to `stdout`.
* **Pop!_OS (`probe_pop.sh`):**
  * **Storage:** `smartctl -a -j /dev/nvme0n1`, `df -B1 --output=source,size,used,avail,pcent,target`.
  * **Snapshots & Packages:** `timeshift --list`, `dpkg --audit`, `apt-mark showhold`, `flatpak repair --dry-run`.
  * **Services & Kernel:** `systemctl list-units --state=failed --output=json`, `dkms status`, `system76-power profile`, `kernelstub -p`.
  * **Thermals & Memory:** `/sys/class/thermal/thermal_zone*/temp`, `free -b`, `vmstat 1 2`, `swapon --show=NAME,SIZE,USED --bytes`.
* **Windows (`probe_win.bat` / PowerShell Core wrapper):**
  * **Storage:** `Get-PhysicalDisk | Get-StorageReliabilityCounter | ConvertTo-Json`, `Get-Volume | ConvertTo-Json`.
  * **System Integrity:** Parses `C:\Windows\Logs\CBS\CBS.log` tail, checks pending reboot flags in Registry (`Component Based Servicing\RebootPending`), queries `Get-HotFix`.
  * **Hardware & Thermals:** Queries CIM/WMI classes `Win32_Processor`, `Win32_OperatingSystem`, `Win32_PageFileUsage`, and `MSAcpi_ThermalZoneTemperature`.
  * **Services:** `Get-Service | Where-Object {$_.Status -eq 'Stopped' -and $_.StartType -eq 'Automatic'} | Select-Object Name, DisplayName, Status | ConvertTo-Json`.

#### 2.2.3 Rust: High-Speed Log Ingestion Engine (`kwikparse`)
* **Role:** Multi-threaded, memory-mapped ingestion and deduplication of massive binary and plaintext system logs.
* **Key Crates:** `memmap2`, `rayon`, `regex`, `serde`, `serde_json`, `evtx` (for native cross-platform Windows `.evtx` binary parsing), `chrono`.
* **Responsibilities:**
  * **Pop!_OS:** Ingests `/var/log/syslog`, `/var/log/kern.log`, and output streams from `journalctl -p 0..3 -b --output=json`. Extracts OOM-killer invocations (`Out of memory: Killed process`), Segfaults, I/O buffer errors (`blk_update_request: I/O error`), and NVIDIA/AMD GPU ring timeouts (`NVRM: Xid` or `amdgpu: ring gfx timeout`).
  * **Windows:** Directly parses `C:\Windows\System32\winevt\Logs\System.evtx` and `Application.evtx` using the `evtx` crate without relying on slow PowerShell `Get-WinEvent` COM interop. Filters for Critical/Error Event IDs (e.g., Event ID 41 `Kernel-Power`, Event ID 153 `disk`, Event ID 1001 `BugCheck`, Event ID 18/19 `WHEA-Logger`).
  * **Deduplication:** Hashes log message signatures (stripping dynamic timestamps and PIDs) and groups identical recurring errors into frequency buckets (`signature_hash`, `first_seen`, `last_seen`, `occurrence_count`, `sample_payload`) to prevent log storms from bloating downstream analysis.

#### 2.2.4 Python: Diagnostic Logic & Prescription Engine (`kwikdiag`)
* **Role:** Deterministic rule evaluation, historical trend calculation, and prescription synthesis.
* **Runtime Requirements:** Python 3.10+ (utilizing standard library `sqlite3`, `json`, `statistics`, `dataclasses`, and `typing`—zero external PyPI dependencies required for air-gapped portability).
* **Responsibilities:**
  * Reads the normalized JSON payload combining the Shell probe telemetry and Rust log anomalies.
  * Queries the local SQLite database for the last $N$ historical runs (default $N = 10$) to calculate rate-of-change deltas ($\Delta$) and moving averages for key hardware metrics (e.g., NVMe spare capacity depletion rate, idle CPU temperature creep, swap thrashing frequency).
  * Evaluates metrics against the **Diagnostic Rule Matrix** (Section 5) to classify system health into `OPTIMAL`, `DEGRADED`, or `CRITICAL`.
  * Outputs structured remediation objects containing both exact CLI fix strings (for software issues) and physical intervention checklists (for hardware issues).

#### 2.2.5 SQLite3 (WAL Mode): Local Time-Series Persistence
* **Role:** Single-file, zero-configuration relational and time-series data store (`kwiklog.db`).
* **Configuration:** Initialized with `PRAGMA journal_mode=WAL;`, `PRAGMA synchronous=NORMAL;`, `PRAGMA foreign_keys=ON;`, and `PRAGMA busy_timeout=5000;`.
* **Responsibilities:** Ensures concurrent read/write performance so the Go HTTP server can query historical trends for the HTMX UI while a diagnostic scan is actively writing new telemetry rows.

#### 2.2.6 HTMX + Brutalist CSS: Local Web Frontend
* **Role:** Zero-bloat, high-contrast visual dashboard and interactive report viewer.
* **Design Tokens:**
  * Background Primary: `#0A0A0A` (Void Black)
  * Background Secondary: `#121212` (Panel Carbon)
  * Text Primary: `#EAEAEA` (Stark White)
  * Accent Optimal: `#00FF66` (Terminal Green)
  * Accent Warning: `#FFB000` (Amber Phosphor)
  * Accent Critical: `#FF0033` (Crimson Alert)
  * Border Geometry: `1px solid #2A2A2A`, `border-radius: 0px` globally enforced (`* { border-radius: 0 !important; }`).
  * Typography: Monospace stack (`'JetBrains Mono', 'Fira Code', 'Consolas', monospace`).
* **Interactivity:** Uses HTMX attributes (`hx-get`, `hx-post`, `hx-swap="outerHTML"`, `hx-ext="sse"`) to trigger live scans, filter severity levels, compare historical run diffs, and copy remediation commands to the clipboard without any client-side React/Vue/Angular bundle.

---

## 3. Inter-Process Communication (IPC) & Data Contracts

All subprocess communication is orchestrated by `kwiklogd` via standard streams (`stdin`/`stdout`/`stderr`) using strict JSON schemas. Subprocesses must never write unstructured text to `stdout`; all debug logging goes to `stderr`.

### 3.1 Shell Probe Output Schema (`probe_pop.sh` / `probe_win.bat` -> Go)

```json
{
  "schema_version": "1.0",
  "timestamp_utc": "2026-10-27T04:15:00Z",
  "os_family": "linux",
  "os_distro": "Pop!_OS 24.04 LTS",
  "kernel_version": "6.9.3-76060903-generic",
  "uptime_seconds": 432190,
  "hardware": {
    "cpu_model": "AMD Ryzen 9 7950X",
    "cpu_temp_celsius": 88.5,
    "cpu_load_percent": 14.2,
    "ram_total_bytes": 68719476736,
    "ram_avail_bytes": 4294967296,
    "swap_total_bytes": 17179869184,
    "swap_used_bytes": 15032385536,
    "disks": [
      {
        "device": "/dev/nvme0n1",
        "model": "Samsung SSD 990 PRO 2TB",
        "smart_passed": true,
        "critical_warning_byte": 0,
        "temp_celsius": 64,
        "available_spare_pct": 98,
        "percentage_used": 12,
        "media_errors": 4,
        "unsafe_shutdowns": 19,
        "mount_points": [
          {
            "path": "/",
            "fs_type": "ext4",
            "used_pct": 94.2
          }
        ]
      }
    ]
  },
  "software_state": {
    "failed_services": ["networking.service", "fwupd.service"],
    "broken_packages_count": 3,
    "held_packages": ["linux-image-generic"],
    "timeshift_status": {
      "installed": true,
      "snapshot_count": 0,
      "last_snapshot_epoch": null
    },
    "pending_reboot": true
  }
}
```

### 3.2 Rust Log Parser Output Schema (`kwikparse` -> Go)

```json
{
  "parse_duration_ms": 142,
  "bytes_processed": 1073741824,
  "total_events_scanned": 845920,
  "anomalies": [
    {
      "signature_hash": "a94a8fe5ccb19ba6",
      "source": "kernel",
      "event_id": null,
      "severity": "CRITICAL",
      "category": "STORAGE_IO",
      "first_seen_utc": "2026-10-25T11:20:01Z",
      "last_seen_utc": "2026-10-27T03:59:12Z",
      "occurrence_count": 47,
      "sample_message": "blk_update_request: I/O error, dev nvme0n1, sector 89234112 op 0x0:(READ)"
    },
    {
      "signature_hash": "e3b0c44298fc1c14",
      "source": "Microsoft-Windows-Kernel-PnP",
      "event_id": 41,
      "severity": "CRITICAL",
      "category": "POWER_KERNEL",
      "first_seen_utc": "2026-10-26T22:14:00Z",
      "last_seen_utc": "2026-10-26T22:14:00Z",
      "occurrence_count": 1,
      "sample_message": "The system has rebooted without cleanly shutting down first."
    }
  ]
}
```

### 3.3 Python Diagnostic Engine Output Schema (`kwikdiag` -> Go)

```json
{
  "overall_health_score": 42,
  "overall_status": "CRITICAL",
  "evaluated_rules_count": 38,
  "triggered_prescriptions": [
    {
      "rule_id": "POP_PKG_001",
      "severity": "HIGH",
      "domain": "SOFTWARE",
      "title": "Interrupted DPKG & Broken APT Dependencies Detected",
      "finding_summary": "3 packages are in an unconfigured or half-installed state, blocking system updates.",
      "historical_context": "First detected in current run.",
      "remediation_type": "CLI_COMMAND",
      "commands": [
        "sudo dpkg --configure -a",
        "sudo apt-get update && sudo apt-get install -f -y"
      ],
      "verification_cmd": "sudo dpkg --audit",
      "risk_level": "SAFE"
    },
    {
      "rule_id": "HW_NVME_002",
      "severity": "CRITICAL",
      "domain": "HARDWARE",
      "title": "NVMe Media Integrity Errors & Kernel Read Failures",
      "finding_summary": "Device /dev/nvme0n1 reported 4 SMART media_errors and 47 blk_update_request I/O errors in kernel logs.",
      "historical_context": "Media errors increased by +4 over the last 3 runs (Slope: +1.33/run).",
      "remediation_type": "PHYSICAL_INTERVENTION",
      "physical_steps": [
        "IMMEDIATE ACTION: Back up critical data from /dev/nvme0n1 to external media.",
        "Power down workstation, discharge residual flea power, and inspect M.2 slot for thermal pad oil bleed or loose mounting screw.",
        "Replace NVMe module; non-zero media_errors coupled with kernel blk_update_request failures indicate irreversible NAND flash degradation."
      ],
      "risk_level": "CRITICAL_HARDWARE"
    }
  ]
}
```

---

## 4. Database Schema & Time-Series Degradation Model

### 4.1 SQLite3 DDL (`schema.sql`)

```sql
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;

-- 1. Master table for each diagnostic execution
CREATE TABLE IF NOT EXISTS diagnostic_runs (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp_utc TEXT NOT NULL,
    os_family TEXT NOT NULL CHECK(os_family IN ('linux', 'windows')),
    os_distro TEXT NOT NULL,
    kernel_version TEXT NOT NULL,
    health_score INTEGER NOT NULL CHECK(health_score BETWEEN 0 AND 100),
    overall_status TEXT NOT NULL CHECK(overall_status IN ('OPTIMAL', 'DEGRADED', 'CRITICAL')),
    scan_duration_ms INTEGER NOT NULL,
    raw_telemetry_json TEXT NOT NULL
);

CREATE INDEX idx_runs_timestamp ON diagnostic_runs(timestamp_utc DESC);

-- 2. Flattened numerical metrics for fast time-series trend queries
CREATE TABLE IF NOT EXISTS telemetry_metrics (
    metric_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    component_type TEXT NOT NULL, -- e.g., 'CPU', 'RAM', 'SWAP', 'DISK:/dev/nvme0n1'
    metric_name TEXT NOT NULL,    -- e.g., 'temp_celsius', 'media_errors', 'used_pct'
    metric_value REAL NOT NULL,
    FOREIGN KEY (run_id) REFERENCES diagnostic_runs(run_id) ON DELETE CASCADE
);

CREATE INDEX idx_metrics_lookup ON telemetry_metrics(component_type, metric_name, run_id);

-- 3. Deduplicated log anomalies captured by Rust kwikparse
CREATE TABLE IF NOT EXISTS log_anomalies (
    anomaly_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    signature_hash TEXT NOT NULL,
    source TEXT NOT NULL,
    event_id INTEGER,
    severity TEXT NOT NULL,
    category TEXT NOT NULL,
    first_seen_utc TEXT NOT NULL,
    last_seen_utc TEXT NOT NULL,
    occurrence_count INTEGER NOT NULL,
    sample_message TEXT NOT NULL,
    FOREIGN KEY (run_id) REFERENCES diagnostic_runs(run_id) ON DELETE CASCADE
);

CREATE INDEX idx_anomalies_hash ON log_anomalies(signature_hash);

-- 4. Generated software commands and hardware interventions
CREATE TABLE IF NOT EXISTS prescriptions (
    prescription_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    rule_id TEXT NOT NULL,
    severity TEXT NOT NULL CHECK(severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    domain TEXT NOT NULL CHECK(domain IN ('SOFTWARE', 'HARDWARE')),
    title TEXT NOT NULL,
    finding_summary TEXT NOT NULL,
    historical_context TEXT,
    remediation_type TEXT NOT NULL CHECK(remediation_type IN ('CLI_COMMAND', 'PHYSICAL_INTERVENTION')),
    action_payload_json TEXT NOT NULL, -- JSON array of commands or physical steps
    verification_cmd TEXT,
    acknowledged INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (run_id) REFERENCES diagnostic_runs(run_id) ON DELETE CASCADE
);
```

### 4.2 Time-Series Degradation Math (`kwikdiag`)
To detect progressive hardware degradation before catastrophic failure occurs, `kwikdiag` computes the ordinary least squares (OLS) linear regression slope $m$ for continuous hardware metrics across the last $N$ runs ($N \ge 3$):

$$m = \frac{N \sum_{i=1}^{N} (t_i \cdot y_i) - \sum_{i=1}^{N} t_i \sum_{i=1}^{N} y_i}{N \sum_{i=1}^{N} t_i^2 - \left(\sum_{i=1}^{N} t_i\right)^2}$$

Where:
* $t_i$ is the normalized epoch timestamp (in days) of diagnostic run $i$.
* $y_i$ is the recorded metric value (e.g., CPU idle temperature normalized by load, or NVMe `percentage_used`).

**Trigger Condition:** Even if a current metric $y_N$ has not yet breached its static absolute ceiling, a warning prescription is triggered if $m$ exceeds a defined velocity threshold (e.g., CPU normalized temperature rising by $> 1.5^\circ\text{C}$ per week, indicating heatsink dust accumulation or thermal paste degradation).

---

## 5. Comprehensive Diagnostic & Remediation Matrix

### 5.1 Pop!_OS (Linux) Ruleset

| Rule ID | Target Telemetry / Log Trigger | Condition | Prescribed Remediation (CLI / Physical) |
| :--- | :--- | :--- | :--- |
| **`POP_PKG_001`** | `dpkg --audit` or `apt-get check` | Non-empty output / exit code $\neq 0$ | `sudo dpkg --configure -a && sudo apt-get install -f -y` |
| **`POP_PKG_002`** | `/var/lib/apt/lists/lock` or `dpkg/lock-frontend` | Lock held with no active `apt`/`dpkg` PID | `sudo rm -f /var/lib/dpkg/lock-frontend /var/lib/apt/lists/lock && sudo dpkg --configure -a` |
| **`POP_BOOT_001`** | `/boot/efi` or `/recovery` mount usage | `used_pct` $\ge 90\%$ | `sudo apt-get autoremove --purge -y && sudo kernelstub -v` |
| **`POP_BOOT_002`** | `dkms status` | Contains `broken`, `added` (not `installed` for running kernel) | `sudo dkms autoinstall -k $(uname -r) && sudo update-initramfs -u -k all` |
| **`POP_SNAP_001`** | `timeshift --list` | `snapshot_count == 0` or `last_snapshot` $> 30$ days | `sudo timeshift --create --comments "KwikLogPro Automated Checkpoint"` |
| **`POP_FLAT_001`** | `flatpak repair --dry-run` | Reports invalid/missing OSTree objects | `flatpak repair && flatpak uninstall --unused -y` |
| **`POP_SVC_001`** | `systemctl list-units --state=failed` | Count $\ge 1$ | `sudo systemctl reset-failed && sudo systemctl restart <unit_name>` |
| **`POP_GPU_001`** | `journalctl` / `kern.log` (`kwikparse`) | Matches `NVRM: Xid` or `amdgpu: ring gfx timeout` | **CLI:** `sudo apt-get install --reinstall system76-driver-nvidia`<br>**HW:** Verify PCIe power cables are fully seated; check GPU hotspot thermals. |

### 5.2 Windows (10 / 11) Ruleset

| Rule ID | Target Telemetry / Log Trigger | Condition | Prescribed Remediation (CLI / Physical) |
| :--- | :--- | :--- | :--- |
| **`WIN_IMG_001`** | System Event Log / `CBS.log` | Event ID `10010` or corrupt component store indicators | `DISM.exe /Online /Cleanup-Image /RestoreHealth && sfc /scannow` |
| **`WIN_DSK_001`** | `System.evtx` (`kwikparse`) | Event ID `55` (NTFS corruption) or Event ID `153` (Disk I/O retry) | **CLI:** `chkdsk C: /f /r` (Schedule on next reboot)<br>**HW:** Inspect SATA/M.2 seating; check `Get-StorageReliabilityCounter`. |
| **`WIN_PWR_001`** | `System.evtx` (`kwikparse`) | Event ID `41` (`Kernel-Power`) with `BugcheckCode == 0` | **HW:** Unclean power loss without BSOD. Test PSU 12V rail stability under transient load; inspect ATX 24-pin and EPS 8-pin connectors; verify UPS battery health. |
| **`WIN_WHEA_01`** | `System.evtx` (`kwikparse`) | Event ID `18` or `19` (`WHEA-Logger` Machine Check Exception) | **HW:** Hardware-level CPU cache/interconnect error. Disable XMP/EXPO or curve optimizer undervolts in BIOS; update motherboard AGESA/BIOS firmware; test CPU stability. |
| **`WIN_MEM_001`** | `System.evtx` (`kwikparse`) | BugCheck `0x1A` (`MEMORY_MANAGEMENT`) or `0x50` (`PAGE_FAULT_IN_NONPAGED_AREA`) | **CLI:** `mdsched.exe`<br>**HW:** Reseat DIMMs in slots A2/B2; clean gold contacts with 99% isopropyl alcohol; run MemTest86+. |
| **`WIN_WMI_001`** | `winmgmt /verifyrepository` | Returns `WMI repository is inconsistent` | `winmgmt /salvagerepository` |
| **`WIN_NET_001`** | DNS / Winsock telemetry probe | High socket exhaustion or DNS resolution timeouts | `netsh winsock reset && netsh int ip reset && ipconfig /flushdns` |

### 5.3 Cross-Platform Hardware Ruleset

| Rule ID | Metric | Threshold | Prescribed Physical Intervention |
| :--- | :--- | :--- | :--- |
| **`HW_THM_001`** | CPU Temperature vs Load | `cpu_temp` $\ge 80^\circ\text{C}$ while `cpu_load` $< 15\%$ | **Thermal Transfer Failure:** Clear dust from intake filters and radiator fins using compressed air. Inspect AIO pump RPM or CPU fan curve. Repaste CPU IHS using high-viscosity thermal compound (e.g., PTM7950 or Kryonaut). |
| **`HW_NVME_001`** | SMART `available_spare_pct` | $< 20\%$ or `percentage_used` $> 95\%$ | **End-of-Life NAND Wear:** Provision replacement NVMe drive and clone partitions immediately. Drive is approaching read-only lock mode. |
| **`HW_MEM_002`** | Swap / Pagefile Usage | `swap_used_pct` $> 85\%$ & `ram_avail` $< 5\%$ | **Severe Memory Pressure / Thrashing:** Identify runaway processes leaking memory, or physically upgrade system DIMM capacity to prevent SSD wear from constant swap paging. |

---

## 6. Brutalist Cybercore UI Specification (HTMX + CSS)

### 6.1 Visual & Layout Wireframe

```
+----------------------------------------------------------------------------------+
| KWIKLOGPRO // v1.0.0-PROD              HOST: POP-WORKSTATION [LINUX 6.9.3]       |
| STATUS: [ CRITICAL ]                   SCORE: [ 42 / 100 ]   [ RUN AUDIT (POST) ]|
+----------------------------------------------------------------------------------+
| TELEMETRY SNAPSHOT                     | HISTORICAL DEGRADATION (LAST 10 RUNS)   |
|----------------------------------------|-----------------------------------------|
| CPU TEMP : 88.5 C  [||||||||||..] CRIT | NVME MEDIA ERRORS : +4 (SLOPE: +1.3/d)  |
| RAM USED : 93.7 %  [|||||||||||.] WARN | CPU IDLE TEMP     : +6.2 C OVER 14 DAYS |
| SWAP USED: 87.5 %  [||||||||||..] WARN | HEALTH SCORE      : 94 -> 78 -> 42      |
| NVME0N1  : 98% SPR [||||||||||||] OPT  | LAST TIMESHIFT    : NEVER [ALERT]       |
+----------------------------------------------------------------------------------+
| PRESCRIBED REMEDIATION QUEUE           | FILTER: [ALL] [SOFTWARE] [HARDWARE]     |
+----------------------------------------------------------------------------------+
| [!] RULE: HW_NVME_002 // SEVERITY: CRITICAL // DOMAIN: HARDWARE                  |
| FINDING : Device /dev/nvme0n1 reported 4 SMART media_errors and 47 I/O errors.   |
| CONTEXT : Media errors increased by +4 over the last 3 runs.                     |
| ACTION  : PHYSICAL INTERVENTION REQUIRED                                         |
|   [1] Back up critical data from /dev/nvme0n1 to external media immediately.     |
|   [2] Power down workstation and inspect M.2 slot mounting and thermal pad.      |
|   [3] Replace NVMe module; non-zero media_errors indicate NAND degradation.      |
+----------------------------------------------------------------------------------+
| [!] RULE: POP_PKG_001 // SEVERITY: HIGH // DOMAIN: SOFTWARE                      |
| FINDING : 3 packages are in an unconfigured state, blocking system updates.      |
| COMMAND : $ sudo dpkg --configure -a && sudo apt-get install -f -y  [COPY CMD]   |
| VERIFY  : $ sudo dpkg --audit                                                    |
+----------------------------------------------------------------------------------+
| DEDUPLICATED LOG ANOMALIES (RUST KWIKPARSE: 1.07 GB SCANNED IN 142ms)            |
+----------------------------------------------------------------------------------+
| COUNT | LAST SEEN            | SOURCE | MESSAGE                                  |
| 47x   | 2026-10-27 03:59:12Z | kernel | blk_update_request: I/O error, nvme0n1   |
| 12x   | 2026-10-27 01:12:04Z | systemd| Failed to start fwupd.service            |
+----------------------------------------------------------------------------------+
```

### 6.2 HTTP Endpoints (`kwiklogd`)
* `GET /` — Renders the full dashboard layout (`index.html`).
* `POST /api/scan` — Triggers an asynchronous pipeline run (`Shell -> Rust -> Python -> SQLite`) and returns an HTMX SSE listener block.
* `GET /api/scan/stream` — Server-Sent Events (SSE) stream pushing live phase updates (`[PHASE 1/3: SHELL PROBES]`, `[PHASE 2/3: RUST LOG PARSER]`, `[PHASE 3/3: PYTHON DIAGNOSTICS]`).
* `GET /api/runs/{id}` — Returns an HTML fragment swapping the main report view with any historical run from the SQLite database.
* `GET /api/prescriptions?domain={SOFTWARE|HARDWARE}` — Filters the remediation queue via HTMX partial swap.
* `POST /api/export/{id}` — Generates a standalone, self-contained Markdown or HTML report file in `./exports/` for offline archiving.

---

## 7. Project Repository Structure

```text
kwiklogpro/
├── Makefile                        # Unified multi-language build & bundle automation
├── README.md
├── kwiklog.db                      # Generated SQLite3 WAL database (gitignored)
├── exports/                        # Generated offline Markdown/HTML reports
│
├── cmd/
│   └── kwiklogd/
│       ├── main.go                 # Go entry point, CLI flags (--cli, --serve, --port)
│       ├── orchestrator.go         # Subprocess execution & timeout supervisor
│       ├── db.go                   # SQLite3 WAL writer & query handlers
│       └── server.go               # HTMX HTTP server & SSE broadcaster
│
├── probes/
│   ├── probe_pop.sh                # Pop!_OS telemetry extractor (Bash)
│   └── probe_win.bat               # Windows telemetry extractor (Batch/PowerShell hybrid)
│
├── kwikparse/                      # Rust high-speed log parser crate
│   ├── Cargo.toml
│   └── src/
│       ├── main.rs                 # CLI arguments & stdout JSON serializer
│       ├── linux_logs.rs           # mmap syslog/kern.log/journalctl parser
│       ├── windows_evtx.rs         # Native .evtx binary chunk parser
│       └── dedup.rs                # Signature hashing & frequency bucketing
│
├── kwikdiag/                       # Python diagnostic & prescription engine
│   ├── kwikdiag.py                 # Entry point reading stdin JSON & querying SQLite
│   ├── rules_pop.py                # Pop!_OS specific evaluation rules
│   ├── rules_win.py                # Windows specific evaluation rules
│   ├── rules_hw.py                 # Cross-platform hardware & SMART rules
│   └── trends.py                   # OLS linear regression slope calculator
│
└── web/
    ├── static/
    │   ├── htmx.min.js             # Vendored local HTMX binary (zero CDN usage)
    │   └── brutalist.css           # Strict 0px border-radius dark-mode stylesheet
    └── templates/
        ├── index.html              # Master dashboard frame
        ├── report_fragment.html    # HTMX swappable diagnostic report view
        └── progress_sse.html       # Live scan progress component
```

---

## 8. Security, Privilege & Safety Guardrails

1. **Read-Only Execution Guarantee:** KwikLogPro **never** automatically executes destructive or state-mutating remediation commands (`apt`, `dism`, `rm`, `chkdsk`) during a scan. It operates strictly as an auditor and prescription generator. The user must explicitly copy and run the prescribed commands or trigger an opt-in confirmation prompt.
2. **Privilege Escalation Handling:**
   * Hardware telemetry (`smartctl`, raw `.evtx` security logs, `dmidecode`) requires root/Administrator privileges.
   * If `kwiklogd` is launched without elevated privileges, it detects the UID/SID mismatch immediately, logs a stark warning banner, and runs in **Degraded Unprivileged Mode** (skipping raw disk SMART probes and protected kernel logs rather than crashing).
3. **Command Injection Prevention:**
   * All variables interpolated into prescribed CLI commands (such as failed systemd unit names or disk device paths like `/dev/nvme0n1`) are validated against strict allowlist regular expressions (`^[a-zA-Z0-9_.@-]+$`) inside `kwikdiag.py` to prevent malicious log entries from injecting shell metacharacters into the remediation report.
4. **Loopback Binding Only:** The Go HTTP server binds strictly to `127.0.0.1` (localhost) by default, preventing unauthorized network access to system telemetry on shared LANs.

---

## 9. Phased Implementation Roadmap

### Phase 1: Foundation & Telemetry Probes (Milestone 1)
* Initialize the standalone project repository and SQLite3 WAL schema (`schema.sql`).
* Build `probe_pop.sh` and `probe_win.bat` to output normalized hardware/software JSON payloads.
* Construct the Go `kwiklogd` subprocess supervisor to execute the probes and write raw snapshots into SQLite.

### Phase 2: Rust Log Parser (`kwikparse`) (Milestone 2)
* Implement memory-mapped regex scanning for Linux `/var/log/` and `journalctl` JSON streams.
* Implement native Windows `.evtx` parsing using the Rust `evtx` crate.
* Build the signature deduplication hash table and integrate binary invocation into `kwiklogd`.

### Phase 3: Python Diagnostic Engine (`kwikdiag.py`) (Milestone 3)
* Implement the Pop!_OS, Windows, and Cross-Platform Hardware rule matrices.
* Build the historical SQLite query module and OLS linear regression slope calculator (`trends.py`).
* Wire `kwikdiag.py` output into the `prescriptions` SQLite table and build the high-contrast CLI table reporter.

### Phase 4: Brutalist HTMX Web UI & Packaging (Milestone 4)
* Build the Go HTTP server, SSE progress streamer, and HTML templates with `brutalist.css`.
* Configure `go:embed` to bundle static assets and create the root `Makefile` to compile Go and Rust binaries into a portable, air-gapped release directory.