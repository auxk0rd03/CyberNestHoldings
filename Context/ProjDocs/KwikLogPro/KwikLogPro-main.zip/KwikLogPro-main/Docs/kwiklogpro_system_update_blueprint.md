# KwikLogPro (`v2.0-MEGA`): Comprehensive Post-Audit Engineering Blueprint & ROI Expansion Specification

* **Target Project Directory**: `/home/auxk0rd/Desktop/KwikLogPro`
* **Architecture Stack**: RPGS+HTMX (`Rust` + `Python 3.10+` + `Go 1.22` + `POSIX/PowerShell Probes` + `SQLite3 WAL` + `Vendored HTMX`)
* **Audit Baseline Analyzed**: `exports/kwiklog_run_2.md`, `exports/kwiklog_run_2.html`, `Handoff.md`, and Workspace Tree (`114 directories, 683 files`)
* **Prepared For**: Auxk0rd (Principal Software Architect)

---

## 1. Forensic Review of `kwiklog_run_2` Diagnostic Results

An end-to-end engineering inspection of your `kwiklog_run_2.md` and `kwiklog_run_2.html` artifacts alongside `Handoff.md` confirms that the core three-stage polyglot pipeline is fast (`383 ms` wall-clock scan time) and deterministic. However, the live and simulated telemetry inside Run #2 exposed **15 specific architectural gaps** that currently limit diagnostic accuracy, signal-to-noise ratio, cross-hardware versatility, and operator ROI:

| # | Forensic Finding in `kwiklog_run_2` & Codebase Tree | Root Cause in Current RPGS+HTMX Implementation |
| :--- | :--- | :--- |
| **1** | `Slope: +0.00/run` and `OLS Slope: +0.00 C/day` despite CPU temp jumping $+60.7^\circ\text{C}$ and NVMe media errors jumping $+4$. | `kwikdiag/trends.py` returns $m = 0.0$ whenever $N < 3$, and lacks Time-To-Failure (TTF) threshold projection and $R^2$ confidence metrics. |
| **2** | Run #2 (simulated fault run) computed its $+60.7^\circ\text{C}$ delta against Run #1 (live host baseline run). | `schema.sql` and `cmd/kwiklogd/db.go` store simulated and live runs in the same unpartitioned table without an `is_simulated` filter in `trends.py`. |
| **3** | Identical failures appear twice in the anomaly list (e.g., `Failed to start app-cosmic-com.system76.CosmicAppList-37876.scope` at rows #39 and #45). | `/var/log/syslog` lines retain `<hostname> <unit>[<pid>]:` prefixes after ISO timestamp stripping, whereas `journalctl` JSON emits raw `MESSAGE` strings, producing two different SHA-256 hashes for the same event. |
| **4** | 21 of the 50 anomaly slots are consumed by identical `no rectangle for surface Id(4..10)`, `ACPI ... [\_SB.PC00.XHCI.RHUB.HS01..10._UPC]`, and raw hex segfault pointers (`at 74e94aadc03d`). | `kwikparse/src/dedup.rs` (`DYNAMIC_TOKEN_RE`) only strips `0x`-prefixed hex and `6+` digit numbers, missing unprefixed 64-bit hex pointers, parenthesized IDs `Id(\d+)`, and ACPI node indices. |
| **5** | Benign kernel/user-session quirks (`AE_ALREADY_EXISTS`, Bluetooth `sap-server`, `CosmicTheme` watcher warnings) are flagged as `[HIGH]` severity. | `kwikparse/src/linux_logs.rs` maps all `journalctl -p 0..3` lines to `HIGH` (`JOURNAL_ERR`) without a noise-suppression or severity-downgrade matrix. |
| **6** | Multiple `xdg-desktop-por` and `cosmic-player` segfaults (`PROCESS_CRASH`) and `portal.desktop.cosmic.service` failures occurred in Run #2 with **zero** matching prescriptions. | `kwikdiag/rules_pop.py` has no rules evaluating `PROCESS_CRASH` anomalies or Pop!_OS 24.04 COSMIC Desktop / Wayland compositor faults. |
| **7** | `HW_MEM_002` reports `15.2 GiB` swap used and only `2.0 GiB` of `64 GiB` RAM available, but tells the operator to manually run `ps aux` to find the leak. | `probes/probe_pop.sh` and `probes/probe_win.bat` do not capture top resident memory (RSS) or CPU process offenders at the moment of the scan. |
| **8** | Storage health rules (`HW_NVME_001`, `HW_NVME_002`) only inspect NVMe SMART health logs (`nvme_smart_health_information_log`). | SATA SSDs, AHCI/SAS drives, and MDADM/ZFS arrays using ATA SMART attributes (IDs `5`, `187`, `197`, `198`, `199`) are not normalized into `DiskTelemetry`. |
| **9** | `POP_GPU_001` detected `NVRM: Xid 79 (GPU has fallen off the bus)`, yet Hardware Telemetry Snapshot has zero GPU metrics. | Stage 1 probes do not query `nvidia-smi`, `rocm-smi`, `/sys/class/drm/card*/device/hwmon`, or PCIe AER error counters. |
| **10** | Run #2 scored `0 / 100` (`CRITICAL`) from simple linear subtraction ($100 - 152 = 0$). | `kwikdiag/kwikdiag.py` uses flat uncapped subtraction where 4 minor software issues equal 2 fatal hardware issues, destroying score granularity below 30. |
| **11** | `exports/kwiklog_run_2.html` is just the raw Markdown file wrapped inside a `<pre>` tag. | `DBStore.ExportRunReport()` in `cmd/kwiklogd/db.go` does not render a true self-contained Brutalist Cybercore HTML dashboard with inline CSS, gauges, and interactive copy buttons. |
| **12** | Operators must manually copy/paste every `verification_cmd` to check if a fix worked, and re-run a full system scan. | `cmd/kwiklogd/server.go` lacks a dedicated read-only `POST /api/prescriptions/{id}/verify` HTMX endpoint to execute `verification_cmd` and auto-mark directives verified. |
| **13** | Old log errors from `2026-10-23` still trigger active `CRITICAL` prescriptions on `2026-10-27` even after a fix is applied. | `kwikparse` scans full log files and boots without checking the last acknowledged timestamp or `--since` cursor in SQLite. |
| **14** | `kwiklogd` only audits when manually invoked via `--cli` or `POST /api/scan`, and `kwiklog.db` grows unbounded over time. | `cmd/kwiklogd` lacks a background autonomous watchdog ticker (`--interval`), desktop alert hooks (`notify-send` / Windows Toast), and automated WAL retention pruning. |
| **15** | All rule thresholds (`80.0 C` CPU idle temp, `90%` disk usage) are hardcoded in Python, and the UI cannot diff two runs side-by-side. | Missing external `config.json` threshold injection and an HTMX Run-to-Run Diff Engine (`GET /api/runs/diff`). |

---

## 2. Detailed Architectural Improvements & RPGS+HTMX Implementation Blueprints

---

### Improvement 1: Two-Point Velocity Fallback, $R^2$ Confidence, and Time-To-Failure (TTF) Extrapolation
* **Target Tier**: Python Diagnostic Engine (`kwikdiag/trends.py`, `kwikdiag/rules_hw.py`) & Go View Model (`cmd/kwiklogd/server.go`)
* **Problem Solved**: Eliminates the `+0.00/run` and `+0.00 C/day` blind spot when $N = 2$, quantifies trend reliability via the coefficient of determination ($R^2$), and predicts exact **Days Until Critical Threshold Breach (TTF)** (e.g., when NVMe wear hits $100\%$ or CPU idle temp hits $85^\circ\text{C}$).
* **Mathematical Formulation**:
  For $N = 2$ points $(t_1, y_1)$ and $(t_2, y_2)$ where $\Delta t = t_2 - t_1 > 0$:
  $$m_{\text{day}} = \frac{y_2 - y_1}{\Delta t}, \quad m_{\text{run}} = y_2 - y_1$$
  For $N \ge 3$ points, alongside the OLS slope $m$, compute the goodness-of-fit $R^2$:
  $$R^2 = 1 - \frac{\sum_{i=1}^{N} (y_i - \hat{y}_i)^2}{\sum_{i=1}^{N} (y_i - \bar{y})^2}$$
  For any monotonically degrading metric with upper failure ceiling $Y_{\text{crit}}$ and positive slope $m_{\text{day}} > 0$:
  $$\text{TTF}_{\text{days}} = \frac{Y_{\text{crit}} - y_N}{m_{\text{day}}}$$

#### Clean Implementation in `kwikdiag/trends.py`:
```python
from dataclasses import dataclass
from typing import List, Tuple, Optional

CRITICAL_CEILINGS = {
    ("CPU", "temp_celsius"): 85.0,
    ("RAM", "used_pct"): 95.0,
    ("SWAP", "used_pct"): 90.0,
}

@dataclass
class MetricTrend:
    component: str
    metric_name: str
    sample_count: int
    first_value: float
    latest_value: float
    delta: float
    slope_per_day: float
    slope_per_run: float
    moving_average: float
    r_squared: float = 0.0
    estimated_ttf_days: Optional[float] = None


def calculate_ols_slope_and_r2(points: List[Tuple[float, float]]) -> Tuple[float, float]:
    n = len(points)
    if n < 2:
        return 0.0, 0.0
    t0 = points[0][0]
    ts = [p[0] - t0 for p in points]
    ys = [p[1] for p in points]

    if n == 2:
        dt = ts[1] - ts[0]
        return ((ys[1] - ys[0]) / dt if dt > 1e-9 else 0.0), 1.0

    sum_t = sum(ts)
    sum_y = sum(ys)
    sum_ty = sum(t * y for t, y in zip(ts, ys))
    sum_t2 = sum(t * t for t in ts)

    denom = (n * sum_t2) - (sum_t * sum_t)
    if abs(denom) < 1e-12:
        return 0.0, 0.0

    slope = ((n * sum_ty) - (sum_t * sum_y)) / denom
    intercept = (sum_y - slope * sum_t) / n

    mean_y = sum_y / n
    ss_tot = sum((y - mean_y) ** 2 for y in ys)
    ss_res = sum((y - (slope * t + intercept)) ** 2 for t, y in zip(ts, ys))
    r2 = 1.0 - (ss_res / ss_tot) if ss_tot > 1e-12 else 0.0
    return slope, max(0.0, min(1.0, r2))
```
Inside `compute_metric_trend()`, calculate `slope_per_run` for $N=2$ directly as `ys[-1] - ys[0]`, and when `slope_per_day > 0.01`, compute `estimated_ttf_days = round((ceiling - latest_value) / slope_per_day, 1)` if `latest_value < ceiling`.

---

### Improvement 2: Simulation Isolation Guard in SQLite3 WAL (`is_simulated` Partitioning)
* **Target Tier**: SQLite Schema (`schema.sql`), Go Persistence (`cmd/kwiklogd/db.go`, `cmd/kwiklogd/orchestrator.go`), Python Trend Loader (`kwikdiag/trends.py`)
* **Problem Solved**: Prevents `--simulate` (or `[ SIMULATE FAULT AUDIT ]` in the HTMX UI) from corrupting the live workstation's historical OLS regression slopes or baseline health score trajectory.

#### Clean Implementation:
1. **`schema.sql`**: Add `is_simulated INTEGER NOT NULL DEFAULT 0 CHECK(is_simulated IN (0, 1))` to `diagnostic_runs`:
   ```sql
   ALTER TABLE diagnostic_runs ADD COLUMN is_simulated INTEGER NOT NULL DEFAULT 0;
   CREATE INDEX IF NOT EXISTS idx_runs_sim_ts ON diagnostic_runs(is_simulated, timestamp_utc DESC);
   ```
   *(Note: Also include `is_simulated` directly inside the `CREATE TABLE IF NOT EXISTS diagnostic_runs` DDL for fresh databases, and run an idempotent column check in `NewDBStore()` in `cmd/kwiklogd/db.go`).*
2. **`cmd/kwiklogd/orchestrator.go`**: Add `IsSimulated bool` to `CombinedScanBundle` and pass `--simulate-history` to `kwikdiag.py` only when `simulateDegraded == true`.
3. **`kwikdiag/trends.py`**: Filter `load_historical_trends()` by `WHERE is_simulated = ?` so live runs only regress against prior live runs (`is_simulated = 0`), and simulated runs regress against simulated runs.

---

### Improvement 3: Cross-Source Syslog Prefix Stripping & Unified Signature Hashing
* **Target Tier**: Rust Log Ingestion Engine (`kwikparse/src/dedup.rs`, `kwikparse/src/linux_logs.rs`)
* **Problem Solved**: In `kwiklog_run_2.md`, `/var/log/syslog` and `journalctl` produced duplicate anomaly rows for the exact same failure because `/var/log/syslog` prepends `<ISO-Timestamp> <hostname> <unit>[<pid>]: ` while `journalctl` JSON provides the bare `MESSAGE`.

#### Clean Implementation in `kwikparse/src/dedup.rs`:
Add a pre-normalization function `strip_syslog_envelope(raw: &str) -> &str` that removes leading RFC3339/RFC3164 timestamps, hostname, and daemon tag before both signature hashing and storing `sample_message`:
```rust
static SYSLOG_ENVELOPE_RE: OnceLock<Regex> = OnceLock::new();

pub fn strip_syslog_envelope(msg: &str) -> String {
    let re = SYSLOG_ENVELOPE_RE.get_or_init(|| {
        Regex::new(
            r"^(?:\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\s+)?(?:[a-zA-Z0-9_-]+\s+)?(?:[a-zA-Z0-9_.\-@\\]+(?:\[\d+\])?:\s+)"
        ).unwrap()
    });
    re.replace(msg.trim(), "").to_string()
}
```
Call `let clean_msg = strip_syslog_envelope(&event.message);` at the start of `deduplicate_events()` in `kwikparse/src/dedup.rs`. Now `2026-10-27T02:17:04.736977-04:00 pop-os systemd[2489]: Failed to start app-cosmic...` and `Failed to start app-cosmic...` normalize to the exact same string and collapse into a single deduplicated bucket.

---

### Improvement 4: Enhanced SIMD Token Normalizer for Unprefixed Hex Pointers, ACPI Nodes, and Surface IDs
* **Target Tier**: Rust Log Ingestion Engine (`kwikparse/src/dedup.rs`)
* **Problem Solved**: Collapses the 14 separate `ACPI BIOS Error ... [\_SB.PC00.XHCI.RHUB.HS01..10._UPC]` entries into **1 bucket (`14x`)**, the 5 `no rectangle for surface Id(4..10)` entries into **1 bucket (`5x`)**, and unprefixed 64-bit kernel segfault addresses (`at 74e94aadc03d ip 000074e94aadc03d sp 000074e9393f9680`) into **1 bucket (`4x`)**.

#### Clean Implementation in `kwikparse/src/dedup.rs`:
Update `DYNAMIC_TOKEN_RE` in `normalize_signature_input()` to include:
```rust
static DYNAMIC_TOKEN_RE: OnceLock<Regex> = OnceLock::new();

pub fn normalize_signature_input(msg: &str) -> String {
    let re = DYNAMIC_TOKEN_RE.get_or_init(|| {
        Regex::new(concat!(
            r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?|",
            r"\[\s*\d+\.\d+\s*\]|",
            r"0x[0-9a-fA-F]+|",
            r"\b[0-9a-fA-F]{8,16}\b|",                        // Unprefixed 32/64-bit hex pointers in segfaults
            r"\\?_SB\.[A-Z0-9_.]+|",                          // ACPI namespace object paths (\_SB.PC00.XHCI...)
            r"\bId\(\d+\)|",                                  // Wayland/COSMIC surface Id(N)
            r"-[0-9]+\.scope\b|",                             // Transient systemd scope suffixes (-37876.scope)
            r"\b(?:sector|pid=?|CPU|core|socket|error)\s*\d+|",// Hardware/kernel positional counters
            r"\[\d+\]|",
            r"\b\d{5,}\b"
        )).unwrap()
    });
    re.replace_all(msg, "<TOKEN>").to_lowercase()
}
```

---

### Improvement 5: Three-Tier Log Noise Suppression & Severity Reclassification Matrix
* **Target Tier**: Rust Log Ingestion Engine (`kwikparse/src/linux_logs.rs`)
* **Problem Solved**: Prevents benign kernel/BIOS messages (`AE_ALREADY_EXISTS`, `TDX not supported`, `Sap driver initialization failed`) and transient user-scope desktop notifications (`Notification not found... pushing instead`) from masquerading as `[HIGH]` system threats in `scan_journalctl()`.

#### Clean Implementation in `kwikparse/src/linux_logs.rs`:
Introduce a two-stage classifier inside `scan_journalctl()`:
1. **`BENIGN_NOISE_RE` (Drop or Downgrade to `LOW`)**:
   ```rust
   static BENIGN_IGNORE_RE: OnceLock<Regex> = OnceLock::new();
   fn is_benign_noise(msg: &str) -> bool {
       let re = BENIGN_IGNORE_RE.get_or_init(|| {
           Regex::new(r"(?i)(ACPI BIOS Error.*AE_ALREADY_EXISTS|ACPI Error: AE_ALREADY_EXISTS|virt/tdx: TDX not supported|Sap driver initialization failed|sap-server: Operation not permitted|Notification not found\.\.\. pushing instead|no rectangle for surface Id|surface missing from known popups)").unwrap()
       });
       re.is_match(msg)
   }
   ```
2. **Scope-Aware Severity Mapping**: When scanning `journalctl` JSON lines, inspect `_SYSTEMD_USER_UNIT` and `SYSLOG_IDENTIFIER`. If the event originates from a non-root user session scope (`session-*.scope`, `user@*.service`) and is not a `PROCESS_CRASH` or `GPU_SUBSYSTEM` fault, classify its severity as `MEDIUM` or `LOW` (`USER_SESSION_WARN`) rather than `HIGH` (`JOURNAL_ERR`).

---

### Improvement 6: Pop!_OS 24.04 COSMIC Desktop & Userspace Segfault Rules (`POP_COSMIC_001` & `POP_CRASH_001`)
* **Target Tier**: Python Rule Matrix (`kwikdiag/rules_pop.py`) & Rust Log Categorizer (`kwikparse/src/linux_logs.rs`)
* **Problem Solved**: `kwiklog_run_2.md` logged repeated `xdg-desktop-por` segfaults, `cosmic-player` segfaults in `libwayland-client.so`, and `org.freedesktop.impl.portal.desktop.cosmic.service` failures without triggering a single remediation rule.

#### Clean Implementation in `kwikdiag/rules_pop.py`:
Add two new deterministic rules to `evaluate_pop_rules(telemetry, anomalies)`:
```python
    # 9. POP_COSMIC_001: COSMIC Desktop Compositor / XDG Portal Failure
    evaluated_count += 1
    cosmic_faults = [
        a for a in anomalies
        if any(k in a.get("sample_message", "").lower() for k in (
            "portal.desktop.cosmic", "cosmic-comp", "cosmic-panel", "cosmicapplist", "libwayland-client"
        ))
    ]
    if cosmic_faults:
        total_hits = sum(int(a.get("occurrence_count", 1)) for a in cosmic_faults)
        prescriptions.append({
            "rule_id": "POP_COSMIC_001",
            "severity": "MEDIUM",
            "domain": "SOFTWARE",
            "title": "COSMIC Desktop Session / XDG Portal Subsystem Instability",
            "finding_summary": (
                f"Detected {len(cosmic_faults)} distinct COSMIC/Wayland fault signature(s) "
                f"({total_hits} total occurrences), including XDG desktop portal or Wayland client crashes."
            ),
            "historical_context": f"Latest sample: {cosmic_faults[0].get('sample_message', '')[:120]}",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "systemctl --user reset-failed",
                "systemctl --user restart xdg-desktop-portal.service",
                "sudo apt-get update && sudo apt-get install --only-upgrade cosmic-comp xdg-desktop-portal-cosmic -y"
            ],
            "verification_cmd": "systemctl --user list-units --state=failed",
            "risk_level": "SAFE",
        })

    # 10. POP_CRASH_001: Recurring Userspace Binary Segmentation Faults (PROCESS_CRASH)
    evaluated_count += 1
    segfaults = [a for a in anomalies if a.get("category") == "PROCESS_CRASH"]
    if segfaults:
        total_crashes = sum(int(a.get("occurrence_count", 1)) for a in segfaults)
        prescriptions.append({
            "rule_id": "POP_CRASH_001",
            "severity": "HIGH" if total_crashes >= 3 else "MEDIUM",
            "domain": "SOFTWARE",
            "title": "Recurring Userspace Process Segmentation Faults Detected",
            "finding_summary": (
                f"Kernel logged {total_crashes} segmentation fault(s) across {len(segfaults)} binary signature(s). "
                f"Primary fault: '{segfaults[0].get('sample_message', '')[:110]}'."
            ),
            "historical_context": "Frequent segfaults indicate shared library mismatch or unstable RAM XMP timings.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "coredumpctl list --no-pager | tail -n 10",
                "sudo ldconfig && sudo dpkg --verify"
            ],
            "verification_cmd": "dmesg -T | grep -i segfault | tail -n 5",
            "risk_level": "SAFE",
        })
```

---

### Improvement 7: Live Process Culprit Attribution for Memory Thrashing & Thermal Spikes
* **Target Tier**: OS Probes (`probes/probe_pop.sh`, `probes/probe_win.bat`), Go IPC Structs (`cmd/kwiklogd/orchestrator.go`), Python Rules (`kwikdiag/rules_hw.py`)
* **Problem Solved**: When `HW_MEM_002` (88.7% Swap saturation) or `HW_THM_001` triggers, the operator immediately sees the top 5 memory-consuming and CPU-consuming processes captured at the exact millisecond of the audit.

#### Clean Implementation:
1. **`probes/probe_pop.sh`**:
   Collect top 5 RSS memory and CPU hogs in Bash and pass them to the Python serializer:
   ```bash
   TOP_MEM_PROCS=$(ps -eo pid,comm,%mem,rss --sort=-rss 2>/dev/null | awk 'NR>1 && NR<=6 {printf "%s(%s:%.1f%%) ", $2, $1, $3}' | sed 's/ $//')
   TOP_CPU_PROCS=$(ps -eo pid,comm,%cpu --sort=-%cpu 2>/dev/null | awk 'NR>1 && NR<=6 {printf "%s(%s:%.1f%%) ", $2, $1, $3}' | sed 's/ $//')
   export TOP_MEM_PROCS TOP_CPU_PROCS
   ```
   Include `"top_mem_processes": os.environ.get("TOP_MEM_PROCS", "")` and `"top_cpu_processes": os.environ.get("TOP_CPU_PROCS", "")` inside `"software_state"`.
2. **`probes/probe_win.bat`**:
   Query `Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 5` in PowerShell and format identically into `$payload.software_state.top_mem_processes`.
3. **`cmd/kwiklogd/orchestrator.go`**:
   Add `TopMemProcesses string` (`json:"top_mem_processes,omitempty"`) and `TopCPUProcesses string` (`json:"top_cpu_processes,omitempty"`) to `SoftwareState`.
4. **`kwikdiag/rules_hw.py`**:
   In `HW_MEM_002`, append `f" Top resident memory consumers at scan time: [{sw.get('top_mem_processes', 'N/A')}]."` directly to `finding_summary`.

---

### Improvement 8: Multi-Transport Storage Generalization (SATA/ATA SMART, NVMe, and ZFS/BTRFS Integrity)
* **Target Tier**: OS Probes (`probes/probe_pop.sh`), Go Structs (`cmd/kwiklogd/orchestrator.go`), Python Hardware Rules (`kwikdiag/rules_hw.py`)
* **Problem Solved**: Extends KwikLogPro beyond single-NVMe workstations to support SATA SSDs, rotational enterprise HDDs, and multi-disk configurations by normalizing ATA SMART attributes alongside NVMe health logs.

#### Clean Implementation in `probes/probe_pop.sh`:
Inside the inline Python block in `probes/probe_pop.sh`, when `smartctl -a -j <dev>` returns ATA SMART data (`"ata_smart_attributes"`), normalize the critical counters into the existing `DiskTelemetry` JSON contract:
```python
ata_table = smart_json.get("ata_smart_attributes", {}).get("table", [])
ata_map = {row.get("id"): row.get("raw", {}).get("value", 0) for row in ata_table}
# ID 5: Reallocated_Sector_Ct, ID 187: Reported_Uncorrect, ID 197: Current_Pending_Sector, ID 198: Offline_Uncorrectable
ata_media_errors = (
    int(ata_map.get(5, 0)) +
    int(ata_map.get(187, 0)) +
    int(ata_map.get(197, 0)) +
    int(ata_map.get(198, 0))
)
# ID 199: UDMA_CRC_Error_Count (bad SATA cable/backplane)
udma_crc_errors = int(ata_map.get(199, 0))
```
Map `ata_media_errors` into `media_errors` when `nvme_smart_health_information_log` is absent, and add `interface_crc_errors` to `DiskTelemetry` so `rules_hw.py` can distinguish between physical NAND/platter failure (`HW_NVME_002`) and a loose SATA/PCIe interconnect (`HW_DSK_003`).

---

### Improvement 9: Dedicated GPU Hardware Telemetry & PCIe AER Bus Fault Probe
* **Target Tier**: OS Probes (`probes/probe_pop.sh`, `probes/probe_win.bat`), Go Orchestrator (`cmd/kwiklogd/orchestrator.go`), UI & CLI (`cmd/kwiklogd/server.go`, `cmd/kwiklogd/main.go`)
* **Problem Solved**: Captures GPU model, core temperature ($^\circ\text{C}$), GPU utilization ($\%$), VRAM used/total bytes, and PCIe Advanced Error Reporting (AER) uncorrectable link errors across NVIDIA (`nvidia-smi`), AMD (`rocm-smi` / `/sys/class/drm/card*/device/hwmon`), and Intel Arc/iGPU.

#### Clean Implementation:
1. **`probes/probe_pop.sh`**:
   ```bash
   GPU_MODEL="Integrated / Unknown"
   GPU_TEMP="0.0"
   GPU_LOAD="0.0"
   if command -v nvidia-smi >/dev/null 2>&1; then
       IFS=',' read -r g_name g_temp g_load < <(nvidia-smi --query-gpu=name,temperature.gpu,utilization.gpu --format=csv,noheader,nounits 2>/dev/null | head -n 1)
       GPU_MODEL="${g_name:-NVIDIA GPU}"
       GPU_TEMP="${g_temp:-0.0}"
       GPU_LOAD="${g_load:-0.0}"
   fi
   export GPU_MODEL GPU_TEMP GPU_LOAD
   ```
2. **`cmd/kwiklogd/orchestrator.go`**:
   Add `GPUModel string`, `GPUTempCelsius float64`, and `GPULoadPercent float64` to `HardwareTelemetry`.
3. **`cmd/kwiklogd/db.go` & `kwikdiag/trends.py`**:
   Flatten `("GPU", "temp_celsius")` into `telemetry_metrics` so GPU thermal paste degradation is tracked via OLS regression alongside CPU temperature!

---

### Improvement 10: Domain-Partitioned Exponential Health Scoring Engine
* **Target Tier**: Python Diagnostic Engine (`kwikdiag/kwikdiag.py`)
* **Problem Solved**: Replaces flat additive subtraction (which clamped Run #2 to `0 / 100`) with a domain-weighted diminishing-returns formula that separates **Hardware Integrity ($60\%$ weight)** from **Software/OS Stability ($40\%$ weight)** and applies a per-category penalty ceiling so repetitive log noise never zeroes out the score of a bootable machine.

#### Mathematical Formulation:
Let $P_{\text{HW}}$ be the sum of hardware prescription weights and $P_{\text{SW}}$ be the sum of software prescription weights, using base weights $W = \{\text{CRITICAL}: 35, \text{HIGH}: 18, \text{MEDIUM}: 8, \text{LOW}: 3\}$.
Compute the sub-scores via exponential decay:
$$S_{\text{HW}} = 100 \cdot e^{-P_{\text{HW}} / 65}, \quad S_{\text{SW}} = 100 \cdot e^{-P_{\text{SW}} / 55}$$
The composite system health score is:
$$S_{\text{total}} = \text{round}\left(0.60 \cdot S_{\text{HW}} + 0.40 \cdot S_{\text{SW}}\right)$$

#### Clean Implementation in `kwikdiag/kwikdiag.py`:
```python
import math

def compute_health_scores(prescriptions: List[Dict[str, Any]]) -> Tuple[int, int, int, str]:
    hw_penalty = 0.0
    sw_penalty = 0.0
    for p in prescriptions:
        if p.get("acknowledged", False):
            continue
        w = float(SEVERITY_PENALTY.get(p.get("severity", "LOW"), 3))
        if p.get("domain") == "HARDWARE":
            hw_penalty += w
        else:
            sw_penalty += w

    hw_score = int(round(100.0 * math.exp(-hw_penalty / 65.0)))
    sw_score = int(round(100.0 * math.exp(-sw_penalty / 55.0)))
    overall = int(round(0.60 * hw_score + 0.40 * sw_score))
    overall = max(1, min(100, overall)) if (hw_penalty + sw_penalty) > 0 else 100

    has_critical = any(p.get("severity") == "CRITICAL" and not p.get("acknowledged", False) for p in prescriptions)
    if has_critical or overall < 50:
        status = "CRITICAL"
    elif overall < 80 or prescriptions:
        status = "DEGRADED"
    else:
        status = "OPTIMAL"

    return overall, hw_score, sw_score, status
```
In Run #2, this yields an informative `21 / 100` (`HW: 19 / 100`, `SW: 24 / 100`) instead of a flatlined `0 / 100`, allowing the operator to watch the score climb incrementally (`21 -> 48 -> 76 -> 94`) as each prescription is remediated!

---

### Improvement 11: Self-Contained Brutalist Cybercore HTML Report Exporter
* **Target Tier**: Go Persistence & Exporter (`cmd/kwiklogd/db.go`, `cmd/kwiklogd/server.go`)
* **Problem Solved**: Currently, `exports/kwiklog_run_2.html` is just the Markdown string inside `<pre>...</pre>`. We can render the actual Brutalist Cybercore HTML dashboard template with inline `brutalist.css`, ASCII bar gauges, color-coded severity badges, OLS trend tables, and working `[COPY CMD]` buttons into `exports/kwiklog_run_<id>.html`.

#### Clean Implementation in `cmd/kwiklogd/db.go`:
Update `ExportRunReport(runID int64, exportDir string)` to embed the CSS rules from `web/static/brutalist.css` and render structured HTML tables (`<table class="data-table">`), `.prescription-card` blocks, and inline `<button onclick="navigator.clipboard.writeText(...)">[COPY CMD]</button>` elements so exported `.html` archives look identical to the live `127.0.0.1:8484` web dashboard when opened on any air-gapped machine.

---

### Improvement 12: Closed-Loop HTMX Verification Runner (`[ VERIFY FIX ]`)
* **Target Tier**: Go HTTP Server (`cmd/kwiklogd/server.go`), SQLite Schema (`schema.sql`), HTMX Template (`web/templates/report_fragment.html`)
* **Problem Solved**: Every prescription includes a read-only `verification_cmd` (such as `systemctl list-units --state=failed` or `df -h /boot/efi /recovery /`). Instead of forcing the operator to switch to a terminal, paste the verification command, and manually click `[ACK DIRECTIVE]`, add a `[ VERIFY FIX ]` button in HTMX that runs the read-only `verification_cmd` under a 10-second `context.WithTimeout` and displays the live verification output inline!

#### Clean Implementation:
1. **`cmd/kwiklogd/server.go`**:
   Register route `POST /api/prescriptions/{id}/verify`:
   ```go
   func (s *Server) handleVerifyPrescription(w http.ResponseWriter, r *http.Request) {
       // 1. Lookup prescription by ID from SQLite
       // 2. Execute p.VerificationCmd via bash -c (Linux) or powershell -Command (Windows)
       //    with context.WithTimeout(r.Context(), 10*time.Second)
       // 3. Return a Brutalist HTML snippet showing exit status (0 = VERIFIED PASS in #00FF66,
       //    non-zero = STILL FAILING in #FF0033) and the command STDOUT/STDERR output.
   }
   ```
2. **`web/templates/report_fragment.html`**:
   Inside each `.prescription-card`, add:
   ```html
   <button class="btn-brutalist"
           hx-post="/api/prescriptions/{{.PrescriptionID}}/verify"
           hx-target="#verify-slot-{{.PrescriptionID}}"
           hx-swap="innerHTML">
       [ VERIFY FIX ]
   </button>
   <div id="verify-slot-{{.PrescriptionID}}"></div>
   ```

---

### Improvement 13: Log Anomaly Temporal Windowing & Acknowledged Signature Suppression
* **Target Tier**: Rust Log Ingestion (`kwikparse/src/main.rs`, `kwikparse/src/linux_logs.rs`), Go Orchestrator (`cmd/kwiklogd/orchestrator.go`, `cmd/kwiklogd/db.go`)
* **Problem Solved**: In `kwiklog_run_2.md`, errors from `2026-10-23` (`4 days` prior to the `2026-10-27` audit) are still treated as active failures. If an operator fixes a failed service or GPU driver and runs a new audit, `/var/log/syslog` still contains the old lines from days ago, causing KwikLogPro to re-trigger the exact same prescription.

#### Clean Implementation:
1. **Add `--since-hours <int>` to `kwikparse`** (default `72` hours for file logs, and current boot `-b` for `journalctl`).
2. **Acknowledged Signature Suppression**: When an operator acknowledges a prescription (`acknowledged = 1`) in `kwiklog.db`, record the `acknowledged_at_utc` timestamp. In `ExecutePipeline()`, pass `--since <last_ack_timestamp>` or filter out log anomalies whose `last_seen_utc` is older than the most recent acknowledgment of that rule!

---

### Improvement 14: Autonomous Background Watchdog Daemon Mode & SQLite WAL Retention Pruning
* **Target Tier**: Go Daemon (`cmd/kwiklogd/main.go`, `cmd/kwiklogd/db.go`)
* **Problem Solved**: Adds hands-free continuous monitoring and bounds disk usage of `kwiklog.db`.

#### Clean Implementation:
1. **CLI Flags in `cmd/kwiklogd/main.go`**:
   Add `--watch-interval <duration>` (e.g., `--watch-interval 6h`, default `0` = disabled) and `--max-runs <int>` (default `500`).
2. **Background Goroutine**:
   When `--serve` and `--watch-interval` are active, spawn a ticker goroutine that executes `orchestrator.ExecutePipeline(store, false, nil)`. If `bundle.Diag.OverallStatus == "CRITICAL"`, trigger a non-blocking local desktop alert via `notify-send -u critical "KwikLogPro Alert" "System Health dropped to CRITICAL"` (Linux) or PowerShell Toast notification (Windows).
3. **Database Pruning in `cmd/kwiklogd/db.go`**:
   ```go
   func (s *DBStore) PruneOldRuns(maxRuns int) error {
       s.mu.Lock()
       defer s.mu.Unlock()
       _, err := s.db.Exec(`
           DELETE FROM diagnostic_runs
           WHERE run_id NOT IN (
               SELECT run_id FROM diagnostic_runs ORDER BY timestamp_utc DESC LIMIT ?
           );`, maxRuns)
       return err
   }
   ```
   Because `telemetry_metrics`, `log_anomalies`, and `prescriptions` are defined with `ON DELETE CASCADE` in `schema.sql`, deleting old rows in `diagnostic_runs` automatically cleans all child tables in a single atomic operation!

---

### Improvement 15: Externalized JSON Policy Configuration & HTMX Run-to-Run Diff Engine
* **Target Tier**: Root Config (`config.json`), Go Server (`cmd/kwiklogd/server.go`), Python Engine (`kwikdiag/kwikdiag.py`), HTMX UI (`web/templates/report_fragment.html`)
* **Problem Solved**:
  1. Allows operators to tune static and OLS thresholds per hardware profile (e.g., thin-and-light Intel i3-1215U laptops vs. rackmount workstations) via `/home/auxk0rd/Desktop/KwikLogPro/config.json` without modifying Python source code.
  2. Adds an interactive `[ COMPARE RUNS (DIFF) ]` selector in the HTMX masthead (`GET /api/runs/diff?base=<runA>&target=<runB>`) that highlights newly triggered prescriptions, resolved prescriptions, and metric deltas ($\Delta$ CPU Temp, $\Delta$ RAM, $\Delta$ Health Score) between any two historical audits.

#### Clean Implementation:
1. **`config.json` Contract**:
   ```json
   {
     "ols_window_runs": 10,
     "log_lookback_hours": 72,
     "max_retained_runs": 500,
     "thresholds": {
       "cpu_idle_temp_celsius": 80.0,
       "cpu_idle_load_ceiling_pct": 15.0,
       "cpu_temp_ols_slope_per_week": 1.5,
       "mount_usage_crit_pct": 90.0,
       "swap_thrash_usage_pct": 85.0,
       "ram_avail_floor_pct": 5.0,
       "nvme_spare_floor_pct": 20
     }
   }
   ```
2. **HTMX Diff Endpoint (`GET /api/runs/diff` in `cmd/kwiklogd/server.go`)**:
   Loads `baseRun` and `targetRun` via `s.store.GetRun()`, computes set differences across `RuleID`s (`RESOLVED` in `#00FF66`, `NEW FAULT` in `#FF0033`, `PERSISTENT` in `#FFB000`), and swaps `#report-viewport` with a side-by-side Brutalist comparison table.

---

## 3. Clean Implementation Order & Build Hygiene Checklist

To implement these 15 improvements cleanly without breaking existing unit tests (`./dev.sh test`):

1. **Workspace Cleanup First**:
   Notice in your `tree` output that `kwikparse/target/debug/` and `kwikparse/target/release/` contain hundreds of intermediate `.o` and `.rlib` build artifacts, and `kwikdiag/__pycache__/` contains compiled `.pyc` files. Update `.gitignore` and `Makefile` (`clean` target) to purge `kwikdiag/__pycache__` alongside `kwikparse/target`.
2. **Phase A (Database & Contracts)**:
   Update `schema.sql`, `config.json`, and `cmd/kwiklogd/orchestrator.go` + `cmd/kwiklogd/db.go` (Improvements 2, 11, 14, 15).
3. **Phase B (Probes & Rust Log Engine)**:
   Update `probes/probe_pop.sh`, `probes/probe_win.bat`, `kwikparse/src/dedup.rs`, and `kwikparse/src/linux_logs.rs` (Improvements 3, 4, 5, 7, 8, 9, 13). Run `cd kwikparse && cargo test --offline`.
4. **Phase C (Python OLS & Rule Matrices)**:
   Update `kwikdiag/trends.py`, `kwikdiag/rules_pop.py`, `kwikdiag/rules_hw.py`, `kwikdiag/kwikdiag.py`, and `kwikdiag/test_kwikdiag.py` (Improvements 1, 6, 10). Run `python3 -m unittest discover -s kwikdiag -p "test_*.py"`.
5. **Phase D (Go HTMX Server & Templates)**:
   Update `cmd/kwiklogd/server.go`, `cmd/kwiklogd/main.go`, and `web/templates/report_fragment.html` (Improvements 12, 15). Run `./dev.sh build && ./dev.sh test`.

---

## 4. MANDATORY DIRECTIVE: Detailed Update Specification for `Handoff.md`

> **CRITICAL ARCHITECTURAL GOVERNANCE RULE**:  
> Every action taken while updating the KwikLogPro codebase **MUST** be documented in detail inside `/home/auxk0rd/Desktop/KwikLogPro/Handoff.md` **AND** synchronized immediately to `/home/auxk0rd/Desktop/KwikLogPro/Docs/Handoff.md` (while verifying that the symbolic link `/home/auxk0rd/Desktop/KwikLogPro/Code/Handoff.md -> ../Handoff.md` remains intact). No pull request or release bundle (`make bundle`) may be signed off until `Handoff.md` reflects the exact state of the codebase.

When implementing the 15 improvements above, you **must** update `Handoff.md` across the following sections in full detail:

### 4.1 Update Section 2 (`Complete Codebase Directory Tree`)
* Add `config.json` to the root directory tree description as the externalized threshold and retention policy configuration manifest.
* Document any new HTML template partials added under `web/templates/` (such as `diff_fragment.html` if separated from `report_fragment.html`).

### 4.2 Update Section 3.1 (`Core Orchestration and Storage Layer`)
* **`schema.sql`**: Document the new `is_simulated INTEGER NOT NULL DEFAULT 0` column and `idx_runs_sim_ts` index on `diagnostic_runs`, as well as any verification status columns (`verified INTEGER NOT NULL DEFAULT 0`, `last_verified_utc TEXT`) added to `prescriptions`.
* **`cmd/kwiklogd/main.go`**: Document the new CLI flags (`--config`, `--watch-interval`, `--max-runs`, `--since-hours`) and the sub-score breakdown (`HW SCORE` / `SW SCORE`) in `printCLIReport()`.
* **`cmd/kwiklogd/orchestrator.go`**: Document the expanded Contract 1 fields (`GPUModel`, `GPUTempCelsius`, `GPULoadPercent`, `TopMemProcesses`, `TopCPUProcesses`, `InterfaceCRCErrors`), Contract 3 fields (`HardwareScore`, `SoftwareScore`, `R2`, `EstimatedTTFDays`), and the `--since-hours` / `--config` subprocess arguments.
* **`cmd/kwiklogd/db.go`**: Document `PruneOldRuns(maxRuns int)`, the `GPU:temp_celsius` flattened metric insertion in `SaveDiagnosticRun()`, and the upgraded self-contained Brutalist HTML generator in `ExportRunReport()`.
* **`cmd/kwiklogd/server.go`**: Document the two new HTMX routes:
  * `POST /api/prescriptions/{id}/verify` (executes read-only `verification_cmd` with a 10s timeout and returns live pass/fail hypermedia output).
  * `GET /api/runs/diff` (computes and renders the Run-to-Run Diff view between `base` and `target` run IDs).

### 4.3 Update Section 3.2 (`Native OS Telemetry Probes Layer`)
* **`probes/probe_pop.sh` & `probes/probe_win.bat`**: Document the extraction of top 5 RSS memory and CPU processes (`top_mem_processes`, `top_cpu_processes`), GPU hardware telemetry (`nvidia-smi` / `rocm-smi` / DRM `hwmon` / `Win32_VideoController`), and ATA SMART attribute normalization (IDs `5`, `187`, `197`, `198`, `199`).

### 4.4 Update Section 3.3 (`High-Speed Rust Log Ingestion Layer`)
* **`kwikparse/src/dedup.rs`**: Document `strip_syslog_envelope()` (which unifies `/var/log/syslog` and `journalctl` JSON messages prior to SHA-256 hashing) and the expanded `DYNAMIC_TOKEN_RE` patterns covering unprefixed 64-bit hex pointers, ACPI object paths (`\_SB.*`), Wayland `Id(\d+)` tokens, and transient `.scope` suffixes.
* **`kwikparse/src/linux_logs.rs`**: Document the `BENIGN_IGNORE_RE` noise-suppression filter, user-session vs. system-daemon severity classification, and the `--since-hours` temporal cutoff filter.

### 4.5 Update Section 3.4 (`Deterministic Python Diagnostic and Prescription Engine Layer`)
* **`kwikdiag/trends.py`**: Document the $N = 2$ two-point velocity fallback formula, the $R^2$ goodness-of-fit calculation, the `EstimatedTTFDays` linear threshold projection formula, and the `is_simulated` SQLite query filter.
* **`kwikdiag/rules_pop.py`**: Document the new `POP_COSMIC_001` (COSMIC Desktop / XDG Portal crash remediation) and `POP_CRASH_001` (userspace binary segfault audit) rules, updating the total rule count in Sections 1.2 and 3.4.
* **`kwikdiag/rules_hw.py`**: Document ATA SMART error evaluation, `HW_DSK_003` (SATA/PCIe CRC interconnect faults), and live process culprit interpolation in `HW_MEM_002` and `HW_THM_001`.
* **`kwikdiag/kwikdiag.py`**: Document the domain-partitioned exponential health scoring formula ($60\%$ Hardware Integrity, $40\%$ Software Stability) replacing flat linear subtraction.

### 4.6 Append to Section 7 (`Recent Enhancements and Critical Bug Fixes`)
* Add numbered subsections `7.5` through `7.19` in `Handoff.md` recording the **Problem**, **Solution**, and **Impact** for each of the 15 architectural improvements implemented from this `UPDATE.md` specification, and synchronize the updated file via:
  ```bash
  cp /home/auxk0rd/Desktop/KwikLogPro/Handoff.md /home/auxk0rd/Desktop/KwikLogPro/Docs/Handoff.md
  ```