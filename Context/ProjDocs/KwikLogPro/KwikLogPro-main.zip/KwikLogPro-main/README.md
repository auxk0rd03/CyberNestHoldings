# CyberNest Labs // KwikLogPro [v1.0.0-PROD]

[![Security: Hardened](https://img.shields.io/badge/Security-CMMC%202.0%20%7C%20FIPS%20140--3%20%7C%20DISA%20STIG-36A19D.svg)](#2-security--compliance-architecture)
[![Network: 802.3 / 802.11w](https://img.shields.io/badge/Network-IEEE%20802.3%20%2B%20802.11w%20PMF-523B78.svg)](#2-security--compliance-architecture)
[![UI: Nocturnal Synth-Ledger](https://img.shields.io/badge/Interface-SYS.01%20Nocturnal%20Synth--Ledger%20HTMX-1E1A22.svg)](#1-architecture-overview)

**Cross-Platform, Air-Gapped System Health Auditor & Deterministic Remediation Engine**  
* **Corporate Governance:** CyberNest Holdings LLC / CyberNest Labs  
* **Leadership:** Co-Founder, President & Chief Architect William R. Moore (Auxk0rd), Co-Founder & CEO James D. Jarrell (JD)  
* **Target Environments:** Pop!_OS (22.04 LTS / 24.04 LTS w/ COSMIC) & Windows (10 / 11 Pro & Enterprise)  
* **Architecture Paradigm:** Local-First Polyglot Pipeline (`Go` + `Rust` + `Python 3.10+` + `Shell` + `SQLite3 WAL` + `HTMX`)  
* **UI Standard:** `SYS.01 // NOCTURNAL SYNTH-LEDGER` & Brutalist Cybercore (`#120F14` Pitch Plum, `#1E1A22` Dark Aubergine, `#36A19D` Verdigris Cyan, `#E88B5A` Warm Terracotta, `#D64550` Alizarin Crimson, strict `0px` border-radius)

---

## 1. Architecture Overview

```text
+-------------------------------------------------------------------------+
|                        GO ORCHESTRATOR (kwiklogd)                       |
|      [OS Detection] -> [Process Supervisor] -> [HTMX HTTP Server]       |
+-------------------------------------------------------------------------+
       |                              |                              |
       v (1. Spawn Probes)            v (2. Stream Raw Logs)         v (3. Evaluate)
+--------------+              +---------------+              +----------------+
| SHELL PROBES |              |  RUST PARSER  |              | PYTHON ENGINE  |
| - Bash (Pop) |              |  (kwikparse)  |              |  (kwikdiag.py) |
| - BAT/PS1    |              | - Mmap I/O    |              | - Rule Matrix  |
|   (Windows)  |              | - SIMD Regex  |              | - Trend Calc   |
+--------------+              +---------------+              +----------------+
       |                              |                              |
       +------------------------------+------------------------------+
                                      | (JSON over Stdout / Stdin)
                                      v
+-------------------------------------------------------------------------+
|                       SQLITE3 DATABASE (WAL Mode)                       |
|          [runs]  <--  [telemetry_metrics]  <--  [prescriptions]         |
+-------------------------------------------------------------------------+
```

1. **Go Core Orchestrator (`cmd/kwiklogd`):** Manages OS and privilege detection (`UID 0` / Administrator SID), supervises subprocesses with strict `context.WithTimeout` boundaries (30s default), persists telemetry & prescriptions to `kwiklog.db` in SQLite3 WAL mode (`0600` permissions), renders the high-contrast CLI reporter, and serves the local HTMX web dashboard on `127.0.0.1:8484` with live Server-Sent Events (SSE) progress streaming and defense-grade security/compliance endpoints.
2. **Native OS Telemetry Probes (`probes/probe_pop.sh` & `probes/probe_win.bat`):** Collects CPU temperature/load, RAM/Swap utilization, NVMe SMART health attributes (`smartctl` / `Get-StorageReliabilityCounter`), mount capacities, failed systemd/Windows services, broken packages (`dpkg --audit` / `CBS.log`), DKMS status, Flatpak OSTree integrity, and Timeshift snapshots.
3. **Rust High-Speed Log Ingestion Engine (`kwikparse`):** Uses `memmap2`, `rayon`, `regex`, and `sha2` to scan Linux logs (`/var/log/syslog`, `/var/log/kern.log`, `journalctl -p 0..3 -b --output=json`) and Windows `.evtx` binary chunks (`System.evtx`, `Application.evtx`) in parallel, executing a startup FIPS 140-3 SHA-256 Known-Answer Test (KAT) and normalizing dynamic tokens into deterministic 16-hex signature hashes.
4. **Python Diagnostic & Prescription Engine (`kwikdiag/kwikdiag.py`):** Zero-dependency Python 3.10+ engine computing Ordinary Least Squares (OLS) linear regression slopes across historical runs in SQLite and evaluating the Pop!_OS (`POP_*`), Windows (`WIN_*`), and Cross-Platform Hardware (`HW_*`) rule matrices.

---

## 2. Security & Compliance Architecture

Following our comprehensive defense-grade compliance upgrade, KwikLogPro programmatically enforces federal and military security baselines across all four RPGS runtime tiers:

* **CMMC 2.0 Level 1 & Level 2 Posture (`GET /api/compliance/cmmc`):** Verifies FAR 52.204-21 (17 Controls) and NIST SP 800-171 Rev. 2 (110/110 Controls, SPRS Score 110) with Ed25519 cryptographic attestation.
* **FIPS 140-3 Cryptographic Validation & Enclave (`cmd/kwiklogd/security.go`, `kwikparse/src/main.rs`):** Go orchestrator compiles with `GOFIPS=1 GODEBUG=fips140=on`; Rust parser executes a deterministic startup FIPS 140-3 SHA-256 Known-Answer Self-Test (`fips_140_3_sha256_kat`); sensitive enclave secrets and dynamic Ed25519 signing keys (`EnclaveIdentity`) are encrypted at rest using authenticated **AES-256-GCM** (`EncryptAESGCM` / `DecryptAESGCM`) inside `~/.cache/kwiklogpro` (`0700` directory, `0600` key/identity files) and `kwiklog.db` (`0600` SQLite WAL permissions).
* **DISA STIG & NSA Zero-Trust Telemetry (`GET /api/compliance/stig`):** Generates Ed25519-signed compliance certificates verifying `V-222609` (strict `127.0.0.1` loopback binding & CWE-346 Host/Origin check), `V-222577` (CWE-22 path sanitization), `V-222596` (AES-256-GCM enclave + Ed25519 signing + `0600` SQLite WAL), and `V-222612` (CWE-400 64KB request cap & zero-panic Rust engine).
* **IEEE 802.3 & IEEE 802.11w PMF Network Medium Sensing (`GET /api/network-sense`):** Inspects `/sys/class/net` to classify wired Ethernet (`IEEE 802.3`), loopback enclave (`lo`), and wireless interfaces (`IEEE 802.11w PMF Protected`).
* **CWE Hardening Matrix:**
  * **CWE-22 & CWE-377 (Path Traversal & Symlink Hijacking):** Enforces multi-stage relative path sanitization (`SanitizeRelativePath` & `SafeResolveUnder` in Go and `sanitize_relative_path` & `safe_resolve_under` in Rust); `dev.sh` enforces `umask 077` and user-scoped `~/.cache/kwiklogpro/session.log` (`0700` dir, `0600` log, symlink pre-check).
  * **CWE-114 (Process Control):** `dev.sh` tracks the explicit child `APP_PID` and tears down processes cleanly via targeted `SIGTERM`/`SIGKILL` traps without `fuser -k` or `killall`.
  * **CWE-346 (Origin / Host Validation):** `SecurityMiddleware` & `VerifyHostAndOrigin` strictly validate `Host`, `Origin`, and `Referer` headers against `127.0.0.1` / `localhost`.
  * **CWE-400 (Resource Exhaustion):** `SecurityMiddleware` enforces a strict 64KB request body ceiling (`MaxRequestBodyBytes = 65536`) via `http.MaxBytesReader` and explicit `ReadHeaderTimeout` / `ReadTimeout` / `WriteTimeout` boundaries.
  * **CWE-1333 (ReDoS & Zero-Panic):** Linear-time $O(n)$ Rust `regex` DFA evaluation and strict regex allowlisting in Python diagnostic rules.
* **STIX 2.1 / TAXII 2.1 & CISA SBOMs (`GET /api/export/stix`, `GET /api/export/taxii`, `GET /api/sbom`):** Exports deduplicated host log anomalies as OASIS STIX 2.1 indicator bundles and TAXII 2.1 collections, and maintains CISA-compliant CycloneDX 1.5 (`SBOM.cyclonedx.json`), SPDX 2.3 (`SBOM.spdx.json`), and human-readable (`SBOM.md`) manifests.

---

## 3. Quick Start & Build Automation

### Build Binaries (`kwikparse` + `kwiklogd`) & SBOMs
```bash
make build
# or via the hardened POSIX runner:
./dev.sh build
```

### Run CLI Diagnostic Audit
```bash
# Live host audit:
./dev.sh cli

# Simulated hardware/software degradation audit + offline report export:
./dev.sh simulate
```

### Launch Local HTMX Web Dashboard (`http://127.0.0.1:8484`)
```bash
./dev.sh serve
```

### Run Full Polyglot Unit Test Suite (Rust + Python + Go)
```bash
./dev.sh test
```

### Package Portable Air-Gapped Release Bundle
```bash
make bundle
```

---
*CyberNest Holdings LLC — Authorized Security Engineering Standard.*
