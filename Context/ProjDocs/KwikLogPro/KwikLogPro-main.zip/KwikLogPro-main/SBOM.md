# CISA-COMPLIANT SOFTWARE BILL OF MATERIALS (SBOM) // KWIKLOGPRO

## 1. Executive Order 14028 & CISA Minimum Elements Attestation

| CISA Mandatory Metadata Field | Verified Value |
| :--- | :--- |
| **SBOM Document Title** | `KwikLogPro - CyberNest CISA SBOM Ledger` |
| **SBOM Serial / Namespace UUID** | `urn:uuid:7d56906e-fb5c-57ad-acb4-79993d7cb9fa` |
| **Author of SBOM Data** | `CyberNest Holdings LLC - William Ray Moore (President & Chief Architect) & James Dwayne Jarrell (CEO)` |
| **Timestamp (UTC)** | `2026-10-29T20:04:56Z` |
| **Primary Supplier Name** | `CyberNest Holdings LLC (Internal Department: CyberNest Labs)` |
| **Corporate Jurisdiction & Registration** | `Commonwealth of Pennsylvania LLC // SAM.gov UEI & CAGE: Not Yet Assigned (Pre-Registration)` |
| **Target Repository / Source** | `.` |
| **Ingestion & Parse Engines** | `go_repo_ingestor + rust_sbom_scanner` |
| **Supported Machine Formats** | `CycloneDX 1.5 JSON (SBOM.cyclonedx.json)` & `SPDX 2.3 JSON (SBOM.spdx.json)` |
| **Zero External Runtime Dependency Guarantee** | `ENFORCED (100% Air-Gapped Autonomous Execution)` |
| **FIPS 140-3 Cryptographic Validation** | `ENABLED (GOFIPS=1 / AWS-LC-FIPS / SHA-256 & AES-256-GCM KAT Passed)` |
| **CMMC 2.0 Compliance Posture** | `CMMC Level 1 (FAR 52.204-21) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110)` |
| **Enforced CWE Mitigations** | `CWE-377, CWE-114, CWE-22, CWE-346, CWE-400, CWE-1333` |
| **Ed25519 Signer Key ID** | `CN-ED25519-99AC51E14879E456` |
| **Ed25519 Signature** | `7e6be248db791e58184b53a6f308bc7234a6a7d24af12dfb...` |

---

## 2. Component Inventory & Unique Identifiers (NTIA / CISA Minimum Elements)

| # | Component Name | Version | Ecosystem | Supplier | PURL (Unique ID) | License | Source Manifest | SHA-256 Digest |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `001` | `kwiklogpro` | `1.0.0` | `golang-root` | CyberNest Holdings LLC (Auxk0rd) | `pkg:golang/kwiklogpro@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `go.mod` | `167e9d758d0f8640...` |
| `002` | `github.com/mattn/go-sqlite3` | `1.14.22` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/mattn/go-sqlite3@v1.14.22` | `BSD-3-Clause OR MIT` | `go.mod` | `167e9d758d0f8640...` |
| `003` | `kwikparse` | `1.0.0` | `cargo-root` | CyberNest Holdings LLC (Auxk0rd) | `pkg:cargo/kwikparse@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `004` | `chrono` | `0.4` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/chrono@0.4` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `005` | `memmap2` | `0.9` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/memmap2@0.9` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `006` | `rayon` | `1.10` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/rayon@1.10` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `007` | `regex` | `1.11` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/regex@1.11` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `008` | `serde` | `1.0` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/serde@1.0` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `009` | `serde_json` | `1.0` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/serde_json@1.0` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |
| `010` | `sha2` | `0.10` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/sha2@0.10` | `MIT OR Apache-2.0` | `kwikparse/Cargo.toml` | `2526dedd356e2511...` |

---

## 3. Dependency Relationship Graph

* **Root Application Node**: `pkg:generic/cybernest/KwikLogPro@1.0.0`
  * `DEPENDS_ON` -> `pkg:golang/kwiklogpro@1.0.0` (`cpe:2.3:a:cybernest:kwiklogpro:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/mattn/go-sqlite3@v1.14.22` (`cpe:2.3:a:golang:github.com_mattn_go-sqlite3:1.14.22:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/kwikparse@1.0.0` (`cpe:2.3:a:cybernest:kwikparse:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/chrono@0.4` (`cpe:2.3:a:rust-lang:chrono:0.4:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/memmap2@0.9` (`cpe:2.3:a:rust-lang:memmap2:0.9:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/rayon@1.10` (`cpe:2.3:a:rust-lang:rayon:1.10:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/regex@1.11` (`cpe:2.3:a:rust-lang:regex:1.11:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/serde@1.0` (`cpe:2.3:a:rust-lang:serde:1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/serde_json@1.0` (`cpe:2.3:a:rust-lang:serde_json:1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/sha2@0.10` (`cpe:2.3:a:rust-lang:sha2:0.10:*:*:*:*:*:*:*`)

---

## 4. Cryptographic Integrity & CWE Hardening Attestation

* **Files Cryptographically Hashed (SHA-256)**: `21`
* **Shannon Entropy High-Risk Secret Alerts**: `0`
* **Ed25519 Public Key**: `99ac51e14879e456c9747f49ff458f77e3fb3d60ec822762e6ac5ef5438f6315`
* **Full Ed25519 Signature**: `7e6be248db791e58184b53a6f308bc7234a6a7d24af12dfbda69260fba885a8ebe52bcbd859748e341fd2d6bda38e2afaedfc1b3d027c72308a839bb2dfed502`

*Generated automatically by CyberNest Labs NestSBOM RPGS Engine.*
