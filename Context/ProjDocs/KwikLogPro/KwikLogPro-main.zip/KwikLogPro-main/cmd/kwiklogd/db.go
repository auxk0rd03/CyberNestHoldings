package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"

	_ "github.com/mattn/go-sqlite3"
)

// DiagnosticRunRecord represents a row in diagnostic_runs.
type DiagnosticRunRecord struct {
	RunID            int64
	TimestampUTC     string
	OSFamily         string
	OSDistro         string
	KernelVersion    string
	HealthScore      int
	OverallStatus    string
	ScanDurationMs   int64
	RawTelemetryJSON string
}

// DBStore manages concurrent WAL access to kwiklog.db.
type DBStore struct {
	db     *sql.DB
	dbPath string
	mu     sync.Mutex
}

// NewDBStore opens or initializes kwiklog.db in SQLite3 WAL mode and applies schema.sql.
func NewDBStore(dbPath, schemaPath string) (*DBStore, error) {
	dsn := fmt.Sprintf("file:%s?_busy_timeout=5000&_journal_mode=WAL&_foreign_keys=on", dbPath)
	db, err := sql.Open("sqlite3", dsn)
	if err != nil {
		return nil, fmt.Errorf("failed to open sqlite db: %w", err)
	}
	db.SetMaxOpenConns(4)

	pragmas := []string{
		"PRAGMA journal_mode = WAL;",
		"PRAGMA synchronous = NORMAL;",
		"PRAGMA foreign_keys = ON;",
		"PRAGMA busy_timeout = 5000;",
	}
	for _, p := range pragmas {
		if _, err := db.Exec(p); err != nil {
			_ = db.Close()
			return nil, fmt.Errorf("failed to set pragma (%s): %w", p, err)
		}
	}

	schemaBytes, err := os.ReadFile(schemaPath)
	if err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("failed to read schema.sql: %w", err)
	}
	if _, err := db.Exec(string(schemaBytes)); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("failed to apply schema.sql: %w", err)
	}
	_ = os.Chmod(dbPath, 0600)

	return &DBStore{
		db:     db,
		dbPath: dbPath,
	}, nil
}

// Close closes the underlying database connection pool.
func (s *DBStore) Close() error {
	return s.db.Close()
}

// SaveDiagnosticRun persists a complete scan bundle across diagnostic_runs, telemetry_metrics, log_anomalies, and prescriptions.
func (s *DBStore) SaveDiagnosticRun(bundle *CombinedScanBundle, scanDurationMs int64) (int64, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	rawJSON, err := json.Marshal(bundle)
	if err != nil {
		return 0, err
	}

	tx, err := s.db.Begin()
	if err != nil {
		return 0, err
	}
	defer func() { _ = tx.Rollback() }()

	osFamily := strings.ToLower(bundle.Telemetry.OSFamily)
	if osFamily != "linux" && osFamily != "windows" {
		osFamily = "linux"
	}

	status := strings.ToUpper(bundle.Diag.OverallStatus)
	if status != "OPTIMAL" && status != "DEGRADED" && status != "CRITICAL" {
		status = "DEGRADED"
	}

	res, err := tx.Exec(
		`INSERT INTO diagnostic_runs
		(timestamp_utc, os_family, os_distro, kernel_version, health_score, overall_status, scan_duration_ms, raw_telemetry_json)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
		bundle.Telemetry.TimestampUTC,
		osFamily,
		bundle.Telemetry.OSDistro,
		bundle.Telemetry.KernelVersion,
		bundle.Diag.OverallHealthScore,
		status,
		scanDurationMs,
		string(rawJSON),
	)
	if err != nil {
		return 0, err
	}

	runID, err := res.LastInsertId()
	if err != nil {
		return 0, err
	}

	// 2. Insert flattened telemetry_metrics
	hw := bundle.Telemetry.Hardware
	insertMetric := func(comp, name string, val float64) error {
		_, err := tx.Exec(
			`INSERT INTO telemetry_metrics (run_id, component_type, metric_name, metric_value) VALUES (?, ?, ?, ?)`,
			runID, comp, name, val,
		)
		return err
	}

	if err := insertMetric("CPU", "temp_celsius", hw.CPUTempCelsius); err != nil {
		return 0, err
	}
	if err := insertMetric("CPU", "load_percent", hw.CPULoadPercent); err != nil {
		return 0, err
	}

	ramUsedPct := 0.0
	if hw.RAMTotalBytes > 0 {
		ramUsedPct = float64(hw.RAMTotalBytes-hw.RAMAvailBytes) / float64(hw.RAMTotalBytes) * 100.0
	}
	if err := insertMetric("RAM", "used_pct", ramUsedPct); err != nil {
		return 0, err
	}

	swapUsedPct := 0.0
	if hw.SwapTotalBytes > 0 {
		swapUsedPct = float64(hw.SwapUsedBytes) / float64(hw.SwapTotalBytes) * 100.0
	}
	if err := insertMetric("SWAP", "used_pct", swapUsedPct); err != nil {
		return 0, err
	}

	for _, d := range hw.Disks {
		comp := "DISK:" + d.Device
		_ = insertMetric(comp, "temp_celsius", d.TempCelsius)
		_ = insertMetric(comp, "available_spare_pct", float64(d.AvailableSparePct))
		_ = insertMetric(comp, "percentage_used", float64(d.PercentageUsed))
		_ = insertMetric(comp, "media_errors", float64(d.MediaErrors))
		_ = insertMetric(comp, "unsafe_shutdowns", float64(d.UnsafeShutdowns))
	}

	// 3. Insert deduplicated log_anomalies
	for _, a := range bundle.LogParser.Anomalies {
		var evID interface{}
		if a.EventID != nil {
			evID = *a.EventID
		}
		_, err := tx.Exec(
			`INSERT INTO log_anomalies
			(run_id, signature_hash, source, event_id, severity, category, first_seen_utc, last_seen_utc, occurrence_count, sample_message)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
			runID, a.SignatureHash, a.Source, evID, a.Severity, a.Category, a.FirstSeenUTC, a.LastSeenUTC, a.OccurrenceCount, a.SampleMessage,
		)
		if err != nil {
			return 0, err
		}
	}

	// 4. Insert triggered prescriptions
	for i := range bundle.Diag.TriggeredPrescriptions {
		p := &bundle.Diag.TriggeredPrescriptions[i]
		steps := p.Commands
		if p.RemediationType == "PHYSICAL_INTERVENTION" {
			steps = p.PhysicalSteps
		}
		p.ActionSteps = steps
		payloadJSON, _ := json.Marshal(steps)
		risk := p.RiskLevel
		if risk == "" {
			risk = "SAFE"
		}
		pRes, err := tx.Exec(
			`INSERT INTO prescriptions
			(run_id, rule_id, severity, domain, title, finding_summary, historical_context, remediation_type, action_payload_json, verification_cmd, risk_level, acknowledged)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)`,
			runID, p.RuleID, p.Severity, p.Domain, p.Title, p.FindingSummary, p.HistoricalContext, p.RemediationType, string(payloadJSON), p.VerificationCmd, risk,
		)
		if err != nil {
			return 0, err
		}
		p.PrescriptionID, _ = pRes.LastInsertId()
	}

	if err := tx.Commit(); err != nil {
		return 0, err
	}
	return runID, nil
}

// GetRun retrieves a specific diagnostic run (or the latest run if runID <= 0).
func (s *DBStore) GetRun(runID int64) (*DiagnosticRunRecord, *CombinedScanBundle, error) {
	var row *sql.Row
	if runID <= 0 {
		row = s.db.QueryRow(
			`SELECT run_id, timestamp_utc, os_family, os_distro, kernel_version, health_score, overall_status, scan_duration_ms, raw_telemetry_json
			 FROM diagnostic_runs ORDER BY run_id DESC LIMIT 1`,
		)
	} else {
		row = s.db.QueryRow(
			`SELECT run_id, timestamp_utc, os_family, os_distro, kernel_version, health_score, overall_status, scan_duration_ms, raw_telemetry_json
			 FROM diagnostic_runs WHERE run_id = ?`,
			runID,
		)
	}

	var rec DiagnosticRunRecord
	if err := row.Scan(
		&rec.RunID,
		&rec.TimestampUTC,
		&rec.OSFamily,
		&rec.OSDistro,
		&rec.KernelVersion,
		&rec.HealthScore,
		&rec.OverallStatus,
		&rec.ScanDurationMs,
		&rec.RawTelemetryJSON,
	); err != nil {
		return nil, nil, err
	}

	var bundle CombinedScanBundle
	if err := json.Unmarshal([]byte(rec.RawTelemetryJSON), &bundle); err != nil {
		return &rec, nil, err
	}

	// Hydrate prescriptions from the relational table so acknowledged flags & IDs are accurate
	prescriptions, err := s.GetPrescriptions(rec.RunID, "")
	if err == nil {
		bundle.Diag.TriggeredPrescriptions = prescriptions
	}

	return &rec, &bundle, nil
}

// ListRecentRuns returns the most recent N diagnostic run headers.
func (s *DBStore) ListRecentRuns(limit int) ([]DiagnosticRunRecord, error) {
	rows, err := s.db.Query(
		`SELECT run_id, timestamp_utc, os_family, os_distro, kernel_version, health_score, overall_status, scan_duration_ms, ''
		 FROM diagnostic_runs ORDER BY run_id DESC LIMIT ?`,
		limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []DiagnosticRunRecord
	for rows.Next() {
		var r DiagnosticRunRecord
		if err := rows.Scan(&r.RunID, &r.TimestampUTC, &r.OSFamily, &r.OSDistro, &r.KernelVersion, &r.HealthScore, &r.OverallStatus, &r.ScanDurationMs, &r.RawTelemetryJSON); err != nil {
			return nil, err
		}
		list = append(list, r)
	}
	return list, nil
}

// GetPrescriptions queries prescriptions for a run, optionally filtered by SOFTWARE or HARDWARE domain.
func (s *DBStore) GetPrescriptions(runID int64, domain string) ([]TriggeredPrescription, error) {
	query := `SELECT prescription_id, rule_id, severity, domain, title, finding_summary, COALESCE(historical_context, ''), remediation_type, action_payload_json, COALESCE(verification_cmd, ''), COALESCE(risk_level, 'SAFE'), acknowledged
			  FROM prescriptions WHERE run_id = ?`
	args := []interface{}{runID}
	if domain == "SOFTWARE" || domain == "HARDWARE" {
		query += ` AND domain = ?`
		args = append(args, domain)
	}
	query += ` ORDER BY CASE severity WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END, prescription_id ASC`

	rows, err := s.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []TriggeredPrescription
	for rows.Next() {
		var p TriggeredPrescription
		var payloadJSON string
		var ackInt int
		if err := rows.Scan(
			&p.PrescriptionID,
			&p.RuleID,
			&p.Severity,
			&p.Domain,
			&p.Title,
			&p.FindingSummary,
			&p.HistoricalContext,
			&p.RemediationType,
			&payloadJSON,
			&p.VerificationCmd,
			&p.RiskLevel,
			&ackInt,
		); err != nil {
			return nil, err
		}
		p.Acknowledged = ackInt != 0
		var steps []string
		_ = json.Unmarshal([]byte(payloadJSON), &steps)
		p.ActionSteps = steps
		if p.RemediationType == "PHYSICAL_INTERVENTION" {
			p.PhysicalSteps = steps
		} else {
			p.Commands = steps
		}
		out = append(out, p)
	}
	return out, nil
}

// AcknowledgePrescription marks a prescription as acknowledged in SQLite.
func (s *DBStore) AcknowledgePrescription(prescriptionID int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	_, err := s.db.Exec(`UPDATE prescriptions SET acknowledged = 1 WHERE prescription_id = ?`, prescriptionID)
	return err
}

// ExportRunReport writes a standalone Markdown & HTML report into ./exports/ for offline archiving.
func (s *DBStore) ExportRunReport(runID int64, exportDir string) (string, string, error) {
	rec, bundle, err := s.GetRun(runID)
	if err != nil {
		return "", "", err
	}
	if err := os.MkdirAll(exportDir, 0755); err != nil {
		return "", "", err
	}

	mdPath := filepath.Join(exportDir, fmt.Sprintf("kwiklog_run_%d.md", rec.RunID))
	htmlPath := filepath.Join(exportDir, fmt.Sprintf("kwiklog_run_%d.html", rec.RunID))

	var md strings.Builder
	fmt.Fprintf(&md, "# KWIKLOGPRO OFFLINE DIAGNOSTIC REPORT // RUN #%d\n\n", rec.RunID)
	fmt.Fprintf(&md, "- **Timestamp (UTC):** `%s`\n", rec.TimestampUTC)
	fmt.Fprintf(&md, "- **OS Distro:** `%s` (`%s`)\n", rec.OSDistro, rec.KernelVersion)
	fmt.Fprintf(&md, "- **Overall Status:** `%s`\n", rec.OverallStatus)
	fmt.Fprintf(&md, "- **Health Score:** `%d / 100`\n", rec.HealthScore)
	fmt.Fprintf(&md, "- **Scan Duration:** `%d ms`\n\n", rec.ScanDurationMs)

	hw := bundle.Telemetry.Hardware
	fmt.Fprintf(&md, "## 1. Hardware Telemetry Snapshot\n\n")
	fmt.Fprintf(&md, "- **CPU:** %s (`%.1f °C`, Load `%.1f%%`)\n", hw.CPUModel, hw.CPUTempCelsius, hw.CPULoadPercent)
	fmt.Fprintf(&md, "- **RAM:** `%d` bytes available of `%d` bytes total\n", hw.RAMAvailBytes, hw.RAMTotalBytes)
	fmt.Fprintf(&md, "- **Swap:** `%d` bytes used of `%d` bytes total\n\n", hw.SwapUsedBytes, hw.SwapTotalBytes)

	fmt.Fprintf(&md, "## 2. Prescribed Remediation Queue (%d)\n\n", len(bundle.Diag.TriggeredPrescriptions))
	for _, p := range bundle.Diag.TriggeredPrescriptions {
		fmt.Fprintf(&md, "### [%s] `%s` — %s (%s)\n", p.Severity, p.RuleID, p.Title, p.Domain)
		fmt.Fprintf(&md, "- **Finding:** %s\n", p.FindingSummary)
		if p.HistoricalContext != "" {
			fmt.Fprintf(&md, "- **Historical Context:** %s\n", p.HistoricalContext)
		}
		fmt.Fprintf(&md, "- **Remediation (%s):**\n", p.RemediationType)
		for idx, step := range p.ActionSteps {
			fmt.Fprintf(&md, "  %d. `%s`\n", idx+1, step)
		}
		if p.VerificationCmd != "" {
			fmt.Fprintf(&md, "- **Verification:** `%s`\n", p.VerificationCmd)
		}
		fmt.Fprintf(&md, "\n")
	}

	fmt.Fprintf(&md, "## 3. Deduplicated Log Anomalies (%d)\n\n", len(bundle.LogParser.Anomalies))
	for _, a := range bundle.LogParser.Anomalies {
		fmt.Fprintf(&md, "- **[%s] %dx** `%s` (%s) — `%s` (Last seen: `%s`)\n",
			a.Severity, a.OccurrenceCount, a.Source, a.Category, a.SampleMessage, a.LastSeenUTC)
	}

	if err := os.WriteFile(mdPath, []byte(md.String()), 0644); err != nil {
		return "", "", err
	}

	htmlContent := fmt.Sprintf(`<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>KwikLogPro Report #%d</title>
<style>body{background:#0A0A0A;color:#EAEAEA;font-family:monospace;padding:24px;} pre{background:#121212;border:1px solid #2A2A2A;padding:16px;white-space:pre-wrap;}</style>
</head><body><pre>%s</pre></body></html>`, rec.RunID, md.String())

	if err := os.WriteFile(htmlPath, []byte(htmlContent), 0644); err != nil {
		return mdPath, "", err
	}

	return mdPath, htmlPath, nil
}
