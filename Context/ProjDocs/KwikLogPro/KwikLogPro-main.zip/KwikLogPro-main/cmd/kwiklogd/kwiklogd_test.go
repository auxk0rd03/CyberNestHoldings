package main

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestSQLiteWALStoreAndHTMXServer(t *testing.T) {
	tmpDir := t.TempDir()
	dbPath := filepath.Join(tmpDir, "test_kwiklog.db")
	schemaPath := filepath.Join("..", "..", "schema.sql")

	store, err := NewDBStore(dbPath, schemaPath)
	if err != nil {
		t.Fatalf("NewDBStore failed: %v", err)
	}
	defer store.Close()

	sampleBundle := &CombinedScanBundle{
		Telemetry: TelemetryPayload{
			SchemaVersion: "1.0",
			TimestampUTC:  "2026-10-27T04:15:00Z",
			OSFamily:      "linux",
			OSDistro:      "Pop!_OS 24.04 LTS",
			KernelVersion: "6.9.3-76060903-generic",
			UptimeSeconds: 432190,
			Hardware: HardwareTelemetry{
				CPUModel:       "AMD Ryzen 9 7950X",
				CPUTempCelsius: 88.5,
				CPULoadPercent: 14.2,
				RAMTotalBytes:  68719476736,
				RAMAvailBytes:  4294967296,
				SwapTotalBytes: 17179869184,
				SwapUsedBytes:  15032385536,
				Disks: []DiskTelemetry{
					{
						Device:            "/dev/nvme0n1",
						Model:             "Samsung SSD 990 PRO 2TB",
						SmartPassed:       true,
						TempCelsius:       64,
						AvailableSparePct: 98,
						PercentageUsed:    12,
						MediaErrors:       4,
						UnsafeShutdowns:   19,
						MountPoints: []MountPoint{
							{Path: "/", FSType: "ext4", UsedPct: 94.2},
						},
					},
				},
			},
			SoftwareState: SoftwareState{
				FailedServices:      []string{"networking.service", "fwupd.service"},
				BrokenPackagesCount: 3,
				HeldPackages:        []string{"linux-image-generic"},
			},
		},
		LogParser: ParserOutput{
			ParseDurationMs:    142,
			BytesProcessed:     1073741824,
			TotalEventsScanned: 845920,
			Anomalies: []LogAnomaly{
				{
					SignatureHash:   "a94a8fe5ccb19ba6",
					Source:          "kernel",
					Severity:        "CRITICAL",
					Category:        "STORAGE_IO",
					FirstSeenUTC:    "2026-10-25T11:20:01Z",
					LastSeenUTC:     "2026-10-27T03:59:12Z",
					OccurrenceCount: 47,
					SampleMessage:   "blk_update_request: I/O error, dev nvme0n1, sector 89234112 op 0x0:(READ)",
				},
			},
		},
		Diag: DiagOutput{
			OverallHealthScore:  42,
			OverallStatus:       "CRITICAL",
			EvaluatedRulesCount: 38,
			TriggeredPrescriptions: []TriggeredPrescription{
				{
					RuleID:            "POP_PKG_001",
					Severity:          "HIGH",
					Domain:            "SOFTWARE",
					Title:             "Interrupted DPKG & Broken APT Dependencies Detected",
					FindingSummary:    "3 packages are in an unconfigured state.",
					HistoricalContext: "First detected in current run.",
					RemediationType:   "CLI_COMMAND",
					Commands:          []string{"sudo dpkg --configure -a"},
					VerificationCmd:   "sudo dpkg --audit",
					RiskLevel:         "SAFE",
				},
				{
					RuleID:            "HW_NVME_002",
					Severity:          "CRITICAL",
					Domain:            "HARDWARE",
					Title:             "NVMe Media Integrity Errors & Kernel Read Failures",
					FindingSummary:    "Device /dev/nvme0n1 reported 4 SMART media_errors.",
					HistoricalContext: "Media errors increased by +4 over the last 3 runs.",
					RemediationType:   "PHYSICAL_INTERVENTION",
					PhysicalSteps:     []string{"Back up critical data immediately."},
					RiskLevel:         "CRITICAL_HARDWARE",
				},
			},
			ScoreTrajectory: []int{94, 78, 42},
		},
	}

	runID, err := store.SaveDiagnosticRun(sampleBundle, 185)
	if err != nil {
		t.Fatalf("SaveDiagnosticRun failed: %v", err)
	}
	if runID != 1 {
		t.Fatalf("expected runID 1, got %d", runID)
	}

	// Verify HTTP Dashboard & HTMX Partials
	orch := NewOrchestrator(tmpDir, dbPath)
	srv, err := NewServer(store, orch, false)
	if err != nil {
		t.Fatalf("NewServer failed: %v", err)
	}
	handler := srv.Routes()

	// 1. GET /
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	rec := httptest.NewRecorder()
	handler.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GET / returned %d", rec.Code)
	}
	body := rec.Body.String()
	if !strings.Contains(body, "KWIKLOGPRO") || !strings.Contains(body, "HW_NVME_002") || !strings.Contains(body, "POP_PKG_001") {
		t.Fatalf("GET / body missing expected diagnostic blocks")
	}

	// 2. GET /api/prescriptions?domain=HARDWARE
	reqHw := httptest.NewRequest(http.MethodGet, "/api/prescriptions?run_id=1&domain=HARDWARE", nil)
	recHw := httptest.NewRecorder()
	handler.ServeHTTP(recHw, reqHw)
	if recHw.Code != http.StatusOK {
		t.Fatalf("GET /api/prescriptions?domain=HARDWARE returned %d", recHw.Code)
	}
	hwBody := recHw.Body.String()
	if !strings.Contains(hwBody, "HW_NVME_002") || strings.Contains(hwBody, "POP_PKG_001") {
		t.Fatalf("HARDWARE domain filter did not isolate hardware prescriptions")
	}

	// 3. POST /api/export/1
	reqExp := httptest.NewRequest(http.MethodPost, "/api/export/1", nil)
	recExp := httptest.NewRecorder()
	handler.ServeHTTP(recExp, reqExp)
	if recExp.Code != http.StatusOK || !strings.Contains(recExp.Body.String(), "OFFLINE ARCHIVE EXPORTED") {
		t.Fatalf("POST /api/export/1 failed: %d %s", recExp.Code, recExp.Body.String())
	}

	// 4. Verify CWE-22, CWE-346, AES-256-GCM, Ed25519, STIX/TAXII, and CMMC/STIG endpoints
	if _, err := SanitizeRelativePath("../etc/passwd"); err == nil {
		t.Fatalf("expected CWE-22 rejection for ../etc/passwd")
	}
	if _, err := SafeResolveUnder(tmpDir, "reports/run1.md"); err != nil {
		t.Fatalf("expected valid SafeResolveUnder, got %v", err)
	}
	ct, err := EncryptAESGCM([]byte("KWIKLOG-CUI-SECRET"))
	if err != nil {
		t.Fatalf("EncryptAESGCM failed: %v", err)
	}
	pt, err := DecryptAESGCM(ct)
	if err != nil || string(pt) != "KWIKLOG-CUI-SECRET" {
		t.Fatalf("DecryptAESGCM mismatch: %v", err)
	}
	for _, ep := range []string{"/api/compliance/cmmc", "/api/compliance/stig", "/api/export/stix", "/api/export/taxii", "/api/network-sense"} {
		rEp := httptest.NewRequest(http.MethodGet, ep, nil)
		wEp := httptest.NewRecorder()
		handler.ServeHTTP(wEp, rEp)
		if wEp.Code != http.StatusOK {
			t.Fatalf("GET %s returned %d", ep, wEp.Code)
		}
	}
	// Verify CWE-346 blocks external Host/Origin
	rEvil := httptest.NewRequest(http.MethodGet, "/", nil)
	rEvil.Host = "evil.attacker.org"
	wEvil := httptest.NewRecorder()
	handler.ServeHTTP(wEvil, rEvil)
	if wEvil.Code != http.StatusForbidden {
		t.Fatalf("expected 403 Forbidden for untrusted Host, got %d", wEvil.Code)
	}
}
