package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	ansiReset = "\033[0m"
	ansiBold  = "\033[1m"
	ansiGreen = "\033[38;2;0;255;102m"
	ansiAmber = "\033[38;2;255;176;0m"
	ansiRed   = "\033[38;2;255;0;51m"
	ansiMuted = "\033[38;2;140;140;140m"
)

func colorForStatus(status string) string {
	switch strings.ToUpper(status) {
	case "OPTIMAL", "OPT", "LOW", "SAFE":
		return ansiGreen
	case "DEGRADED", "WARN", "MEDIUM", "HIGH":
		return ansiAmber
	case "CRITICAL", "CRIT":
		return ansiRed
	default:
		return ansiReset
	}
}

func printCLIReport(runID int64, bundle *CombinedScanBundle, isPrivileged bool) {
	border := "+" + strings.Repeat("-", 82) + "+"
	fmt.Println(border)
	fmt.Printf("| %sKWIKLOGPRO // v1.0.0-PROD%s              OS: %-37s |\n",
		ansiBold, ansiReset, fmt.Sprintf("%s [%s]", bundle.Telemetry.OSDistro, bundle.Telemetry.KernelVersion))

	stColor := colorForStatus(bundle.Diag.OverallStatus)
	fmt.Printf("| STATUS: %s[ %-8s ]%s                   SCORE: %s[ %3d / 100 ]%s   RUN ID: #%-9d |\n",
		stColor, bundle.Diag.OverallStatus, ansiReset,
		stColor, bundle.Diag.OverallHealthScore, ansiReset,
		runID)
	fmt.Println(border)

	if !isPrivileged {
		fmt.Printf("| %s[!] WARNING: DEGRADED UNPRIVILEGED MODE (UID != 0). Direct SMART restricted.%s    |\n", ansiAmber, ansiReset)
		fmt.Println(border)
	}

	hw := bundle.Telemetry.Hardware
	ramUsedPct := 0.0
	if hw.RAMTotalBytes > 0 {
		ramUsedPct = float64(hw.RAMTotalBytes-hw.RAMAvailBytes) / float64(hw.RAMTotalBytes) * 100.0
	}
	swapUsedPct := 0.0
	if hw.SwapTotalBytes > 0 {
		swapUsedPct = float64(hw.SwapUsedBytes) / float64(hw.SwapTotalBytes) * 100.0
	}

	fmt.Printf("| %-38s | %-39s |\n", "TELEMETRY SNAPSHOT", "HISTORICAL DEGRADATION (LAST 10 RUNS)")
	fmt.Println("|" + strings.Repeat("-", 40) + "|" + strings.Repeat("-", 41) + "|")

	cpuTrend := bundle.Diag.HistoricalTrends["CPU:temp_celsius"]
	fmt.Printf("| CPU TEMP : %5.1f C  %-12s       | CPU IDLE TEMP     : %+5.1f C (%+.2fC/d)  |\n",
		hw.CPUTempCelsius, buildASCIIGauge(hw.CPUTempCelsius), cpuTrend.Delta, cpuTrend.SlopePerDay)

	var scoreParts []string
	for _, s := range bundle.Diag.ScoreTrajectory {
		scoreParts = append(scoreParts, fmt.Sprintf("%d", s))
	}
	scoreTraj := strings.Join(scoreParts, " -> ")
	if len(scoreTraj) > 19 {
		scoreTraj = scoreTraj[len(scoreTraj)-19:]
	}

	fmt.Printf("| RAM USED : %5.1f %%  %-12s       | HEALTH SCORE      : %-19s |\n",
		ramUsedPct, buildASCIIGauge(ramUsedPct), scoreTraj)

	tsLabel := "ACTIVE"
	if !bundle.Telemetry.SoftwareState.TimeshiftStatus.Installed {
		tsLabel = "UNINSTALLED"
	} else if bundle.Telemetry.SoftwareState.TimeshiftStatus.SnapshotCount == 0 {
		tsLabel = "NEVER [ALERT]"
	}
	fmt.Printf("| SWAP USED: %5.1f %%  %-12s       | LAST TIMESHIFT    : %-19s |\n",
		swapUsedPct, buildASCIIGauge(swapUsedPct), tsLabel)

	for _, d := range hw.Disks {
		meTrend := bundle.Diag.HistoricalTrends["DISK:"+d.Device+":media_errors"]
		fmt.Printf("| %-8s : %3d%% SPR %-12s       | NVME MEDIA ERRORS : %+d (SLOPE: %+.2f/r) |\n",
			strings.ToUpper(filepath.Base(d.Device)), d.AvailableSparePct, buildASCIIGauge(float64(d.AvailableSparePct)),
			int(meTrend.Delta), meTrend.SlopePerRun)
	}
	fmt.Println(border)

	fmt.Printf("| %sPRESCRIBED REMEDIATION QUEUE (%d DIRECTIVES)%s                                      |\n",
		ansiBold, len(bundle.Diag.TriggeredPrescriptions), ansiReset)
	fmt.Println(border)

	if len(bundle.Diag.TriggeredPrescriptions) == 0 {
		fmt.Printf("| %s[OPTIMAL] Zero remediation directives triggered. System is healthy.%s              |\n", ansiGreen, ansiReset)
		fmt.Println(border)
	} else {
		for _, p := range bundle.Diag.TriggeredPrescriptions {
			c := colorForStatus(p.Severity)
			fmt.Printf("| %s[!] RULE: %-12s // SEVERITY: %-8s // DOMAIN: %-10s%s               |\n",
				c, p.RuleID, p.Severity, p.Domain, ansiReset)
			fmt.Printf("| FINDING : %-70s |\n", truncateStr(p.FindingSummary, 70))
			if p.HistoricalContext != "" {
				fmt.Printf("| CONTEXT : %-70s |\n", truncateStr(p.HistoricalContext, 70))
			}
			if p.RemediationType == "PHYSICAL_INTERVENTION" {
				fmt.Printf("| ACTION  : %sPHYSICAL INTERVENTION REQUIRED%s                                         |\n", ansiRed, ansiReset)
				for idx, step := range p.ActionSteps {
					fmt.Printf("|   [%d] %-74s |\n", idx+1, truncateStr(step, 74))
				}
			} else {
				for _, cmd := range p.ActionSteps {
					fmt.Printf("| COMMAND : %s$ %-68s%s |\n", ansiGreen, truncateStr(cmd, 68), ansiReset)
				}
				if p.VerificationCmd != "" {
					fmt.Printf("| VERIFY  : %s$ %-68s%s |\n", ansiMuted, truncateStr(p.VerificationCmd, 68), ansiReset)
				}
			}
			fmt.Println(border)
		}
	}

	fmt.Printf("| DEDUPLICATED LOG ANOMALIES (RUST KWIKPARSE: %s SCANNED IN %dms)           |\n",
		formatBytes(bundle.LogParser.BytesProcessed), bundle.LogParser.ParseDurationMs)
	fmt.Println(border)
	if len(bundle.LogParser.Anomalies) == 0 {
		fmt.Printf("| %s[OK] Zero critical/error log signatures detected.%s                                |\n", ansiGreen, ansiReset)
	} else {
		fmt.Println("| COUNT | LAST SEEN            | SOURCE   | MESSAGE                                |")
		for _, a := range bundle.LogParser.Anomalies {
			fmt.Printf("| %-5s | %-20s | %-8s | %-38s |\n",
				fmt.Sprintf("%dx", a.OccurrenceCount),
				truncateStr(a.LastSeenUTC, 20),
				truncateStr(a.Source, 8),
				truncateStr(a.SampleMessage, 38))
		}
	}
	fmt.Println(border)
}

func truncateStr(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	if maxLen <= 3 {
		return s[:maxLen]
	}
	return s[:maxLen-3] + "..."
}

func resolveRootDir() string {
	if envRoot := os.Getenv("KWIKLOG_ROOT"); envRoot != "" {
		return envRoot
	}
	cwd, err := os.Getwd()
	if err == nil {
		if _, err := os.Stat(filepath.Join(cwd, "schema.sql")); err == nil {
			return cwd
		}
	}
	exe, err := os.Executable()
	if err == nil {
		exeDir := filepath.Dir(exe)
		parent := filepath.Dir(exeDir)
		if _, err := os.Stat(filepath.Join(parent, "schema.sql")); err == nil {
			return parent
		}
	}
	return "."
}

func main() {
	cliMode := flag.Bool("cli", false, "Run a diagnostic sweep and output the Brutalist CLI report table")
	serveMode := flag.Bool("serve", false, "Start the local HTMX HTTP web server on 127.0.0.1")
	port := flag.Int("port", 8484, "Loopback TCP port for the HTMX web interface")
	dbFlag := flag.String("db", "", "Path to SQLite3 WAL database (defaults to <root>/kwiklog.db)")
	simulateFlag := flag.Bool("simulate", false, "Simulate degraded hardware & software anomalies for testing")
	exportFlag := flag.Bool("export", false, "Export standalone Markdown & HTML report to ./exports/ after CLI scan")
	flag.Parse()

	if !*cliMode && !*serveMode {
		*serveMode = true
	}

	rootDir := resolveRootDir()
	dbPath := *dbFlag
	if dbPath == "" {
		dbPath = filepath.Join(rootDir, "kwiklog.db")
	}
	schemaPath := filepath.Join(rootDir, "schema.sql")

	isPrivileged := CheckPrivileges()
	if !isPrivileged {
		log.Println("[SECURITY GUARDRAIL] Running in Degraded Unprivileged Mode (UID != 0 / Non-Admin SID). Protected SMART & raw kernel logs restricted.")
	}

	store, err := NewDBStore(dbPath, schemaPath)
	if err != nil {
		log.Fatalf("Failed to initialize SQLite3 WAL store: %v", err)
	}
	defer store.Close()

	orchestrator := NewOrchestrator(rootDir, dbPath)

	if *cliMode {
		runID, bundle, err := orchestrator.ExecutePipeline(store, *simulateFlag, nil)
		if err != nil {
			log.Fatalf("Diagnostic pipeline execution failed: %v", err)
		}
		printCLIReport(runID, bundle, isPrivileged)

		if *exportFlag {
			exportDir := filepath.Join(rootDir, "exports")
			mdPath, htmlPath, err := store.ExportRunReport(runID, exportDir)
			if err != nil {
				log.Printf("Export warning: %v", err)
			} else {
				fmt.Printf("\n[EXPORTED] Offline reports saved to:\n  - %s\n  - %s\n", mdPath, htmlPath)
			}
		}

		if !*serveMode {
			return
		}
	}

	// Ensure at least one diagnostic run exists before starting HTTP server
	if _, _, err := store.GetRun(0); err != nil {
		log.Println("[STARTUP] No historical runs found in kwiklog.db; executing initial baseline scan...")
		if _, _, scanErr := orchestrator.ExecutePipeline(store, *simulateFlag, nil); scanErr != nil {
			log.Printf("[STARTUP WARNING] Initial scan error: %v", scanErr)
		}
	}

	srv, err := NewServer(store, orchestrator, isPrivileged)
	if err != nil {
		log.Fatalf("Failed to initialize HTTP server: %v", err)
	}

	bindAddr := fmt.Sprintf("127.0.0.1:%d", *port)
	log.Printf("[KWIKLOGD] Brutalist HTMX Dashboard listening strictly on http://%s (Loopback Only)", bindAddr)
	httpSrv := &http.Server{
		Addr:              bindAddr,
		Handler:           srv.Routes(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       60 * time.Second,
		MaxHeaderBytes:    65536,
	}
	if err := httpSrv.ListenAndServe(); err != nil {
		log.Fatalf("HTTP server terminated: %v", err)
	}
}
