package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

// MountPoint represents a filesystem mount telemetry item.
type MountPoint struct {
	Path    string  `json:"path"`
	FSType  string  `json:"fs_type"`
	UsedPct float64 `json:"used_pct"`
}

// DiskTelemetry represents a physical disk and SMART health snapshot.
type DiskTelemetry struct {
	Device              string       `json:"device"`
	Model               string       `json:"model"`
	SmartPassed         bool         `json:"smart_passed"`
	CriticalWarningByte int          `json:"critical_warning_byte"`
	TempCelsius         float64      `json:"temp_celsius"`
	AvailableSparePct   int          `json:"available_spare_pct"`
	PercentageUsed      int          `json:"percentage_used"`
	MediaErrors         int          `json:"media_errors"`
	UnsafeShutdowns     int          `json:"unsafe_shutdowns"`
	MountPoints         []MountPoint `json:"mount_points"`
}

// HardwareTelemetry holds CPU, RAM, Swap, and Disks metrics.
type HardwareTelemetry struct {
	CPUModel       string          `json:"cpu_model"`
	CPUTempCelsius float64         `json:"cpu_temp_celsius"`
	CPULoadPercent float64         `json:"cpu_load_percent"`
	RAMTotalBytes  int64           `json:"ram_total_bytes"`
	RAMAvailBytes  int64           `json:"ram_avail_bytes"`
	SwapTotalBytes int64           `json:"swap_total_bytes"`
	SwapUsedBytes  int64           `json:"swap_used_bytes"`
	Disks          []DiskTelemetry `json:"disks"`
}

// TimeshiftStatus represents system restore snapshot status.
type TimeshiftStatus struct {
	Installed         bool   `json:"installed"`
	SnapshotCount     int    `json:"snapshot_count"`
	LastSnapshotEpoch *int64 `json:"last_snapshot_epoch"`
}

// SoftwareState holds service, package, and snapshot health flags.
type SoftwareState struct {
	FailedServices      []string        `json:"failed_services"`
	BrokenPackagesCount int             `json:"broken_packages_count"`
	HeldPackages        []string        `json:"held_packages"`
	AptLockStale        bool            `json:"apt_lock_stale"`
	DKMSStatus          string          `json:"dkms_status"`
	FlatpakIssues       bool            `json:"flatpak_issues"`
	TimeshiftStatus     TimeshiftStatus `json:"timeshift_status"`
	PendingReboot       bool            `json:"pending_reboot"`
}

// TelemetryPayload matches Section 3.1 Shell Probe Output Schema.
type TelemetryPayload struct {
	SchemaVersion string            `json:"schema_version"`
	TimestampUTC  string            `json:"timestamp_utc"`
	OSFamily      string            `json:"os_family"`
	OSDistro      string            `json:"os_distro"`
	KernelVersion string            `json:"kernel_version"`
	UptimeSeconds int64             `json:"uptime_seconds"`
	Hardware      HardwareTelemetry `json:"hardware"`
	SoftwareState SoftwareState     `json:"software_state"`
}

// LogAnomaly matches Section 3.2 Rust Log Parser anomaly item.
type LogAnomaly struct {
	SignatureHash   string `json:"signature_hash"`
	Source          string `json:"source"`
	EventID         *int   `json:"event_id"`
	Severity        string `json:"severity"`
	Category        string `json:"category"`
	FirstSeenUTC    string `json:"first_seen_utc"`
	LastSeenUTC     string `json:"last_seen_utc"`
	OccurrenceCount int    `json:"occurrence_count"`
	SampleMessage   string `json:"sample_message"`
}

// ParserOutput matches Section 3.2 Rust Log Parser Output Schema.
type ParserOutput struct {
	ParseDurationMs    int64        `json:"parse_duration_ms"`
	BytesProcessed     int64        `json:"bytes_processed"`
	TotalEventsScanned int64        `json:"total_events_scanned"`
	Anomalies          []LogAnomaly `json:"anomalies"`
}

// TriggeredPrescription matches Section 3.3 Python Diagnostic Engine item.
type TriggeredPrescription struct {
	PrescriptionID    int64    `json:"prescription_id,omitempty"`
	RuleID            string   `json:"rule_id"`
	Severity          string   `json:"severity"`
	Domain            string   `json:"domain"`
	Title             string   `json:"title"`
	FindingSummary    string   `json:"finding_summary"`
	HistoricalContext string   `json:"historical_context"`
	RemediationType   string   `json:"remediation_type"`
	Commands          []string `json:"commands,omitempty"`
	PhysicalSteps     []string `json:"physical_steps,omitempty"`
	ActionSteps       []string `json:"action_steps,omitempty"`
	VerificationCmd   string   `json:"verification_cmd"`
	RiskLevel         string   `json:"risk_level"`
	Acknowledged      bool     `json:"acknowledged"`
}

// MetricTrendItem represents OLS slope data returned by kwikdiag.py.
type MetricTrendItem struct {
	ComponentType string  `json:"component_type"`
	MetricName    string  `json:"metric_name"`
	SampleCount   int     `json:"sample_count"`
	FirstValue    float64 `json:"first_value"`
	LatestValue   float64 `json:"latest_value"`
	Delta         float64 `json:"delta"`
	SlopePerDay   float64 `json:"slope_per_day"`
	SlopePerRun   float64 `json:"slope_per_run"`
	MovingAverage float64 `json:"moving_average"`
}

// DiagOutput matches Section 3.3 Python Diagnostic Engine Output Schema.
type DiagOutput struct {
	OverallHealthScore     int                          `json:"overall_health_score"`
	OverallStatus          string                       `json:"overall_status"`
	EvaluatedRulesCount    int                          `json:"evaluated_rules_count"`
	TriggeredPrescriptions []TriggeredPrescription      `json:"triggered_prescriptions"`
	HistoricalTrends       map[string]MetricTrendItem   `json:"historical_trends"`
	ScoreTrajectory        []int                        `json:"score_trajectory"`
}

// CombinedScanBundle stores the full raw telemetry + parser + diag snapshot in diagnostic_runs.raw_telemetry_json.
type CombinedScanBundle struct {
	Telemetry TelemetryPayload `json:"telemetry"`
	LogParser ParserOutput     `json:"log_parser"`
	Diag      DiagOutput       `json:"diag"`
}

// Orchestrator supervises probes, parser, and diagnostic engine subprocesses.
type Orchestrator struct {
	RootDir      string
	DBPath       string
	ProbeTimeout time.Duration
}

// NewOrchestrator creates an Orchestrator with a 30-second timeout per probe boundary.
func NewOrchestrator(rootDir, dbPath string) *Orchestrator {
	return &Orchestrator{
		RootDir:      rootDir,
		DBPath:       dbPath,
		ProbeTimeout: 30 * time.Second,
	}
}

// CheckPrivileges detects Root UID 0 on Linux or Administrator SID S-1-5-32-544 on Windows.
func CheckPrivileges() bool {
	if runtime.GOOS == "windows" {
		cmd := exec.Command("powershell", "-NoProfile", "-Command",
			"([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)")
		out, err := cmd.Output()
		if err != nil {
			return false
		}
		return strings.EqualFold(strings.TrimSpace(string(out)), "True")
	}
	return os.Geteuid() == 0
}

// resolveKwikparseBinary locates the compiled Rust kwikparse binary.
func (o *Orchestrator) resolveKwikparseBinary() string {
	candidates := []string{
		filepath.Join(o.RootDir, "bin", "kwikparse"),
		filepath.Join(o.RootDir, "kwikparse", "target", "release", "kwikparse"),
		filepath.Join(o.RootDir, "kwikparse", "target", "debug", "kwikparse"),
	}
	if runtime.GOOS == "windows" {
		for i := range candidates {
			candidates[i] += ".exe"
		}
	}
	for _, c := range candidates {
		if st, err := os.Stat(c); err == nil && !st.IsDir() {
			return c
		}
	}
	return candidates[1]
}

// ExecutePipeline runs Shell Probe -> Rust Log Parser -> Python Diagnostic Engine -> SQLite WAL Persistence.
func (o *Orchestrator) ExecutePipeline(store *DBStore, simulateDegraded bool, onPhase func(string)) (int64, *CombinedScanBundle, error) {
	startWall := time.Now()
	notify := func(msg string) {
		log.Println(msg)
		if onPhase != nil {
			onPhase(msg)
		}
	}

	env := os.Environ()
	if simulateDegraded {
		env = append(env, "KWIKLOG_SIMULATE_DEGRADED=1")
	}

	// PHASE 1: SHELL PROBES
	notify("[PHASE 1/3: SHELL PROBES] Executing native OS hardware & software telemetry sweep...")
	ctx1, cancel1 := context.WithTimeout(context.Background(), o.ProbeTimeout)
	defer cancel1()

	var probeCmd *exec.Cmd
	if runtime.GOOS == "windows" {
		probePath := filepath.Join(o.RootDir, "probes", "probe_win.bat")
		probeCmd = exec.CommandContext(ctx1, "cmd.exe", "/C", probePath)
	} else {
		probePath := filepath.Join(o.RootDir, "probes", "probe_pop.sh")
		probeCmd = exec.CommandContext(ctx1, "bash", probePath)
	}
	probeCmd.Env = env

	var probeStdout, probeStderr bytes.Buffer
	probeCmd.Stdout = &probeStdout
	probeCmd.Stderr = &probeStderr

	if err := probeCmd.Run(); err != nil {
		return 0, nil, fmt.Errorf("shell probe failed (%v): %s", err, probeStderr.String())
	}
	if probeStderr.Len() > 0 {
		log.Printf("[probe stderr] %s", strings.TrimSpace(probeStderr.String()))
	}

	var telemetry TelemetryPayload
	if err := json.Unmarshal(probeStdout.Bytes(), &telemetry); err != nil {
		return 0, nil, fmt.Errorf("failed to decode shell probe JSON: %w", err)
	}

	// PHASE 2: RUST LOG PARSER (kwikparse)
	notify("[PHASE 2/3: RUST LOG PARSER] Running multi-threaded mmap & SIMD regex log anomaly extraction...")
	ctx2, cancel2 := context.WithTimeout(context.Background(), o.ProbeTimeout)
	defer cancel2()

	kwikparseBin := o.resolveKwikparseBinary()
	parseArgs := []string{"--os", telemetry.OSFamily}
	if simulateDegraded {
		parseArgs = append(parseArgs, "--simulate-degraded")
	}
	parseCmd := exec.CommandContext(ctx2, kwikparseBin, parseArgs...)
	parseCmd.Env = env

	var parseStdout, parseStderr bytes.Buffer
	parseCmd.Stdout = &parseStdout
	parseCmd.Stderr = &parseStderr

	var parserOut ParserOutput
	if err := parseCmd.Run(); err != nil {
		log.Printf("[kwikparse warning] binary execution returned %v (%s); continuing with empty anomaly list", err, parseStderr.String())
		parserOut = ParserOutput{
			ParseDurationMs:    1,
			BytesProcessed:     0,
			TotalEventsScanned: 0,
			Anomalies:          []LogAnomaly{},
		}
	} else {
		if err := json.Unmarshal(parseStdout.Bytes(), &parserOut); err != nil {
			return 0, nil, fmt.Errorf("failed to decode kwikparse JSON: %w", err)
		}
	}

	// PHASE 3: PYTHON DIAGNOSTIC ENGINE (kwikdiag.py)
	notify("[PHASE 3/3: PYTHON DIAGNOSTICS] Evaluating rule matrix & OLS time-series degradation slopes...")
	ctx3, cancel3 := context.WithTimeout(context.Background(), o.ProbeTimeout)
	defer cancel3()

	diagInput := map[string]interface{}{
		"telemetry":  telemetry,
		"log_parser": parserOut,
	}
	diagInputBytes, err := json.Marshal(diagInput)
	if err != nil {
		return 0, nil, fmt.Errorf("failed to marshal kwikdiag input: %w", err)
	}

	diagScript := filepath.Join(o.RootDir, "kwikdiag", "kwikdiag.py")
	pyBin := "python3"
	if runtime.GOOS == "windows" {
		pyBin = "python"
	}
	diagCmd := exec.CommandContext(ctx3, pyBin, diagScript, "--db", o.DBPath)
	diagCmd.Env = env
	diagCmd.Stdin = bytes.NewReader(diagInputBytes)

	var diagStdout, diagStderr bytes.Buffer
	diagCmd.Stdout = &diagStdout
	diagCmd.Stderr = &diagStderr

	if err := diagCmd.Run(); err != nil {
		return 0, nil, fmt.Errorf("kwikdiag.py failed (%v): %s", err, diagStderr.String())
	}

	var diagOut DiagOutput
	if err := json.Unmarshal(diagStdout.Bytes(), &diagOut); err != nil {
		return 0, nil, fmt.Errorf("failed to decode kwikdiag JSON: %w", err)
	}

	// Normalize ActionSteps for templates
	for i := range diagOut.TriggeredPrescriptions {
		p := &diagOut.TriggeredPrescriptions[i]
		if p.RemediationType == "PHYSICAL_INTERVENTION" {
			p.ActionSteps = p.PhysicalSteps
		} else {
			p.ActionSteps = p.Commands
		}
	}

	bundle := &CombinedScanBundle{
		Telemetry: telemetry,
		LogParser: parserOut,
		Diag:      diagOut,
	}

	totalDurationMs := time.Since(startWall).Milliseconds()
	if totalDurationMs < 1 {
		totalDurationMs = 1
	}

	runID, err := store.SaveDiagnosticRun(bundle, totalDurationMs)
	if err != nil {
		return 0, nil, fmt.Errorf("failed to persist diagnostic run to SQLite: %w", err)
	}

	notify(fmt.Sprintf("[SCAN COMPLETE] Persisted Run #%d (Status: %s, Score: %d/100) in %dms.",
		runID, diagOut.OverallStatus, diagOut.OverallHealthScore, totalDurationMs))

	return runID, bundle, nil
}
