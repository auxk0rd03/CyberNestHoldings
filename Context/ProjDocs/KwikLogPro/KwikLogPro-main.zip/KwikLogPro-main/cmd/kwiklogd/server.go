package main

import (
	"fmt"
	"html/template"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	webassets "kwiklogpro/web"
)

// SnapshotRow formats a single row in the left Telemetry Snapshot table.
type SnapshotRow struct {
	Label          string
	ValueFormatted string
	ASCIIGauge     string
	Badge          string
	StateClass     string
}

// DegradationRow formats a single row in the right Historical Degradation OLS table.
type DegradationRow struct {
	Label          string
	Trajectory     string
	SlopeFormatted string
	StateClass     string
}

// ParserStatsView formats Rust kwikparse execution metrics for the header bar.
type ParserStatsView struct {
	BytesFormatted string
	DurationMs     int64
	EventsScanned  int64
}

// DashboardViewData holds template context for index.html and report_fragment.html.
type DashboardViewData struct {
	IsPrivileged    bool
	Hostname        string
	CurrentRun      DiagnosticRunRecord
	RecentRuns      []DiagnosticRunRecord
	Telemetry       TelemetryPayload
	SnapshotRows    []SnapshotRow
	DegradationRows []DegradationRow
	Prescriptions   []TriggeredPrescription
	Anomalies       []LogAnomaly
	ParserStats     ParserStatsView
	ActiveDomain    string
}

// ScanJob tracks an active SSE scan stream.
type ScanJob struct {
	ID        string
	Events    chan string
	Completed chan int64
	Done      bool
	FinalRun  int64
	History   []string
	mu        sync.Mutex
}

// Server manages HTTP endpoints and SSE scan streams on 127.0.0.1.
type Server struct {
	store        *DBStore
	orchestrator *Orchestrator
	templates    *template.Template
	isPrivileged bool
	hostname     string
	jobsMu       sync.Mutex
	jobs         map[string]*ScanJob
}

// NewServer initializes the HTMX HTTP server and parses embedded HTML templates.
func NewServer(store *DBStore, orchestrator *Orchestrator, isPrivileged bool) (*Server, error) {
	funcMap := template.FuncMap{
		"add1": func(i int) int { return i + 1 },
	}

	tmpl, err := template.New("").Funcs(funcMap).ParseFS(webassets.EmbeddedFS, "templates/*.html")
	if err != nil {
		return nil, fmt.Errorf("failed to parse embedded templates: %w", err)
	}

	host, err := os.Hostname()
	if err != nil || host == "" {
		host = "POP-WORKSTATION"
	}

	return &Server{
		store:        store,
		orchestrator: orchestrator,
		templates:    tmpl,
		isPrivileged: isPrivileged,
		hostname:      strings.ToUpper(host),
		jobs:         make(map[string]*ScanJob),
	}, nil
}

// buildASCIIGauge renders a 12-segment brutalist bar gauge like [||||||||||..].
func buildASCIIGauge(pct float64) string {
	if pct < 0 {
		pct = 0
	}
	if pct > 100 {
		pct = 100
	}
	filled := int((pct / 100.0) * 12.0)
	if filled > 12 {
		filled = 12
	}
	return "[" + strings.Repeat("|", filled) + strings.Repeat(".", 12-filled) + "]"
}

func formatBytes(b int64) string {
	const unit = 1024
	if b < unit {
		return fmt.Sprintf("%d B", b)
	}
	div, exp := int64(unit), 0
	for n := b / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.2f %cB", float64(b)/float64(div), "KMGTPE"[exp])
}

func (s *Server) buildViewData(runID int64, domainFilter string) (*DashboardViewData, error) {
	rec, bundle, err := s.store.GetRun(runID)
	if err != nil {
		return nil, err
	}

	recent, _ := s.store.ListRecentRuns(15)
	prescriptions, err := s.store.GetPrescriptions(rec.RunID, domainFilter)
	if err != nil {
		prescriptions = bundle.Diag.TriggeredPrescriptions
	}

	hw := bundle.Telemetry.Hardware
	var snapRows []SnapshotRow

	// 1. CPU Temperature
	cpuBadge := "OPT"
	cpuClass := "optimal"
	if hw.CPUTempCelsius >= 80.0 {
		cpuBadge = "CRIT"
		cpuClass = "critical"
	} else if hw.CPUTempCelsius >= 70.0 {
		cpuBadge = "WARN"
		cpuClass = "warning"
	}
	snapRows = append(snapRows, SnapshotRow{
		Label:          "CPU TEMP",
		ValueFormatted: fmt.Sprintf("%.1f C (LOAD %.1f%%)", hw.CPUTempCelsius, hw.CPULoadPercent),
		ASCIIGauge:     buildASCIIGauge(hw.CPUTempCelsius),
		Badge:          cpuBadge,
		StateClass:     cpuClass,
	})

	// 2. RAM Used
	ramUsedPct := 0.0
	if hw.RAMTotalBytes > 0 {
		ramUsedPct = float64(hw.RAMTotalBytes-hw.RAMAvailBytes) / float64(hw.RAMTotalBytes) * 100.0
	}
	ramBadge := "OPT"
	ramClass := "optimal"
	if ramUsedPct >= 92.0 {
		ramBadge = "CRIT"
		ramClass = "critical"
	} else if ramUsedPct >= 80.0 {
		ramBadge = "WARN"
		ramClass = "warning"
	}
	snapRows = append(snapRows, SnapshotRow{
		Label:          "RAM USED",
		ValueFormatted: fmt.Sprintf("%.1f %% (%s / %s)", ramUsedPct, formatBytes(hw.RAMTotalBytes-hw.RAMAvailBytes), formatBytes(hw.RAMTotalBytes)),
		ASCIIGauge:     buildASCIIGauge(ramUsedPct),
		Badge:          ramBadge,
		StateClass:     ramClass,
	})

	// 3. Swap Used
	swapUsedPct := 0.0
	if hw.SwapTotalBytes > 0 {
		swapUsedPct = float64(hw.SwapUsedBytes) / float64(hw.SwapTotalBytes) * 100.0
	}
	swapBadge := "OPT"
	swapClass := "optimal"
	if swapUsedPct >= 85.0 {
		swapBadge = "WARN"
		swapClass = "warning"
	}
	snapRows = append(snapRows, SnapshotRow{
		Label:          "SWAP USED",
		ValueFormatted: fmt.Sprintf("%.1f %% (%s / %s)", swapUsedPct, formatBytes(hw.SwapUsedBytes), formatBytes(hw.SwapTotalBytes)),
		ASCIIGauge:     buildASCIIGauge(swapUsedPct),
		Badge:          swapBadge,
		StateClass:     swapClass,
	})

	// 4. Disks & Mounts
	primaryDev := "/dev/nvme0n1"
	for _, d := range hw.Disks {
		primaryDev = d.Device
		dBadge := "OPT"
		dClass := "optimal"
		if d.MediaErrors > 0 || !d.SmartPassed || d.AvailableSparePct < 20 {
			dBadge = "CRIT"
			dClass = "critical"
		}
		shortDev := filepath.Base(d.Device)
		snapRows = append(snapRows, SnapshotRow{
			Label:          strings.ToUpper(shortDev),
			ValueFormatted: fmt.Sprintf("%d%% SPR // %d MEDIA ERR // %.0f C", d.AvailableSparePct, d.MediaErrors, d.TempCelsius),
			ASCIIGauge:     buildASCIIGauge(float64(d.AvailableSparePct)),
			Badge:          dBadge,
			StateClass:     dClass,
		})
		for _, mp := range d.MountPoints {
			mBadge := "OPT"
			mClass := "optimal"
			if mp.UsedPct >= 90.0 {
				mBadge = "CRIT"
				mClass = "critical"
			} else if mp.UsedPct >= 80.0 {
				mBadge = "WARN"
				mClass = "warning"
			}
			snapRows = append(snapRows, SnapshotRow{
				Label:          "MOUNT " + mp.Path,
				ValueFormatted: fmt.Sprintf("%.1f %% (%s)", mp.UsedPct, mp.FSType),
				ASCIIGauge:     buildASCIIGauge(mp.UsedPct),
				Badge:          mBadge,
				StateClass:     mClass,
			})
		}
	}

	// Build Right Column: Historical Degradation (Last 10 Runs)
	var degRows []DegradationRow
	trends := bundle.Diag.HistoricalTrends

	if meTrend, ok := trends["DISK:"+primaryDev+":media_errors"]; ok {
		cls := "optimal"
		if meTrend.LatestValue > 0 || meTrend.Delta > 0 {
			cls = "critical"
		}
		degRows = append(degRows, DegradationRow{
			Label:          "NVME MEDIA ERRORS",
			Trajectory:     fmt.Sprintf("%+.0f (TOTAL: %.0f across %d runs)", meTrend.Delta, meTrend.LatestValue, meTrend.SampleCount),
			SlopeFormatted: fmt.Sprintf("SLOPE: %+.2f / run", meTrend.SlopePerRun),
			StateClass:     cls,
		})
	}

	if cpuTrend, ok := trends["CPU:temp_celsius"]; ok {
		cls := "optimal"
		if cpuTrend.SlopePerDay > 0.2 || cpuTrend.LatestValue >= 80.0 {
			cls = "warning"
		}
		degRows = append(degRows, DegradationRow{
			Label:          "CPU IDLE TEMP",
			Trajectory:     fmt.Sprintf("%+.1f C (AVG: %.1f C)", cpuTrend.Delta, cpuTrend.MovingAverage),
			SlopeFormatted: fmt.Sprintf("SLOPE: %+.2f C / day", cpuTrend.SlopePerDay),
			StateClass:     cls,
		})
	}

	// Score trajectory
	var scoreStrs []string
	for _, sc := range bundle.Diag.ScoreTrajectory {
		scoreStrs = append(scoreStrs, strconv.Itoa(sc))
	}
	if len(scoreStrs) == 0 {
		scoreStrs = []string{strconv.Itoa(rec.HealthScore)}
	}
	scoreClass := "optimal"
	if rec.HealthScore < 50 {
		scoreClass = "critical"
	} else if rec.HealthScore < 85 {
		scoreClass = "warning"
	}
	degRows = append(degRows, DegradationRow{
		Label:          "HEALTH SCORE",
		Trajectory:     strings.Join(scoreStrs, " -> "),
		SlopeFormatted: fmt.Sprintf("%d RUNS TRACKED", len(scoreStrs)),
		StateClass:     scoreClass,
	})

	// Timeshift status
	tsStatus := "ACTIVE (" + strconv.Itoa(bundle.Telemetry.SoftwareState.TimeshiftStatus.SnapshotCount) + " SNAPSHOTS)"
	tsClass := "optimal"
	if !bundle.Telemetry.SoftwareState.TimeshiftStatus.Installed {
		tsStatus = "NOT INSTALLED [WARN]"
		tsClass = "warning"
	} else if bundle.Telemetry.SoftwareState.TimeshiftStatus.SnapshotCount == 0 {
		tsStatus = "NEVER [ALERT]"
		tsClass = "critical"
	}
	degRows = append(degRows, DegradationRow{
		Label:          "LAST TIMESHIFT",
		Trajectory:     tsStatus,
		SlopeFormatted: fmt.Sprintf("BROKEN PKGS: %d", bundle.Telemetry.SoftwareState.BrokenPackagesCount),
		StateClass:     tsClass,
	})

	pStats := ParserStatsView{
		BytesFormatted: formatBytes(bundle.LogParser.BytesProcessed),
		DurationMs:     bundle.LogParser.ParseDurationMs,
		EventsScanned:  bundle.LogParser.TotalEventsScanned,
	}

	return &DashboardViewData{
		IsPrivileged:    s.isPrivileged,
		Hostname:        s.hostname,
		CurrentRun:      *rec,
		RecentRuns:      recent,
		Telemetry:       bundle.Telemetry,
		SnapshotRows:    snapRows,
		DegradationRows: degRows,
		Prescriptions:   prescriptions,
		Anomalies:       bundle.LogParser.Anomalies,
		ParserStats:     pStats,
		ActiveDomain:    domainFilter,
	}, nil
}

// Routes constructs the HTTP ServeMux for kwiklogd.
func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()

	// Static assets (/static/htmx.min.js, /static/brutalist.css)
	staticSub, _ := fs.Sub(webassets.EmbeddedFS, "static")
	mux.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.FS(staticSub))))

	mux.HandleFunc("/", s.handleIndex)
	mux.HandleFunc("/api/scan", s.handleTriggerScan)
	mux.HandleFunc("/api/scan/stream", s.handleScanSSE)
	mux.HandleFunc("/api/runs/select", s.handleRunSelect)
	mux.HandleFunc("/api/runs/", s.handleGetRun)
	mux.HandleFunc("/api/prescriptions/", s.handleAckPrescription)
	mux.HandleFunc("/api/prescriptions", s.handleFilterPrescriptions)
	mux.HandleFunc("/api/export/stix", s.handleExportSTIX)
	mux.HandleFunc("/api/export/taxii", s.handleExportTAXII)
	mux.HandleFunc("/api/export/", s.handleExportRun)
	mux.HandleFunc("/api/compliance/cmmc", s.handleComplianceCMMC)
	mux.HandleFunc("/api/compliance/stig", s.handleComplianceSTIG)
	mux.HandleFunc("/api/network-sense", s.handleNetworkSense)
	mux.HandleFunc("/api/sbom", s.handleSBOM)

	return SecurityMiddleware(mux)
}

func (s *Server) handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}

	view, err := s.buildViewData(0, "")
	if err != nil {
		// Automatically perform an initial baseline scan if database is empty
		if _, _, scanErr := s.orchestrator.ExecutePipeline(s.store, false, nil); scanErr != nil {
			http.Error(w, "Initial diagnostic scan failed: "+scanErr.Error(), http.StatusInternalServerError)
			return
		}
		view, err = s.buildViewData(0, "")
		if err != nil {
			http.Error(w, "Failed to load diagnostic run: "+err.Error(), http.StatusInternalServerError)
			return
		}
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := s.templates.ExecuteTemplate(w, "index.html", view); err != nil {
		log.Printf("[http error] index template: %v", err)
	}
}

func (s *Server) handleTriggerScan(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	simulate := r.URL.Query().Get("simulate") == "1"
	jobID := fmt.Sprintf("scan-%d", time.Now().UnixNano())
	job := &ScanJob{
		ID:        jobID,
		Events:    make(chan string, 16),
		Completed: make(chan int64, 1),
	}

	s.jobsMu.Lock()
	s.jobs[jobID] = job
	s.jobsMu.Unlock()

	go func() {
		runID, _, err := s.orchestrator.ExecutePipeline(s.store, simulate, func(phaseMsg string) {
			job.mu.Lock()
			job.History = append(job.History, phaseMsg)
			job.mu.Unlock()
			select {
			case job.Events <- phaseMsg:
			default:
			}
		})
		if err != nil {
			log.Printf("[scan job %s error] %v", jobID, err)
		}
		job.mu.Lock()
		job.Done = true
		job.FinalRun = runID
		job.mu.Unlock()
		select {
		case job.Completed <- runID:
		default:
		}
	}()

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_ = s.templates.ExecuteTemplate(w, "progress_sse.html", map[string]string{"JobID": jobID})
}

func (s *Server) handleScanSSE(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "Streaming unsupported", http.StatusInternalServerError)
		return
	}

	jobID := r.URL.Query().Get("job_id")
	s.jobsMu.Lock()
	job, exists := s.jobs[jobID]
	s.jobsMu.Unlock()

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")

	if !exists {
		fmt.Fprintf(w, "event: complete\ndata: 0\n\n")
		flusher.Flush()
		return
	}

	// Replay any phase events that already fired before EventSource connected
	job.mu.Lock()
	for _, msg := range job.History {
		fmt.Fprintf(w, "event: phase\ndata: %s\n\n", msg)
	}
	if job.Done {
		fmt.Fprintf(w, "event: complete\ndata: %d\n\n", job.FinalRun)
		job.mu.Unlock()
		flusher.Flush()
		return
	}
	job.mu.Unlock()
	flusher.Flush()

	ctx := r.Context()
	for {
		select {
		case <-ctx.Done():
			return
		case msg := <-job.Events:
			fmt.Fprintf(w, "event: phase\ndata: %s\n\n", msg)
			flusher.Flush()
		case runID := <-job.Completed:
			fmt.Fprintf(w, "event: complete\ndata: %d\n\n", runID)
			flusher.Flush()
			return
		case <-time.After(35 * time.Second):
			fmt.Fprintf(w, "event: complete\ndata: 0\n\n")
			flusher.Flush()
			return
		}
	}
}

func (s *Server) handleRunSelect(w http.ResponseWriter, r *http.Request) {
	runID, _ := strconv.ParseInt(r.URL.Query().Get("run_id"), 10, 64)
	s.renderRunFragment(w, runID)
}

func (s *Server) handleGetRun(w http.ResponseWriter, r *http.Request) {
	idStr := strings.TrimPrefix(r.URL.Path, "/api/runs/")
	runID, _ := strconv.ParseInt(idStr, 10, 64)
	s.renderRunFragment(w, runID)
}

func (s *Server) renderRunFragment(w http.ResponseWriter, runID int64) {
	view, err := s.buildViewData(runID, "")
	if err != nil {
		http.Error(w, "Run not found: "+err.Error(), http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_ = s.templates.ExecuteTemplate(w, "report_fragment.html", view)
}

func (s *Server) handleFilterPrescriptions(w http.ResponseWriter, r *http.Request) {
	runID, _ := strconv.ParseInt(r.URL.Query().Get("run_id"), 10, 64)
	domain := strings.ToUpper(strings.TrimSpace(r.URL.Query().Get("domain")))
	view, err := s.buildViewData(runID, domain)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_ = s.templates.ExecuteTemplate(w, "prescriptions_partial", view)
}

func (s *Server) handleAckPrescription(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	trimmed := strings.TrimPrefix(r.URL.Path, "/api/prescriptions/")
	trimmed = strings.TrimSuffix(trimmed, "/ack")
	pID, _ := strconv.ParseInt(trimmed, 10, 64)
	if pID > 0 {
		_ = s.store.AcknowledgePrescription(pID)
	}
	runID, _ := strconv.ParseInt(r.URL.Query().Get("run_id"), 10, 64)
	domain := strings.ToUpper(strings.TrimSpace(r.URL.Query().Get("domain")))
	view, err := s.buildViewData(runID, domain)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_ = s.templates.ExecuteTemplate(w, "prescriptions_partial", view)
}

func (s *Server) handleExportRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/api/export/")
	runID, _ := strconv.ParseInt(idStr, 10, 64)
	exportDir := filepath.Join(s.orchestrator.RootDir, "exports")
	mdPath, htmlPath, err := s.store.ExportRunReport(runID, exportDir)
	if err != nil {
		http.Error(w, "Export failed: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprintf(w, `<div class="frame-box" style="border-color: var(--accent-optimal); padding: 10px 14px; color: var(--accent-optimal);">
		<strong>[OFFLINE ARCHIVE EXPORTED]</strong> Markdown: <code>%s</code> // HTML: <code>%s</code>
	</div>`, mdPath, htmlPath)
}
