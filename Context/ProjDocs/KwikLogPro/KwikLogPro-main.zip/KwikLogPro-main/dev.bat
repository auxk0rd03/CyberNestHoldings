@echo off
REM ==============================================================================
REM CyberNest Labs // KwikLogPro Windows 10/11 Orchestration Runner (dev.bat)
REM Standard: CN-DIR-2026-004 (Dual-Native Orchestration Architecture)
REM Security: CWE-377 (Symlink/Reparse Defense, Strict ACLs) & CWE-114 (PID Control)
REM ==============================================================================
setlocal enabledelayedexpansion

REM --- 1. Path Hijacking Defense (CWE-377) ---
cd /d "%~dp0"
set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

REM --- 2. User Cache Preservation Under Admin Elevation ---
set "REAL_USERPROFILE=%USERPROFILE%"
echo "%REAL_USERPROFILE%" | findstr /I "System32" >nul 2>&1
if not errorlevel 1 (
    for /f "usebackq delims=" %%U in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "[Environment]::GetFolderPath('UserProfile')"`) do (
        if not "%%U"=="" set "REAL_USERPROFILE=%%U"
    )
)
if "%LOCALAPPDATA%"=="" (
    set "REAL_LOCALAPPDATA=%REAL_USERPROFILE%\AppData\Local"
) else (
    set "REAL_LOCALAPPDATA=%LOCALAPPDATA%"
)

set "CARGO_HOME=%REAL_USERPROFILE%\.cargo"
set "RUSTUP_HOME=%REAL_USERPROFILE%\.rustup"
set "GOPATH=%REAL_USERPROFILE%\go"
set "GOMODCACHE=%REAL_USERPROFILE%\go\pkg\mod"
set "GOCACHE=%REAL_LOCALAPPDATA%\go-build"
set "PATH=%CARGO_HOME%\bin;%GOPATH%\bin;%PATH%"

REM --- 3. Hardened Local Enclave Logging & ACLs (CWE-377) ---
set "CACHE_DIR=%REAL_LOCALAPPDATA%\kwiklogpro"
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
icacls "%CACHE_DIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1

set "LOG_FILE=%CACHE_DIR%\session.log"
if exist "%LOG_FILE%" (
    fsutil reparsepoint query "%LOG_FILE%" >nul 2>&1 && del /f /q "%LOG_FILE%"
)
type nul >> "%LOG_FILE%"
icacls "%LOG_FILE%" /inheritance:r /grant:r "%USERNAME%:F" >nul 2>&1

set "CMD=%~1"
if "%CMD%"=="" set "CMD=run"

if /I "%CMD%"=="setup" goto :cmd_setup
if /I "%CMD%"=="build" goto :cmd_build
if /I "%CMD%"=="run" goto :cmd_run
if /I "%CMD%"=="serve" goto :cmd_run
if /I "%CMD%"=="cli" goto :cmd_cli
if /I "%CMD%"=="simulate" goto :cmd_simulate
if /I "%CMD%"=="test" goto :cmd_test
if /I "%CMD%"=="fmt" goto :cmd_fmt

echo Usage: %~nx0 {setup^|build^|run^|serve^|cli^|simulate^|test^|fmt}
exit /b 1

:cmd_setup
echo ==^> [SETUP] Verifying Windows 10/11 polyglot toolchain ^& probe assets...
where go >nul 2>&1 || (echo [ERROR] Go compiler not found in PATH. & exit /b 1)
where cargo >nul 2>&1 || (echo [ERROR] Rust/Cargo toolchain not found in PATH. & exit /b 1)
where python >nul 2>&1 || (echo [ERROR] Python 3.10+ interpreter not found in PATH. & exit /b 1)
if not exist "probes\probe_win.bat" (echo [ERROR] Missing probes\probe_win.bat & exit /b 1)
if not exist "kwikdiag\kwikdiag.py" (echo [ERROR] Missing kwikdiag\kwikdiag.py & exit /b 1)
go version
cargo --version
python --version
echo ==^> [SETUP] All required toolchains and probes verified.
exit /b 0

:do_build
if not exist "bin" mkdir "bin"
echo ==^> [1/3] Compiling Go Core Orchestrator (bin\kwiklogd.exe with GOFIPS=1)...
set "GOFIPS=1"
set "GODEBUG=fips140=on"
go build -o bin\kwiklogd.exe .\cmd\kwiklogd
if errorlevel 1 exit /b 1

echo ==^> [2/3] Compiling Rust High-Speed Log Parser (bin\kwikparse.exe)...
pushd kwikparse
cargo build --release --offline 2>nul || cargo build --release
if errorlevel 1 (popd & exit /b 1)
popd
copy /y kwikparse\target\release\kwikparse.exe bin\kwikparse.exe >nul
if errorlevel 1 exit /b 1

echo ==^> [3/3] Generating CycloneDX 1.5, SPDX 2.3 ^& CISA SBOM manifests...
if exist "..\NestSBOM\sbom_cli.py" (
    python ..\NestSBOM\sbom_cli.py --repo . --out-dir . >nul
)
exit /b 0

:cmd_build
call :do_build
exit /b %ERRORLEVEL%

:cmd_run
call :do_build
if errorlevel 1 exit /b 1
echo ==^> Starting KwikLogPro HTMX Server on http://127.0.0.1:8484 ...
echo ==^> Session Log: %LOG_FILE%
set "GOFIPS=1"
set "GODEBUG=fips140=on"
set "APP_PID="
for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath 'bin\kwiklogd.exe' -ArgumentList '--serve','--port','8484' -NoNewWindow -PassThru -RedirectStandardOutput '%LOG_FILE%'; Write-Output $p.Id"`) do (
    set "APP_PID=%%P"
)
if defined APP_PID (
    echo [INFO] Tracked child PID: !APP_PID! ^(Press Ctrl+C to terminate^)
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Wait-Process -Id !APP_PID! } finally { Stop-Process -Id !APP_PID! -Force -ErrorAction SilentlyContinue }"
    taskkill /PID !APP_PID! /T /F >nul 2>&1
) else (
    bin\kwiklogd.exe --serve --port 8484 >> "%LOG_FILE%" 2>&1
)
exit /b 0

:cmd_cli
call :do_build
if errorlevel 1 exit /b 1
echo ==^> Running KwikLogPro CLI Diagnostic Sweep...
set "GOFIPS=1"
set "GODEBUG=fips140=on"
bin\kwiklogd.exe --cli
exit /b %ERRORLEVEL%

:cmd_simulate
call :do_build
if errorlevel 1 exit /b 1
echo ==^> Running KwikLogPro Simulated Hardware/Software Fault Audit...
set "GOFIPS=1"
set "GODEBUG=fips140=on"
bin\kwiklogd.exe --cli --simulate --export
exit /b %ERRORLEVEL%

:cmd_test
echo ==^> Running full polyglot test suite (Go + Rust + Python)...
set "GOFIPS=1"
set "GODEBUG=fips140=on"
go test ./...
if errorlevel 1 exit /b 1
pushd kwikparse
cargo test --offline 2>nul || cargo test
if errorlevel 1 (popd & exit /b 1)
popd
python -m unittest discover -s kwikdiag -p "test_*.py" -v
exit /b %ERRORLEVEL%

:cmd_fmt
echo ==^> Formatting Go and Rust source code...
go fmt ./...
if errorlevel 1 exit /b 1
pushd kwikparse
cargo fmt
if errorlevel 1 (popd & exit /b 1)
popd
exit /b 0
