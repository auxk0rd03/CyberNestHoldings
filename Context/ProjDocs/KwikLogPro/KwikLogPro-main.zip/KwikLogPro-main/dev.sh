#!/usr/bin/env bash
# KwikLogPro Local Build, Test, CLI & Server Automation Runner (dev.sh)
# Hardened for CWE-377 (Symlink Hijacking Defense) & CWE-114 (Process Control)
set -euo pipefail
umask 077

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

# When invoked via `sudo ./dev.sh`, preserve the non-root operator's Cargo & Go caches
REAL_USER="${SUDO_USER:-${USER:-auxk0rd}}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6 || echo "/home/$REAL_USER")"
export CARGO_HOME="${REAL_HOME}/.cargo"
export RUSTUP_HOME="${REAL_HOME}/.rustup"
export GOPATH="${REAL_HOME}/go"
export GOMODCACHE="${REAL_HOME}/go/pkg/mod"
export GOCACHE="${REAL_HOME}/.cache/go-build"
export PATH="${REAL_HOME}/.cargo/bin:/usr/local/go/bin:/usr/bin:/bin:${PATH}"

CACHE_DIR="${REAL_HOME}/.cache/kwiklogpro"
mkdir -p "$CACHE_DIR"
chmod 700 "$CACHE_DIR"
LOG_FILE="${CACHE_DIR}/session.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE"
chmod 600 "$LOG_FILE"

APP_PID=""
cleanup() {
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        kill -TERM "$APP_PID" 2>/dev/null || true
        sleep 0.2
        kill -KILL "$APP_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT INT TERM

CMD="${1:-run}"

case "$CMD" in
  setup)
    echo "==> Verifying polyglot toolchain & permissions..."
    chmod +x probes/probe_pop.sh probes/probe_win.bat kwikdiag/kwikdiag.py
    go version
    cargo --version
    python3 --version
    ;;
  build)
    echo "==> Building KwikLogPro release binaries (kwikparse + kwiklogd) & SBOMs..."
    make build
    ;;
  run|serve)
    echo "==> Building & starting KwikLogPro HTMX Server on http://127.0.0.1:8484 ..."
    make build
    GODEBUG=fips140=on ./bin/kwiklogd --serve --port 8484 2>&1 | tee -a "$LOG_FILE" &
    APP_PID=$!
    wait "$APP_PID"
    ;;
  cli)
    echo "==> Running KwikLogPro CLI Diagnostic Sweep..."
    make build
    GODEBUG=fips140=on ./bin/kwiklogd --cli
    ;;
  simulate)
    echo "==> Running KwikLogPro Simulated Hardware/Software Fault Audit..."
    make build
    GODEBUG=fips140=on ./bin/kwiklogd --cli --simulate --export
    ;;
  test)
    echo "==> Running full polyglot test suite (Rust + Python + Go)..."
    make test
    ;;
  fmt)
    echo "==> Formatting Go and Rust source code..."
    go fmt ./...
    (cd kwikparse && cargo fmt)
    ;;
  *)
    echo "Usage: $0 {setup|build|run|serve|cli|simulate|test|fmt}"
    exit 1
    ;;
esac
