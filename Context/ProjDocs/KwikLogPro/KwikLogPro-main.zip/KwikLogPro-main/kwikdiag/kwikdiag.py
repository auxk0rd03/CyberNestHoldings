#!/usr/bin/env python3
"""
KwikLogPro Diagnostic Logic & Prescription Engine (kwikdiag.py)
Reads combined Shell probe + Rust log anomalies JSON from stdin, queries historical runs
from SQLite3 (WAL mode) to compute OLS linear regression degradation slopes, evaluates
Pop!_OS, Windows, and Cross-Platform Hardware rule matrices, and outputs the structured
prescription report JSON to stdout (Section 3.3).
"""

from __future__ import annotations
import argparse
import json
import os
import sys
from dataclasses import asdict
from typing import Any, Dict, List

# Ensure local module imports resolve regardless of working directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from rules_hw import evaluate_hw_rules
from rules_pop import evaluate_pop_rules
from rules_win import evaluate_win_rules
from trends import load_historical_trends

SEVERITY_PENALTY = {
    "CRITICAL": 28,
    "HIGH": 15,
    "MEDIUM": 8,
    "LOW": 3,
}


def compute_health_score_and_status(prescriptions: List[dict], anomalies: List[dict]) -> tuple[int, str]:
    """
    Computes overall_health_score (0..100) and overall_status ('OPTIMAL', 'DEGRADED', 'CRITICAL').
    """
    score = 100
    has_critical = False
    has_high_or_med = False

    for p in prescriptions:
        sev = str(p.get("severity", "LOW")).upper()
        score -= SEVERITY_PENALTY.get(sev, 5)
        if sev == "CRITICAL":
            has_critical = True
        elif sev in ("HIGH", "MEDIUM"):
            has_high_or_med = True

    # Minor deduction for unmapped log anomalies
    crit_anomalies = sum(1 for a in anomalies if a.get("severity") == "CRITICAL")
    if crit_anomalies > 0 and not has_critical:
        score -= min(15, crit_anomalies * 5)
        has_high_or_med = True

    score = max(0, min(100, score))

    if has_critical or score < 50:
        status = "CRITICAL"
    elif has_high_or_med or score < 85:
        status = "DEGRADED"
    else:
        status = "OPTIMAL"

    return score, status


def evaluate_payload(payload: Dict[str, Any], db_path: str | None = None) -> Dict[str, Any]:
    telemetry = payload.get("telemetry", payload)
    parser_out = payload.get("log_parser", {})
    anomalies = parser_out.get("anomalies", payload.get("anomalies", []))

    trends, past_scores = load_historical_trends(db_path, telemetry, max_runs=10)

    pop_eval_cnt, pop_prescriptions = evaluate_pop_rules(telemetry, anomalies)
    win_eval_cnt, win_prescriptions = evaluate_win_rules(telemetry, anomalies)
    hw_eval_cnt, hw_prescriptions = evaluate_hw_rules(telemetry, anomalies, trends)

    # Baseline rule matrix count (38 total rules across OS + HW + SMART sub-checks per EDD Section 3.3)
    evaluated_rules_count = max(38, pop_eval_cnt + win_eval_cnt + hw_eval_cnt)

    # Order prescriptions CRITICAL -> HIGH -> MEDIUM -> LOW
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    all_prescriptions = hw_prescriptions + pop_prescriptions + win_prescriptions
    all_prescriptions.sort(key=lambda p: (sev_rank.get(p.get("severity", "LOW"), 4), p.get("rule_id", "")))

    score, status = compute_health_score_and_status(all_prescriptions, anomalies)
    score_trajectory = past_scores + [score]

    trends_dict = {k: asdict(v) for k, v in trends.items()}

    return {
        "overall_health_score": score,
        "overall_status": status,
        "evaluated_rules_count": evaluated_rules_count,
        "triggered_prescriptions": all_prescriptions,
        "historical_trends": trends_dict,
        "score_trajectory": score_trajectory,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="KwikLogPro Diagnostic & Prescription Engine")
    parser.add_argument("--db", default="kwiklog.db", help="Path to SQLite3 WAL database")
    parser.add_argument("--input", default="-", help="Input JSON path or '-' for stdin")
    args = parser.parse_args()

    try:
        if args.input == "-":
            raw_in = sys.stdin.read()
        else:
            with open(args.input, "r", encoding="utf-8") as f:
                raw_in = f.read()

        if not raw_in.strip():
            raise ValueError("Empty input payload received on stdin")

        payload = json.loads(raw_in)
    except Exception as exc:
        print(f"[kwikdiag.py] Failed to parse input JSON: {exc}", file=sys.stderr)
        return 1

    db_path = args.db if args.db and os.path.exists(args.db) else None
    result = evaluate_payload(payload, db_path=db_path)
    sys.stdout.write(json.dumps(result, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
