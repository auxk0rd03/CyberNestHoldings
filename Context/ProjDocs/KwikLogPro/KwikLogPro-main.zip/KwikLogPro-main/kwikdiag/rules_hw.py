"""
KwikLogPro Cross-Platform Hardware & Time-Series Degradation Ruleset (rules_hw.py)
Implements Section 5.3 Hardware rules + Section 3.3 / 4.2 OLS Trend Degradation triggers.
"""

from __future__ import annotations
import re
from typing import Dict, List, Tuple
from trends import MetricTrend

SAFE_DEV_RE = re.compile(r"^[a-zA-Z0-9_./\\:-]+$")


def sanitize_dev_path(raw: str) -> str:
    candidate = raw.strip()
    if SAFE_DEV_RE.match(candidate):
        return candidate
    return "/dev/nvme0n1"


def evaluate_hw_rules(
    telemetry: dict,
    anomalies: List[dict],
    trends: Dict[str, MetricTrend],
) -> Tuple[int, List[dict]]:
    """
    Evaluates Cross-Platform Hardware & SMART & OLS Velocity rules:
      - HW_THM_001: CPU Temperature vs Load (>= 80C while load < 15%, or OLS slope > +0.21C/day [+1.5C/wk])
      - HW_NVME_001: SMART available_spare_pct < 20% or percentage_used > 95%
      - HW_NVME_002: SMART media_errors > 0 or critical_warning_byte != 0 or blk_update_request I/O errors
      - HW_MEM_002: Swap used > 85% and RAM avail < 5%, or Kernel OOM-killer invocations
    Returns (evaluated_count, triggered_prescriptions).
    """
    hw = telemetry.get("hardware", {})
    prescriptions: List[dict] = []
    evaluated_count = 4

    # 1. HW_THM_001: CPU Thermal Transfer Failure or Progressive Thermal Creep
    cpu_temp = float(hw.get("cpu_temp_celsius", 0.0))
    cpu_load = float(hw.get("cpu_load_percent", 0.0))
    cpu_trend = trends.get("CPU:temp_celsius")
    slope_per_week = (cpu_trend.slope_per_day * 7.0) if cpu_trend else 0.0
    static_thermal_breach = cpu_temp >= 80.0 and cpu_load < 15.0
    slope_thermal_breach = (
        cpu_trend is not None
        and cpu_trend.sample_count >= 3
        and slope_per_week > 1.5
        and cpu_temp >= 65.0
    )

    if static_thermal_breach or slope_thermal_breach:
        hist_ctx = "First detected in current run."
        if cpu_trend and cpu_trend.sample_count >= 2:
            sign = "+" if cpu_trend.delta >= 0 else ""
            hist_ctx = (
                f"CPU temperature changed by {sign}{cpu_trend.delta:.1f} C over last "
                f"{cpu_trend.sample_count} runs (OLS Slope: {cpu_trend.slope_per_day:+.2f} C/day)."
            )
        prescriptions.append({
            "rule_id": "HW_THM_001",
            "severity": "CRITICAL" if static_thermal_breach else "HIGH",
            "domain": "HARDWARE",
            "title": "CPU Thermal Transfer Failure / Idle Heatsink Saturation",
            "finding_summary": (
                f"CPU temperature reached {cpu_temp:.1f} C while CPU load is only {cpu_load:.1f}% "
                f"(Model: {hw.get('cpu_model', 'Unknown CPU')})."
            ),
            "historical_context": hist_ctx,
            "remediation_type": "PHYSICAL_INTERVENTION",
            "physical_steps": [
                "Clear dust accumulation from chassis intake filters and heatsink/radiator fins using dry compressed air.",
                "Inspect AIO liquid cooler pump RPM telemetry or CPU fan PWM curve in BIOS.",
                "Clean old thermal interface material with 99% isopropyl alcohol and repaste CPU IHS using high-viscosity phase-change compound (e.g., PTM7950 or Kryonaut).",
            ],
            "verification_cmd": "sensors || cat /sys/class/thermal/thermal_zone*/temp",
            "risk_level": "CRITICAL_HARDWARE" if static_thermal_breach else "MODERATE",
        })

    # 2. Disk / NVMe SMART Rules: HW_NVME_001 & HW_NVME_002
    io_anomalies = [a for a in anomalies if a.get("category") == "STORAGE_IO"]
    total_io_errors = sum(int(a.get("occurrence_count", 0)) for a in io_anomalies)

    for disk in hw.get("disks", []):
        dev = sanitize_dev_path(str(disk.get("device", "/dev/nvme0n1")))
        avail_spare = int(disk.get("available_spare_pct", 100))
        pct_used = int(disk.get("percentage_used", 0))
        media_errors = int(disk.get("media_errors", 0))
        crit_byte = int(disk.get("critical_warning_byte", 0))
        smart_passed = bool(disk.get("smart_passed", True))

        evaluated_count += 2

        # HW_NVME_001: End-of-Life NAND Wear
        if avail_spare < 20 or pct_used > 95:
            spare_trend = trends.get(f"DISK:{dev}:available_spare_pct")
            hist_ctx = "First detected in current run."
            if spare_trend and spare_trend.sample_count >= 2:
                hist_ctx = (
                    f"Available spare changed by {spare_trend.delta:+.1f}% over the last "
                    f"{spare_trend.sample_count} runs (Slope: {spare_trend.slope_per_run:+.2f}%/run)."
                )
            prescriptions.append({
                "rule_id": "HW_NVME_001",
                "severity": "CRITICAL",
                "domain": "HARDWARE",
                "title": "End-of-Life NVMe NAND Wear / Spare Block Exhaustion",
                "finding_summary": (
                    f"Device {dev} reported available_spare_pct={avail_spare}% and percentage_used={pct_used}%."
                ),
                "historical_context": hist_ctx,
                "remediation_type": "PHYSICAL_INTERVENTION",
                "physical_steps": [
                    f"Provision replacement NVMe drive and clone partitions from {dev} immediately.",
                    "Drive is approaching controller read-only lock mode due to NAND spare block exhaustion.",
                ],
                "verification_cmd": f"sudo smartctl -a {dev}",
                "risk_level": "CRITICAL_HARDWARE",
            })

        # HW_NVME_002: NVMe Media Integrity Errors & Kernel Read Failures
        if media_errors > 0 or crit_byte != 0 or not smart_passed or total_io_errors > 0:
            me_trend = trends.get(f"DISK:{dev}:media_errors")
            hist_ctx = "First detected in current run."
            if me_trend and me_trend.sample_count >= 2:
                sign = "+" if me_trend.delta >= 0 else ""
                hist_ctx = (
                    f"Media errors increased by {sign}{int(me_trend.delta)} over the last "
                    f"{me_trend.sample_count} runs (Slope: {me_trend.slope_per_run:+.2f}/run)."
                )
            prescriptions.append({
                "rule_id": "HW_NVME_002",
                "severity": "CRITICAL",
                "domain": "HARDWARE",
                "title": "NVMe Media Integrity Errors & Kernel Read Failures",
                "finding_summary": (
                    f"Device {dev} reported {media_errors} SMART media_errors and "
                    f"{total_io_errors} blk_update_request I/O errors in kernel logs."
                ),
                "historical_context": hist_ctx,
                "remediation_type": "PHYSICAL_INTERVENTION",
                "physical_steps": [
                    f"IMMEDIATE ACTION: Back up critical data from {dev} to external media.",
                    "Power down workstation, discharge residual flea power, and inspect M.2 slot for thermal pad oil bleed or loose mounting screw.",
                    "Replace NVMe module; non-zero media_errors coupled with kernel blk_update_request failures indicate irreversible NAND flash degradation.",
                ],
                "verification_cmd": f"sudo smartctl -a {dev}",
                "risk_level": "CRITICAL_HARDWARE",
            })

    # 3. HW_MEM_002: Severe Memory Pressure / Swap Thrashing
    ram_total = float(hw.get("ram_total_bytes", 0))
    ram_avail = float(hw.get("ram_avail_bytes", 0))
    swap_total = float(hw.get("swap_total_bytes", 0))
    swap_used = float(hw.get("swap_used_bytes", 0))

    ram_avail_pct = (ram_avail / ram_total * 100.0) if ram_total > 0 else 100.0
    swap_used_pct = (swap_used / swap_total * 100.0) if swap_total > 0 else 0.0
    oom_anomalies = [a for a in anomalies if a.get("category") == "MEMORY_OOM"]

    if (swap_used_pct > 85.0 and ram_avail_pct < 5.0) or oom_anomalies:
        swap_trend = trends.get("SWAP:used_pct")
        hist_ctx = "First detected in current run."
        if swap_trend and swap_trend.sample_count >= 2:
            hist_ctx = (
                f"Swap saturation averaged {swap_trend.moving_average:.1f}% across last "
                f"{swap_trend.sample_count} runs (Slope: {swap_trend.slope_per_run:+.2f}%/run)."
            )
        prescriptions.append({
            "rule_id": "HW_MEM_002",
            "severity": "HIGH" if not oom_anomalies else "CRITICAL",
            "domain": "HARDWARE",
            "title": "Severe Memory Pressure & Swap Partition Thrashing",
            "finding_summary": (
                f"Swap usage is at {swap_used_pct:.1f}% while available RAM is {ram_avail_pct:.1f}% "
                f"({len(oom_anomalies)} OOM-killer events)."
            ),
            "historical_context": hist_ctx,
            "remediation_type": "PHYSICAL_INTERVENTION",
            "physical_steps": [
                "Audit runaway processes leaking resident memory via 'ps aux --sort=-%mem | head -n 15'.",
                "Physically upgrade system DIMM capacity to prevent premature NVMe SSD wear from constant swap paging.",
            ],
            "verification_cmd": "free -h && swapon --show",
            "risk_level": "MODERATE",
        })

    return evaluated_count, prescriptions
