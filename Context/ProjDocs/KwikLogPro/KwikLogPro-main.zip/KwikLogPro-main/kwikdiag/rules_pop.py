"""
KwikLogPro Pop!_OS (Linux) Diagnostic Ruleset (rules_pop.py)
Implements Section 5.1 rules with strict allowlist sanitization (Section 8.3).
"""

from __future__ import annotations
import re
from typing import Dict, List, Tuple

SAFE_IDENTIFIER_RE = re.compile(r"^[a-zA-Z0-9_.@-]+$")


def sanitize_identifier(raw: str, fallback: str = "unknown.service") -> str:
    """Enforces Section 8.3 Command Injection Prevention allowlist regex."""
    candidate = raw.strip()
    if SAFE_IDENTIFIER_RE.match(candidate):
        return candidate
    return fallback


def evaluate_pop_rules(telemetry: dict, anomalies: List[dict]) -> Tuple[int, List[dict]]:
    """
    Evaluates all 8 Pop!_OS diagnostic rules from Section 5.1.
    Returns (evaluated_count, triggered_prescriptions).
    """
    if telemetry.get("os_family", "linux").lower() != "linux":
        return 0, []

    sw = telemetry.get("software_state", {})
    hw = telemetry.get("hardware", {})
    prescriptions: List[dict] = []
    evaluated_count = 8

    # 1. POP_PKG_001: Interrupted DPKG & Broken APT Dependencies
    broken_pkgs = int(sw.get("broken_packages_count", 0) or 0)
    dpkg_anomalies = [a for a in anomalies if a.get("category") == "PACKAGE_MANAGER"]
    if broken_pkgs > 0 or dpkg_anomalies:
        count_label = broken_pkgs if broken_pkgs > 0 else len(dpkg_anomalies)
        prescriptions.append({
            "rule_id": "POP_PKG_001",
            "severity": "HIGH",
            "domain": "SOFTWARE",
            "title": "Interrupted DPKG & Broken APT Dependencies Detected",
            "finding_summary": f"{count_label} packages are in an unconfigured or half-installed state, blocking system updates.",
            "historical_context": "Detected during package database audit.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "sudo dpkg --configure -a",
                "sudo apt-get update && sudo apt-get install -f -y",
            ],
            "verification_cmd": "sudo dpkg --audit",
            "risk_level": "SAFE",
        })

    # 2. POP_PKG_002: Stale APT/DPKG Lock File
    if sw.get("apt_lock_stale", False):
        prescriptions.append({
            "rule_id": "POP_PKG_002",
            "severity": "MEDIUM",
            "domain": "SOFTWARE",
            "title": "Orphaned APT / DPKG Lock File Blocking Package Operations",
            "finding_summary": "Lock held on /var/lib/dpkg/lock-frontend or /var/lib/apt/lists/lock with no active apt/dpkg PID.",
            "historical_context": "Indicates an abruptly terminated previous package transaction.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "sudo rm -f /var/lib/dpkg/lock-frontend /var/lib/apt/lists/lock && sudo dpkg --configure -a"
            ],
            "verification_cmd": "sudo apt-get check",
            "risk_level": "SAFE",
        })

    # 3. POP_BOOT_001: /boot/efi, /recovery, or root mount capacity >= 90%
    crowded_mounts = []
    for disk in hw.get("disks", []):
        for mp in disk.get("mount_points", []):
            path = mp.get("path", "")
            used_pct = float(mp.get("used_pct", 0.0))
            if used_pct >= 90.0 and path in ("/boot/efi", "/recovery", "/boot", "/"):
                crowded_mounts.append(f"{path} ({used_pct:.1f}%)")
    if crowded_mounts:
        prescriptions.append({
            "rule_id": "POP_BOOT_001",
            "severity": "HIGH",
            "domain": "SOFTWARE",
            "title": "Critical Boot / Root Partition Capacity Exhaustion",
            "finding_summary": f"Mount usage exceeded 90% ceiling on: {', '.join(crowded_mounts)}.",
            "historical_context": "Full /boot/efi or /recovery prevents kernelstub & initramfs updates on Pop!_OS.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "sudo apt-get autoremove --purge -y && sudo kernelstub -v",
                "sudo journalctl --vacuum-size=200M",
            ],
            "verification_cmd": "df -h /boot/efi /recovery /",
            "risk_level": "SAFE",
        })

    # 4. POP_BOOT_002: DKMS broken or unbuilt modules
    dkms_status = str(sw.get("dkms_status", "")).strip()
    if dkms_status and ("broken" in dkms_status.lower() or "added" in dkms_status.lower()):
        prescriptions.append({
            "rule_id": "POP_BOOT_002",
            "severity": "HIGH",
            "domain": "SOFTWARE",
            "title": "Unbuilt or Broken DKMS Kernel Modules Detected",
            "finding_summary": f"DKMS reported modules not installed for running kernel ({telemetry.get('kernel_version', 'current')}).",
            "historical_context": "May cause missing NVIDIA/ZFS/VirtualBox/Wi-Fi drivers on reboot.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "sudo dkms autoinstall -k $(uname -r) && sudo update-initramfs -u -k all"
            ],
            "verification_cmd": "dkms status",
            "risk_level": "SAFE",
        })

    # 5. POP_SNAP_001: Timeshift checkpoint missing or > 30 days old
    ts_info = sw.get("timeshift_status", {}) or {}
    ts_installed = bool(ts_info.get("installed", False))
    ts_count = int(ts_info.get("snapshot_count", 0) or 0)
    if ts_installed and ts_count == 0:
        prescriptions.append({
            "rule_id": "POP_SNAP_001",
            "severity": "MEDIUM",
            "domain": "SOFTWARE",
            "title": "No Active Timeshift System Restore Checkpoints Found",
            "finding_summary": "Timeshift is installed on the workstation, but snapshot_count is 0.",
            "historical_context": "LAST TIMESHIFT: NEVER [ALERT]",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                'sudo timeshift --create --comments "KwikLogPro Automated Checkpoint"'
            ],
            "verification_cmd": "sudo timeshift --list",
            "risk_level": "SAFE",
        })

    # 6. POP_FLAT_001: Corrupted Flatpak OSTree objects
    if sw.get("flatpak_issues", False):
        prescriptions.append({
            "rule_id": "POP_FLAT_001",
            "severity": "MEDIUM",
            "domain": "SOFTWARE",
            "title": "Invalid or Corrupted Flatpak OSTree Objects",
            "finding_summary": "flatpak repair --dry-run detected missing or corrupted local OSTree repo refs.",
            "historical_context": "First detected in current run.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "flatpak repair && flatpak uninstall --unused -y"
            ],
            "verification_cmd": "flatpak repair --dry-run",
            "risk_level": "SAFE",
        })

    # 7. POP_SVC_001: Failed Systemd Units
    failed_units = sw.get("failed_services", []) or []
    if failed_units:
        safe_units = [sanitize_identifier(u) for u in failed_units]
        restart_cmds = [f"sudo systemctl restart {u}" for u in safe_units]
        prescriptions.append({
            "rule_id": "POP_SVC_001",
            "severity": "HIGH",
            "domain": "SOFTWARE",
            "title": "Failed Systemd Daemons Detected",
            "finding_summary": f"{len(safe_units)} systemd unit(s) entered failed state: {', '.join(safe_units)}.",
            "historical_context": "Active service crash or dependency timeout.",
            "remediation_type": "CLI_COMMAND",
            "commands": ["sudo systemctl reset-failed"] + restart_cmds,
            "verification_cmd": "systemctl list-units --state=failed",
            "risk_level": "SAFE",
        })

    # 8. POP_GPU_001: NVIDIA Xid / AMDGPU Ring Timeout in Kernel Logs
    gpu_anomalies = [a for a in anomalies if a.get("category") == "GPU_SUBSYSTEM"]
    if gpu_anomalies:
        total_gpu_hits = sum(int(a.get("occurrence_count", 1)) for a in gpu_anomalies)
        sample_msg = gpu_anomalies[0].get("sample_message", "GPU ring/bus timeout")
        prescriptions.append({
            "rule_id": "POP_GPU_001",
            "severity": "CRITICAL",
            "domain": "SOFTWARE",
            "title": "GPU Driver Reset / PCIe Ring Timeout (NVRM Xid / AMDGPU)",
            "finding_summary": f"Kernel logged {total_gpu_hits} GPU fault event(s): '{sample_msg}'.",
            "historical_context": "Recurring GPU hangs indicate driver corruption or PCIe power delivery instability.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "sudo apt-get install --reinstall system76-driver-nvidia",
                "sudo update-initramfs -u -k all",
            ],
            "verification_cmd": "nvidia-smi || dmesg | grep -iE 'nvrm|amdgpu'",
            "risk_level": "MODERATE",
        })

    return evaluated_count, prescriptions
