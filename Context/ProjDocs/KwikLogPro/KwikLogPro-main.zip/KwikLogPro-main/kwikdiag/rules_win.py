"""
KwikLogPro Windows (10 / 11) Diagnostic Ruleset (rules_win.py)
Implements Section 5.2 rules for Windows Event Log / WMI / CBS telemetry.
"""

from __future__ import annotations
from typing import List, Tuple


def evaluate_win_rules(telemetry: dict, anomalies: List[dict]) -> Tuple[int, List[dict]]:
    """
    Evaluates all 7 Windows 10/11 diagnostic rules from Section 5.2.
    Also evaluates Windows event anomalies when cross-testing `.evtx` logs.
    Returns (evaluated_count, triggered_prescriptions).
    """
    is_win = telemetry.get("os_family", "linux").lower() == "windows"
    has_win_events = any(a.get("event_id") is not None for a in anomalies)
    if not is_win and not has_win_events:
        return 0, []

    sw = telemetry.get("software_state", {})
    prescriptions: List[dict] = []
    evaluated_count = 7

    event_ids = {int(a["event_id"]): a for a in anomalies if a.get("event_id") is not None}

    # 1. WIN_IMG_001: CBS.log corruption or Event ID 10010
    if sw.get("cbs_corrupt", False) or 10010 in event_ids:
        prescriptions.append({
            "rule_id": "WIN_IMG_001",
            "severity": "HIGH",
            "domain": "SOFTWARE",
            "title": "Windows Component Store (WinSxS / CBS) Corruption Detected",
            "finding_summary": "System Event Log (Event ID 10010) or CBS.log reported corrupt component store manifests.",
            "historical_context": "First detected in current run.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "DISM.exe /Online /Cleanup-Image /RestoreHealth",
                "sfc /scannow",
            ],
            "verification_cmd": "DISM.exe /Online /Cleanup-Image /CheckHealth",
            "risk_level": "SAFE",
        })

    # 2. WIN_DSK_001: Event ID 55 (NTFS corruption) or Event ID 153 (Disk I/O retry)
    if 55 in event_ids or 153 in event_ids:
        ev = event_ids.get(55) or event_ids.get(153)
        cnt = ev.get("occurrence_count", 1) if ev else 1
        prescriptions.append({
            "rule_id": "WIN_DSK_001",
            "severity": "CRITICAL",
            "domain": "SOFTWARE",
            "title": "NTFS File System Structure Corruption / Disk Block Retry",
            "finding_summary": f"System.evtx logged {cnt} disk/NTFS anomaly event(s) (Event ID 55 / 153).",
            "historical_context": "Recurring block retries indicate filesystem metadata damage or failing storage media.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "chkdsk C: /f /r",
                "powershell -Command \"Get-PhysicalDisk | Get-StorageReliabilityCounter\"",
            ],
            "verification_cmd": "fsutil dirty query C:",
            "risk_level": "MODERATE",
        })

    # 3. WIN_PWR_001: Event ID 41 (Kernel-Power unclean shutdown)
    if 41 in event_ids:
        ev = event_ids[41]
        prescriptions.append({
            "rule_id": "WIN_PWR_001",
            "severity": "CRITICAL",
            "domain": "HARDWARE",
            "title": "Kernel-Power Event ID 41 Unclean Power Loss Detected",
            "finding_summary": f"System rebooted without cleanly shutting down first ({ev.get('occurrence_count', 1)}x occurrences).",
            "historical_context": "Unclean power loss without BSOD indicates transient PSU rail drop or power delivery fault.",
            "remediation_type": "PHYSICAL_INTERVENTION",
            "physical_steps": [
                "Test PSU 12V rail stability under transient load spikes.",
                "Inspect ATX 24-pin and EPS 8-pin motherboard power connectors for thermal discoloration or loose seating.",
                "Verify external UPS battery health and sine-wave switchover latency.",
            ],
            "verification_cmd": "wevtutil qe System /q:\"*[System[(EventID=41)]]\" /c:5 /f:text",
            "risk_level": "CRITICAL_HARDWARE",
        })

    # 4. WIN_WHEA_01: Event ID 18 or 19 (WHEA-Logger Machine Check Exception)
    if 18 in event_ids or 19 in event_ids:
        ev = event_ids.get(18) or event_ids.get(19)
        prescriptions.append({
            "rule_id": "WIN_WHEA_01",
            "severity": "CRITICAL",
            "domain": "HARDWARE",
            "title": "WHEA-Logger Machine Check Exception (CPU / Interconnect Hardware Fault)",
            "finding_summary": f"Hardware-level CPU cache or PCIe interconnect error logged ({ev.get('sample_message', 'WHEA Event 18')}).",
            "historical_context": "Silicon-level uncorrectable or corrected hardware fault.",
            "remediation_type": "PHYSICAL_INTERVENTION",
            "physical_steps": [
                "Enter BIOS/UEFI and disable aggressive XMP/EXPO memory profiles or Curve Optimizer undervolts.",
                "Update motherboard AGESA / UEFI firmware to the latest stable microcode release.",
                "Run OCCT / Prime95 core-cycling stability verification and inspect CPU socket pin tension.",
            ],
            "verification_cmd": "wevtutil qe System /q:\"*[System[Provider[@Name='Microsoft-Windows-WHEA-Logger']]]\" /c:5 /f:text",
            "risk_level": "CRITICAL_HARDWARE",
        })

    # 5. WIN_MEM_001: BugCheck 0x1A (MEMORY_MANAGEMENT) or 0x50 (PAGE_FAULT_IN_NONPAGED_AREA)
    if 1001 in event_ids:
        prescriptions.append({
            "rule_id": "WIN_MEM_001",
            "severity": "CRITICAL",
            "domain": "HARDWARE",
            "title": "BugCheck Memory Management / Non-Paged Pool Page Fault (0x1A / 0x50)",
            "finding_summary": "System experienced kernel BugCheck 0x1A (MEMORY_MANAGEMENT) or 0x50 (PAGE_FAULT_IN_NONPAGED_AREA).",
            "historical_context": "Indicates defective DRAM cell or unstable DIMM contact.",
            "remediation_type": "PHYSICAL_INTERVENTION",
            "physical_steps": [
                "Schedule Windows Memory Diagnostic via 'mdsched.exe' or boot from a MemTest86+ USB drive.",
                "Power down workstation, reseat DIMMs in primary slots A2/B2, and clean gold contacts with 99% isopropyl alcohol.",
                "Isolate faulty DIMM module by testing single-channel configurations.",
            ],
            "verification_cmd": "mdsched.exe",
            "risk_level": "CRITICAL_HARDWARE",
        })

    # 6. WIN_WMI_001: WMI Repository Inconsistent
    if sw.get("wmi_inconsistent", False):
        prescriptions.append({
            "rule_id": "WIN_WMI_001",
            "severity": "HIGH",
            "domain": "SOFTWARE",
            "title": "WMI CIM Repository Inconsistency Detected",
            "finding_summary": "'winmgmt /verifyrepository' reported that the WMI repository is inconsistent.",
            "historical_context": "Prevents reliable hardware and service telemetry collection via CIM/WMI.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "winmgmt /salvagerepository"
            ],
            "verification_cmd": "winmgmt /verifyrepository",
            "risk_level": "SAFE",
        })

    # 7. WIN_NET_001: Winsock / DNS Socket Exhaustion
    if sw.get("dns_timeouts", False):
        prescriptions.append({
            "rule_id": "WIN_NET_001",
            "severity": "MEDIUM",
            "domain": "SOFTWARE",
            "title": "Winsock Catalog Corruption / Ephemeral Socket Exhaustion",
            "finding_summary": "Network probe detected elevated DNS resolution timeouts or Winsock catalog anomalies.",
            "historical_context": "First detected in current run.",
            "remediation_type": "CLI_COMMAND",
            "commands": [
                "netsh winsock reset && netsh int ip reset && ipconfig /flushdns"
            ],
            "verification_cmd": "nslookup localhost",
            "risk_level": "SAFE",
        })

    return evaluated_count, prescriptions
