"""
Unit tests for KwikLogPro Python Diagnostic Engine & OLS Regression Calculator (test_kwikdiag.py).
"""

import os
import sys
import unittest

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from kwikdiag import evaluate_payload
from rules_pop import sanitize_identifier
from trends import calculate_ols_slope


class TestKwikDiagEngine(unittest.TestCase):
    def test_ols_linear_regression_slope(self):
        # Points on y = 2.5 * t + 40.0
        points = [(0.0, 40.0), (1.0, 42.5), (2.0, 45.0), (3.0, 47.5)]
        slope = calculate_ols_slope(points)
        self.assertAlmostEqual(slope, 2.5, places=5)

    def test_command_injection_sanitization(self):
        self.assertEqual(sanitize_identifier("fwupd.service"), "fwupd.service")
        self.assertEqual(
            sanitize_identifier("bad; rm -rf /", fallback="safe.service"),
            "safe.service",
        )

    def test_pop_and_hw_rule_evaluation(self):
        sample_payload = {
            "telemetry": {
                "schema_version": "1.0",
                "timestamp_utc": "2026-10-27T04:15:00Z",
                "os_family": "linux",
                "os_distro": "Pop!_OS 24.04 LTS",
                "kernel_version": "6.9.3-76060903-generic",
                "uptime_seconds": 432190,
                "hardware": {
                    "cpu_model": "AMD Ryzen 9 7950X",
                    "cpu_temp_celsius": 88.5,
                    "cpu_load_percent": 14.2,
                    "ram_total_bytes": 68719476736,
                    "ram_avail_bytes": 2147483648,
                    "swap_total_bytes": 17179869184,
                    "swap_used_bytes": 15247133900,
                    "disks": [
                        {
                            "device": "/dev/nvme0n1",
                            "model": "Samsung SSD 990 PRO 2TB",
                            "smart_passed": True,
                            "critical_warning_byte": 0,
                            "temp_celsius": 64,
                            "available_spare_pct": 15,
                            "percentage_used": 96,
                            "media_errors": 4,
                            "unsafe_shutdowns": 19,
                            "mount_points": [
                                {"path": "/", "fs_type": "ext4", "used_pct": 94.2}
                            ],
                        }
                    ],
                },
                "software_state": {
                    "failed_services": ["networking.service", "fwupd.service"],
                    "broken_packages_count": 3,
                    "held_packages": ["linux-image-generic"],
                    "apt_lock_stale": True,
                    "dkms_status": "nvidia/555.58, 6.9.3: broken",
                    "flatpak_issues": True,
                    "timeshift_status": {
                        "installed": True,
                        "snapshot_count": 0,
                        "last_snapshot_epoch": None,
                    },
                    "pending_reboot": True,
                },
            },
            "log_parser": {
                "parse_duration_ms": 142,
                "bytes_processed": 1073741824,
                "total_events_scanned": 845920,
                "anomalies": [
                    {
                        "signature_hash": "a94a8fe5ccb19ba6",
                        "source": "kernel",
                        "event_id": None,
                        "severity": "CRITICAL",
                        "category": "STORAGE_IO",
                        "first_seen_utc": "2026-10-25T11:20:01Z",
                        "last_seen_utc": "2026-10-27T03:59:12Z",
                        "occurrence_count": 47,
                        "sample_message": "blk_update_request: I/O error, dev nvme0n1, sector 89234112 op 0x0:(READ)",
                    },
                    {
                        "signature_hash": "f7c3bc1d808e0473",
                        "source": "kernel",
                        "event_id": None,
                        "severity": "CRITICAL",
                        "category": "GPU_SUBSYSTEM",
                        "first_seen_utc": "2026-10-27T01:00:00Z",
                        "last_seen_utc": "2026-10-27T02:00:00Z",
                        "occurrence_count": 2,
                        "sample_message": "NVRM: Xid (PCI:0000:01:00): 79, GPU has fallen off the bus",
                    },
                ],
            },
        }

        res = evaluate_payload(sample_payload, db_path=None)
        self.assertEqual(res["overall_status"], "CRITICAL")
        rule_ids = {p["rule_id"] for p in res["triggered_prescriptions"]}
        for expected in (
            "POP_PKG_001",
            "POP_PKG_002",
            "POP_BOOT_001",
            "POP_BOOT_002",
            "POP_SNAP_001",
            "POP_FLAT_001",
            "POP_SVC_001",
            "POP_GPU_001",
            "HW_THM_001",
            "HW_NVME_001",
            "HW_NVME_002",
            "HW_MEM_002",
        ):
            self.assertIn(expected, rule_ids)

    def test_windows_rules_evaluation(self):
        win_payload = {
            "telemetry": {
                "schema_version": "1.0",
                "timestamp_utc": "2026-10-27T04:15:00Z",
                "os_family": "windows",
                "os_distro": "Microsoft Windows 11 Pro",
                "kernel_version": "10.0.22631",
                "uptime_seconds": 12000,
                "hardware": {
                    "cpu_model": "Intel Core i9-14900K",
                    "cpu_temp_celsius": 55.0,
                    "cpu_load_percent": 20.0,
                    "ram_total_bytes": 34359738368,
                    "ram_avail_bytes": 17179869184,
                    "swap_total_bytes": 8589934592,
                    "swap_used_bytes": 1073741824,
                    "disks": [],
                },
                "software_state": {
                    "failed_services": [],
                    "broken_packages_count": 1,
                    "held_packages": [],
                    "wmi_inconsistent": True,
                    "cbs_corrupt": True,
                    "dns_timeouts": True,
                    "timeshift_status": {"installed": False, "snapshot_count": 0, "last_snapshot_epoch": None},
                    "pending_reboot": True,
                },
            },
            "log_parser": {
                "parse_duration_ms": 95,
                "bytes_processed": 52428800,
                "total_events_scanned": 42000,
                "anomalies": [
                    {"signature_hash": "111", "source": "Kernel-Power", "event_id": 41, "severity": "CRITICAL", "category": "POWER_KERNEL", "first_seen_utc": "2026-10-27T00:00:00Z", "last_seen_utc": "2026-10-27T00:00:00Z", "occurrence_count": 1, "sample_message": "Event 41"},
                    {"signature_hash": "222", "source": "Ntfs", "event_id": 55, "severity": "CRITICAL", "category": "STORAGE_FS", "first_seen_utc": "2026-10-27T00:00:00Z", "last_seen_utc": "2026-10-27T00:00:00Z", "occurrence_count": 2, "sample_message": "Event 55"},
                    {"signature_hash": "333", "source": "WHEA-Logger", "event_id": 18, "severity": "CRITICAL", "category": "CPU_HARDWARE", "first_seen_utc": "2026-10-27T00:00:00Z", "last_seen_utc": "2026-10-27T00:00:00Z", "occurrence_count": 1, "sample_message": "Event 18"},
                    {"signature_hash": "444", "source": "BugCheck", "event_id": 1001, "severity": "CRITICAL", "category": "MEMORY_BUGCHECK", "first_seen_utc": "2026-10-27T00:00:00Z", "last_seen_utc": "2026-10-27T00:00:00Z", "occurrence_count": 1, "sample_message": "BugCheck 0x1A"},
                ],
            },
        }
        res = evaluate_payload(win_payload, db_path=None)
        rule_ids = {p["rule_id"] for p in res["triggered_prescriptions"]}
        for expected in (
            "WIN_IMG_001",
            "WIN_DSK_001",
            "WIN_PWR_001",
            "WIN_WHEA_01",
            "WIN_MEM_001",
            "WIN_WMI_001",
            "WIN_NET_001",
        ):
            self.assertIn(expected, rule_ids)


if __name__ == "__main__":
    unittest.main()
