"""
KwikLogPro Time-Series Degradation & OLS Linear Regression Slope Calculator (trends.py)
Implements Section 4.2 Ordinary Least Squares (OLS) slope math across historical runs in SQLite.
"""

from __future__ import annotations
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import mean
from typing import Dict, List, Optional, Tuple


@dataclass
class MetricTrend:
    component_type: str
    metric_name: str
    sample_count: int
    first_value: float
    latest_value: float
    delta: float
    slope_per_day: float
    slope_per_run: float
    moving_average: float


def parse_iso_to_days(iso_str: str) -> float:
    """Converts an ISO-8601 UTC timestamp string into normalized epoch days."""
    try:
        clean = iso_str.strip()
        if clean.endswith("Z"):
            clean = clean[:-1] + "+00:00"
        dt = datetime.fromisoformat(clean)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp() / 86400.0
    except Exception:
        return datetime.now(timezone.utc).timestamp() / 86400.0


def calculate_ols_slope(points: List[Tuple[float, float]]) -> float:
    """
    Computes the Ordinary Least Squares (OLS) linear regression slope m:
        m = (N * sum(t_i * y_i) - sum(t_i) * sum(y_i)) / (N * sum(t_i^2) - (sum(t_i))^2)
    Requires N >= 3 points; returns 0.0 if N < 3 or denominator is near zero.
    """
    n = len(points)
    if n < 3:
        return 0.0

    # Normalize t_i relative to t_0 for numerical stability
    t0 = points[0][0]
    ts = [p[0] - t0 for p in points]
    ys = [p[1] for p in points]

    sum_t = sum(ts)
    sum_y = sum(ys)
    sum_ty = sum(t * y for t, y in zip(ts, ys))
    sum_t2 = sum(t * t for t in ts)

    denom = (n * sum_t2) - (sum_t * sum_t)
    if abs(denom) < 1e-9:
        return 0.0

    return ((n * sum_ty) - (sum_t * sum_y)) / denom


def compute_metric_trend(
    historical_series: List[Tuple[str, float]],
    current_timestamp_utc: str,
    current_value: float,
    component_type: str,
    metric_name: str,
) -> MetricTrend:
    """
    Combines up to N-1 historical (timestamp_utc, metric_value) samples with the current run sample
    and computes OLS slopes (per day and per run), delta, and moving average.
    """
    combined = list(historical_series) + [(current_timestamp_utc, float(current_value))]
    n = len(combined)
    first_val = float(combined[0][1])
    latest_val = float(combined[-1][1])
    delta = round(latest_val - first_val, 2)
    avg = round(mean(v for _, v in combined), 2)

    day_points = [(parse_iso_to_days(ts), float(val)) for ts, val in combined]
    run_points = [(float(idx), float(val)) for idx, (_, val) in enumerate(combined)]

    slope_day = round(calculate_ols_slope(day_points), 3)
    slope_run = round(calculate_ols_slope(run_points), 3)

    # If all runs happened within seconds of each other, fall back to per-run slope for daily projection
    if abs(slope_day) < 1e-6 and abs(slope_run) > 0:
        slope_day = slope_run

    return MetricTrend(
        component_type=component_type,
        metric_name=metric_name,
        sample_count=n,
        first_value=first_val,
        latest_value=latest_val,
        delta=delta,
        slope_per_day=slope_day,
        slope_per_run=slope_run,
        moving_average=avg,
    )


def load_historical_trends(
    db_path: Optional[str],
    telemetry: dict,
    max_runs: int = 10,
) -> Tuple[Dict[str, MetricTrend], List[int]]:
    """
    Queries the local SQLite database for the last N historical runs (default N=10)
    and calculates MetricTrend objects for CPU, RAM, SWAP, and each Disk.
    Also returns the historical health_score sequence.
    """
    trends: Dict[str, MetricTrend] = {}
    health_scores: List[int] = []
    raw_history: Dict[Tuple[str, str], List[Tuple[str, float]]] = {}

    if db_path:
        try:
            conn = sqlite3.connect(db_path, timeout=5.0)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            cur.execute(
                """
                SELECT run_id, timestamp_utc, health_score
                FROM diagnostic_runs
                ORDER BY run_id DESC
                LIMIT ?
                """,
                (max_runs - 1,),
            )
            runs = list(reversed(cur.fetchall()))
            run_ts_map = {r["run_id"]: r["timestamp_utc"] for r in runs}
            health_scores = [int(r["health_score"]) for r in runs]

            if run_ts_map:
                placeholders = ",".join("?" for _ in run_ts_map)
                cur.execute(
                    f"""
                    SELECT run_id, component_type, metric_name, metric_value
                    FROM telemetry_metrics
                    WHERE run_id IN ({placeholders})
                    ORDER BY run_id ASC
                    """,
                    tuple(run_ts_map.keys()),
                )
                for row in cur.fetchall():
                    key = (row["component_type"], row["metric_name"])
                    ts = run_ts_map.get(row["run_id"], "")
                    raw_history.setdefault(key, []).append((ts, float(row["metric_value"])))

            conn.close()
        except Exception:
            pass

    now_ts = telemetry.get("timestamp_utc", datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    hw = telemetry.get("hardware", {})

    # CPU temp & load
    cpu_temp = float(hw.get("cpu_temp_celsius", 0.0))
    trends["CPU:temp_celsius"] = compute_metric_trend(
        raw_history.get(("CPU", "temp_celsius"), []),
        now_ts,
        cpu_temp,
        "CPU",
        "temp_celsius",
    )

    # RAM used pct
    ram_total = float(hw.get("ram_total_bytes", 0))
    ram_avail = float(hw.get("ram_avail_bytes", 0))
    ram_used_pct = round(((ram_total - ram_avail) / ram_total) * 100.0, 1) if ram_total > 0 else 0.0
    trends["RAM:used_pct"] = compute_metric_trend(
        raw_history.get(("RAM", "used_pct"), []),
        now_ts,
        ram_used_pct,
        "RAM",
        "used_pct",
    )

    # SWAP used pct
    swap_total = float(hw.get("swap_total_bytes", 0))
    swap_used = float(hw.get("swap_used_bytes", 0))
    swap_used_pct = round((swap_used / swap_total) * 100.0, 1) if swap_total > 0 else 0.0
    trends["SWAP:used_pct"] = compute_metric_trend(
        raw_history.get(("SWAP", "used_pct"), []),
        now_ts,
        swap_used_pct,
        "SWAP",
        "used_pct",
    )

    # Disks
    for disk in hw.get("disks", []):
        dev = disk.get("device", "/dev/nvme0n1")
        comp = f"DISK:{dev}"
        for m_name in ("media_errors", "available_spare_pct", "percentage_used", "temp_celsius"):
            val = float(disk.get(m_name, 0.0))
            key_str = f"{comp}:{m_name}"
            trends[key_str] = compute_metric_trend(
                raw_history.get((comp, m_name), []),
                now_ts,
                val,
                comp,
                m_name,
            )

    return trends, health_scores
