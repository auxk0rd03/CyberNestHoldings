use regex::Regex;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::sync::OnceLock;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogAnomaly {
    pub signature_hash: String,
    pub source: String,
    pub event_id: Option<u32>,
    pub severity: String,
    pub category: String,
    pub first_seen_utc: String,
    pub last_seen_utc: String,
    pub occurrence_count: u64,
    pub sample_message: String,
}

#[derive(Debug, Clone)]
pub struct RawAnomalyEvent {
    pub source: String,
    pub event_id: Option<u32>,
    pub severity: String,
    pub category: String,
    pub timestamp_utc: String,
    pub message: String,
}

static DYNAMIC_TOKEN_RE: OnceLock<Option<Regex>> = OnceLock::new();

fn normalize_signature_input(
    source: &str,
    category: &str,
    event_id: Option<u32>,
    msg: &str,
) -> String {
    let re_opt = DYNAMIC_TOKEN_RE.get_or_init(|| {
        Regex::new(
            r"(?x)
            \b0x[0-9a-fA-F]+\b |
            \bsector\s+\d+\b |
            \bpid\s*=?\s*\d+\b |
            \[\s*\d+\.\d+\s*\] |
            \[\d+\] |
            \b\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b |
            \b\d{6,}\b
            ",
        )
        .ok()
    });
    let stripped = match re_opt {
        Some(re) => re.replace_all(msg.trim(), "<NUM>").into_owned(),
        None => msg.trim().to_string(),
    };
    format!("{}|{}|{:?}|{}", source, category, event_id, stripped)
}

pub fn compute_signature_hash(
    source: &str,
    category: &str,
    event_id: Option<u32>,
    msg: &str,
) -> String {
    let norm = normalize_signature_input(source, category, event_id, msg);
    let mut hasher = Sha256::new();
    hasher.update(norm.as_bytes());
    let digest = hasher.finalize();
    digest
        .iter()
        .take(8)
        .map(|b| format!("{:02x}", b))
        .collect()
}

pub fn deduplicate_events(events: Vec<RawAnomalyEvent>) -> Vec<LogAnomaly> {
    let mut map: HashMap<String, LogAnomaly> = HashMap::new();

    for ev in events {
        let sig = compute_signature_hash(&ev.source, &ev.category, ev.event_id, &ev.message);
        map.entry(sig.clone())
            .and_modify(|existing| {
                existing.occurrence_count += 1;
                if ev.timestamp_utc < existing.first_seen_utc && !ev.timestamp_utc.is_empty() {
                    existing.first_seen_utc = ev.timestamp_utc.clone();
                }
                if ev.timestamp_utc > existing.last_seen_utc {
                    existing.last_seen_utc = ev.timestamp_utc.clone();
                }
            })
            .or_insert_with(|| LogAnomaly {
                signature_hash: sig,
                source: ev.source,
                event_id: ev.event_id,
                severity: ev.severity,
                category: ev.category,
                first_seen_utc: ev.timestamp_utc.clone(),
                last_seen_utc: ev.timestamp_utc,
                occurrence_count: 1,
                sample_message: ev.message,
            });
    }

    let mut list: Vec<LogAnomaly> = map.into_values().collect();
    list.sort_by(|a, b| {
        b.occurrence_count
            .cmp(&a.occurrence_count)
            .then_with(|| a.signature_hash.cmp(&b.signature_hash))
    });
    list.truncate(50);
    list
}
