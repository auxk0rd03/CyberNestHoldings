use crate::dedup::RawAnomalyEvent;
use chrono::{DateTime, Utc};
use memmap2::Mmap;
use rayon::prelude::*;
use regex::Regex;
use serde_json::Value;
use std::fs::File;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::OnceLock;

struct RulePattern {
    regex: Regex,
    source: &'static str,
    severity: &'static str,
    category: &'static str,
}

static LINUX_PATTERNS: OnceLock<Vec<RulePattern>> = OnceLock::new();
static ISO_TS_RE: OnceLock<Option<Regex>> = OnceLock::new();

fn get_patterns() -> &'static Vec<RulePattern> {
    LINUX_PATTERNS.get_or_init(|| {
        let defs: &[(&str, &'static str, &'static str, &'static str)] = &[
            (
                r"(?i)(blk_update_request:\s*I/O error|Buffer I/O error|I/O error,\s*dev\s+[a-z0-9]+|nvme[0-9a-z]*:\s*I/O\s*error)",
                "kernel",
                "CRITICAL",
                "STORAGE_IO",
            ),
            (
                r"(?i)(Out of memory:\s*Killed process|oom-kill:|invoked oom-killer)",
                "kernel",
                "CRITICAL",
                "MEMORY_OOM",
            ),
            (
                r"(?i)(NVRM:\s*Xid|amdgpu:.*ring\s+\w+\s+timeout|drm:.*GPU hang|nouveau\s+.*fifo:\s*fault)",
                "kernel",
                "CRITICAL",
                "GPU_SUBSYSTEM",
            ),
            (
                r"(?i)(EXT4-fs error|BTRFS:\s*error|XFS.*corruption|FAT-fs.*error)",
                "kernel",
                "CRITICAL",
                "FILESYSTEM",
            ),
            (
                r"(?i)\bsegfault at [0-9a-fA-F]+ ip\b",
                "kernel",
                "HIGH",
                "PROCESS_CRASH",
            ),
            (
                r"(?i)(Failed to start\s+.+|Unit\s+.+\s+entered failed state|Main process exited,\s*code=exited,\s*status=[1-9])",
                "systemd",
                "HIGH",
                "SERVICE_FAILURE",
            ),
            (
                r"(?i)(dpkg:\s*error processing|Sub-process /usr/bin/dpkg returned an error code|dependency problems - leaving unconfigured)",
                "dpkg",
                "HIGH",
                "PACKAGE_MANAGER",
            ),
        ];
        let mut out = Vec::with_capacity(defs.len());
        for (pat, source, severity, category) in defs {
            if let Ok(regex) = Regex::new(pat) {
                out.push(RulePattern {
                    regex,
                    source,
                    severity,
                    category,
                });
            }
        }
        out
    })
}

fn extract_timestamp_or_now(line: &str, fallback_now: &str) -> String {
    let re_opt = ISO_TS_RE.get_or_init(|| {
        Regex::new(r"^(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2})").ok()
    });
    if let Some(re) = re_opt {
        if let Some(caps) = re.captures(line) {
            if let Some(m) = caps.get(1) {
                let mut ts = m.as_str().replace(' ', "T");
                if !ts.ends_with('Z') {
                    ts.push('Z');
                }
                return ts;
            }
        }
    }
    fallback_now.to_string()
}

fn scan_mmap_file(path: &Path, fallback_now: &str) -> (u64, u64, Vec<RawAnomalyEvent>) {
    if let Ok(meta) = std::fs::symlink_metadata(path) {
        if meta.file_type().is_symlink() {
            return (0, 0, Vec::new());
        }
    }
    let file = match File::open(path) {
        Ok(f) => f,
        Err(_) => return (0, 0, Vec::new()),
    };
    let metadata = match file.metadata() {
        Ok(m) => m,
        Err(_) => return (0, 0, Vec::new()),
    };
    if metadata.len() == 0 {
        return (0, 0, Vec::new());
    }

    let mmap = match unsafe { Mmap::map(&file) } {
        Ok(m) => m,
        Err(_) => return (0, 0, Vec::new()),
    };

    let bytes_len = mmap.len() as u64;
    let text = String::from_utf8_lossy(&mmap);
    let lines: Vec<&str> = text.lines().collect();
    let total_lines = lines.len() as u64;
    let patterns = get_patterns();

    let events: Vec<RawAnomalyEvent> = lines
        .par_iter()
        .filter_map(|line| {
            for pat in patterns {
                if pat.regex.is_match(line) {
                    let ts = extract_timestamp_or_now(line, fallback_now);
                    let clean_msg = line.trim();
                    let sample: String = if clean_msg.chars().count() > 220 {
                        let truncated: String = clean_msg.chars().take(220).collect();
                        format!("{}...", truncated)
                    } else {
                        clean_msg.to_string()
                    };
                    return Some(RawAnomalyEvent {
                        source: pat.source.to_string(),
                        event_id: None,
                        severity: pat.severity.to_string(),
                        category: pat.category.to_string(),
                        timestamp_utc: ts,
                        message: sample,
                    });
                }
            }
            None
        })
        .collect();

    (bytes_len, total_lines, events)
}

fn scan_journalctl(fallback_now: &str) -> (u64, u64, Vec<RawAnomalyEvent>) {
    let output = match Command::new("journalctl")
        .args(["-p", "0..3", "-b", "-n", "2500", "--output=json", "--no-pager"])
        .output()
    {
        Ok(o) => o,
        Err(_) => return (0, 0, Vec::new()),
    };

    let bytes_len = output.stdout.len() as u64;
    if bytes_len == 0 {
        return (0, 0, Vec::new());
    }

    let text = String::from_utf8_lossy(&output.stdout);
    let lines: Vec<&str> = text.lines().collect();
    let total_lines = lines.len() as u64;
    let patterns = get_patterns();

    let events: Vec<RawAnomalyEvent> = lines
        .par_iter()
        .filter_map(|line| {
            let v: Value = serde_json::from_str(line).ok()?;
            let msg = v.get("MESSAGE")?.as_str()?;
            let unit = v
                .get("_SYSTEMD_UNIT")
                .or_else(|| v.get("SYSLOG_IDENTIFIER"))
                .and_then(|u| u.as_str())
                .unwrap_or("systemd");

            let ts_usec = v
                .get("__REALTIME_TIMESTAMP")
                .and_then(|t| t.as_str())
                .and_then(|s| s.parse::<i64>().ok());

            let ts_utc = if let Some(usec) = ts_usec {
                DateTime::<Utc>::from_timestamp(usec / 1_000_000, ((usec % 1_000_000) * 1000) as u32)
                    .map(|dt| dt.format("%Y-%m-%dT%H:%M:%SZ").to_string())
                    .unwrap_or_else(|| fallback_now.to_string())
            } else {
                fallback_now.to_string()
            };

            for pat in patterns {
                if pat.regex.is_match(msg) {
                    return Some(RawAnomalyEvent {
                        source: pat.source.to_string(),
                        event_id: None,
                        severity: pat.severity.to_string(),
                        category: pat.category.to_string(),
                        timestamp_utc: ts_utc,
                        message: msg.chars().take(220).collect(),
                    });
                }
            }

            // Priority 0..3 journal entries that didn't match a specific kernel pattern
            let prio = v
                .get("PRIORITY")
                .and_then(|p| p.as_str())
                .and_then(|p| p.parse::<u8>().ok())
                .unwrap_or(3);
            let severity = if prio <= 2 { "CRITICAL" } else { "HIGH" };

            Some(RawAnomalyEvent {
                source: unit.to_string(),
                event_id: None,
                severity: severity.to_string(),
                category: "JOURNAL_ERR".to_string(),
                timestamp_utc: ts_utc,
                message: msg.chars().take(220).collect(),
            })
        })
        .collect();

    (bytes_len, total_lines, events)
}

pub fn ingest_linux_logs(log_dir: Option<&Path>, use_journalctl: bool) -> (u64, u64, Vec<RawAnomalyEvent>) {
    let fallback_now = Utc::now().format("%Y-%m-%dT%H:%M:%SZ").to_string();
    let base_dir = log_dir.unwrap_or_else(|| Path::new("/var/log"));

    let candidate_files: Vec<PathBuf> = vec![
        base_dir.join("syslog"),
        base_dir.join("kern.log"),
        base_dir.join("dpkg.log"),
        base_dir.join("apt/term.log"),
        base_dir.join("messages"),
    ];

    let results: Vec<(u64, u64, Vec<RawAnomalyEvent>)> = candidate_files
        .par_iter()
        .map(|path| scan_mmap_file(path, &fallback_now))
        .collect();

    let mut total_bytes = 0u64;
    let mut total_events = 0u64;
    let mut all_anomalies = Vec::new();

    for (b, e, mut evs) in results {
        total_bytes += b;
        total_events += e;
        all_anomalies.append(&mut evs);
    }

    if use_journalctl {
        let (jb, je, mut jevs) = scan_journalctl(&fallback_now);
        total_bytes += jb;
        total_events += je;
        all_anomalies.append(&mut jevs);
    }

    (total_bytes, total_events, all_anomalies)
}
