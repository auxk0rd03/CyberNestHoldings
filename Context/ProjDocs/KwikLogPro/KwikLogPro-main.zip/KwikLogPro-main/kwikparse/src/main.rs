mod dedup;
mod linux_logs;
mod windows_evtx;

use dedup::{deduplicate_events, LogAnomaly, RawAnomalyEvent};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::env;
use std::path::{Component, Path, PathBuf};
use std::time::Instant;

#[derive(Debug, Serialize, Deserialize)]
pub struct ParseOutput {
    pub parse_duration_ms: u64,
    pub bytes_processed: u64,
    pub total_events_scanned: u64,
    pub fips_140_3_kat_verified: bool,
    pub anomalies: Vec<LogAnomaly>,
}

/// FIPS 140-3 Known-Answer Test (KAT) self-test for SHA-256
pub fn fips_140_3_sha256_kat() -> Result<(), &'static str> {
    let mut hasher = Sha256::new();
    hasher.update(b"abc");
    let digest = hasher.finalize();
    let hex: String = digest.iter().map(|b| format!("{:02x}", b)).collect();
    if hex == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad" {
        Ok(())
    } else {
        Err("FIPS 140-3 SHA-256 KAT self-test failed")
    }
}

/// CWE-22 Multi-stage relative path sanitization
pub fn sanitize_relative_path(rel: &str) -> Result<PathBuf, &'static str> {
    let trimmed = rel.trim();
    if trimmed.is_empty() || trimmed.contains('\0') || trimmed.starts_with('-') {
        return Err("Invalid or empty relative path");
    }
    let normalized = trimmed.replace('\\', "/");
    let path = Path::new(&normalized);
    if path.is_absolute() {
        return Err("Absolute paths are prohibited in relative sanitizer");
    }
    let mut clean = PathBuf::new();
    for comp in path.components() {
        match comp {
            Component::Normal(seg) => clean.push(seg),
            Component::CurDir => {}
            _ => return Err("Directory traversal component detected (CWE-22)"),
        }
    }
    if clean.as_os_str().is_empty() {
        return Err("Resolved path is empty");
    }
    Ok(clean)
}

/// CWE-22 Safe canonical containment check under base_dir
pub fn safe_resolve_under(base_dir: &Path, rel: &str) -> Result<PathBuf, &'static str> {
    let clean_rel = sanitize_relative_path(rel)?;
    let canon_base = base_dir
        .canonicalize()
        .map_err(|_| "Base directory cannot be canonicalized")?;
    let candidate = canon_base.join(&clean_rel);
    if candidate.exists() {
        let meta = std::fs::symlink_metadata(&candidate).map_err(|_| "Metadata check failed")?;
        if meta.file_type().is_symlink() {
            return Err("Symlink target rejected (CWE-377)");
        }
        let canon_cand = candidate
            .canonicalize()
            .map_err(|_| "Candidate canonicalization failed")?;
        if !canon_cand.starts_with(&canon_base) {
            return Err("Path escapes base directory (CWE-22)");
        }
        Ok(canon_cand)
    } else {
        Ok(candidate)
    }
}

fn main() {
    let start = Instant::now();
    let fips_ok = fips_140_3_sha256_kat().is_ok();
    let args: Vec<String> = env::args().collect();

    let mut os_family = if cfg!(target_os = "windows") {
        "windows".to_string()
    } else {
        "linux".to_string()
    };
    let mut log_dir: Option<PathBuf> = None;
    let mut use_journalctl = true;
    let mut simulate_degraded = env::var("KWIKLOG_SIMULATE_DEGRADED")
        .map(|v| v == "1")
        .unwrap_or(false);

    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--os" if i + 1 < args.len() => {
                os_family = args[i + 1].to_lowercase();
                i += 2;
            }
            "--log-dir" if i + 1 < args.len() => {
                let raw_dir = &args[i + 1];
                if !raw_dir.contains('\0') && !raw_dir.contains("..") {
                    log_dir = Some(PathBuf::from(raw_dir));
                }
                i += 2;
            }
            "--no-journalctl" => {
                use_journalctl = false;
                i += 1;
            }
            "--simulate-degraded" => {
                simulate_degraded = true;
                i += 1;
            }
            _ => {
                i += 1;
            }
        }
    }

    let (mut bytes_processed, mut total_events_scanned, mut raw_events) = if os_family == "windows"
    {
        windows_evtx::ingest_windows_logs(log_dir.as_deref())
    } else {
        linux_logs::ingest_linux_logs(log_dir.as_deref(), use_journalctl)
    };

    if simulate_degraded {
        if bytes_processed == 0 {
            bytes_processed = 1_073_741_824;
            total_events_scanned = 845_920;
        }
        for _ in 0..47 {
            raw_events.push(RawAnomalyEvent {
                source: "kernel".to_string(),
                event_id: None,
                severity: "CRITICAL".to_string(),
                category: "STORAGE_IO".to_string(),
                timestamp_utc: "2026-10-27T03:59:12Z".to_string(),
                message:
                    "blk_update_request: I/O error, dev nvme0n1, sector 89234112 op 0x0:(READ)"
                        .to_string(),
            });
        }
        for _ in 0..12 {
            raw_events.push(RawAnomalyEvent {
                source: "systemd".to_string(),
                event_id: None,
                severity: "HIGH".to_string(),
                category: "SERVICE_FAILURE".to_string(),
                timestamp_utc: "2026-10-27T01:12:04Z".to_string(),
                message: "Failed to start fwupd.service - Firmware update daemon.".to_string(),
            });
        }
        for _ in 0..3 {
            raw_events.push(RawAnomalyEvent {
                source: "kernel".to_string(),
                event_id: None,
                severity: "CRITICAL".to_string(),
                category: "GPU_SUBSYSTEM".to_string(),
                timestamp_utc: "2026-10-27T02:18:44Z".to_string(),
                message: "NVRM: Xid (PCI:0000:01:00): 79, pid=4192, GPU has fallen off the bus."
                    .to_string(),
            });
        }
    }

    let anomalies = deduplicate_events(raw_events);
    let elapsed_ms = start.elapsed().as_millis() as u64;

    let output = ParseOutput {
        parse_duration_ms: elapsed_ms.max(1),
        bytes_processed,
        total_events_scanned,
        fips_140_3_kat_verified: fips_ok,
        anomalies,
    };

    match serde_json::to_string_pretty(&output) {
        Ok(json_str) => println!("{}", json_str),
        Err(e) => {
            eprintln!("[kwikparse] JSON serialization error: {}", e);
            std::process::exit(1);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dedup::{compute_signature_hash, deduplicate_events, RawAnomalyEvent};

    #[test]
    fn test_fips_and_cwe22_sanitization() {
        assert!(fips_140_3_sha256_kat().is_ok());
        assert!(sanitize_relative_path("syslog").is_ok());
        assert!(sanitize_relative_path("../etc/passwd").is_err());
        assert!(sanitize_relative_path("/etc/passwd").is_err());
    }

    #[test]
    fn test_deduplication_strips_dynamic_tokens() {
        let h1 = compute_signature_hash(
            "kernel",
            "STORAGE_IO",
            None,
            "blk_update_request: I/O error, dev nvme0n1, sector 89234112 op 0x0:(READ)",
        );
        let h2 = compute_signature_hash(
            "kernel",
            "STORAGE_IO",
            None,
            "blk_update_request: I/O error, dev nvme0n1, sector 99999999 op 0x0:(READ)",
        );
        assert_eq!(
            h1, h2,
            "Signature hash must normalize dynamic sector numbers"
        );

        let events = vec![
            RawAnomalyEvent {
                source: "kernel".to_string(),
                event_id: None,
                severity: "CRITICAL".to_string(),
                category: "STORAGE_IO".to_string(),
                timestamp_utc: "2026-10-25T11:20:01Z".to_string(),
                message:
                    "blk_update_request: I/O error, dev nvme0n1, sector 89234112 op 0x0:(READ)"
                        .to_string(),
            },
            RawAnomalyEvent {
                source: "kernel".to_string(),
                event_id: None,
                severity: "CRITICAL".to_string(),
                category: "STORAGE_IO".to_string(),
                timestamp_utc: "2026-10-27T03:59:12Z".to_string(),
                message:
                    "blk_update_request: I/O error, dev nvme0n1, sector 12345678 op 0x0:(READ)"
                        .to_string(),
            },
        ];
        let deduped = deduplicate_events(events);
        assert_eq!(deduped.len(), 1);
        assert_eq!(deduped[0].occurrence_count, 2);
        assert_eq!(deduped[0].first_seen_utc, "2026-10-25T11:20:01Z");
        assert_eq!(deduped[0].last_seen_utc, "2026-10-27T03:59:12Z");
    }
}
