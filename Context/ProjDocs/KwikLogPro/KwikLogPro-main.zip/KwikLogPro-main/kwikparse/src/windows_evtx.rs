use crate::dedup::RawAnomalyEvent;
use chrono::Utc;
use memmap2::Mmap;
use rayon::prelude::*;
use regex::Regex;
use std::fs::{self, File};
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

const EVTX_FILE_MAGIC: &[u8; 8] = b"ElfFile\0";
const EVTX_CHUNK_MAGIC: &[u8; 8] = b"ElfChnk\0";
const EVTX_HEADER_SIZE: usize = 4096;
const EVTX_CHUNK_SIZE: usize = 65536;

struct WinEventSignature {
    event_id: u32,
    provider: &'static str,
    severity: &'static str,
    category: &'static str,
    default_msg: &'static str,
    pattern: Regex,
}

static WIN_SIGNATURES: OnceLock<Vec<WinEventSignature>> = OnceLock::new();

fn get_win_signatures() -> &'static Vec<WinEventSignature> {
    WIN_SIGNATURES.get_or_init(|| {
        let defs: &[(u32, &'static str, &'static str, &'static str, &'static str, &str)] = &[
            (
                41,
                "Microsoft-Windows-Kernel-Power",
                "CRITICAL",
                "POWER_KERNEL",
                "The system has rebooted without cleanly shutting down first (Kernel-Power Event ID 41, BugcheckCode 0).",
                r"(?i)(Kernel-Power|EventID[^>]*>41<|BugcheckCode)",
            ),
            (
                55,
                "Ntfs",
                "CRITICAL",
                "STORAGE_FS",
                "A corruption was discovered in the file system structure on volume C: (Ntfs Event ID 55).",
                r"(?i)(Ntfs.*corruption|EventID[^>]*>55<)",
            ),
            (
                153,
                "disk",
                "HIGH",
                "STORAGE_IO",
                "The IO operation at logical block address was retried (disk Event ID 153).",
                r"(?i)(IO operation at logical block address.*retried|EventID[^>]*>153<)",
            ),
            (
                18,
                "Microsoft-Windows-WHEA-Logger",
                "CRITICAL",
                "CPU_HARDWARE",
                "A fatal hardware error has occurred. Component: Processor Core (WHEA-Logger Event ID 18 Machine Check Exception).",
                r"(?i)(WHEA-Logger|Machine Check Exception|EventID[^>]*>1[89]<)",
            ),
            (
                1001,
                "Microsoft-Windows-WER-SystemErrorReporting",
                "CRITICAL",
                "MEMORY_BUGCHECK",
                "The computer has rebooted from a bugcheck: 0x0000001a (MEMORY_MANAGEMENT) / 0x00000050 (PAGE_FAULT_IN_NONPAGED_AREA).",
                r"(?i)(bugcheck|0x0000001a|0x00000050|MEMORY_MANAGEMENT|PAGE_FAULT_IN_NONPAGED_AREA)",
            ),
            (
                10010,
                "Microsoft-Windows-DistributedCOM",
                "HIGH",
                "SYSTEM_INTEGRITY",
                "The server did not register with DCOM within the required timeout / CBS component store corruption (Event ID 10010).",
                r"(?i)(EventID[^>]*>10010<|CBS.*corrupt|did not register with DCOM)",
            ),
        ];
        let mut out = Vec::with_capacity(defs.len());
        for (event_id, provider, severity, category, default_msg, pat) in defs {
            if let Ok(pattern) = Regex::new(pat) {
                out.push(WinEventSignature {
                    event_id: *event_id,
                    provider,
                    severity,
                    category,
                    default_msg,
                    pattern,
                });
            }
        }
        out
    })
}

/// Extracts printable ASCII and UTF-16LE strings from a binary EVTX chunk or record slice.
fn extract_lossy_strings_from_chunk(chunk: &[u8]) -> String {
    let mut out = String::with_capacity(chunk.len() / 2);
    // 1. Extract ASCII runs
    let mut i = 0;
    while i < chunk.len() {
        if chunk[i].is_ascii_graphic() || chunk[i] == b' ' {
            let start = i;
            while i < chunk.len() && (chunk[i].is_ascii_graphic() || chunk[i] == b' ') {
                i += 1;
            }
            if i - start >= 4 {
                if let Ok(s) = std::str::from_utf8(&chunk[start..i]) {
                    out.push_str(s);
                    out.push('\n');
                }
            }
        } else {
            i += 1;
        }
    }

    // 2. Extract UTF-16LE runs (BinXML stores strings in UTF-16LE)
    let mut j = 0;
    while j + 1 < chunk.len() {
        if chunk[j].is_ascii_graphic() && chunk[j + 1] == 0 {
            let mut chars = Vec::new();
            while j + 1 < chunk.len()
                && (chunk[j].is_ascii_graphic() || chunk[j] == b' ')
                && chunk[j + 1] == 0
            {
                chars.push(chunk[j] as char);
                j += 2;
            }
            if chars.len() >= 4 {
                let s: String = chars.into_iter().collect();
                out.push_str(&s);
                out.push('\n');
            }
        } else {
            j += 1;
        }
    }
    out
}

pub fn parse_evtx_file(path: &Path, fallback_now: &str) -> (u64, u64, Vec<RawAnomalyEvent>) {
    if let Ok(meta) = std::fs::symlink_metadata(path) {
        if meta.file_type().is_symlink() {
            return (0, 0, Vec::new());
        }
    }
    let file = match File::open(path) {
        Ok(f) => f,
        Err(_) => return (0, 0, Vec::new()),
    };
    let metadata = match file.metadata() {
        Ok(m) => m,
        Err(_) => return (0, 0, Vec::new()),
    };
    if metadata.len() == 0 {
        return (0, 0, Vec::new());
    }

    let mmap = match unsafe { Mmap::map(&file) } {
        Ok(m) => m,
        Err(_) => return (0, 0, Vec::new()),
    };

    let bytes_len = mmap.len() as u64;
    let sigs = get_win_signatures();

    // Check if binary EVTX header (`ElfFile\0`) is present
    if mmap.len() >= EVTX_HEADER_SIZE && &mmap[0..8] == EVTX_FILE_MAGIC {
        let body = &mmap[EVTX_HEADER_SIZE..];
        let chunks: Vec<&[u8]> = body.chunks(EVTX_CHUNK_SIZE).collect();
        let total_chunks = chunks.len() as u64;

        let events: Vec<RawAnomalyEvent> = chunks
            .par_iter()
            .flat_map(|chunk| {
                let mut found = Vec::new();
                if chunk.len() >= 8 && &chunk[0..8] == EVTX_CHUNK_MAGIC {
                    let extracted = extract_lossy_strings_from_chunk(chunk);
                    for sig in sigs {
                        if sig.pattern.is_match(&extracted) {
                            found.push(RawAnomalyEvent {
                                source: sig.provider.to_string(),
                                event_id: Some(sig.event_id),
                                severity: sig.severity.to_string(),
                                category: sig.category.to_string(),
                                timestamp_utc: fallback_now.to_string(),
                                message: sig.default_msg.to_string(),
                            });
                        }
                    }
                }
                found
            })
            .collect();

        return (bytes_len, total_chunks * 64, events);
    }

    // Fallback for XML/JSON exported Windows Event Logs or plaintext CBS.log
    let text = String::from_utf8_lossy(&mmap);
    let lines: Vec<&str> = text.lines().collect();
    let total_lines = lines.len() as u64;

    let events: Vec<RawAnomalyEvent> = lines
        .par_iter()
        .filter_map(|line| {
            for sig in sigs {
                if sig.pattern.is_match(line) {
                    return Some(RawAnomalyEvent {
                        source: sig.provider.to_string(),
                        event_id: Some(sig.event_id),
                        severity: sig.severity.to_string(),
                        category: sig.category.to_string(),
                        timestamp_utc: fallback_now.to_string(),
                        message: line.trim().chars().take(220).collect(),
                    });
                }
            }
            None
        })
        .collect();

    (bytes_len, total_lines, events)
}

pub fn ingest_windows_logs(log_dir: Option<&Path>) -> (u64, u64, Vec<RawAnomalyEvent>) {
    let fallback_now = Utc::now().format("%Y-%m-%dT%H:%M:%SZ").to_string();
    let base_dir = log_dir.unwrap_or_else(|| Path::new(r"C:\Windows\System32\winevt\Logs"));

    let mut files: Vec<PathBuf> = vec![
        base_dir.join("System.evtx"),
        base_dir.join("Application.evtx"),
    ];

    if let Ok(entries) = fs::read_dir(base_dir) {
        for entry in entries.flatten() {
            let p = entry.path();
            if let Some(ext) = p.extension() {
                if ext == "evtx" || ext == "xml" || ext == "log" {
                    if !files.contains(&p) {
                        files.push(p);
                    }
                }
            }
        }
    }

    let results: Vec<(u64, u64, Vec<RawAnomalyEvent>)> = files
        .par_iter()
        .map(|p| parse_evtx_file(p, &fallback_now))
        .collect();

    let mut total_bytes = 0u64;
    let mut total_events = 0u64;
    let mut all_anomalies = Vec::new();

    for (b, e, mut evs) in results {
        total_bytes += b;
        total_events += e;
        all_anomalies.append(&mut evs);
    }

    (total_bytes, total_events, all_anomalies)
}
