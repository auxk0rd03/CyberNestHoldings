#!/usr/bin/env bash
# CyberNest Labs // KwikLogPro Standardized POSIX Entrypoint (launcher.sh)
# Delegates to dev.sh per CN-DIR-2026-004 Bi-Launcher Specification
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${ROOT_DIR}/dev.sh" "$@"
