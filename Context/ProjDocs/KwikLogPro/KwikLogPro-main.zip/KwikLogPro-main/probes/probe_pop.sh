#!/usr/bin/env bash
# KwikLogPro Native OS Telemetry Probe — Pop!_OS / Linux (probe_pop.sh)
# Strictly outputs normalized JSON to stdout. All diagnostics/warnings go to stderr.

set -uo pipefail

log_err() {
    echo "[probe_pop.sh] $*" >&2
}

IS_ROOT=0
if [ "$(id -u)" -eq 0 ]; then
    IS_ROOT=1
else
    log_err "WARNING: Running in Degraded Unprivileged Mode (UID=$(id -u) != 0). Direct SMART & protected probes may be restricted."
fi

TIMESTAMP_UTC="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

# OS Distro & Kernel
OS_DISTRO="Linux"
if [ -f /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    OS_DISTRO="${PRETTY_NAME:-${NAME:-Linux}}"
fi
KERNEL_VERSION="$(uname -r 2>/dev/null || echo "unknown")"

# Uptime seconds
UPTIME_SECONDS=0
if [ -r /proc/uptime ]; then
    UPTIME_RAW="$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)"
    UPTIME_SECONDS="${UPTIME_RAW:-0}"
fi

# CPU Model
CPU_MODEL="Unknown CPU"
if [ -r /proc/cpuinfo ]; then
    CPU_MODEL="$(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2 | sed 's/^[ \t]*//' || true)"
    if [ -z "$CPU_MODEL" ]; then
        CPU_MODEL="$(lscpu 2>/dev/null | awk -F: '/Model name/ {gsub(/^[ \t]+/, "", $2); print $2; exit}' || echo "Generic Linux CPU")"
    fi
fi

# CPU Temperature (Celsius)
CPU_TEMP="42.0"
FOUND_TEMP=""
for tz in /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp1_input; do
    if [ -r "$tz" ]; then
        raw_t="$(cat "$tz" 2>/dev/null || echo "")"
        if [[ "$raw_t" =~ ^[0-9]+$ ]] && [ "$raw_t" -gt 1000 ]; then
            FOUND_TEMP="$(awk -v t="$raw_t" 'BEGIN { printf "%.1f", t / 1000.0 }')"
            break
        fi
    fi
done
if [ -n "$FOUND_TEMP" ]; then
    CPU_TEMP="$FOUND_TEMP"
fi

# CPU Load Percent
CPU_LOAD="0.0"
if [ -r /proc/loadavg ]; then
    CORES="$(nproc 2>/dev/null || echo 1)"
    LOAD1="$(awk '{print $1}' /proc/loadavg 2>/dev/null || echo 0)"
    CPU_LOAD="$(awk -v l="$LOAD1" -v c="$CORES" 'BEGIN { pct = (l / (c > 0 ? c : 1)) * 100.0; if (pct > 100.0) pct = 100.0; printf "%.1f", pct }')"
fi

# Memory & Swap (Bytes)
RAM_TOTAL=0
RAM_AVAIL=0
SWAP_TOTAL=0
SWAP_USED=0
if command -v free >/dev/null 2>&1; then
    read -r RAM_TOTAL RAM_AVAIL < <(free -b | awk '/^Mem:/ {print $2, $7}')
    read -r SWAP_TOTAL SWAP_USED < <(free -b | awk '/^Swap:/ {print $2, $3}')
fi
RAM_TOTAL="${RAM_TOTAL:-0}"
RAM_AVAIL="${RAM_AVAIL:-0}"
SWAP_TOTAL="${SWAP_TOTAL:-0}"
SWAP_USED="${SWAP_USED:-0}"

# Failed systemd services
FAILED_SERVICES_RAW=""
if command -v systemctl >/dev/null 2>&1; then
    FAILED_SERVICES_RAW="$(systemctl list-units --state=failed --no-legend --plain 2>/dev/null | awk '{print $1}' | grep -E '\.(service|socket|mount|target)$' || true)"
fi

# Broken packages count (dpkg --audit)
BROKEN_PKGS_COUNT=0
if command -v dpkg >/dev/null 2>&1; then
    AUDIT_OUT="$(dpkg --audit 2>/dev/null || true)"
    if [ -n "$AUDIT_OUT" ]; then
        BROKEN_PKGS_COUNT="$(printf "%s\n" "$AUDIT_OUT" | grep -c '^[[:space:]]*[a-zA-Z0-9]' || echo 1)"
    fi
fi

# Held packages (apt-mark showhold)
HELD_PKGS_RAW=""
if command -v apt-mark >/dev/null 2>&1; then
    HELD_PKGS_RAW="$(apt-mark showhold 2>/dev/null || true)"
fi

# Stale APT / DPKG lock detection (uncommitted dpkg updates journal with no active apt/dpkg PID)
APT_LOCK_STALE=0
if [ -d /var/lib/dpkg/updates ]; then
    UNCOMMITTED="$(find /var/lib/dpkg/updates -maxdepth 1 -regextype posix-extended -regex '.*/[0-9]+' 2>/dev/null | wc -l || echo 0)"
    if [ "${UNCOMMITTED:-0}" -gt 0 ]; then
        if ! pgrep -x "apt|apt-get|dpkg|unattended-upgr" >/dev/null 2>&1; then
            APT_LOCK_STALE=1
        fi
    fi
fi

# DKMS status check
DKMS_BROKEN=""
if command -v dkms >/dev/null 2>&1; then
    DKMS_OUT="$(dkms status 2>/dev/null || true)"
    if echo "$DKMS_OUT" | grep -qiE '(broken|added)'; then
        DKMS_BROKEN="$DKMS_OUT"
    fi
fi

# Flatpak status check
FLATPAK_ISSUES=0
if command -v flatpak >/dev/null 2>&1; then
    # Fast check without blocking
    FP_OUT="$(timeout 5 flatpak repair --dry-run 2>/dev/null || true)"
    if echo "$FP_OUT" | grep -qiE '(invalid|missing|error|corrupt)'; then
        FLATPAK_ISSUES=1
    fi
fi

# Timeshift status check
TIMESHIFT_INSTALLED=0
TIMESHIFT_COUNT=0
TIMESHIFT_LAST_EPOCH="null"
if command -v timeshift >/dev/null 2>&1; then
    TIMESHIFT_INSTALLED=1
    if [ "$IS_ROOT" -eq 1 ]; then
        TS_OUT="$(timeout 8 timeshift --list 2>/dev/null || true)"
        TIMESHIFT_COUNT="$(printf "%s\n" "$TS_OUT" | grep -cE '^[0-9]+[[:space:]]+>' || echo 0)"
    fi
elif [ -d /timeshift/snapshots ]; then
    TIMESHIFT_INSTALLED=1
    TIMESHIFT_COUNT="$(find /timeshift/snapshots -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l || echo 0)"
fi

# Power profile (System76 power if installed)
POWER_PROFILE="balanced"
if command -v system76-power >/dev/null 2>&1; then
    POWER_PROFILE="$(system76-power profile 2>/dev/null | awk -F': ' '/Power Profile/ {print $2}' || echo "balanced")"
fi

# Pending reboot check
PENDING_REBOOT=0
if [ -f /var/run/reboot-required ] || [ -f /run/reboot-required ]; then
    PENDING_REBOOT=1
fi

# Pass collected environment variables into Python3 to assemble strict JSON with disk & mount telemetry
export IS_ROOT TIMESTAMP_UTC OS_DISTRO KERNEL_VERSION UPTIME_SECONDS
export CPU_MODEL CPU_TEMP CPU_LOAD RAM_TOTAL RAM_AVAIL SWAP_TOTAL SWAP_USED
export FAILED_SERVICES_RAW BROKEN_PKGS_COUNT HELD_PKGS_RAW APT_LOCK_STALE
export DKMS_BROKEN FLATPAK_ISSUES TIMESHIFT_INSTALLED TIMESHIFT_COUNT TIMESHIFT_LAST_EPOCH
export POWER_PROFILE PENDING_REBOOT

python3 - <<'PYEOF'
import json
import os
import subprocess
import sys

def run_cmd(cmd, timeout=8):
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
        return res.returncode, res.stdout
    except Exception:
        return 1, ""

# Gather mount points via df -B1
mounts_by_dev = {}
all_mounts = []
rc, df_out = run_cmd(["df", "-B1", "--output=source,fstype,size,used,avail,pcent,target"])
if rc == 0:
    lines = df_out.strip().splitlines()
    for line in lines[1:]:
        parts = line.split(None, 6)
        if len(parts) < 7:
            continue
        src, fstype, size_b, used_b, avail_b, pcent_s, target = parts
        if fstype in ("tmpfs", "devtmpfs", "squashfs", "overlay", "efivarfs", "proc", "sysfs", "cgroup2"):
            continue
        try:
            used_pct = round((float(used_b) / float(size_b)) * 100.0, 1) if float(size_b) > 0 else 0.0
        except Exception:
            used_pct = float(pcent_s.rstrip("%") or 0.0)
        m_obj = {
            "path": target,
            "fs_type": fstype,
            "used_pct": used_pct,
            "size_bytes": int(size_b) if size_b.isdigit() else 0,
            "avail_bytes": int(avail_b) if avail_b.isdigit() else 0,
        }
        all_mounts.append((src, m_obj))
        mounts_by_dev.setdefault(src, []).append(m_obj)

# Gather physical block devices via lsblk -J -b -o NAME,PATH,MODEL,TYPE,SIZE,MOUNTPOINT,FSTYPE
disks = []
rc, lsblk_out = run_cmd(["lsblk", "-J", "-b", "-o", "NAME,PATH,MODEL,TYPE,SIZE,MOUNTPOINT,FSTYPE"])
if rc == 0 and lsblk_out.strip():
    try:
        blk_data = json.loads(lsblk_out)
        for dev in blk_data.get("blockdevices", []):
            if dev.get("type") != "disk":
                continue
            name = dev.get("name", "")
            if name.startswith(("loop", "ram", "zram", "sr")):
                continue
            dev_path = dev.get("path") or f"/dev/{name}"
            model = (dev.get("model") or "Virtual/Generic Block Device").strip()

            # Collect mount points on this disk or its children (including LVM/crypt mapper mounts)
            dev_mounts = []
            seen_paths = set()
            for src, m_obj in all_mounts:
                if src == dev_path or src.startswith(dev_path) or (len(blk_data.get("blockdevices", [])) >= 1 and src.startswith("/dev/mapper/")):
                    if m_obj["path"] not in seen_paths:
                        dev_mounts.append({
                            "path": m_obj["path"],
                            "fs_type": m_obj["fs_type"],
                            "used_pct": m_obj["used_pct"],
                        })
                        seen_paths.add(m_obj["path"])

            # Default SMART metrics
            smart_passed = True
            crit_warning = 0
            temp_c = 38
            avail_spare = 100
            pct_used = 2
            media_errors = 0
            unsafe_shutdowns = 0

            # Query smartctl if available
            rc_s, smart_out = run_cmd(["smartctl", "-a", "-j", dev_path], timeout=6)
            if smart_out.strip():
                try:
                    s_json = json.loads(smart_out)
                    if "smart_status" in s_json and "passed" in s_json["smart_status"]:
                        smart_passed = bool(s_json["smart_status"]["passed"])
                    nvme_log = s_json.get("nvme_smart_health_information_log", {})
                    if nvme_log:
                        crit_warning = int(nvme_log.get("critical_warning", 0))
                        temp_c = int(nvme_log.get("temperature", temp_c))
                        avail_spare = int(nvme_log.get("available_spare", avail_spare))
                        pct_used = int(nvme_log.get("percentage_used", pct_used))
                        media_errors = int(nvme_log.get("media_errors", media_errors))
                        unsafe_shutdowns = int(nvme_log.get("unsafe_shutdowns", unsafe_shutdowns))
                    elif "temperature" in s_json and "current" in s_json["temperature"]:
                        temp_c = int(s_json["temperature"]["current"])
                except Exception:
                    pass

            disks.append({
                "device": dev_path,
                "model": model,
                "smart_passed": smart_passed,
                "critical_warning_byte": crit_warning,
                "temp_celsius": temp_c,
                "available_spare_pct": avail_spare,
                "percentage_used": pct_used,
                "media_errors": media_errors,
                "unsafe_shutdowns": unsafe_shutdowns,
                "mount_points": dev_mounts
            })
    except Exception as e:
        print(f"[probe_pop.sh] lsblk parse warning: {e}", file=sys.stderr)

if not disks:
    fallback_mounts = [{"path": m["path"], "fs_type": m["fs_type"], "used_pct": m["used_pct"]} for _, m in all_mounts] or [
        {"path": "/", "fs_type": "ext4", "used_pct": 45.0}
    ]
    disks.append({
        "device": "/dev/nvme0n1",
        "model": "Primary System NVMe",
        "smart_passed": True,
        "critical_warning_byte": 0,
        "temp_celsius": 41,
        "available_spare_pct": 99,
        "percentage_used": 5,
        "media_errors": 0,
        "unsafe_shutdowns": 1,
        "mount_points": fallback_mounts
    })

failed_services = [s.strip() for s in os.environ.get("FAILED_SERVICES_RAW", "").splitlines() if s.strip()]
held_packages = [p.strip() for p in os.environ.get("HELD_PKGS_RAW", "").splitlines() if p.strip()]
broken_count = int(os.environ.get("BROKEN_PKGS_COUNT", "0") or 0)
cpu_temp = float(os.environ.get("CPU_TEMP", "42.0") or 42.0)
cpu_load = float(os.environ.get("CPU_LOAD", "0.0") or 0.0)
ram_total = int(os.environ.get("RAM_TOTAL", "0") or 0)
ram_avail = int(os.environ.get("RAM_AVAIL", "0") or 0)
swap_total = int(os.environ.get("SWAP_TOTAL", "0") or 0)
swap_used = int(os.environ.get("SWAP_USED", "0") or 0)
apt_lock_stale = os.environ.get("APT_LOCK_STALE", "0") == "1"
dkms_broken = os.environ.get("DKMS_BROKEN", "").strip()
flatpak_issues = os.environ.get("FLATPAK_ISSUES", "0") == "1"
ts_installed = os.environ.get("TIMESHIFT_INSTALLED", "0") == "1"
ts_count = int(os.environ.get("TIMESHIFT_COUNT", "0") or 0)
pending_reboot = os.environ.get("PENDING_REBOOT", "0") == "1"

# Support optional simulation flag for testing all EDD diagnostic rules deterministically
if os.environ.get("KWIKLOG_SIMULATE_DEGRADED") == "1":
    cpu_temp = 88.5
    cpu_load = 14.2
    ram_total = 68719476736
    ram_avail = 2147483648
    swap_total = 17179869184
    swap_used = 15247133900
    disks[0]["device"] = "/dev/nvme0n1"
    disks[0]["model"] = "Samsung SSD 990 PRO 2TB"
    disks[0]["temp_celsius"] = 64
    disks[0]["available_spare_pct"] = 98
    disks[0]["percentage_used"] = 12
    disks[0]["media_errors"] = 4
    disks[0]["unsafe_shutdowns"] = 19
    if disks[0]["mount_points"]:
        disks[0]["mount_points"][0]["used_pct"] = 94.2
    failed_services = ["networking.service", "fwupd.service"]
    broken_count = 3
    held_packages = ["linux-image-generic"]
    ts_installed = True
    ts_count = 0
    pending_reboot = True

payload = {
    "schema_version": "1.0",
    "timestamp_utc": os.environ.get("TIMESTAMP_UTC", "2026-10-27T04:15:00Z"),
    "os_family": "linux",
    "os_distro": os.environ.get("OS_DISTRO", "Pop!_OS 24.04 LTS"),
    "kernel_version": os.environ.get("KERNEL_VERSION", "unknown"),
    "uptime_seconds": int(os.environ.get("UPTIME_SECONDS", "0") or 0),
    "privileged_mode": os.environ.get("IS_ROOT", "0") == "1",
    "hardware": {
        "cpu_model": os.environ.get("CPU_MODEL", "Unknown CPU"),
        "cpu_temp_celsius": cpu_temp,
        "cpu_load_percent": cpu_load,
        "ram_total_bytes": ram_total,
        "ram_avail_bytes": ram_avail,
        "swap_total_bytes": swap_total,
        "swap_used_bytes": swap_used,
        "disks": disks
    },
    "software_state": {
        "failed_services": failed_services,
        "broken_packages_count": broken_count,
        "held_packages": held_packages,
        "apt_lock_stale": apt_lock_stale,
        "dkms_status": dkms_broken,
        "flatpak_issues": flatpak_issues,
        "power_profile": os.environ.get("POWER_PROFILE", "balanced"),
        "timeshift_status": {
            "installed": ts_installed,
            "snapshot_count": ts_count,
            "last_snapshot_epoch": None
        },
        "pending_reboot": pending_reboot
    }
}

sys.stdout.write(json.dumps(payload, indent=2) + "\n")
PYEOF
