@echo off
REM KwikLogPro Native OS Telemetry Probe — Windows 10/11 (probe_win.bat)
REM Strictly outputs normalized JSON to stdout. All diagnostics/warnings go to stderr.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference = 'SilentlyContinue'; " ^
  "$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator); " ^
  "if (-not $isAdmin) { [Console]::Error.WriteLine('[probe_win.bat] WARNING: Running in Degraded Unprivileged Mode (Non-Administrator SID).') }; " ^
  "$os = Get-CimInstance Win32_OperatingSystem; " ^
  "$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1; " ^
  "$pf = Get-CimInstance Win32_PageFileUsage | Select-Object -First 1; " ^
  "$tz = Get-CimInstance -Namespace root/wmi MSAcpi_ThermalZoneTemperature | Select-Object -First 1; " ^
  "$cpuTemp = if ($tz -and $tz.CurrentTemperature) { [math]::Round(($tz.CurrentTemperature / 10.0) - 273.15, 1) } else { 48.0 }; " ^
  "$uptime = if ($os.LastBootUpTime) { [int]((Get-Date) - $os.LastBootUpTime).TotalSeconds } else { 3600 }; " ^
  "$ramTotal = [int64]($os.TotalVisibleMemorySize * 1024); " ^
  "$ramAvail = [int64]($os.FreePhysicalMemory * 1024); " ^
  "$swapTotal = if ($pf) { [int64]($pf.AllocatedBaseSize * 1024 * 1024) } else { 0 }; " ^
  "$swapUsed = if ($pf) { [int64]($pf.CurrentUsage * 1024 * 1024) } else { 0 }; " ^
  "$vols = Get-Volume | Where-Object { $_.DriveLetter -ne $null } | ForEach-Object { " ^
  "  $usedPct = if ($_.Size -gt 0) { [math]::Round((($_.Size - $_.SizeRemaining) / $_.Size) * 100.0, 1) } else { 0.0 }; " ^
  "  @{ path = ($_.DriveLetter + ':\'); fs_type = [string]$_.FileSystemType; used_pct = $usedPct } " ^
  "}; " ^
  "$disks = @(); " ^
  "$physDisks = Get-PhysicalDisk; " ^
  "foreach ($pd in $physDisks) { " ^
  "  $rel = $pd | Get-StorageReliabilityCounter; " ^
  "  $disks += @{ " ^
  "    device = ('\\.\PhysicalDrive' + $pd.DeviceId); " ^
  "    model = [string]$pd.FriendlyName; " ^
  "    smart_passed = ($pd.OperationalStatus -eq 'OK'); " ^
  "    critical_warning_byte = 0; " ^
  "    temp_celsius = if ($rel -and $rel.Temperature) { [int]$rel.Temperature } else { 40 }; " ^
  "    available_spare_pct = 100 - (if ($rel -and $rel.Wear) { [int]$rel.Wear } else { 1 }); " ^
  "    percentage_used = if ($rel -and $rel.Wear) { [int]$rel.Wear } else { 1 }; " ^
  "    media_errors = if ($rel -and $rel.ReadErrorsUncorrected) { [int]$rel.ReadErrorsUncorrected } else { 0 }; " ^
  "    unsafe_shutdowns = 0; " ^
  "    mount_points = @($vols) " ^
  "  } " ^
  "}; " ^
  "$failedSvcs = @(Get-Service | Where-Object { $_.Status -eq 'Stopped' -and $_.StartType -eq 'Automatic' } | Select-Object -ExpandProperty Name); " ^
  "$rebootPending = [bool](Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'); " ^
  "$wmiVerify = (winmgmt /verifyrepository) -join ' '; " ^
  "$wmiInconsistent = ($wmiVerify -match 'inconsistent'); " ^
  "$cbsCorrupt = $false; " ^
  "if (Test-Path 'C:\Windows\Logs\CBS\CBS.log') { " ^
  "  $cbsTail = Get-Content 'C:\Windows\Logs\CBS\CBS.log' -Tail 200; " ^
  "  if ($cbsTail -match 'corrupt|Cannot repair member file') { $cbsCorrupt = $true } " ^
  "}; " ^
  "$payload = @{ " ^
  "  schema_version = '1.0'; " ^
  "  timestamp_utc = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); " ^
  "  os_family = 'windows'; " ^
  "  os_distro = [string]$os.Caption; " ^
  "  kernel_version = [string]$os.Version; " ^
  "  uptime_seconds = $uptime; " ^
  "  privileged_mode = $isAdmin; " ^
  "  hardware = @{ " ^
  "    cpu_model = [string]$cpu.Name; " ^
  "    cpu_temp_celsius = $cpuTemp; " ^
  "    cpu_load_percent = [double]$cpu.LoadPercentage; " ^
  "    ram_total_bytes = $ramTotal; " ^
  "    ram_avail_bytes = $ramAvail; " ^
  "    swap_total_bytes = $swapTotal; " ^
  "    swap_used_bytes = $swapUsed; " ^
  "    disks = $disks " ^
  "  }; " ^
  "  software_state = @{ " ^
  "    failed_services = $failedSvcs; " ^
  "    broken_packages_count = if ($cbsCorrupt) { 1 } else { 0 }; " ^
  "    held_packages = @(); " ^
  "    wmi_inconsistent = $wmiInconsistent; " ^
  "    cbs_corrupt = $cbsCorrupt; " ^
  "    dns_timeouts = $false; " ^
  "    timeshift_status = @{ installed = $false; snapshot_count = 0; last_snapshot_epoch = $null }; " ^
  "    pending_reboot = $rebootPending " ^
  "  } " ^
  "}; " ^
  "$payload | ConvertTo-Json -Depth 6"
