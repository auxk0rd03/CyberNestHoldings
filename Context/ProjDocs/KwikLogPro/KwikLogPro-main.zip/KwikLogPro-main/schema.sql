PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;

-- 1. Master table for each diagnostic execution
CREATE TABLE IF NOT EXISTS diagnostic_runs (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp_utc TEXT NOT NULL,
    os_family TEXT NOT NULL CHECK(os_family IN ('linux', 'windows')),
    os_distro TEXT NOT NULL,
    kernel_version TEXT NOT NULL,
    health_score INTEGER NOT NULL CHECK(health_score BETWEEN 0 AND 100),
    overall_status TEXT NOT NULL CHECK(overall_status IN ('OPTIMAL', 'DEGRADED', 'CRITICAL')),
    scan_duration_ms INTEGER NOT NULL,
    raw_telemetry_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_runs_timestamp ON diagnostic_runs(timestamp_utc DESC);

-- 2. Flattened numerical metrics for fast time-series trend queries
CREATE TABLE IF NOT EXISTS telemetry_metrics (
    metric_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    component_type TEXT NOT NULL, -- e.g., 'CPU', 'RAM', 'SWAP', 'DISK:/dev/nvme0n1'
    metric_name TEXT NOT NULL,    -- e.g., 'temp_celsius', 'media_errors', 'used_pct'
    metric_value REAL NOT NULL,
    FOREIGN KEY (run_id) REFERENCES diagnostic_runs(run_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_metrics_lookup ON telemetry_metrics(component_type, metric_name, run_id);

-- 3. Deduplicated log anomalies captured by Rust kwikparse
CREATE TABLE IF NOT EXISTS log_anomalies (
    anomaly_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    signature_hash TEXT NOT NULL,
    source TEXT NOT NULL,
    event_id INTEGER,
    severity TEXT NOT NULL,
    category TEXT NOT NULL,
    first_seen_utc TEXT NOT NULL,
    last_seen_utc TEXT NOT NULL,
    occurrence_count INTEGER NOT NULL,
    sample_message TEXT NOT NULL,
    FOREIGN KEY (run_id) REFERENCES diagnostic_runs(run_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_anomalies_hash ON log_anomalies(signature_hash);

-- 4. Generated software commands and hardware interventions
CREATE TABLE IF NOT EXISTS prescriptions (
    prescription_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    rule_id TEXT NOT NULL,
    severity TEXT NOT NULL CHECK(severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    domain TEXT NOT NULL CHECK(domain IN ('SOFTWARE', 'HARDWARE')),
    title TEXT NOT NULL,
    finding_summary TEXT NOT NULL,
    historical_context TEXT,
    remediation_type TEXT NOT NULL CHECK(remediation_type IN ('CLI_COMMAND', 'PHYSICAL_INTERVENTION')),
    action_payload_json TEXT NOT NULL, -- JSON array of commands or physical steps
    verification_cmd TEXT,
    risk_level TEXT NOT NULL DEFAULT 'SAFE',
    acknowledged INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (run_id) REFERENCES diagnostic_runs(run_id) ON DELETE CASCADE
);
