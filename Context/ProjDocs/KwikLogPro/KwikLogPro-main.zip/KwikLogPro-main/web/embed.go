package webassets

import "embed"

// EmbeddedFS bundles all static assets (htmx.min.js, brutalist.css) and HTML templates into kwiklogd.
//
//go:embed static/* templates/*
var EmbeddedFS embed.FS
