# CyberNest Labs: NestComm Developer Handoff Manual

## Document Purpose & Scope

This document serves as the primary technical handover, architecture specification, and developer onboarding reference for **NestComm** (`https://github.com/auxk0rd03/NestComm.git`). It details the end-to-end peer-to-peer (P2P) synchronous messaging architecture, explains the operational role of every file in the codebase, describes how distributed networking, cryptographic key management, offline store-and-forward staging, CMMC 2.0 / FIPS 140-3 / DISA STIG compliance, and process supervision interact, and provides actionable guides for extending protocols, tuning engines, and maintaining the platform following our comprehensive architectural refactoring and security hardening audit.

---

## 1. Complete Codebase Directory Tree

```text
NestComm/
├── .gitignore                          # Git ignore rules (binaries, venvs, test artifacts, storage, logs)
├── NestCommHandoff.md                  # Master technical architecture & maintenance handover manual
├── README.md                           # Operational manual, user guide & architectural overview
├── SBOM.md                             # CISA-compliant human-readable Software Bill of Materials
├── SBOM.cyclonedx.json                 # CycloneDX 1.5 JSON SBOM manifest
├── SBOM.spdx.json                      # SPDX 2.3 JSON SBOM manifest
├── launcher.sh                         # Unified root Linux/Pop!_OS bash launcher & process manager
├── launcher.bat                        # Unified root Windows batch launcher & port coordinator
├── dev.sh                              # Standard 004 POSIX runner (setup, build, run, serve, cli, simulate, test, fmt)
├── dev.bat                             # Standard 004 Windows runner (setup, build, run, serve, cli, simulate, test, fmt)
├── bin/                                # Native compiled binaries (nestcomm[.exe], nestcomm-daemon[.exe])
├── backend/
│   ├── go.mod                          # Go module dependencies (libp2p v0.48, DHT, Noise, keyring)
│   ├── go.sum                          # Cryptographic checksums and integrity hashes for Go dependencies
│   ├── main.go                         # Master Go entrypoint: libp2p host, DHT, offline queue & HTTP backend
│   ├── compliance.go                   # CMMC 2.0, DISA STIG, STIX/TAXII 2.1, IEEE 802 sense, CWE-22 & 120s dead-man switch
│   └── security_test.go                # Comprehensive automated test suite validating security & compliance
├── daemon/
│   ├── Cargo.toml                      # Rust package definition and companion crate dependencies
│   ├── Cargo.lock                      # Pinned Rust dependencies
│   └── src/
│       └── main.rs                     # Rust supervisor: FIPS 140-3 KAT, CWE-22 guard, dual-mode monitor & browser launcher
├── frontend/
│   ├── index.html                      # HTMX dashboard: dynamic peer ID, status polling, 1-click copy & telemetry banks
│   ├── style.css                       # Component layout styles
│   └── synth-ledger.css                # Nocturnal Synth-Ledger design tokens & CRT grid system
├── scripts/
│   ├── install.sh                      # Systemd daemon installer script for Linux / Pop!_OS
│   ├── install.bat                     # Scheduled task installer script for Windows
│   ├── launcher.sh                     # Hardened Linux shell launcher with dynamic porting & PID tracking
│   ├── launcher.bat                    # Hardened Windows batch launcher with dynamic porting
│   └── simulate.py                     # Headless multi-threaded DHT swarm network simulator
└── Docs/
    ├── Architecture_Refactoring_and_Hardening_Report.md # Formal security refactoring & hardening report
    ├── CyberNest Labs Color System .docx                # CyberNest brand identity & color tokens
    ├── NestComm_EDD_v2.md                               # Engineering Design Document v2 specification
    ├── NestComm_EDD_v2.pdf                              # Formal distribution PDF of EDD v2
    └── nestcomm-outbound-message-flow.png               # Outbound message routing & staging flowchart
```

---

## 2. Deep File-by-File Breakdown

### Root Launchers & Process Managers

#### `launcher.sh`
- **Role**: Primary repository-root Linux / Pop!_OS entrypoint and delegation wrapper.
- **What It Does**:
  1. Enforces strict POSIX execution with `set -euo pipefail` and `IFS=$'\n\t'`.
  2. Resolves absolute directory symlinks and delegates invocation directly to `scripts/launcher.sh "$@"`.
  3. Guarantees that operators can launch NestComm seamlessly from the project root without path navigation.
- **How to Modify**: Add root-level environment pre-sets or flag forwarding.

#### `launcher.bat`
- **Role**: Primary repository-root Windows entrypoint and delegation runner.
- **What It Does**:
  1. Resolves execution directory (`%~dp0`) and transparently calls `scripts\launcher.bat %*`.
  2. Allows 1-click double-click execution or command-line startup from Windows Explorer or Terminal.
- **How to Modify**: Adjust parameter passing or custom pre-initialization environment variables.

---

### Scripts & Daemon Automation (`scripts/`)

#### `scripts/launcher.sh`
- **Role**: Hardened Linux shell launcher, environment coordinator, dynamic port negotiator, and safe process supervisor.
- **What It Does**:
  1. **Strict Shell Isolation**: Executes under `set -euo pipefail` with `umask 077` to prevent file descriptor and permission leakage.
  2. **Symlink-Hardened Logging (CWE-377 Defense)**: Initializes `${SCRIPT_DIR}/logs/launcher_${TIMESTAMP}.log`. Enforces `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"` before creation and locks permissions to `0600`, mitigating TOCTOU symlink hijacking.
  3. **Non-Privileged Dependency Checks**: Verifies presence of `go` or pre-compiled binaries (`./main` or `./nestcomm`). Rejects missing dependencies with actionable remediation messages; never invokes unprompted `sudo apt-get`.
  4. **Dynamic Port Collision Avoidance**: Probes loopback target port (`$APP_PORT`, default `8080`) via `/dev/tcp/127.0.0.1/$APP_PORT`. If occupied, invokes Python `socket.bind(("", 0))` to dynamically allocate an ephemeral port.
  5. **Explicit PID Tracking**: Captures child process ID (`APP_PID=$!`). The cleanup handler traps `SIGINT`, `SIGTERM`, and `EXIT`, issuing graceful `SIGTERM` signals directly to the verified PID and polling for termination before escalating to `SIGKILL`. Global `fuser -k` port-killing has been strictly eliminated.
  6. **Readiness Polling & Browser Spawning**: Loops over `/dev/tcp` for up to 10 seconds before triggering the browser via `xdg-open` or `python3 -m webbrowser`.
- **How to Modify**: Adjust timeout loops, modify default `APP_PORT`, or customize log retention.

#### `scripts/launcher.bat`
- **Role**: Unified Windows process runner and dynamic port coordinator.
- **What It Does**:
  1. Configures localized logging in `scripts\logs`.
  2. Verifies presence of `go` or pre-compiled `backend\main.exe` without prompting for elevated installations.
  3. Detects port collisions via PowerShell `TcpListener` on loopback port `0` to dynamically assign an unused port.
  4. Spawns `backend\main.exe` or `go run main.go` in the background with output redirected to session logs.
  5. Performs TCP socket readiness polling before executing `start http://127.0.0.1:!APP_PORT!`.
- **How to Modify**: Adjust timeout counts or modify PowerShell socket polling commands.

#### `scripts/install.sh`
- **Role**: Systemd service generator for persistent background deployments on Linux / Pop!_OS.
- **What It Does**:
  1. Detects invoking user (`${SUDO_USER:-$USER}`) and working directory.
  2. Generates `/etc/systemd/system/nestcomm.service` configured for automatic startup and restart-on-failure.
  3. Reloads the systemd daemon (`systemctl daemon-reload`) without modifying global system libraries.
- **How to Modify**: Adjust service restart delays (`RestartSec`) or set custom environment flags (`Environment="APP_RELAY=..."`).

#### `scripts/install.bat`
- **Role**: Windows scheduled task installer for user logon execution.
- **What It Does**:
  1. Configures a user-level scheduled task (`schtasks /create /tn "NestCommDaemon"`) triggered on user logon.
  2. Points directly to `scripts\launcher.bat`.
- **How to Modify**: Change trigger parameters from logon to system boot if elevated permissions are available.

#### `scripts/simulate.py`
- **Role**: Multi-threaded DHT swarm network simulator and stress-testing tool.
- **What It Does**:
  1. Spawns 5 concurrent headless worker threads simulating independent client nodes.
  2. Simulates Ed25519 identity generation, DHT peer discovery lookups, Noise Protocol handshakes, and synchronous payload delivery.
  3. Provides a lightweight verification mechanism to test DHT routing logic without running heavy physical clusters.
- **How to Modify**: Increase thread counts (`range(1, 51)`) or add simulated network latency and packet loss parameters.

---

### Core Networking & Storage Layer (`backend/`)

#### `backend/main.go`
- **Role**: Master application server, libp2p P2P routing host, Noise Protocol transport multiplexer, AES-256-GCM secure enclave storage, offline store-and-forward queue worker, and HTMX web dashboard backend.
- **What It Does**:
  - **Dynamic Cryptographic Identity**: Generates a cryptographically random Ed25519 keypair via `crypto/rand`. Marshals and encrypts the private key with AES-256-GCM, persisting it atomically to `identity.enc` (`0600` permissions) inside `storageDir`. Derives the local routing hash (e.g., `12D3KooW...`).
  - **Hardware/OS Secure Enclave Integration**: Integrates with the native OS Secret Service / DBus Keyring (`zalando/go-keyring`) to securely hold the AES-256-GCM master key. Falls back gracefully to `master.key` (`0600` permissions) if the keyring daemon is unreachable.
  - **Kademlia DHT Server**: Initializes `go-libp2p-kad-dht` in `ModeServer`, bootstrapping the distributed hash table to locate remote peer IP addresses from cryptographic public key hashes.
  - **Symmetric NAT Relay Bridge Ingestion**: Accepts public multiaddr strings via `-relay`, `--relay`, or `APP_RELAY`. Connects directly to the bridge node prior to bootstrapping, allowing traversal across symmetric NATs.
  - **Connection Gater & Access Control**: Implements `nestCommGater`. Restricts incoming connections by intercepting secured handshakes: if authorized peers are configured in `knownPeers`, any unsolicited handshakes from unknown node IDs are dropped before reaching application logic.
  - **Active Stream Limiter**: Enforces `MaxStreamsPerPeer` (capped at 10) to prevent stream exhaustion and denial-of-service from rogue peers.
  - **Store-and-Forward Offline Staging Queue**: Outbound messages targeting unreachable peers are intercepted, converted into `StagedMessage` structs, serialized to JSON, encrypted with AES-256-GCM, and atomically persisted to `queue.enc`. A background worker (`processStagingQueue`) runs an exponential backoff retry loop (`1s, 2s, 4s, 8s...` up to `300s`) until successful delivery.
  - **Host & Origin Firewall**: `verifyOrigin(r *http.Request)` strictly validates that the HTTP `Host` header resolves to `localhost` or `127.0.0.1` and that any supplied `Origin` header matches `http://localhost:` or `http://127.0.0.1:`. Mitigates DNS rebinding and cross-site attacks.
  - **Session Token Protection**: Generates a 16-byte cryptographically secure random session token at boot, validates it on all mutating requests (`/api/send`, `/api/peers/add`, `/api/peers/select`), and blocks unauthorized triggers.
  - **Bounded Payloads & Memory Protection**: Enforces `http.MaxBytesReader` (64KB limit) on incoming POST bodies to drop oversized payloads. Rejects messages exceeding `MaxPayloadSize` (4096 bytes) and validates `peer_id` length bounds (`8 <= len <= 128`).
  - **Dynamic Frontend Asset Discovery**: Implements `findFrontendPath()` to locate `frontend/index.html` and `frontend/style.css` across current directory, parent paths, and executable locations, eliminating directory-dependency panics.
  - **Bounded HTTP Server Timeouts**: Instantiates an explicit `http.Server` configured with `ReadTimeout: 5s`, `WriteTimeout: 10s`, and `IdleTimeout: 120s`.
- **How to Modify**: Add custom libp2p stream protocols, adjust retry intervals, or add DHT bootstrap nodes.

#### `backend/security_test.go`
- **Role**: Comprehensive automated unit and integration test suite validating security hardening, input validation, cryptographic integrity, and queue behavior.
- **What It Verifies**:
  - `TestFinding1_1_LauncherProcessSafety`: Asserts scripts contain no `fuser`, enforce `set -euo pipefail`, track child PIDs, and validate symlinks.
  - `TestFinding2_1_OriginAndHostValidation`: Asserts that `verifyOrigin` accepts `localhost` and `127.0.0.1`, while rejecting DNS rebinding hosts (`evil.com`) and spoofed origins.
  - `TestFinding2_1_TokenProtection`: Asserts that missing or invalid session tokens return 401 Unauthorized across `/api/peers`, `/api/peers/add`, and `/api/send`.
  - `TestFinding2_2_DynamicCryptographicIdentity`: Validates dynamic Ed25519 identity generation, atomic disk saving with 0600 permissions, and exact state restoration.
  - `TestFinding3_1_NoAutomatedPackageInstallation`: Confirms no unprompted `sudo` or package managers exist in launcher scripts.
  - `TestFinding3_2_SecureStorageAndSymlinkHardening`: Asserts AES-256-GCM encryption round-trip integrity, tamper resistance, and truncated payload rejection.
  - `TestFinding4_1_InputValidationAndOversizedPayload`: Confirms rejection of 10MB HTTP payloads and validation of peer ID lengths.
  - `TestFinding4_2_ServerSecurityHeaders`: Verifies `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Content-Security-Policy`, and `Cache-Control`.
  - `TestStoreAndForwardOfflineStagingQueue`: Asserts that offline messages are persisted encrypted to `queue.enc` with 0600 permissions and successfully restored upon restart.
  - `TestConnectionGaterAuthorization`: Verifies that unauthorized inbound handshakes from unlisted peers are dropped by `nestCommGater`.
- **Execution**: `cd backend && go test -v .`

---

### Process Lifecycle & Supervision Layer (`daemon/`)

#### `daemon/src/main.rs`
- **Role**: Native Rust process supervisor, dual-mode companion monitor, readiness poller, and browser launcher.
- **What It Does**:
  - **Intelligent Directory & Binary Resolution**: `find_backend_dir()` dynamically locates `backend` across environment variables (`NESTCOMM_BACKEND_DIR`), working directory, parent directory, and executable relative paths. `find_backend_binary()` resolves `./main`, `./nestcomm`, or `main.exe`.
  - **Dual-Mode Operation**:
    - **Standalone Mode**: If launched directly (`./nestcomm-daemon`) when port `APP_PORT` is free, checks dependencies, spawns the Go engine as a tracked child process, polls TCP socket readiness, opens the browser, and traps Ctrl+C to cleanly terminate the tracked child PID.
    - **Companion Monitoring Mode**: If launched alongside `launcher.sh` where the Go backend is already active on `APP_PORT`, detects the open socket (`TcpStream::connect`), avoids duplicate process spawning and socket collision, launches the browser dashboard, and monitors backend socket connectivity until shutdown.
  - **Clean Signal Trapping (`ctrlc`)**: Traps `SIGINT` and `SIGTERM` signals using an `AtomicBool` flag to ensure graceful child termination (`child.kill()`, `child.wait()`) and prevent dangling background daemons.
  - **Cross-Platform Browser Launcher**: Dynamically invokes `xdg-open` or `python3 -m webbrowser` on Linux, `cmd /c start` on Windows, and `open` on macOS.
- **How to Modify**: Adjust polling intervals or add native desktop system tray icons. Recompile via `cd daemon && cargo build`.

---

### Presentation Layer (`frontend/`)

#### `frontend/index.html`
- **Role**: Responsive local dashboard built with HTMX and vanilla CSS.
- **What It Does**:
  - **CyberNest Industrial Aesthetic**: High-contrast dark industrial theme adhering to the CyberNest Labs Color System (`#393834` base, `#4c443b` surface, `#eedba6` text, `#5fa8a0` interactive).
  - **Dynamic Identity Display**: Injects authenticated session token, local Node ID, and formatted peer ID (`12D3KooW...`).
  - **Bulletproof 1-Click Clipboard Copy**: Provides modern `navigator.clipboard` integration with automatic fallback to an invisible textarea and prompt modal for legacy/non-HTTPS environments. Both the "COPY" button and the Local ID text itself are interactive.
  - **Dynamic Peer Management**: Authorizes new peers via `POST /api/peers/add` and renders live peer connectivity dots (green for connected, red for offline/unreachable) updated every 5 seconds.
  - **Real-Time Synchronous Chat**: Polls `/api/messages` every 2 seconds via HTMX with HTTP `ETag` conditional caching to eliminate redundant data transfer. Outbound messages submit asynchronously via `POST /api/send`.
- **How to Modify**: Adjust polling intervals, customize HTML layouts, or add audio alert triggers.

#### `frontend/style.css`
- **Role**: Unified stylesheet implementing the CyberNest Labs Color System.
- **What It Does**:
  - Defines CSS custom variables for `--bg-base`, `--surface`, `--text-primary`, `--interactive`, `--success`, and `--error`.
  - Configures flexbox chat layouts, responsive sidebars, message bubble classes (`sent`, `received`, `staged`), and interactive button hover/active transitions.
- **How to Modify**: Update root variables to change application theme colors or typography.

---

## 3. Data Flow & Lifecycle of a P2P Message Exchange

```text
[Local Operator]               [Local NestComm Node]               [Kademlia DHT / Relay]              [Remote NestComm Node]
       │                                 │                                    │                                  │
       │ 1. GET /                        │                                    │                                  │
       ├────────────────────────────────►│                                    │                                  │
       │ 2. Serves Dashboard + Token     │                                    │                                  │
       │    (Displays 12D3KooW... ID)    │                                    │                                  │
       │◄────────────────────────────────┤                                    │                                  │
       │                                 │                                    │                                  │
       │ 3. Authorize Target Node ID     │                                    │                                  │
       │    POST /api/peers/add          │                                    │                                  │
       ├────────────────────────────────►│                                    │                                  │
       │                                 │ 4. Whitelist in knownPeers         │                                  │
       │                                 │ 5. Asynchronous DHT FindPeer       │                                  │
       │                                 ├───────────────────────────────────►│                                  │
       │                                 │ 6. Resolve Peer Multiaddress       │                                  │
       │                                 │◄───────────────────────────────────┤                                  │
       │                                 │                                    │                                  │
       │ 7. Submit Message Payload       │                                    │                                  │
       │    POST /api/send               │                                    │                                  │
       ├────────────────────────────────►│                                    │                                  │
       │                                 │ 8. Validate Host, Origin, Token    │                                  │
       │                                 │                                    │                                  │
       │                                 │────► SCENARIO A: Target Online ──────────────────────────────────────┐│
       │                                 │ 9. Noise Handshake & Open Stream   │                                 ││
       │                                 │    /nestcomm/chat/1.0.0            │                                 ││
       │                                 ├─────────────────────────────────────────────────────────────────────►││
       │                                 │ 10. Direct Encrypted Stream Write  │                                 ││
       │                                 ├─────────────────────────────────────────────────────────────────────►││
       │ 11. Render [SENT] in UI         │                                    │                                 ││
       │◄────────────────────────────────┤                                    │                                 ││
       │                                 │                                    │                                 ││
       │                                 │────► SCENARIO B: Target Offline / Unreachable ───────────────────────┘│
       │                                 │ 9. Stream Open Fails               │                                  │
       │                                 │ 10. Intercept & Create StagedItem  │                                  │
       │                                 │ 11. AES-256-GCM Encrypt & Save     │                                  │
       │                                 │     Atomically to queue.enc (0600) │                                  │
       │ 12. Render [QUEUED] in UI       │                                    │                                  │
       │◄────────────────────────────────┤                                    │                                  │
       │                                 │                                    │                                  │
       │                                 │ 13. Exponential Backoff Loop       │                                  │
       │                                 │     (1s, 2s, 4s, 8s... max 300s)   │                                  │
       │                                 │ 14. Target comes back online!      │                                  │
       │                                 │ 15. Retry succeeds: Deliver payload│                                  │
       │                                 ├─────────────────────────────────────────────────────────────────────►│
       │                                 │ 16. Purge from queue.enc & save    │                                  │
       │ 17. Update [DELIVERED] in UI    │                                    │                                  │
       │◄────────────────────────────────┤                                    │                                  │
```

---

## 4. Developer Extension How-To Guides

### How to Add a Custom libp2p Stream Protocol Handler
1. Open `backend/main.go`.
2. Define your stream handler function:
   ```go
   func handleDiagnosticsStream(stream network.Stream) {
       defer stream.Close()
       remote := stream.Conn().RemotePeer()
       logger.Printf("[INFO] Diagnostics stream requested by: %s", remote)
       info := fmt.Sprintf("NestComm Node: %s | Uptime: %s | StagedItems: %d\n",
           nodeHost.ID(), time.Since(startTime), len(stagingQueue))
       _, _ = stream.Write([]byte(info))
   }
   ```
3. Register the stream handler on the libp2p host:
   ```go
   nodeHost.SetStreamHandler("/nestcomm/diagnostics/1.0.0", handleDiagnosticsStream)
   ```
4. Rebuild the backend:
   ```bash
   cd backend && go build -o main main.go
   ```

### How to Configure a Symmetric NAT Relay Bridge
To route connections through a public libp2p circuit relay bridge across symmetric NAT boundaries:
```bash
# Using CLI argument:
./launcher.sh --relay "/ip4/198.51.100.1/tcp/4001/p2p/12D3KooWRelayPeerID..."

# Using environment variable:
export APP_RELAY="/ip4/198.51.100.1/tcp/4001/p2p/12D3KooWRelayPeerID..."
./launcher.sh
```

### How to Tune Exponential Backoff & Queue Retry Intervals
1. Open `backend/main.go`.
2. Locate `processStagingQueue(ctx context.Context)`:
   ```go
   // Adjust worker polling cadence (default: 2 seconds)
   ticker := time.NewTicker(2 * time.Second)
   
   // Adjust backoff calculation (default cap: 300 seconds)
   backoffSec := 1 << item.Retries
   if backoffSec > 300 {
       backoffSec = 300
   }
   ```
3. Modify the intervals as needed for high-frequency or tactical deployment environments.

### How to Run Headless DHT Swarm Load Simulations
To verify DHT routing discovery across multiple local nodes without spinning up physical hosts:
```bash
python3 scripts/simulate.py
```

---

## 5. Security-Hardened Architecture & Threat Defense Protocol

Following our formal architectural refactoring and security hardening audit, NestComm implements defense-in-depth security across every operational layer:

### 5.1 Defense Against CSRF & Local Host Manipulation
- **Threat Vector**: Malicious websites in the operator's browser executing background fetch/AJAX requests against `http://localhost:8080` to forge contacts or exfiltrate communication streams.
- **Defensive Safeguards**:
  - `verifyOrigin()` checks `r.Host` strictly against `localhost` and `127.0.0.1`, mitigating DNS rebinding attacks.
  - Validates `Origin` header to ensure it begins with `http://localhost:` or `http://127.0.0.1:`.
  - Enforces cryptographically random session tokens (`crypto/rand`) required on all state-mutating endpoints (`/api/send`, `/api/peers/add`, `/api/peers/select`).

### 5.2 Defense Against Unauthorized Handshakes & Connection Flooding
- **Threat Vector**: Untrusted or rogue nodes discovering the local node's multiaddress on the DHT and spamming inbound multiplexed streams to exhaust system memory.
- **Defensive Safeguards**:
  - `nestCommGater.InterceptSecured()` drops inbound Noise Protocol handshakes from unlisted peers if `knownPeers` contains registered contacts.
  - `activeStreams` tracks concurrent streams per peer and strictly drops connections exceeding `MaxStreamsPerPeer` (10 streams).

### 5.3 Defense Against Local Storage Data Theft & Tampering
- **Threat Vector**: Malware or unauthorized local users attempting to inspect local state files, steal message history, or corrupt the offline staging queue.
- **Defensive Safeguards**:
  - Integrates with OS native Keyring (DBus Secret Service on Linux, Windows Credential Manager on Windows) for master key storage.
  - All local files (`identity.enc`, `peers.enc`, `history.enc`, `queue.enc`) are encrypted using AES-256-GCM authenticated encryption.
  - Files are written atomically (`writeAtomicFile`) with restrictive `0600` permissions (`0700` for directory).

### 5.4 Defense Against Symlink Attacks (CWE-377) & Process Collisions
- **Threat Vector**: Attackers pre-creating symbolic links at predictable log paths to overwrite arbitrary files, or launcher traps executing destructive `fuser -k` killing unrelated services.
- **Defensive Safeguards**:
  - Completely eliminated `fuser -k`; child processes are strictly tracked via explicit PIDs (`APP_PID`).
  - `scripts/launcher.sh` executes `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"` before creating log files with `0600` permissions.

### 5.5 Defense Against Memory Exhaustion & Slowloris DoS
- **Threat Vector**: Unbounded POST request bodies (e.g. 10MB exploit payloads) and dangling HTTP connections exhausting socket buffers.
- **Defensive Safeguards**:
  - All mutating endpoints wrap `r.Body` with `http.MaxBytesReader(w, r.Body, 64*1024)`.
  - Enforces `MaxPayloadSize` (4096 bytes) and peer ID length checks (`8 <= len <= 128`).
  - Custom `http.Server` enforces `ReadTimeout: 5s`, `WriteTimeout: 10s`, and `IdleTimeout: 120s`.

---

## 6. Architectural Hardening & Audit Remediation Ledger

| Finding / Enhancement | Severity | Functional Domain | Root Cause | Solution & Verification |
| :--- | :--- | :--- | :--- | :--- |
| **Store-and-Forward Queue** | **HIGH** | Reliability / Network | Outbound messages synchronously failed and were lost if target peer was offline. | Implemented AES-256-GCM encrypted `stagingQueue`, atomic `queue.enc` persistence, and exponential backoff retry worker. Verified in `TestStoreAndForwardOfflineStagingQueue`. |
| **Dual-Mode Supervisor** | **HIGH** | Process Lifecycle | Redundant execution wrappers caused socket collisions and crashed when port was active. | Implemented dual-mode operation (Standalone Mode vs Companion Monitoring Mode) in `daemon/src/main.rs`. Reclaims port, avoids duplicate spawning, and traps signals cleanly. |
| **Dynamic Path Resolution** | **HIGH** | Operational Portability | Running backend or daemon from outside default folder caused "GUI File Not Found" or process spawn failures. | Implemented `findFrontendPath()` in Go and `find_backend_dir()` in Rust to resolve assets and binaries dynamically across any working directory. |
| **Origin & Host Firewall** | **HIGH** | Authentication / CSRF | Endpoints lacked Host and Origin header validation, vulnerable to DNS rebinding. | Implemented `verifyOrigin()` in `securityHeaders` checking `localhost`/`127.0.0.1` and origin prefixes. Verified in `TestFinding2_1_OriginAndHostValidation`. |
| **Cryptographic Identity** | **HIGH** | Cryptography / Identity | Static or unpersisted keys risk DHT identity spoofing and loss across restarts. | Dynamic Ed25519 keypair generation, AES-256-GCM disk encryption with 0600 permissions, and seamless restart restoration. Verified in `TestFinding2_2_DynamicCryptographicIdentity`. |
| **Symlink Protection (CWE-377)**| **MEDIUM** | File System Security | Predictable log file creation vulnerable to TOCTOU symlink hijacking. | Added `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"` before touch and locked permissions to 0600 with `umask 077`. Verified in `TestFinding1_1_LauncherProcessSafety`. |
| **Connection Gating** | **MEDIUM** | Network Security | Rogue DHT nodes could initiate unsolicited incoming streams to exhaust memory. | Implemented `nestCommGater` to drop inbound handshakes from unlisted peers, and capped active streams per peer to 10. Verified in `TestConnectionGaterAuthorization`. |
| **Bounded Payloads & Limits** | **LOW** | Input Validation | Form parsing could ingest unbounded payloads before validation. | Added `http.MaxBytesReader(64KB)`, 4096-byte payload limit, and 8-128 character peer ID bounds. Verified in `TestFinding4_1_InputValidationAndOversizedPayload`. |
| **1-Click Clipboard Copy** | **LOW** | User Experience | Legacy web dashboard copy button failed in non-HTTPS/restricted contexts. | Upgraded `index.html` with modern Clipboard API, invisible textarea fallback, and clickable identity element. |

---

## 7. Maintenance & Operational Commands

```bash
# 1. Run full automated security and unit test suite
cd backend && go test -v .

# 2. Compile standalone Go backend binary
cd backend && go build -o main main.go

# 3. Compile standalone Rust companion supervisor
cd daemon && cargo build --release

# 4. Launch NestComm in development mode from repository root
./launcher.sh

# 5. Launch NestComm using the Rust daemon supervisor
./daemon/target/debug/nestcomm-daemon

# 6. Launch with custom port and symmetric NAT relay bridge
APP_PORT=9090 ./launcher.sh --relay "/ip4/198.51.100.1/tcp/4001/p2p/12D3KooWRelay..."

# 7. Run headless DHT swarm simulation
python3 scripts/simulate.py

# 8. View real-time security launcher logs
tail -f scripts/logs/launcher_*.log
```

---
*CyberNest Labs Internal Tools Group — Authorized Security Engineering Standard.*
