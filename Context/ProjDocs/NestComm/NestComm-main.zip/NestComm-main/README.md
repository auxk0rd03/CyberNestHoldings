# Project NestComm

[![Security: Hardened](https://img.shields.io/badge/Security-CMMC%202.0%20%7C%20FIPS%20140--3-36A19D.svg)](#security--compliance-architecture)
[![Network: libp2p](https://img.shields.io/badge/Network-libp2p%20DHT%20%2B%20Noise-523B78.svg)](#overview)
[![UI: HTMX](https://img.shields.io/badge/Frontend-HTMX%20Synth--Ledger-DCD5C6.svg)](#operational-instructions)

## Overview

**NestComm** is a decentralized, end-to-end encrypted, peer-to-peer (P2P) synchronous and store-and-forward messaging application developed by CyberNest Labs. By eliminating central routing servers and directory authorities, the architecture mitigates single points of failure inherent in standard communication models.

This system integrates a **Go networking and cryptographic enclave daemon** (`backend/main.go`, `backend/compliance.go`) for distributed network participation via the Kademlia Distributed Hash Table (DHT) and the Noise Protocol framework, coupled with a localized **HTMX Nocturnal Synth-Ledger frontend** (`frontend/index.html`, `frontend/synth-ledger.css`) for secure interface rendering. A **Rust daemon supervisor** (`daemon/src/main.rs`) manages process lifecycles, FIPS 140-3 Known-Answer Self-Tests (KAT), CWE-22 path sanitization, and signal teardown.

## Authorship

Developed by Dept. CyberNest Labs for CyberNestHoldings LLC.
Lead Systems Architect: Auxk0rd

---

## Security & Compliance Architecture

Following a comprehensive architectural and security compliance upgrade, NestComm enforces defense-in-depth safeguards across all operational layers:

* **CMMC 2.0 Level 1 & Level 2 Posture:** Implements FAR 52.204-21 (17 Controls) and NIST SP 800-171 Rev. 2 (110/110 Controls) self-assessment telemetry via `/api/compliance/cmmc`.
* **FIPS 140-3 Cryptographic Mode:** Executes under `GOFIPS=1` / `GODEBUG=fips140=on` with AES-256-GCM authenticated enclave storage, Ed25519 cryptographic identities (`0600` permissions), native OS Keyring integration (`zalando/go-keyring`), and deterministic Rust FIPS 140-3 startup self-tests (`fips140_self_test`).
* **DISA STIG Hardening:** Live compliance certificate generation (`/api/compliance/stig`) covering `V-222609` (loopback binding & Host/Origin validation), `V-222577` (CWE-22 path traversal prevention), `V-222596` (AES-256-GCM enclave + Ed25519 identity), and `V-222612` (CWE-400 64KB request caps + `ConnectionGater` peer allowlist + 120s dead-man's switch).
* **Multi-Stage Path Sanitization (CWE-22 & CWE-377):** Both Go (`SanitizeRelativePath`, `SafeResolveUnder`) and Rust (`sanitize_relative_path`, `safe_resolve_under`) reject directory traversal, null bytes, volume prefixes, and symbolic links prior to file operations.
* **Host, Origin & Session CSRF Firewall (CWE-346):** `verifyOrigin` restricts access strictly to `localhost` and `127.0.0.1` and enforces cryptographically random 16-byte session tokens across state-mutating endpoints.
* **Store-and-Forward Offline Encrypted Queue:** Messages targeting unreachable peers are encrypted via AES-256-GCM (`queue.enc`, `0600`) and retried automatically with exponential backoff (`1s` to `300s`).
* **120-Second Transactional Dead-Man's Switch:** Supports automatic state rollback timers (`StartDeadManSwitch120s` / `ConfirmDeadManSwitch`) for unconfirmed configuration mutations.
* **IEEE 802.3 / 802.11w PMF Sensing & Threat Intelligence Feeds:** Inspects `/sys/class/net` for physical/wireless medium posture (`/api/network-sense`) and exports STIX 2.1 bundles (`/api/export/stix`), TAXII 2.1 collections (`/api/export/taxii`), and CISA-compliant CycloneDX 1.5 / SPDX 2.3 SBOMs (`/api/sbom`, `SBOM.md`, `SBOM.cyclonedx.json`, `SBOM.spdx.json`).

---

## Operational Instructions (`CN-DIR-2026-004` Bi-Launcher Specification)

NestComm implements **CyberNest Labs Architecture Specification // Standard 004 (`CN-DIR-2026-004`)**: the **Dual-Native Orchestration Architecture (Bi-Launcher Specification)** providing 1:1 behavioral parity across Pop!_OS / Linux (`dev.sh` / `launcher.sh`) and Windows 10/11 Pro & Enterprise (`dev.bat` / `launcher.bat`).

### Universal Command Parity Contract

| Subcommand | Linux / Pop!_OS (`./dev.sh` / `./launcher.sh`) | Windows 10/11 (`.\dev.bat` / `.\launcher.bat`) | Operational Behavior |
| :--- | :--- | :--- | :--- |
| `setup` | `./dev.sh setup` | `.\dev.bat setup` | Verifies Go, Cargo, and Python 3 runtimes and runtime path boundaries. |
| `build` | `./dev.sh build` | `.\dev.bat build` | Compiles Go backend (`bin/nestcomm[.exe]`) & Rust daemon (`bin/nestcomm-daemon[.exe]`) + generates CISA SBOMs. |
| `run` / `serve` | `./dev.sh serve` | `.\dev.bat serve` | Launches local Nocturnal Synth-Ledger WebGUI on `http://127.0.0.1:8080` with `CWE-114` PID tracking. |
| `cli` | `./dev.sh cli` | `.\dev.bat cli` | Executes a single-sweep diagnostic & compliance audit and emits JSON report to stdout. |
| `simulate` | `./dev.sh simulate` | `.\dev.bat simulate` | Executes P2P fault-injection & degradation simulation and exports offline report to `exports/`. |
| `test` | `./dev.sh test` | `.\dev.bat test` | Executes polyglot automated test suite (Go security tests, Rust daemon tests). |
| `fmt` | `./dev.sh fmt` | `.\dev.bat fmt` | Formats all Go (`go fmt ./...`) and Rust (`cargo fmt`) source code. |

### Quick Start Examples

**Linux / Pop!_OS:**
```bash
./dev.sh build        # Compiles native Go FIPS 140-3 backend and Rust supervisor
./dev.sh cli          # Single-sweep CLI diagnostic audit
./dev.sh simulate     # Automated fault-injection audit and offline export
./dev.sh test         # Automated security & unit test suite
./dev.sh serve        # Launches local WebGUI at http://127.0.0.1:8080
```

**Windows 10/11 (Command Prompt or PowerShell):**
```cmd
dev.bat build         :: Compiles bin\nestcomm.exe and bin\nestcomm-daemon.exe
dev.bat cli           :: Single-sweep CLI diagnostic audit
dev.bat simulate      :: Automated fault-injection audit and offline export
dev.bat test          :: Automated security & unit test suite
dev.bat serve         :: Launches local WebGUI at http://127.0.0.1:8080
```

### How to Communicate with Another Node (Step-by-Step Guide)

NestComm is designed to connect two computers directly over the internet. You do **not** need a centralized messaging server or corporate VPN. The software automatically navigates through standard network topologies utilizing the Kademlia DHT.

For this guide, we will refer to the two nodes as:

* **Your Node (Local):** The computer you are physically operating.
* **Target Node (Remote):** The peer you intend to securely message.

#### Step 1: Start NestComm on Both Nodes

The NestComm application must be running on both your node and the target node simultaneously.

1. On **Your Node**, open a terminal and run the launcher script. Navigate to `http://127.0.0.1:8080` in your local web browser.
2. Instruct the user at the **Target Node** to perform the exact same action to initialize their daemon.

#### Step 2: Exchange Cryptographic Identities

Every time NestComm initializes, it generates (or restores from its AES-256-GCM enclave) a unique cryptographic "Local ID" displayed in the web dashboard. This ID acts as your secure routing hash.

1. Ask the operator at the **Target Node** to observe their web dashboard.
2. Have them copy their "Local ID" (e.g., `12D3KooW...`) and transmit it to you via a secure, out of band communication channel.

#### Step 3: Initiate the Secure Session

1. On **Your Node**, navigate to your NestComm web dashboard.
2. Input the Target Node's cryptographic ID into the environmental trust registry or contact whitelist (`CH_01 // ADD_PEER`) to authorize their connection.
3. The background daemon will automatically query the DHT to resolve the IP address associated with the target hash.

#### Background Execution

Once the IP is resolved, the application handles the technical routing autonomously. Both systems will attempt to establish a direct TCP/UDP tunnel. A Noise Protocol cryptographic handshake authenticates the session, exchanging ephemeral keys. Once the tunnel is up, plaintext from the HTMX GUI is encrypted locally, streamed over the tunnel, and decrypted by the peer.

#### Step 4: Confirming Your Connection

After the automated routing process completes, you must verify that the secure tunnel is active and ready for use.

1. **Check the Web Dashboard:** Observe the NestComm dashboard on **Your Node**. The active peers list in the sidebar should reflect the connection status.
2. **Send a Message:** Type a message into the chat input field and press "SEND". The HTMX interface will securely submit the payload to the local daemon, which encrypts and transmits it to the remote peer.
3. **Verify Receipt:** Confirm with the Target Node operator that the message successfully rendered in their local dashboard.

> **Operational Note:** The 1-click "COPY" button and clickable Local ID in the web dashboard are fully operational with cross-browser clipboard integration (with automatic fallback to invisible textarea selection and prompt modal for legacy/restricted environments). Alternatively, the full Node ID is logged to the terminal output upon startup.

---

## Verification & Automated Security Test Suite

```bash
# Run Go backend security & compliance unit test suite
cd backend && go test -v .

# Run Rust daemon FIPS 140-3 & CWE-22 unit tests
cd daemon && cargo test
```
