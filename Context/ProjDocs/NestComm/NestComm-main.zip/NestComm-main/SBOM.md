# CISA-COMPLIANT SOFTWARE BILL OF MATERIALS (SBOM) // NESTCOMM

## 1. Executive Order 14028 & CISA Minimum Elements Attestation

| CISA Mandatory Metadata Field | Verified Value |
| :--- | :--- |
| **SBOM Document Title** | `NestComm - CyberNest CISA SBOM Ledger` |
| **SBOM Serial / Namespace UUID** | `urn:uuid:9f8f6c2c-c034-5815-88f9-1ce13d558ef1` |
| **Author of SBOM Data** | `CyberNest Holdings LLC - William Ray Moore (President & Chief Architect) & James Dwayne Jarrell (CEO)` |
| **Timestamp (UTC)** | `2026-10-31T02:21:09Z` |
| **Primary Supplier Name** | `CyberNest Holdings LLC (Internal Department: CyberNest Labs)` |
| **Corporate Jurisdiction & Registration** | `Commonwealth of Pennsylvania LLC // SAM.gov UEI & CAGE: Not Yet Assigned (Pre-Registration)` |
| **Target Repository / Source** | `./NestComm` |
| **Ingestion & Parse Engines** | `go_repo_ingestor + rust_sbom_scanner` |
| **Supported Machine Formats** | `CycloneDX 1.5 JSON (SBOM.cyclonedx.json)` & `SPDX 2.3 JSON (SBOM.spdx.json)` |
| **Zero External Runtime Dependency Guarantee** | `ENFORCED (100% Air-Gapped Autonomous Execution)` |
| **FIPS 140-3 Cryptographic Validation** | `ENABLED (GOFIPS=1 / AWS-LC-FIPS / SHA-256 & AES-256-GCM KAT Passed)` |
| **CMMC 2.0 Compliance Posture** | `CMMC Level 1 (FAR 52.204-21) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110)` |
| **Enforced CWE Mitigations** | `CWE-377, CWE-114, CWE-22, CWE-346, CWE-400, CWE-1333` |
| **Ed25519 Signer Key ID** | `CN-ED25519-99AC51E14879E456` |
| **Ed25519 Signature** | `5b787632b95d559206fb3f5d7f6e99e4e3fcaea1cb4ace1a...` |

---

## 2. Component Inventory & Unique Identifiers (NTIA / CISA Minimum Elements)

| # | Component Name | Version | Ecosystem | Supplier | PURL (Unique ID) | License | Source Manifest | SHA-256 Digest |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `001` | `nestcomm-daemon` | `0.1.0` | `cargo-root` | CyberNest Holdings LLC (CyberNest Labs Department) | `pkg:cargo/nestcomm-daemon@0.1.0` | `LicenseRef-CyberNest-Proprietary` | `daemon/Cargo.toml` | `4c651929fcfc1dd3...` |
| `002` | `ctrlc` | `3.5.2` | `cargo` | Crates.io / Rust Ecosystem | `pkg:cargo/ctrlc@3.5.2` | `MIT OR Apache-2.0` | `daemon/Cargo.toml` | `4c651929fcfc1dd3...` |
| `003` | `nestcomm` | `1.0.0` | `golang-root` | CyberNest Holdings LLC (CyberNest Labs Department) | `pkg:golang/nestcomm@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `004` | `filippo.io/bigmod` | `0.1.1-0.20260103110540-f8a47775ebe5` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/filippo.io/bigmod@v0.1.1-0.20260103110540-f8a47775ebe5` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `005` | `filippo.io/keygen` | `0.0.0-20260114151900-8e2790ea4c5b` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/filippo.io/keygen@v0.0.0-20260114151900-8e2790ea4c5b` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `006` | `github.com/benbjohnson/clock` | `1.3.5` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/benbjohnson/clock@v1.3.5` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `007` | `github.com/beorn7/perks` | `1.0.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/beorn7/perks@v1.0.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `008` | `github.com/cespare/xxhash/v2` | `2.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/cespare/xxhash/v2@v2.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `009` | `github.com/danieljoos/wincred` | `1.2.3` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/danieljoos/wincred@v1.2.3` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `010` | `github.com/davidlazar/go-crypto` | `0.0.0-20200604182044-b73af7476f6c` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/davidlazar/go-crypto@v0.0.0-20200604182044-b73af7476f6c` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `011` | `github.com/decred/dcrd/dcrec/secp256k1/v4` | `4.4.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/decred/dcrd/dcrec/secp256k1/v4@v4.4.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `012` | `github.com/dunglas/httpsfv` | `1.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/dunglas/httpsfv@v1.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `013` | `github.com/filecoin-project/go-clock` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/filecoin-project/go-clock@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `014` | `github.com/flynn/noise` | `1.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/flynn/noise@v1.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `015` | `github.com/go-logr/logr` | `1.4.3` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/go-logr/logr@v1.4.3` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `016` | `github.com/go-logr/stdr` | `1.2.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/go-logr/stdr@v1.2.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `017` | `github.com/godbus/dbus/v5` | `5.2.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/godbus/dbus/v5@v5.2.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `018` | `github.com/google/gopacket` | `1.1.19` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/google/gopacket@v1.1.19` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `019` | `github.com/google/uuid` | `1.6.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/google/uuid@v1.6.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `020` | `github.com/gorilla/websocket` | `1.5.3` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/gorilla/websocket@v1.5.3` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `021` | `github.com/hashicorp/golang-lru` | `1.0.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/hashicorp/golang-lru@v1.0.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `022` | `github.com/huin/goupnp` | `1.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/huin/goupnp@v1.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `023` | `github.com/ipfs/boxo` | `0.39.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/ipfs/boxo@v0.39.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `024` | `github.com/ipfs/go-cid` | `0.6.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/ipfs/go-cid@v0.6.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `025` | `github.com/ipfs/go-datastore` | `0.9.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/ipfs/go-datastore@v0.9.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `026` | `github.com/ipfs/go-log/v2` | `2.9.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/ipfs/go-log/v2@v2.9.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `027` | `github.com/ipld/go-ipld-prime` | `0.23.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/ipld/go-ipld-prime@v0.23.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `028` | `github.com/jackpal/go-nat-pmp` | `1.0.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/jackpal/go-nat-pmp@v1.0.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `029` | `github.com/jbenet/go-temp-err-catcher` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/jbenet/go-temp-err-catcher@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `030` | `github.com/klauspost/cpuid/v2` | `2.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/klauspost/cpuid/v2@v2.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `031` | `github.com/koron/go-ssdp` | `0.0.6` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/koron/go-ssdp@v0.0.6` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `032` | `github.com/libp2p/go-buffer-pool` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-buffer-pool@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `033` | `github.com/libp2p/go-cidranger` | `1.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-cidranger@v1.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `034` | `github.com/libp2p/go-flow-metrics` | `0.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-flow-metrics@v0.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `035` | `github.com/libp2p/go-libp2p` | `0.48.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-libp2p@v0.48.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `036` | `github.com/libp2p/go-libp2p-asn-util` | `0.4.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-libp2p-asn-util@v0.4.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `037` | `github.com/libp2p/go-libp2p-kad-dht` | `0.41.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-libp2p-kad-dht@v0.41.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `038` | `github.com/libp2p/go-libp2p-kbucket` | `0.8.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-libp2p-kbucket@v0.8.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `039` | `github.com/libp2p/go-libp2p-record` | `0.3.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-libp2p-record@v0.3.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `040` | `github.com/libp2p/go-libp2p-routing-helpers` | `0.7.5` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-libp2p-routing-helpers@v0.7.5` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `041` | `github.com/libp2p/go-msgio` | `0.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-msgio@v0.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `042` | `github.com/libp2p/go-netroute` | `0.4.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-netroute@v0.4.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `043` | `github.com/libp2p/go-reuseport` | `0.4.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-reuseport@v0.4.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `044` | `github.com/libp2p/go-yamux/v5` | `5.0.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/libp2p/go-yamux/v5@v5.0.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `045` | `github.com/marten-seemann/tcp` | `0.0.0-20210406111302-dfbc87cc63fd` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/marten-seemann/tcp@v0.0.0-20210406111302-dfbc87cc63fd` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `046` | `github.com/mattn/go-isatty` | `0.0.22` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/mattn/go-isatty@v0.0.22` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `047` | `github.com/mikioh/tcpinfo` | `0.0.0-20190314235526-30a79bb1804b` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/mikioh/tcpinfo@v0.0.0-20190314235526-30a79bb1804b` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `048` | `github.com/mikioh/tcpopt` | `0.0.0-20190314235656-172688c1accc` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/mikioh/tcpopt@v0.0.0-20190314235656-172688c1accc` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `049` | `github.com/minio/sha256-simd` | `1.0.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/minio/sha256-simd@v1.0.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `050` | `github.com/mr-tron/base58` | `1.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/mr-tron/base58@v1.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `051` | `github.com/multiformats/go-base32` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-base32@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `052` | `github.com/multiformats/go-base36` | `0.2.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-base36@v0.2.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `053` | `github.com/multiformats/go-multiaddr` | `0.16.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multiaddr@v0.16.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `054` | `github.com/multiformats/go-multiaddr-dns` | `0.5.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multiaddr-dns@v0.5.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `055` | `github.com/multiformats/go-multiaddr-fmt` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multiaddr-fmt@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `056` | `github.com/multiformats/go-multibase` | `0.3.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multibase@v0.3.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `057` | `github.com/multiformats/go-multicodec` | `0.10.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multicodec@v0.10.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `058` | `github.com/multiformats/go-multihash` | `0.2.3` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multihash@v0.2.3` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `059` | `github.com/multiformats/go-multistream` | `0.6.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-multistream@v0.6.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `060` | `github.com/multiformats/go-varint` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/multiformats/go-varint@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `061` | `github.com/munnerz/goautoneg` | `0.0.0-20191010083416-a7dc8b61c822` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/munnerz/goautoneg@v0.0.0-20191010083416-a7dc8b61c822` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `062` | `github.com/pbnjay/memory` | `0.0.0-20210728143218-7b4eea64cf58` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pbnjay/memory@v0.0.0-20210728143218-7b4eea64cf58` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `063` | `github.com/pion/datachannel` | `1.5.10` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/datachannel@v1.5.10` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `064` | `github.com/pion/dtls/v3` | `3.1.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/dtls/v3@v3.1.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `065` | `github.com/pion/ice/v4` | `4.0.10` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/ice/v4@v4.0.10` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `066` | `github.com/pion/interceptor` | `0.1.40` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/interceptor@v0.1.40` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `067` | `github.com/pion/logging` | `0.2.4` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/logging@v0.2.4` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `068` | `github.com/pion/mdns/v2` | `2.0.7` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/mdns/v2@v2.0.7` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `069` | `github.com/pion/randutil` | `0.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/randutil@v0.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `070` | `github.com/pion/rtcp` | `1.2.16` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/rtcp@v1.2.16` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `071` | `github.com/pion/rtp` | `1.8.19` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/rtp@v1.8.19` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `072` | `github.com/pion/sctp` | `1.8.39` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/sctp@v1.8.39` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `073` | `github.com/pion/sdp/v3` | `3.0.18` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/sdp/v3@v3.0.18` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `074` | `github.com/pion/srtp/v3` | `3.0.6` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/srtp/v3@v3.0.6` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `075` | `github.com/pion/stun/v3` | `3.1.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/stun/v3@v3.1.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `076` | `github.com/pion/transport/v3` | `3.0.7` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/transport/v3@v3.0.7` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `077` | `github.com/pion/transport/v4` | `4.0.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/transport/v4@v4.0.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `078` | `github.com/pion/turn/v4` | `4.0.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/turn/v4@v4.0.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `079` | `github.com/pion/webrtc/v4` | `4.1.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/pion/webrtc/v4@v4.1.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `080` | `github.com/polydawn/refmt` | `0.89.1-0.20231129105047-37766d95467a` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/polydawn/refmt@v0.89.1-0.20231129105047-37766d95467a` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `081` | `github.com/prometheus/client_golang` | `1.23.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/prometheus/client_golang@v1.23.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `082` | `github.com/prometheus/client_model` | `0.6.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/prometheus/client_model@v0.6.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `083` | `github.com/prometheus/common` | `0.67.5` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/prometheus/common@v0.67.5` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `084` | `github.com/prometheus/procfs` | `0.20.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/prometheus/procfs@v0.20.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `085` | `github.com/quic-go/qpack` | `0.6.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/quic-go/qpack@v0.6.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `086` | `github.com/quic-go/quic-go` | `0.59.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/quic-go/quic-go@v0.59.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `087` | `github.com/quic-go/webtransport-go` | `0.10.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/quic-go/webtransport-go@v0.10.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `088` | `github.com/spaolacci/murmur3` | `1.1.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/spaolacci/murmur3@v1.1.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `089` | `github.com/whyrusleeping/go-keyspace` | `0.0.0-20160322163242-5b898ac5add1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/whyrusleeping/go-keyspace@v0.0.0-20160322163242-5b898ac5add1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `090` | `github.com/wlynxg/anet` | `0.0.5` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/wlynxg/anet@v0.0.5` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `091` | `github.com/zalando/go-keyring` | `0.2.8` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/github.com/zalando/go-keyring@v0.2.8` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `092` | `go.opentelemetry.io/auto/sdk` | `1.2.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.opentelemetry.io/auto/sdk@v1.2.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `093` | `go.opentelemetry.io/otel` | `1.42.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.opentelemetry.io/otel@v1.42.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `094` | `go.opentelemetry.io/otel/metric` | `1.42.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.opentelemetry.io/otel/metric@v1.42.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `095` | `go.opentelemetry.io/otel/trace` | `1.42.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.opentelemetry.io/otel/trace@v1.42.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `096` | `go.uber.org/dig` | `1.19.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.uber.org/dig@v1.19.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `097` | `go.uber.org/fx` | `1.24.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.uber.org/fx@v1.24.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `098` | `go.uber.org/mock` | `0.5.2` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.uber.org/mock@v0.5.2` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `099` | `go.uber.org/multierr` | `1.11.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.uber.org/multierr@v1.11.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `100` | `go.uber.org/zap` | `1.28.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.uber.org/zap@v1.28.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `101` | `go.yaml.in/yaml/v2` | `2.4.4` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/go.yaml.in/yaml/v2@v2.4.4` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `102` | `golang.org/x/crypto` | `0.50.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/crypto@v0.50.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `103` | `golang.org/x/exp` | `0.0.0-20260410095643-746e56fc9e2f` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/exp@v0.0.0-20260410095643-746e56fc9e2f` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `104` | `golang.org/x/mod` | `0.35.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/mod@v0.35.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `105` | `golang.org/x/net` | `0.53.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/net@v0.53.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `106` | `golang.org/x/sync` | `0.20.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/sync@v0.20.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `107` | `golang.org/x/sys` | `0.43.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/sys@v0.43.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `108` | `golang.org/x/telemetry` | `0.0.0-20260409153401-be6f6cb8b1fa` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/telemetry@v0.0.0-20260409153401-be6f6cb8b1fa` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `109` | `golang.org/x/text` | `0.36.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/text@v0.36.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `110` | `golang.org/x/time` | `0.12.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/time@v0.12.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `111` | `golang.org/x/tools` | `0.44.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/golang.org/x/tools@v0.44.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `112` | `gonum.org/v1/gonum` | `0.17.0` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/gonum.org/v1/gonum@v0.17.0` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `113` | `google.golang.org/protobuf` | `1.36.11` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/google.golang.org/protobuf@v1.36.11` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |
| `114` | `lukechampine.com/blake3` | `1.4.1` | `golang` | Go Module Mirror / Upstream Author | `pkg:golang/lukechampine.com/blake3@v1.4.1` | `BSD-3-Clause OR MIT` | `backend/go.mod` | `1fd8a452491b8ed8...` |

---

## 3. Dependency Relationship Graph

* **Root Application Node**: `pkg:generic/cybernest/NestComm@1.0.0`
  * `DEPENDS_ON` -> `pkg:cargo/nestcomm-daemon@0.1.0` (`cpe:2.3:a:cybernest:nestcomm-daemon:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:cargo/ctrlc@3.5.2` (`cpe:2.3:a:rust-lang:ctrlc:3.5.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/nestcomm@1.0.0` (`cpe:2.3:a:cybernest:nestcomm:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/filippo.io/bigmod@v0.1.1-0.20260103110540-f8a47775ebe5` (`cpe:2.3:a:golang:filippo.io_bigmod:0.1.1-0.20260103110540-f8a47775ebe5:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/filippo.io/keygen@v0.0.0-20260114151900-8e2790ea4c5b` (`cpe:2.3:a:golang:filippo.io_keygen:0.0.0-20260114151900-8e2790ea4c5b:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/benbjohnson/clock@v1.3.5` (`cpe:2.3:a:golang:github.com_benbjohnson_clock:1.3.5:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/beorn7/perks@v1.0.1` (`cpe:2.3:a:golang:github.com_beorn7_perks:1.0.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/cespare/xxhash/v2@v2.3.0` (`cpe:2.3:a:golang:github.com_cespare_xxhash_v2:2.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/danieljoos/wincred@v1.2.3` (`cpe:2.3:a:golang:github.com_danieljoos_wincred:1.2.3:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/davidlazar/go-crypto@v0.0.0-20200604182044-b73af7476f6c` (`cpe:2.3:a:golang:github.com_davidlazar_go-crypto:0.0.0-20200604182044-b73af7476f6c:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/decred/dcrd/dcrec/secp256k1/v4@v4.4.1` (`cpe:2.3:a:golang:github.com_decred_dcrd_dcrec_secp256k1_v4:4.4.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/dunglas/httpsfv@v1.1.0` (`cpe:2.3:a:golang:github.com_dunglas_httpsfv:1.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/filecoin-project/go-clock@v0.1.0` (`cpe:2.3:a:golang:github.com_filecoin-project_go-clock:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/flynn/noise@v1.1.0` (`cpe:2.3:a:golang:github.com_flynn_noise:1.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/go-logr/logr@v1.4.3` (`cpe:2.3:a:golang:github.com_go-logr_logr:1.4.3:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/go-logr/stdr@v1.2.2` (`cpe:2.3:a:golang:github.com_go-logr_stdr:1.2.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/godbus/dbus/v5@v5.2.2` (`cpe:2.3:a:golang:github.com_godbus_dbus_v5:5.2.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/google/gopacket@v1.1.19` (`cpe:2.3:a:golang:github.com_google_gopacket:1.1.19:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/google/uuid@v1.6.0` (`cpe:2.3:a:golang:github.com_google_uuid:1.6.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/gorilla/websocket@v1.5.3` (`cpe:2.3:a:golang:github.com_gorilla_websocket:1.5.3:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/hashicorp/golang-lru@v1.0.2` (`cpe:2.3:a:golang:github.com_hashicorp_golang-lru:1.0.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/huin/goupnp@v1.3.0` (`cpe:2.3:a:golang:github.com_huin_goupnp:1.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/ipfs/boxo@v0.39.0` (`cpe:2.3:a:golang:github.com_ipfs_boxo:0.39.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/ipfs/go-cid@v0.6.1` (`cpe:2.3:a:golang:github.com_ipfs_go-cid:0.6.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/ipfs/go-datastore@v0.9.1` (`cpe:2.3:a:golang:github.com_ipfs_go-datastore:0.9.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/ipfs/go-log/v2@v2.9.2` (`cpe:2.3:a:golang:github.com_ipfs_go-log_v2:2.9.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/ipld/go-ipld-prime@v0.23.0` (`cpe:2.3:a:golang:github.com_ipld_go-ipld-prime:0.23.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/jackpal/go-nat-pmp@v1.0.2` (`cpe:2.3:a:golang:github.com_jackpal_go-nat-pmp:1.0.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/jbenet/go-temp-err-catcher@v0.1.0` (`cpe:2.3:a:golang:github.com_jbenet_go-temp-err-catcher:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/klauspost/cpuid/v2@v2.3.0` (`cpe:2.3:a:golang:github.com_klauspost_cpuid_v2:2.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/koron/go-ssdp@v0.0.6` (`cpe:2.3:a:golang:github.com_koron_go-ssdp:0.0.6:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-buffer-pool@v0.1.0` (`cpe:2.3:a:golang:github.com_libp2p_go-buffer-pool:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-cidranger@v1.1.0` (`cpe:2.3:a:golang:github.com_libp2p_go-cidranger:1.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-flow-metrics@v0.3.0` (`cpe:2.3:a:golang:github.com_libp2p_go-flow-metrics:0.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-libp2p@v0.48.0` (`cpe:2.3:a:golang:github.com_libp2p_go-libp2p:0.48.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-libp2p-asn-util@v0.4.1` (`cpe:2.3:a:golang:github.com_libp2p_go-libp2p-asn-util:0.4.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-libp2p-kad-dht@v0.41.0` (`cpe:2.3:a:golang:github.com_libp2p_go-libp2p-kad-dht:0.41.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-libp2p-kbucket@v0.8.0` (`cpe:2.3:a:golang:github.com_libp2p_go-libp2p-kbucket:0.8.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-libp2p-record@v0.3.1` (`cpe:2.3:a:golang:github.com_libp2p_go-libp2p-record:0.3.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-libp2p-routing-helpers@v0.7.5` (`cpe:2.3:a:golang:github.com_libp2p_go-libp2p-routing-helpers:0.7.5:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-msgio@v0.3.0` (`cpe:2.3:a:golang:github.com_libp2p_go-msgio:0.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-netroute@v0.4.0` (`cpe:2.3:a:golang:github.com_libp2p_go-netroute:0.4.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-reuseport@v0.4.0` (`cpe:2.3:a:golang:github.com_libp2p_go-reuseport:0.4.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/libp2p/go-yamux/v5@v5.0.1` (`cpe:2.3:a:golang:github.com_libp2p_go-yamux_v5:5.0.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/marten-seemann/tcp@v0.0.0-20210406111302-dfbc87cc63fd` (`cpe:2.3:a:golang:github.com_marten-seemann_tcp:0.0.0-20210406111302-dfbc87cc63fd:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/mattn/go-isatty@v0.0.22` (`cpe:2.3:a:golang:github.com_mattn_go-isatty:0.0.22:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/mikioh/tcpinfo@v0.0.0-20190314235526-30a79bb1804b` (`cpe:2.3:a:golang:github.com_mikioh_tcpinfo:0.0.0-20190314235526-30a79bb1804b:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/mikioh/tcpopt@v0.0.0-20190314235656-172688c1accc` (`cpe:2.3:a:golang:github.com_mikioh_tcpopt:0.0.0-20190314235656-172688c1accc:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/minio/sha256-simd@v1.0.1` (`cpe:2.3:a:golang:github.com_minio_sha256-simd:1.0.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/mr-tron/base58@v1.3.0` (`cpe:2.3:a:golang:github.com_mr-tron_base58:1.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-base32@v0.1.0` (`cpe:2.3:a:golang:github.com_multiformats_go-base32:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-base36@v0.2.0` (`cpe:2.3:a:golang:github.com_multiformats_go-base36:0.2.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multiaddr@v0.16.1` (`cpe:2.3:a:golang:github.com_multiformats_go-multiaddr:0.16.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multiaddr-dns@v0.5.0` (`cpe:2.3:a:golang:github.com_multiformats_go-multiaddr-dns:0.5.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multiaddr-fmt@v0.1.0` (`cpe:2.3:a:golang:github.com_multiformats_go-multiaddr-fmt:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multibase@v0.3.0` (`cpe:2.3:a:golang:github.com_multiformats_go-multibase:0.3.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multicodec@v0.10.0` (`cpe:2.3:a:golang:github.com_multiformats_go-multicodec:0.10.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multihash@v0.2.3` (`cpe:2.3:a:golang:github.com_multiformats_go-multihash:0.2.3:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-multistream@v0.6.1` (`cpe:2.3:a:golang:github.com_multiformats_go-multistream:0.6.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/multiformats/go-varint@v0.1.0` (`cpe:2.3:a:golang:github.com_multiformats_go-varint:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/munnerz/goautoneg@v0.0.0-20191010083416-a7dc8b61c822` (`cpe:2.3:a:golang:github.com_munnerz_goautoneg:0.0.0-20191010083416-a7dc8b61c822:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pbnjay/memory@v0.0.0-20210728143218-7b4eea64cf58` (`cpe:2.3:a:golang:github.com_pbnjay_memory:0.0.0-20210728143218-7b4eea64cf58:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/datachannel@v1.5.10` (`cpe:2.3:a:golang:github.com_pion_datachannel:1.5.10:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/dtls/v3@v3.1.2` (`cpe:2.3:a:golang:github.com_pion_dtls_v3:3.1.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/ice/v4@v4.0.10` (`cpe:2.3:a:golang:github.com_pion_ice_v4:4.0.10:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/interceptor@v0.1.40` (`cpe:2.3:a:golang:github.com_pion_interceptor:0.1.40:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/logging@v0.2.4` (`cpe:2.3:a:golang:github.com_pion_logging:0.2.4:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/mdns/v2@v2.0.7` (`cpe:2.3:a:golang:github.com_pion_mdns_v2:2.0.7:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/randutil@v0.1.0` (`cpe:2.3:a:golang:github.com_pion_randutil:0.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/rtcp@v1.2.16` (`cpe:2.3:a:golang:github.com_pion_rtcp:1.2.16:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/rtp@v1.8.19` (`cpe:2.3:a:golang:github.com_pion_rtp:1.8.19:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/sctp@v1.8.39` (`cpe:2.3:a:golang:github.com_pion_sctp:1.8.39:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/sdp/v3@v3.0.18` (`cpe:2.3:a:golang:github.com_pion_sdp_v3:3.0.18:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/srtp/v3@v3.0.6` (`cpe:2.3:a:golang:github.com_pion_srtp_v3:3.0.6:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/stun/v3@v3.1.1` (`cpe:2.3:a:golang:github.com_pion_stun_v3:3.1.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/transport/v3@v3.0.7` (`cpe:2.3:a:golang:github.com_pion_transport_v3:3.0.7:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/transport/v4@v4.0.1` (`cpe:2.3:a:golang:github.com_pion_transport_v4:4.0.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/turn/v4@v4.0.2` (`cpe:2.3:a:golang:github.com_pion_turn_v4:4.0.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/pion/webrtc/v4@v4.1.2` (`cpe:2.3:a:golang:github.com_pion_webrtc_v4:4.1.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/polydawn/refmt@v0.89.1-0.20231129105047-37766d95467a` (`cpe:2.3:a:golang:github.com_polydawn_refmt:0.89.1-0.20231129105047-37766d95467a:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/prometheus/client_golang@v1.23.2` (`cpe:2.3:a:golang:github.com_prometheus_client_golang:1.23.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/prometheus/client_model@v0.6.2` (`cpe:2.3:a:golang:github.com_prometheus_client_model:0.6.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/prometheus/common@v0.67.5` (`cpe:2.3:a:golang:github.com_prometheus_common:0.67.5:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/prometheus/procfs@v0.20.1` (`cpe:2.3:a:golang:github.com_prometheus_procfs:0.20.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/quic-go/qpack@v0.6.0` (`cpe:2.3:a:golang:github.com_quic-go_qpack:0.6.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/quic-go/quic-go@v0.59.1` (`cpe:2.3:a:golang:github.com_quic-go_quic-go:0.59.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/quic-go/webtransport-go@v0.10.0` (`cpe:2.3:a:golang:github.com_quic-go_webtransport-go:0.10.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/spaolacci/murmur3@v1.1.0` (`cpe:2.3:a:golang:github.com_spaolacci_murmur3:1.1.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/whyrusleeping/go-keyspace@v0.0.0-20160322163242-5b898ac5add1` (`cpe:2.3:a:golang:github.com_whyrusleeping_go-keyspace:0.0.0-20160322163242-5b898ac5add1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/wlynxg/anet@v0.0.5` (`cpe:2.3:a:golang:github.com_wlynxg_anet:0.0.5:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/github.com/zalando/go-keyring@v0.2.8` (`cpe:2.3:a:golang:github.com_zalando_go-keyring:0.2.8:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.opentelemetry.io/auto/sdk@v1.2.1` (`cpe:2.3:a:golang:go.opentelemetry.io_auto_sdk:1.2.1:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.opentelemetry.io/otel@v1.42.0` (`cpe:2.3:a:golang:go.opentelemetry.io_otel:1.42.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.opentelemetry.io/otel/metric@v1.42.0` (`cpe:2.3:a:golang:go.opentelemetry.io_otel_metric:1.42.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.opentelemetry.io/otel/trace@v1.42.0` (`cpe:2.3:a:golang:go.opentelemetry.io_otel_trace:1.42.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.uber.org/dig@v1.19.0` (`cpe:2.3:a:golang:go.uber.org_dig:1.19.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.uber.org/fx@v1.24.0` (`cpe:2.3:a:golang:go.uber.org_fx:1.24.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.uber.org/mock@v0.5.2` (`cpe:2.3:a:golang:go.uber.org_mock:0.5.2:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.uber.org/multierr@v1.11.0` (`cpe:2.3:a:golang:go.uber.org_multierr:1.11.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.uber.org/zap@v1.28.0` (`cpe:2.3:a:golang:go.uber.org_zap:1.28.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/go.yaml.in/yaml/v2@v2.4.4` (`cpe:2.3:a:golang:go.yaml.in_yaml_v2:2.4.4:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/crypto@v0.50.0` (`cpe:2.3:a:golang:golang.org_x_crypto:0.50.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/exp@v0.0.0-20260410095643-746e56fc9e2f` (`cpe:2.3:a:golang:golang.org_x_exp:0.0.0-20260410095643-746e56fc9e2f:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/mod@v0.35.0` (`cpe:2.3:a:golang:golang.org_x_mod:0.35.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/net@v0.53.0` (`cpe:2.3:a:golang:golang.org_x_net:0.53.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/sync@v0.20.0` (`cpe:2.3:a:golang:golang.org_x_sync:0.20.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/sys@v0.43.0` (`cpe:2.3:a:golang:golang.org_x_sys:0.43.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/telemetry@v0.0.0-20260409153401-be6f6cb8b1fa` (`cpe:2.3:a:golang:golang.org_x_telemetry:0.0.0-20260409153401-be6f6cb8b1fa:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/text@v0.36.0` (`cpe:2.3:a:golang:golang.org_x_text:0.36.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/time@v0.12.0` (`cpe:2.3:a:golang:golang.org_x_time:0.12.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/golang.org/x/tools@v0.44.0` (`cpe:2.3:a:golang:golang.org_x_tools:0.44.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/gonum.org/v1/gonum@v0.17.0` (`cpe:2.3:a:golang:gonum.org_v1_gonum:0.17.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/google.golang.org/protobuf@v1.36.11` (`cpe:2.3:a:golang:google.golang.org_protobuf:1.36.11:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/lukechampine.com/blake3@v1.4.1` (`cpe:2.3:a:golang:lukechampine.com_blake3:1.4.1:*:*:*:*:*:*:*`)

---

## 4. Cryptographic Integrity & CWE Hardening Attestation

* **Files Cryptographically Hashed (SHA-256)**: `15`
* **Shannon Entropy High-Risk Secret Alerts**: `0`
* **Ed25519 Public Key**: `99ac51e14879e456c9747f49ff458f77e3fb3d60ec822762e6ac5ef5438f6315`
* **Full Ed25519 Signature**: `5b787632b95d559206fb3f5d7f6e99e4e3fcaea1cb4ace1a19d8aa044559054a3b6d7d5f36a6b18ef3a2963555464131a0c8b81d29fe2ca72534979ae048100b`

*Generated automatically by CyberNest Labs NestSBOM RPGS Engine.*
