@echo off
rem ==============================================================================
rem CyberNest Labs // NestComm Dual-Native Orchestration Launcher (Windows 10/11)
rem Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
rem Security: CMMC 2.0 Level 2 / FIPS 140-3 / DISA STIG / CWE-22, 78, 114, 377
rem ==============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
set "SCRIPT_DIR=%~dp0"

rem --- User Cache Preservation Under Admin Elevation (CN-DIR-2026-004 Sec 3.2) ---
if "%USERPROFILE%"=="" set "USERPROFILE=%SystemDrive%\Users\%USERNAME%"
if "%LOCALAPPDATA%"=="" set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
if "%CARGO_HOME%"=="" set "CARGO_HOME=%USERPROFILE%\.cargo"
if "%RUSTUP_HOME%"=="" set "RUSTUP_HOME=%USERPROFILE%\.rustup"
if "%GOPATH%"=="" set "GOPATH=%USERPROFILE%\go"
if "%GOMODCACHE%"=="" set "GOMODCACHE=%GOPATH%\pkg\mod"
if "%GOCACHE%"=="" set "GOCACHE=%LOCALAPPDATA%\go-build"
set "PATH=%CARGO_HOME%\bin;%GOPATH%\bin;%PATH%"

set "GOFIPS=1"
set "GODEBUG=fips140=on"

rem --- Hardened Session Logging & Symlink/Reparse-Point Guard (CWE-377) ---
set "LOG_DIR=%LOCALAPPDATA%\nestcomm"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
icacls "%LOG_DIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1
set "LOG_FILE=%LOG_DIR%\session.log"
if exist "%LOG_FILE%" (
    fsutil reparsepoint query "%LOG_FILE%" >nul 2>&1
    if !ERRORLEVEL! equ 0 (
        del /f /q "%LOG_FILE%" >nul 2>&1
    )
)
type nul >> "%LOG_FILE%"
icacls "%LOG_FILE%" /inheritance:r /grant:r "%USERNAME%:F" >nul 2>&1

set "SUBCMD=%~1"
if "%SUBCMD%"=="" set "SUBCMD=run"

if /I "%SUBCMD%"=="setup" goto :cmd_setup
if /I "%SUBCMD%"=="build" goto :cmd_build
if /I "%SUBCMD%"=="run" goto :cmd_run
if /I "%SUBCMD%"=="serve" goto :cmd_run
if /I "%SUBCMD%"=="cli" goto :cmd_cli
if /I "%SUBCMD%"=="--cli" goto :cmd_cli
if /I "%SUBCMD%"=="simulate" goto :cmd_simulate
if /I "%SUBCMD%"=="--simulate" goto :cmd_simulate
if /I "%SUBCMD%"=="test" goto :cmd_test
if /I "%SUBCMD%"=="fmt" goto :cmd_fmt
goto :cmd_run

:cmd_setup
echo [%DATE% %TIME%] [INFO] [NestComm] Verifying Windows 10/11 Dual-Native toolchain... | powershell -NoProfile -Command "$input | Tee-Object -FilePath '%LOG_FILE%' -Append"
where go >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Go compiler ('go') not found in PATH.
    exit /b 1
)
where cargo >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Rust toolchain ('cargo') not found in PATH.
    exit /b 1
)
where python >nul 2>&1
if %ERRORLEVEL% neq 0 (
    where python3 >nul 2>&1
    if !ERRORLEVEL! neq 0 (
        echo [ERROR] Python ('python' or 'python3') not found in PATH.
        exit /b 1
    )
)
go version
cargo --version
if not exist "%SCRIPT_DIR%bin" mkdir "%SCRIPT_DIR%bin"
if not exist "%SCRIPT_DIR%exports" mkdir "%SCRIPT_DIR%exports"
echo [INFO] [NestComm] Windows 10/11 toolchain verified.
exit /b 0

:cmd_build
echo [%DATE% %TIME%] [INFO] [NestComm] Building Windows native binaries (GOFIPS=1)... >> "%LOG_FILE%"
echo [INFO] [NestComm] Building Windows native binaries (bin\nestcomm.exe, bin\nestcomm-daemon.exe)...
if not exist "%SCRIPT_DIR%bin" mkdir "%SCRIPT_DIR%bin"
pushd "%SCRIPT_DIR%backend"
go build -o "%SCRIPT_DIR%bin\nestcomm.exe" .
if !ERRORLEVEL! neq 0 (
    popd
    echo [ERROR] Go backend build failed.
    exit /b 1
)
copy /Y "%SCRIPT_DIR%bin\nestcomm.exe" "%SCRIPT_DIR%backend\main.exe" >nul
popd
pushd "%SCRIPT_DIR%daemon"
cargo build --release
if !ERRORLEVEL! neq 0 (
    popd
    echo [ERROR] Rust companion daemon build failed.
    exit /b 1
)
copy /Y "%SCRIPT_DIR%daemon\target\release\nestcomm-daemon.exe" "%SCRIPT_DIR%bin\nestcomm-daemon.exe" >nul
popd
if exist "%SCRIPT_DIR%..\NestSBOM\sbom_cli.py" (
    python "%SCRIPT_DIR%..\NestSBOM\sbom_cli.py" --repo "%SCRIPT_DIR%." --out-dir "%SCRIPT_DIR%." >nul 2>&1
)
echo [INFO] [NestComm] Build complete: bin\nestcomm.exe and bin\nestcomm-daemon.exe
exit /b 0

:cmd_cli
if not exist "%SCRIPT_DIR%bin\nestcomm.exe" call :cmd_build >nul
"%SCRIPT_DIR%bin\nestcomm.exe" --cli
exit /b %ERRORLEVEL%

:cmd_simulate
if not exist "%SCRIPT_DIR%bin\nestcomm.exe" call :cmd_build >nul
if not exist "%SCRIPT_DIR%exports" mkdir "%SCRIPT_DIR%exports"
"%SCRIPT_DIR%bin\nestcomm.exe" --cli --simulate --export
if exist "%SCRIPT_DIR%scripts\simulate.py" (
    where python >nul 2>&1
    if !ERRORLEVEL! equ 0 (
        python "%SCRIPT_DIR%scripts\simulate.py"
    ) else (
        python3 "%SCRIPT_DIR%scripts\simulate.py"
    )
)
exit /b 0

:cmd_test
echo [INFO] [NestComm] Running Go FIPS 140-3 security and compliance unit tests...
pushd "%SCRIPT_DIR%backend"
go test -v ./...
set "GO_TEST_RC=!ERRORLEVEL!"
popd
if !GO_TEST_RC! neq 0 exit /b !GO_TEST_RC!
echo [INFO] [NestComm] Running Rust companion daemon unit tests...
pushd "%SCRIPT_DIR%daemon"
cargo test
set "RS_TEST_RC=!ERRORLEVEL!"
popd
exit /b !RS_TEST_RC!

:cmd_fmt
echo [INFO] [NestComm] Formatting Go and Rust source code...
pushd "%SCRIPT_DIR%backend"
go fmt ./...
popd
pushd "%SCRIPT_DIR%daemon"
cargo fmt
popd
exit /b 0

:cmd_run
call :cmd_build
if %ERRORLEVEL% neq 0 exit /b %ERRORLEVEL%

if "%APP_PORT%"=="" set "APP_PORT=8080"
netstat -ano | findstr /R /C:":%APP_PORT% .*LISTENING" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    for /f %%p in ('powershell -NoProfile -Command "$l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0); $l.Start(); $p = $l.LocalEndpoint.Port; $l.Stop(); Write-Output $p"') do (
        set "APP_PORT=%%p"
    )
)

echo [%DATE% %TIME%] [INFO] [NestComm] Starting backend on http://127.0.0.1:!APP_PORT! >> "%LOG_FILE%"
echo [INFO] [NestComm] Starting backend on http://127.0.0.1:!APP_PORT!...
pushd "%SCRIPT_DIR%backend"
start "NestComm-Backend" /B "%SCRIPT_DIR%bin\nestcomm.exe" -port !APP_PORT! >> "%LOG_FILE%" 2>&1
popd

set "READY=0"
for /l %%i in (1,1,30) do (
    timeout /t 1 /nobreak >nul
    powershell -NoProfile -Command "$c = New-Object System.Net.Sockets.TcpClient; try { $c.Connect('127.0.0.1', !APP_PORT!); exit 0 } catch { exit 1 } finally { $c.Close() }" >nul 2>&1
    if !ERRORLEVEL! equ 0 (
        set "READY=1"
        goto :run_ready
    )
)

:run_ready
if "!READY!"=="1" (
    echo [INFO] [NestComm] Operational at http://127.0.0.1:!APP_PORT!. Launching browser...
    start http://127.0.0.1:!APP_PORT!
) else (
    echo [WARN] [NestComm] Readiness check delayed; navigate to http://127.0.0.1:!APP_PORT!
)
echo [INFO] [NestComm] Running. Press any key to stop.
pause >nul
exit /b 0
