#!/usr/bin/env bash
# ==============================================================================
# CyberNest Labs // NestComm Dual-Native Orchestration Launcher (Linux / Pop!_OS)
# Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
# Security: CMMC 2.0 Level 2 / FIPS 140-3 / DISA STIG / CWE-22, 78, 114, 377
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# --- Sudo User & Toolchain Cache Preservation (CN-DIR-2026-004 Section 3.2) ---
REAL_USER="${SUDO_USER:-${USER:-$(id -un)}}"
REAL_HOME="$(getent passwd "$REAL_USER" 2>/dev/null | cut -d: -f6 || echo "${HOME:-/tmp}")"
if [ -z "$REAL_HOME" ] || [ ! -d "$REAL_HOME" ]; then
    REAL_HOME="${HOME:-/tmp}"
fi
export CARGO_HOME="${CARGO_HOME:-$REAL_HOME/.cargo}"
export RUSTUP_HOME="${RUSTUP_HOME:-$REAL_HOME/.rustup}"
export GOPATH="${GOPATH:-$REAL_HOME/go}"
export GOMODCACHE="${GOMODCACHE:-$GOPATH/pkg/mod}"
export GOCACHE="${GOCACHE:-$REAL_HOME/.cache/go-build}"
export PATH="$CARGO_HOME/bin:$GOPATH/bin:/usr/local/go/bin:$PATH"

export GOFIPS=1
export GODEBUG=fips140=on

# --- Hardened Session Logging (CWE-377 Defense) ---
LOG_DIR="$REAL_HOME/.cache/nestcomm"
mkdir -p -m 700 "$LOG_DIR"
chmod 700 "$LOG_DIR" 2>/dev/null || true
LOG_FILE="$LOG_DIR/session.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE" && chmod 600 "$LOG_FILE"

log() {
    echo "[$(date -u +'%Y-%m-%dT%H:%M:%SZ')] [INFO] [NestComm] $1" | tee -a "$LOG_FILE"
}

warn() {
    echo "[$(date -u +'%Y-%m-%dT%H:%M:%SZ')] [WARN] [NestComm] $1" | tee -a "$LOG_FILE"
}

error() {
    echo "[$(date -u +'%Y-%m-%dT%H:%M:%SZ')] [ERROR] [NestComm] $1" | tee -a "$LOG_FILE" >&2
}

APP_PID=""
DAEMON_PID=""

cleanup() {
    trap - SIGINT SIGTERM EXIT
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        log "Terminating NestComm backend (PID: $APP_PID)..."
        kill -TERM "$APP_PID" 2>/dev/null || true
        for _ in {1..15}; do
            if ! kill -0 "$APP_PID" 2>/dev/null; then
                break
            fi
            sleep 0.1
        done
        kill -KILL "$APP_PID" 2>/dev/null || true
    fi
    if [ -n "$DAEMON_PID" ] && kill -0 "$DAEMON_PID" 2>/dev/null; then
        kill -TERM "$DAEMON_PID" 2>/dev/null || true
    fi
}

cmd_setup() {
    log "Verifying NestComm Dual-Native toolchain prerequisites (CN-DIR-2026-004)..."
    local missing=0
    for tool in go cargo python3; do
        if command -v "$tool" >/dev/null 2>&1; then
            log "Verified $tool -> $(command -v "$tool")"
        else
            error "Missing required dependency in PATH: $tool"
            missing=1
        fi
    done
    if [ "$missing" -ne 0 ]; then
        error "Toolchain verification failed. Please install missing prerequisites manually."
        exit 1
    fi
    go version | tee -a "$LOG_FILE"
    cargo --version | tee -a "$LOG_FILE"
    python3 --version | tee -a "$LOG_FILE"
    chmod +x "$SCRIPT_DIR/dev.sh" "$SCRIPT_DIR/launcher.sh" "$SCRIPT_DIR/scripts/launcher.sh" 2>/dev/null || true
    mkdir -p "$SCRIPT_DIR/bin" "$SCRIPT_DIR/exports"
    log "Toolchain setup and script permissions verified."
}

cmd_build() {
    log "Building NestComm Go FIPS 140-3 backend and Rust companion supervisor..."
    mkdir -p "$SCRIPT_DIR/bin"
    (
        cd "$SCRIPT_DIR/backend"
        GOFIPS=1 GODEBUG=fips140=on go build -o "$SCRIPT_DIR/bin/nestcomm" .
        cp -f "$SCRIPT_DIR/bin/nestcomm" "$SCRIPT_DIR/backend/main"
    )
    log "Compiled Go backend -> bin/nestcomm (and backend/main)"
    (
        cd "$SCRIPT_DIR/daemon"
        cargo build --release
        cp -f "$SCRIPT_DIR/daemon/target/release/nestcomm-daemon" "$SCRIPT_DIR/bin/nestcomm-daemon"
    )
    log "Compiled Rust companion daemon -> bin/nestcomm-daemon"
    if [ -f "$SCRIPT_DIR/../NestSBOM/sbom_cli.py" ]; then
        python3 "$SCRIPT_DIR/../NestSBOM/sbom_cli.py" --repo "$SCRIPT_DIR" --out-dir "$SCRIPT_DIR" >/dev/null 2>&1 || true
        log "Updated CycloneDX 1.5 and SPDX 2.3 SBOM manifests."
    fi
}

cmd_run() {
    cmd_build
    trap cleanup SIGINT SIGTERM EXIT

    APP_PORT="${APP_PORT:-8080}"
    if (echo > /dev/tcp/127.0.0.1/"$APP_PORT") 2>/dev/null; then
        warn "Port $APP_PORT is occupied. Allocating ephemeral loopback port..."
        APP_PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1]); s.close()')
        log "Dynamically assigned port: $APP_PORT"
    fi

    log "Starting NestComm on http://127.0.0.1:${APP_PORT} (GOFIPS=1)..."
    (
        cd "$SCRIPT_DIR/backend"
        APP_PORT="$APP_PORT" GOFIPS=1 GODEBUG=fips140=on "$SCRIPT_DIR/bin/nestcomm" -port "$APP_PORT" "$@" >> "$LOG_FILE" 2>&1
    ) &
    APP_PID=$!

    local ready=0
    for _ in {1..50}; do
        if (echo > /dev/tcp/127.0.0.1/"$APP_PORT") 2>/dev/null; then
            ready=1
            break
        fi
        sleep 0.2
    done

    if [ "$ready" -eq 1 ]; then
        log "NestComm operational at http://127.0.0.1:${APP_PORT}"
        if command -v xdg-open >/dev/null 2>&1; then
            xdg-open "http://127.0.0.1:${APP_PORT}" >/dev/null 2>&1 || true
        elif command -v python3 >/dev/null 2>&1; then
            python3 -m webbrowser "http://127.0.0.1:${APP_PORT}" >/dev/null 2>&1 || true
        fi
    else
        warn "Backend readiness polling timed out; check $LOG_FILE"
    fi

    log "NestComm active (PID: $APP_PID). Press Ctrl+C to stop."
    wait "$APP_PID"
}

cmd_cli() {
    if [ ! -x "$SCRIPT_DIR/bin/nestcomm" ]; then
        cmd_build >/dev/null
    fi
    GOFIPS=1 GODEBUG=fips140=on "$SCRIPT_DIR/bin/nestcomm" --cli
}

cmd_simulate() {
    if [ ! -x "$SCRIPT_DIR/bin/nestcomm" ]; then
        cmd_build >/dev/null
    fi
    mkdir -p "$SCRIPT_DIR/exports"
    GOFIPS=1 GODEBUG=fips140=on "$SCRIPT_DIR/bin/nestcomm" --cli --simulate --export
    python3 "$SCRIPT_DIR/scripts/simulate.py"
}

cmd_test() {
    log "Executing Go FIPS 140-3 security & compliance test suite..."
    (cd "$SCRIPT_DIR/backend" && GODEBUG=fips140=on go test -v ./...)
    log "Executing Rust daemon supervisor unit tests..."
    (cd "$SCRIPT_DIR/daemon" && cargo test)
    log "All Go and Rust test suites passed."
}

cmd_fmt() {
    log "Formatting Go and Rust source trees..."
    (cd "$SCRIPT_DIR/backend" && go fmt ./...)
    (cd "$SCRIPT_DIR/daemon" && cargo fmt)
    log "Source formatting complete."
}

SUBCMD="${1:-run}"
case "$SUBCMD" in
    setup)
        shift
        cmd_setup "$@"
        ;;
    build)
        shift
        cmd_build "$@"
        ;;
    run|serve)
        shift
        cmd_run "$@"
        ;;
    cli|--cli)
        shift
        cmd_cli "$@"
        ;;
    simulate|--simulate)
        shift
        cmd_simulate "$@"
        ;;
    test)
        shift
        cmd_test "$@"
        ;;
    fmt)
        shift
        cmd_fmt "$@"
        ;;
    *)
        cmd_run "$@"
        ;;
esac
