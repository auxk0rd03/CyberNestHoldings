@echo off
rem ==============================================================================
rem CyberNest Labs // NestComm Root Unified Launcher (Windows 10/11)
rem Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
rem ==============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
call "%~dp0dev.bat" %*
exit /b %ERRORLEVEL%
