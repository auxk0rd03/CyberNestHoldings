@echo off
rem ==============================================================================
rem CyberNest Labs // NestComm Scripts Launcher Wrapper (Windows 10/11)
rem Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
rem ==============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."
call "%~dp0..\dev.bat" %*
exit /b %ERRORLEVEL%
