#!/usr/bin/env bash
# ==============================================================================
# CyberNest Labs // NestComm Scripts Launcher Wrapper (Linux / Pop!_OS)
# Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
LOG_FILE="${HOME:-/tmp}/.cache/nestcomm/session.log"
mkdir -p -m 700 "$(dirname "$LOG_FILE")"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"

APP_PID=""
if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
    kill -TERM "$APP_PID" 2>/dev/null || true
fi

exec "$ROOT_DIR/dev.sh" "$@"
