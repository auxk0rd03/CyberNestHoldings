# NestComm Architectural Refactoring & Security Hardening Report

**Author:** Auxk0rd (Lead Security Systems Architect)
**Target Repository:** NestComm P2P Messaging Daemon (`backend/main.go`, `daemon/src/main.rs`)
**Scope:** Offline Payload Staging, Lifecycle Supervision Streamlining, and Symmetric NAT Relay Ingestion

---

## Executive Summary

This document details the engineering implementation and security hardening of three core architectural improvements across the NestComm decentralized communication stack. The enhancements eliminate single-point-of-failure network dropouts, deprecate fragmented platform-specific bash/batch wrapper dependencies, and introduce flexible NAT traversal primitives without relying on centralized or hardcoded external infrastructure.

---

## 1. Store-and-Forward Offline Staging Queue (`backend/main.go`)

### Problem Statement

In previous iterations, outbound message delivery (`POST /api/send`) operated synchronously against active libp2p multiplexed streams (`/nestcomm/chat/1.0.0`). If a target peer experienced transient network disconnections or was inactive on the Kademlia Distributed Hash Table (DHT), `nodeHost.NewStream` threw an immediate exception, permanently dropping the payload from the local execution context.

### Architectural Implementation

To resolve offline routing bottlenecks without bloating the local-first footprint with full-scale DHT storage relays, a lightweight, encrypted staging queue (`stagingQueue []StagedMessage`) has been implemented directly inside the core daemon:

1. **Payload Staging Intercept**: When `nodeHost.NewStream` encounters an error during `/api/send`, the payload is intercepted and converted into a `StagedMessage` structure:
   ```go
   type StagedMessage struct {
       ID        string    `json:"id"`
       Target    peer.ID   `json:"target"`
       Text      string    `json:"text"`
       Timestamp string    `json:"timestamp"`
       Retries   int       `json:"retries"`
       NextRetry time.Time `json:"next_retry"`
   }
   ```
2. **Atomic Encrypted Persistence (`queue.enc`)**: Staged items are appended to `stagingQueue` and persisted to disk via `saveState()`. The queue is serialized to JSON and encrypted using AES-256-GCM authenticated encryption before being written atomically (`writeAtomicFile`) to `~/.config/nestcomm/queue.enc` (`0600` permissions), preventing data loss or TOCTOU file corruption during system crashes.
3. **Exponential Backoff Worker Routine (`processStagingQueue`)**: A background goroutine evaluates `stagingQueue` every 2 seconds (`time.NewTicker(2 * time.Second)`). For items where `time.Now().After(item.NextRetry)`, the daemon attempts connection recovery (`nodeHost.NewStream` wrapped in a 5-second `context.WithTimeout`).
   * **Failure State**: If stream opening or payload transmission (`stream.Write`) fails, `item.Retries` increments, and `item.NextRetry` is updated using exponential backoff (`1s, 2s, 4s, 8s...` capped at `300s`).
   * **Success State**: Upon confirmed delivery (`writeErr == nil`), the payload is purged from `stagingQueue`, atomic disk state (`queue.enc`) is updated, and the item transitions to `[DELIVERED]` inside the user interface log (`chatLogs`).

---

## 2. Streamlined Multi-Platform Rust Daemon (`daemon/src/main.rs`)

### Problem Statement

The system previously maintained redundant execution wrappers: a Rust lifecycle launcher (`daemon/src/main.rs`) and platform-specific shell scripts (`scripts/launcher.sh` / `scripts/launcher.bat`). This double-daemon redundancy increased the maintenance surface and caused process supervision desynchronization between terminal signal handlers and background child processes.

### Architectural Implementation

The Rust daemon (`nestcomm-daemon`) has been re-compiled to directly handle all pre-flight checks, port scanning, umask initialization, child process management, and browser spawning natively across Linux, Windows, and macOS:

1. **Pre-Flight Dependency Verification**: `check_dependency()` verifies the presence of the Go compiler (`go`) or pre-compiled backend binary (`./main` or `main.exe`) prior to initialization, terminating cleanly (`exit status 1`) if neither is located.
2. **Automated Port Reclamation (`cleanup_orphaned_port`)**: On Unix environments, `lsof -t -i:<port>` identifies any orphaned or lingering processes bound to `APP_PORT` (`8080`), issuing targeted `kill -9` signals to reclaim socket bindings before spawning the Go engine.
3. **Unified Child Spawning & Argument Forwarding**: The daemon resolves absolute filesystem paths (`../backend`) and spawns either the native binary (`./main` / `main.exe`) or `go run main.go`, forwarding all command-line flags (e.g. `--relay`) while inheriting standard output and error streams (`Stdio::inherit()`).
4. **Asynchronous Browser Launching (`launch_browser`)**: A dedicated Rust thread (`thread::spawn`) executes a 2-second initialization delay before invoking platform-specific browser launchers (`xdg-open` / `python3 -m webbrowser` on Linux, `cmd /c start` on Windows, `open` on macOS) targeting `http://127.0.0.1:<APP_PORT>`.
5. **Clean Interrupt Trapping (`ctrlc`)**: Traps `SIGINT` and `SIGTERM` signals, setting an `AtomicBool` state (`Ordering::SeqCst`) to break the supervision loop, explicitly terminate the tracked `pid` (`child.kill()`, `child.wait()`), and perform final socket cleanup.

---

## 3. Symmetric NAT Relay Bridge Ingestion (`--relay` / `APP_RELAY`)

### Problem Statement

Symmetric NAT topologies and strict firewalls randomize outbound port mappings, preventing direct STUN/ICE hole-punching over raw TCP/UDP interfaces (`go-libp2p`) when communicating between restricted nodes lcking public IPFS connectivity.

### Architectural Implementation

To enable reliable NAT traversal without coupling the architecture to hardcoded or centralized bootstrap servers, dynamic relay ingestion has been integrated into `backend/main.go`:

1. **Interface Exposure**: The Go binary accepts a public multiaddr via command-line flags (`-relay` or `--relay`) or through the `APP_RELAY` environment variable (`os.Getenv("APP_RELAY")`).
2. **Bridge Initialization Sequence**: During startup (`main()`), immediately after instantiating the libp2p host (`libp2p.New`) and prior to Kademlia DHT bootstrapping, the daemon parses the relay multiaddr string (`multiaddr.NewMultiaddr(relayFlag)`).
3. **Direct Transport Anchoring**: `peer.AddrInfoFromP2pAddr` decodes the bridge node identity, and the host initiates an authenticated connection (`nodeHost.Connect(appCtx, *peerInfo)`). Once connected, the local node leverages the relay bridge to route encrypted Noise Protocol streams to peers across restricted network boundaries (`circuit.v2` compatibility).

---

## Verification & Deployment Checklist

* **Go Backend Compilation**: Run `go build main.go` inside `backend/` (`Exit code: 0`).
* **Rust Daemon Compilation**: Run `cargo check` inside `daemon/` (`Exit code: 0`).
* **Atomic Storage Inspection**: Verify that `~/.config/nestcomm/queue.enc` initializes with `0600` permissions upon the first staged offline payload.
* **Process Supervision Verification**: Send `SIGINT` to the running `nestcomm-daemon` process and verify via `lsof -i:8080` that TCP socket bindings are fully reclaimed upon termination.
