# Engineering Design Document

## Secure P2P Synchronous Messaging Protocol

**CLASSIFICATION:** CyberNest Internal Only
**STATUS:** Architecture Draft
**DATE:** Q3 2026

---

## 1. Executive Summary & Ecosystem Integration

This document details the architectural blueprint for a serverless, end-to-end encrypted, peer-to-peer (P2P) messaging application developed by CyberNest Labs. By eliminating central routing and directory servers, this tool addresses the "single point of failure" vulnerability prevalent in standard communication models.

This application will integrate seamlessly into the current internal ecosystem, complementing our core active toolset: the dynamic application security testing components (**Nexus-DAST**), our local-first secure shell wrapper (**NestLink**), and our system administrator reconnaissance tool (**KwikLog**). As CyberNest Labs pivots focus toward field engineering operations and the physical development of the Project MULE Unmanned Ground Vehicle (UGV), this messaging tool will secure internal tactical communications between field nodes and localized command environments.

## 2. Technical Stack Definition

The stack is explicitly chosen to maximize performance, guarantee memory safety in network parsing, and allow rapid GUI development without the overhead of heavy frameworks like Electron. The entire footprint must remain lean enough to run quietly as a background daemon across multiple OS environments, including Pop!_OS and Windows.

| Component                | Technology                            | Justification                                                                                                                                                  |
| :----------------------- | :------------------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Core Daemon & Networking | **Rust or Go** (via `libp2p`) | Provides concurrent network connections, memory-safe byte handling, and direct implementations of the Noise Protocol Framework.                                |
| Local Web GUI            | **HTMX**                        | Serves the frontend directly from the local daemon (127.0.0.1). Removes the need for a complex JavaScript SPA framework while providing a native desktop feel. |
| Testing & Simulation     | **Python**                      | Used exclusively to script headless client nodes to simulate heavy DHT routing loads and message queue drops locally before deployment.                        |
| Cross-Platform Setup     | **Bat / Shell**                 | Systemd configuration for Pop!_OS/Linux deployments and Batch scripting for Windows daemon installation.                                                       |

## 3. The Four Core Architectural Pillars

### 3.1. Decentralized Identity via Cryptography

There are no usernames stored in a database. Upon initialization, the local daemon generates an Ed25519 cryptographic keypair. The user's identity on the network is the cryptographic hash of their public key. In the GUI, a user adds a contact simply by importing their public key string.

> **Trust Model:** All outbound messages are signed by the sender's private key. The receiving daemon validates the signature against the registered public key hash before allowing the payload to render in the HTMX interface.

### 3.2. Peer Discovery & Routing (DHT)

Because IP addresses dynamically change and there is no centralized STUN/TURN server, the network relies on a Kademlia-based Distributed Hash Table (DHT). When a user attempts to initiate a chat, the daemon queries the DHT to resolve the target's public key hash into an active TCP/UDP IP address routing path.

### 3.3. Secure Transport Layer

We are avoiding standard PGP as a live transport mechanism due to its lack of Perfect Forward Secrecy for synchronous streams. Instead, the connection sequence follows this logic:

* The daemon retrieves the destination IP from the DHT.
* A direct peer-to-peer connection is established.
* A **Noise Protocol** cryptographic handshake authenticates the session, exchanging ephemeral keys.
* Once the tunnel is up, plaintext from the HTMX GUI is encrypted locally, streamed over the tunnel, decrypted by the peer, and rendered via their local daemon.

### 3.4. Asynchronous Message Queuing (The Offline Problem)

If Node A attempts to message Node B but the DHT reports Node B is offline, the message must not be lost. We will implement an encrypted store-and-forward mechanism. Node A will select random, highly available relay nodes on the network and pass them an encrypted blob with a Time-To-Live (TTL) header. When Node B comes online, it polls the DHT for any holding nodes, retrieves the blobs, and uses its private key to decrypt the offline messages.

## 4. Implementation Phases

The development lifecycle will be isolated to ensure network stability before front-end polish:

1. **Phase 1: Daemon & Identity:** Build the Go/Rust daemon to generate keypairs and run a local listener.
2. **Phase 2: DHT Integration:** Implement `libp2p`. Use Python scripts to spin up 50 local nodes and prove they can discover each other's hashes.
3. **Phase 3: Transport Bridge:** Implement the Noise Protocol handshake between two discovered nodes and verify payload exchange.
4. **Phase 4: HTMX Interface:** Build the local HTTP server in the daemon to render the chat window locally.

---

**Auxk0rd / William M.** *President / Lead Systems Architect* CyberNest Holdings LLC
