package main

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"html"
	"html/template"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/libp2p/go-libp2p"
	dht "github.com/libp2p/go-libp2p-kad-dht"
	"github.com/libp2p/go-libp2p/core/control"
	"github.com/libp2p/go-libp2p/core/crypto"
	"github.com/libp2p/go-libp2p/core/host"
	"github.com/libp2p/go-libp2p/core/network"
	"github.com/libp2p/go-libp2p/core/peer"
	"github.com/multiformats/go-multiaddr"
	"github.com/zalando/go-keyring"
)

var (
	localToken string
	nodeHost   host.Host
	appCtx     context.Context

	peersMu    sync.RWMutex
	knownPeers map[peer.ID]bool

	msgMu        sync.RWMutex
	chatLogs     []Message
	stateVersion uint64

	activeTarget peer.ID

	activeStreamsMu sync.Mutex
	activeStreams   map[peer.ID]int

	stagingMu    sync.Mutex
	stagingQueue []StagedMessage
	relayFlag    string

	storageDir string
	masterKey  []byte
	saveStateMu sync.Mutex
)

const (
	MaxPayloadSize    = 4096
	StreamTimeout     = 10 * time.Second
	MaxLogEntries     = 500
	MaxStreamsPerPeer = 10
	KeyFile           = "master.key"
	PeersFile         = "peers.enc"
	HistoryFile       = "history.enc"
	IdentityFile      = "identity.enc"
	QueueFile         = "queue.enc"
	KeyringService    = "nestcomm"
	KeyringUser       = "master_key"
)

type Message struct {
	Text      string `json:"text"`
	Sender    string `json:"sender"`
	Target    string `json:"target,omitempty"`
	Timestamp string `json:"timestamp"`
	Class     string `json:"class"`
}

type StagedMessage struct {
	ID        string    `json:"id"`
	Target    peer.ID   `json:"target"`
	Text      string    `json:"text"`
	Timestamp string    `json:"timestamp"`
	Retries   int       `json:"retries"`
	NextRetry time.Time `json:"next_retry"`
}

type nestCommGater struct{}

func (g *nestCommGater) InterceptPeerDial(p peer.ID) bool {
	return true
}

func (g *nestCommGater) InterceptAddrDial(p peer.ID, m multiaddr.Multiaddr) bool {
	return true
}

func (g *nestCommGater) InterceptAccept(n network.ConnMultiaddrs) bool {
	return true
}

func (g *nestCommGater) InterceptSecured(dir network.Direction, p peer.ID, n network.ConnMultiaddrs) bool {
	peersMu.RLock()
	isKnown := knownPeers[p]
	totalKnown := len(knownPeers)
	peersMu.RUnlock()

	if dir == network.DirInbound && totalKnown > 0 && !isKnown {
		log.Printf("[WARN] ConnectionGater: Dropped unauthorized handshake from unlisted peer: %s", p)
		return false
	}
	return true
}

func (g *nestCommGater) InterceptUpgraded(c network.Conn) (bool, control.DisconnectReason) {
	return true, 0
}

func generateToken() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		log.Fatal("[CRITICAL] Random generator failed:", err)
	}
	return hex.EncodeToString(b)
}

func formatPeerID(pidStr string) string {
	if len(pidStr) <= 24 {
		return pidStr
	}
	return pidStr[:16] + "..." + pidStr[len(pidStr)-8:]
}

func writeAtomicFile(targetPath string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(targetPath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	tmpFile, err := os.CreateTemp(dir, filepath.Base(targetPath)+".*.tmp")
	if err != nil {
		return err
	}
	tmpPath := tmpFile.Name()
	defer os.Remove(tmpPath)

	if err := tmpFile.Chmod(perm); err != nil {
		tmpFile.Close()
		return err
	}
	if _, err := tmpFile.Write(data); err != nil {
		tmpFile.Close()
		return err
	}
	if err := tmpFile.Sync(); err != nil {
		tmpFile.Close()
		return err
	}
	if err := tmpFile.Close(); err != nil {
		return err
	}
	return os.Rename(tmpPath, targetPath)
}

func initStoragePaths() {
	if envDir := os.Getenv("NESTCOMM_STORAGE_DIR"); envDir != "" {
		storageDir = envDir
	} else if xdg := os.Getenv("XDG_CONFIG_HOME"); xdg != "" {
		storageDir = filepath.Join(xdg, "nestcomm")
	} else {
		homeDir, err := os.UserHomeDir()
		if err == nil {
			storageDir = filepath.Join(homeDir, ".config", "nestcomm")
		} else {
			storageDir = filepath.Join(".", ".storage")
		}
	}

	if err := os.MkdirAll(storageDir, 0700); err != nil {
		storageDir = filepath.Join(".", ".storage")
		_ = os.MkdirAll(storageDir, 0700)
	}

	keyPath := filepath.Join(storageDir, KeyFile)

	if hexKey, err := keyring.Get(KeyringService, KeyringUser); err == nil {
		if decoded, err := hex.DecodeString(hexKey); err == nil && len(decoded) == 32 {
			masterKey = decoded
			log.Println("[INFO] Retrieved AES-256-GCM master key from native OS secure enclave (DBus Secret Service / Keyring)")
			if _, err := os.Stat(keyPath); err == nil {
				_ = os.Remove(keyPath)
				log.Println("[INFO] Removed legacy plaintext key file from disk following OS keyring migration")
			}
			return
		}
	}

	keyData, err := os.ReadFile(keyPath)
	if err == nil && len(keyData) == 32 {
		masterKey = keyData
		log.Println("[INFO] Loaded AES-256-GCM master key from local fallback file:", keyPath)
		if err := keyring.Set(KeyringService, KeyringUser, hex.EncodeToString(masterKey)); err == nil {
			_ = os.Remove(keyPath)
			log.Println("[INFO] Successfully migrated master key to OS secure enclave and purged flat file")
		}
		return
	}

	masterKey = make([]byte, 32)
	if _, err := rand.Read(masterKey); err != nil {
		log.Fatal("[CRITICAL] Master key generation failed:", err)
	}

	if err := keyring.Set(KeyringService, KeyringUser, hex.EncodeToString(masterKey)); err == nil {
		log.Println("[INFO] Generated new AES-256-GCM master key and stored in native OS secure enclave")
		return
	}

	if err := writeAtomicFile(keyPath, masterKey, 0600); err != nil {
		fallbackDir := filepath.Join(".", ".storage")
		_ = os.MkdirAll(fallbackDir, 0700)
		fallbackKey := filepath.Join(fallbackDir, KeyFile)
		if err2 := writeAtomicFile(fallbackKey, masterKey, 0600); err2 == nil {
			storageDir = fallbackDir
			keyPath = fallbackKey
		} else {
			log.Printf("[WARN] Master key held in memory; disk write failed: %v", err)
			return
		}
	}
	log.Printf("[WARN] OS secure enclave unavailable; stored fallback master key with 0600 permissions at %s", keyPath)
}

func encryptPayload(plaintext []byte) ([]byte, error) {
	block, err := aes.NewCipher(masterKey)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

func decryptPayload(ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher(masterKey)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	if len(ciphertext) < gcm.NonceSize() {
		return nil, fmt.Errorf("ciphertext too short")
	}
	nonce, actualCipher := ciphertext[:gcm.NonceSize()], ciphertext[gcm.NonceSize():]
	return gcm.Open(nil, nonce, actualCipher, nil)
}

func loadOrGenerateIdentity() crypto.PrivKey {
	idPath := filepath.Join(storageDir, IdentityFile)
	if encData, err := os.ReadFile(idPath); err == nil {
		if rawKey, err := decryptPayload(encData); err == nil {
			if priv, err := crypto.UnmarshalPrivateKey(rawKey); err == nil {
				log.Println("[INFO] Decrypted and restored persisted Ed25519 identity from secure storage")
				return priv
			}
		}
	}

	priv, _, err := crypto.GenerateEd25519Key(rand.Reader)
	if err != nil {
		log.Fatal("[CRITICAL] Identity generation failed:", err)
	}

	rawKey, err := crypto.MarshalPrivateKey(priv)
	if err != nil {
		log.Fatal("[CRITICAL] Failed to marshal private key:", err)
	}

	encData, err := encryptPayload(rawKey)
	if err != nil {
		log.Fatal("[CRITICAL] Failed to encrypt private key:", err)
	}

	if err := writeAtomicFile(idPath, encData, 0600); err != nil {
		fallbackPath := filepath.Join(".", ".storage", IdentityFile)
		_ = os.MkdirAll(filepath.Dir(fallbackPath), 0700)
		if err2 := writeAtomicFile(fallbackPath, encData, 0600); err2 == nil {
			log.Printf("[INFO] Persisted Ed25519 identity to fallback local storage: %s", fallbackPath)
		} else {
			log.Printf("[WARN] Ed25519 identity generated in memory (disk write restricted): %v", err)
		}
	} else {
		log.Println("[INFO] Generated new Ed25519 identity and atomically persisted to secure storage (identity.enc)")
	}

	return priv
}

func loadState() {
	peersPath := filepath.Join(storageDir, PeersFile)
	if encData, err := os.ReadFile(peersPath); err == nil {
		if data, err := decryptPayload(encData); err == nil {
			var peerStrings []string
			if err := json.Unmarshal(data, &peerStrings); err == nil {
				peersMu.Lock()
				for _, pStr := range peerStrings {
					if pid, err := peer.Decode(pStr); err == nil {
						knownPeers[pid] = true
						if activeTarget == "" {
							activeTarget = pid
						}
					}
				}
				peersMu.Unlock()
				log.Printf("[INFO] Decrypted and loaded %d peers from secure storage", len(knownPeers))
			}
		}
	}

	historyPath := filepath.Join(storageDir, HistoryFile)
	if encData, err := os.ReadFile(historyPath); err == nil {
		if data, err := decryptPayload(encData); err == nil {
			var savedLogs []Message
			if err := json.Unmarshal(data, &savedLogs); err == nil {
				msgMu.Lock()
				chatLogs = savedLogs
				if len(chatLogs) > MaxLogEntries {
					chatLogs = chatLogs[len(chatLogs)-MaxLogEntries:]
				}
				stateVersion++
				msgMu.Unlock()
				log.Printf("[INFO] Decrypted and loaded %d messages from secure storage", len(chatLogs))
			}
		}
	}

	queuePath := filepath.Join(storageDir, QueueFile)
	if encData, err := os.ReadFile(queuePath); err == nil {
		if data, err := decryptPayload(encData); err == nil {
			var savedQueue []StagedMessage
			if err := json.Unmarshal(data, &savedQueue); err == nil {
				stagingMu.Lock()
				stagingQueue = savedQueue
				stagingMu.Unlock()
				log.Printf("[INFO] Decrypted and loaded %d staged messages from secure storage", len(stagingQueue))
			}
		}
	}
}

func saveState() {
	saveStateMu.Lock()
	defer saveStateMu.Unlock()

	peersMu.RLock()
	var peerStrings []string
	for pid := range knownPeers {
		peerStrings = append(peerStrings, pid.String())
	}
	peersMu.RUnlock()

	if data, err := json.MarshalIndent(peerStrings, "", "  "); err == nil {
		if encData, err := encryptPayload(data); err == nil {
			peersPath := filepath.Join(storageDir, PeersFile)
			_ = writeAtomicFile(peersPath, encData, 0600)
		}
	}

	msgMu.RLock()
	if data, err := json.MarshalIndent(chatLogs, "", "  "); err == nil {
		if encData, err := encryptPayload(data); err == nil {
			historyPath := filepath.Join(storageDir, HistoryFile)
			_ = writeAtomicFile(historyPath, encData, 0600)
		}
	}
	msgMu.RUnlock()

	stagingMu.Lock()
	if data, err := json.MarshalIndent(stagingQueue, "", "  "); err == nil {
		if encData, err := encryptPayload(data); err == nil {
			queuePath := filepath.Join(storageDir, QueueFile)
			_ = writeAtomicFile(queuePath, encData, 0600)
		}
	}
	stagingMu.Unlock()
}

func appendMessage(msg Message) {
	msgMu.Lock()
	chatLogs = append(chatLogs, msg)
	if len(chatLogs) > MaxLogEntries {
		chatLogs = chatLogs[len(chatLogs)-MaxLogEntries:]
	}
	stateVersion++
	msgMu.Unlock()
	saveState()
}

func handleStream(stream network.Stream) {
	remotePeer := stream.Conn().RemotePeer()

	peersMu.RLock()
	isKnown := knownPeers[remotePeer]
	peersMu.RUnlock()

	if !isKnown {
		log.Printf("[WARN] Dropping unauthorized stream from unknown peer: %s", remotePeer)
		stream.Reset()
		return
	}

	activeStreamsMu.Lock()
	if activeStreams[remotePeer] >= MaxStreamsPerPeer {
		activeStreamsMu.Unlock()
		log.Printf("[WARN] Rate limit breached: dropping stream from %s (> %d active)", remotePeer, MaxStreamsPerPeer)
		stream.Reset()
		return
	}
	activeStreams[remotePeer]++
	activeStreamsMu.Unlock()

	defer func() {
		activeStreamsMu.Lock()
		activeStreams[remotePeer]--
		activeStreamsMu.Unlock()
		stream.Close()
	}()

	if err := stream.SetReadDeadline(time.Now().Add(StreamTimeout)); err != nil {
		stream.Reset()
		return
	}

	limitedReader := io.LimitReader(stream, MaxPayloadSize)
	buf, err := io.ReadAll(limitedReader)
	if err != nil && err != io.EOF {
		stream.Reset()
		return
	}

	if len(buf) > 0 {
		appendMessage(Message{
			Text:      string(buf),
			Sender:    formatPeerID(remotePeer.String()),
			Target:    remotePeer.String(),
			Timestamp: time.Now().Format("15:04:05"),
			Class:     "received",
		})
	}
}

func findFrontendPath(filename string) string {
	candidates := []string{
		filepath.Join("..", "frontend", filename),
		filepath.Join("frontend", filename),
	}
	if exe, err := os.Executable(); err == nil {
		exeDir := filepath.Dir(exe)
		candidates = append(candidates,
			filepath.Join(exeDir, "..", "frontend", filename),
			filepath.Join(exeDir, "frontend", filename),
		)
	}
	for _, p := range candidates {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return filepath.Join("..", "frontend", filename)
}

func verifyOrigin(r *http.Request) bool {
	host := r.Host
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	if host != "localhost" && host != "127.0.0.1" {
		return false
	}
	origin := r.Header.Get("Origin")
	if origin != "" {
		if !strings.HasPrefix(origin, "http://localhost:") && !strings.HasPrefix(origin, "http://127.0.0.1:") {
			return false
		}
	}
	return true
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !verifyOrigin(r) {
			http.Error(w, "Forbidden: Invalid Host or Origin", http.StatusForbidden)
			return
		}
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Content-Security-Policy", "default-src 'self' https://unpkg.com; style-src 'self' 'unsafe-inline';")
		w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate")
		w.Header().Set("Pragma", "no-cache")
		next.ServeHTTP(w, r)
	})
}

func processStagingQueue(ctx context.Context) {
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			stagingMu.Lock()
			if len(stagingQueue) == 0 {
				stagingMu.Unlock()
				continue
			}

			now := time.Now()
			var remaining []StagedMessage
			changed := false

			for _, item := range stagingQueue {
				if now.Before(item.NextRetry) {
					remaining = append(remaining, item)
					continue
				}

				timeoutCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
				stream, err := nodeHost.NewStream(timeoutCtx, item.Target, "/nestcomm/chat/1.0.0")
				if err != nil {
					cancel()
					item.Retries++
					backoffSec := 1 << item.Retries
					if backoffSec > 300 {
						backoffSec = 300
					}
					item.NextRetry = now.Add(time.Duration(backoffSec) * time.Second)
					remaining = append(remaining, item)
					changed = true
					continue
				}

				stream.SetWriteDeadline(time.Now().Add(StreamTimeout))
				_, writeErr := stream.Write([]byte(item.Text))
				stream.Close()
				cancel()

				if writeErr != nil {
					item.Retries++
					item.NextRetry = now.Add(4 * time.Second)
					remaining = append(remaining, item)
					changed = true
					continue
				}

				log.Printf("[INFO] Staged message delivered successfully to %s after %d retries", item.Target, item.Retries)
				appendMessage(Message{
					Text:      "[DELIVERED] " + item.Text,
					Sender:    "Auxk0rd (You)",
					Target:    item.Target.String(),
					Timestamp: time.Now().Format("15:04:05"),
					Class:     "sent",
				})
				changed = true
			}

			stagingQueue = remaining
			stagingMu.Unlock()

			if changed {
				saveState()
			}
		}
	}
}

func main() {
	flag.StringVar(&relayFlag, "relay", os.Getenv("APP_RELAY"), "Public multiaddr of symmetric NAT relay bridge")
	flag.StringVar(&relayFlag, "r", os.Getenv("APP_RELAY"), "Public multiaddr of symmetric NAT relay bridge (shorthand)")
	flag.Parse()

	localToken = generateToken()
	knownPeers = make(map[peer.ID]bool)
	chatLogs = make([]Message, 0)
	activeStreams = make(map[peer.ID]int)

	initStoragePaths()

	var cancel context.CancelFunc
	appCtx, cancel = context.WithCancel(context.Background())
	defer cancel()

	loadState()

	priv := loadOrGenerateIdentity()

	libp2pOpts := []libp2p.Option{
		libp2p.Identity(priv),
		libp2p.ListenAddrStrings("/ip4/0.0.0.0/tcp/0"),
		libp2p.ConnectionGater(&nestCommGater{}),
		libp2p.EnableRelay(),
		libp2p.EnableHolePunching(),
	}

	nodeHost, err := libp2p.New(libp2pOpts...)
	if err != nil {
		log.Fatal("[CRITICAL] Libp2p host instantiation failed:", err)
	}
	log.Printf("[INFO] Daemon initialized. Local Identity: %s", nodeHost.ID())

	if relayFlag != "" {
		relayAddr, err := multiaddr.NewMultiaddr(relayFlag)
		if err != nil {
			log.Printf("[ERROR] Invalid relay multiaddr specified: %v", err)
		} else if peerInfo, err := peer.AddrInfoFromP2pAddr(relayAddr); err != nil {
			log.Printf("[ERROR] Failed to parse peer info from relay multiaddr: %v", err)
		} else {
			if err := nodeHost.Connect(appCtx, *peerInfo); err != nil {
				log.Printf("[ERROR] Failed to connect to relay bridge %s: %v", relayFlag, err)
			} else {
				log.Printf("[INFO] Successfully connected to symmetric NAT relay bridge: %s", relayFlag)
			}
		}
	}

	nodeHost.SetStreamHandler("/nestcomm/chat/1.0.0", handleStream)

	kadDHT, err := dht.New(appCtx, nodeHost, dht.Mode(dht.ModeServer))
	if err != nil {
		log.Fatal("[CRITICAL] DHT creation failed:", err)
	}

	if err := kadDHT.Bootstrap(appCtx); err != nil {
		log.Println("[WARN] DHT Bootstrap routine failed:", err)
	}

	go processStagingQueue(appCtx)

	mux := http.NewServeMux()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		indexPath := findFrontendPath("index.html")
		tmpl, err := template.ParseFiles(indexPath)
		if err != nil {
			http.Error(w, "GUI File Not Found: "+indexPath, http.StatusInternalServerError)
			return
		}
		data := struct {
			Token       string
			ID          string
			FormattedID string
		}{
			Token:       localToken,
			ID:          nodeHost.ID().String(),
			FormattedID: formatPeerID(nodeHost.ID().String()),
		}
		tmpl.Execute(w, data)
	})

	mux.HandleFunc("/static/style.css", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/css")
		cssPath := findFrontendPath("style.css")
		http.ServeFile(w, r, cssPath)
	})

	registerComplianceRoutes(mux)

	mux.HandleFunc("/api/peers", func(w http.ResponseWriter, r *http.Request) {
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		peersMu.RLock()
		defer peersMu.RUnlock()

		if len(knownPeers) == 0 {
			w.Write([]byte(`<li class="contact-item"><span class="text-secondary" style="font-size: 0.8rem;">No active peers</span></li>`))
			return
		}

		for pid := range knownPeers {
			isActive := (pid == activeTarget)
			class := "contact-item"
			if isActive {
				class = "contact-item active"
			}
			statusColor := "var(--success)"
			if nodeHost.Network().Connectedness(pid) != network.Connected {
				statusColor = "var(--error)"
			}

			fullID := pid.String()
			displayID := formatPeerID(fullID)

			htmlSnippet := `
			<li class="` + class + `" title="Full Peer ID: ` + html.EscapeString(fullID) + `" hx-post="/api/peers/select" hx-vals='{"target": "` + html.EscapeString(fullID) + `", "token": "` + localToken + `"}' hx-target="#contact-list">
				` + html.EscapeString(displayID) + `
				<span style="color: ` + statusColor + `; font-size: 0.7rem;">●</span>
			</li>`
			w.Write([]byte(htmlSnippet))
		}
	})

	mux.HandleFunc("/api/peers/add", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		targetID := strings.TrimSpace(r.FormValue("peer_id"))
		if len(targetID) < 8 || len(targetID) > 128 {
			w.Write([]byte(`<div style="color: var(--error); font-size: 0.8rem; margin-top: 5px;">Invalid Peer ID length</div>`))
			return
		}
		pid, err := peer.Decode(targetID)
		if err != nil {
			w.Write([]byte(`<div style="color: var(--error); font-size: 0.8rem; margin-top: 5px;">Invalid Peer ID</div>`))
			return
		}

		peersMu.Lock()
		knownPeers[pid] = true
		if activeTarget == "" {
			activeTarget = pid
		}
		peersMu.Unlock()
		saveState()

		log.Printf("[INFO] Added and trusted peer: %s", targetID)

		go func() {
			timeoutCtx, cancel := context.WithTimeout(appCtx, 15*time.Second)
			defer cancel()
			peerInfo, err := kadDHT.FindPeer(timeoutCtx, pid)
			if err == nil {
				nodeHost.Connect(timeoutCtx, peerInfo)
			}
		}()

		w.Write([]byte(`<div style="color: var(--success); font-size: 0.8rem; margin-top: 5px;">Peer added and routing initiated.</div>`))
	})

	mux.HandleFunc("/api/peers/select", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		pidStr := strings.TrimSpace(r.FormValue("target"))
		if pid, err := peer.Decode(pidStr); err == nil {
			peersMu.Lock()
			activeTarget = pid
			peersMu.Unlock()
		}
		w.Header().Set("HX-Trigger", `{"refreshPeers": true, "refreshMessages": true}`)
	})

	mux.HandleFunc("/api/messages", func(w http.ResponseWriter, r *http.Request) {
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		peersMu.RLock()
		currentTarget := activeTarget.String()
		peersMu.RUnlock()

		msgMu.RLock()
		defer msgMu.RUnlock()

		etag := fmt.Sprintf(`"%d-%s"`, stateVersion, currentTarget)
		if r.Header.Get("If-None-Match") == etag {
			w.WriteHeader(http.StatusNotModified)
			return
		}
		w.Header().Set("ETag", etag)

		rendered := 0
		for _, msg := range chatLogs {
			// If target is set, only show messages for currentTarget (or legacy messages without target)
			if currentTarget != "" && msg.Target != "" && msg.Target != currentTarget {
				continue
			}
			rendered++
			tmpl := `
			<div class="message {{.Class}}">
				<div>{{.Text}}</div>
				<div class="message-meta">
					<span>{{.Sender}}</span>
					<span>{{.Timestamp}}</span>
				</div>
			</div>`
			t, _ := template.New("msg").Parse(tmpl)
			t.Execute(w, msg)
		}

		if rendered == 0 {
			if currentTarget == "" {
				w.Write([]byte(`<div class="text-secondary" style="text-align: center; margin-top: 2rem; font-size: 0.85rem;">No peer selected. Select an authorized peer from the sidebar to start chat.</div>`))
			} else {
				w.Write([]byte(`<div class="text-secondary" style="text-align: center; margin-top: 2rem; font-size: 0.85rem;">Encrypted channel ready. Send a message to start conversation with ` + html.EscapeString(formatPeerID(currentTarget)) + `</div>`))
			}
		}
	})

	mux.HandleFunc("/api/send", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		msgText := r.FormValue("message")
		if len(msgText) > MaxPayloadSize || len(msgText) == 0 {
			http.Error(w, "Invalid payload", http.StatusBadRequest)
			return
		}

		peersMu.RLock()
		target := activeTarget
		peersMu.RUnlock()

		if target == "" {
			http.Error(w, "No active peer selected", http.StatusBadRequest)
			return
		}

		stream, err := nodeHost.NewStream(appCtx, target, "/nestcomm/chat/1.0.0")
		if err != nil {
			log.Printf("[WARN] Target %s unreachable. Staging payload for exponential backoff retry: %v", target, err)
			staged := StagedMessage{
				ID:        fmt.Sprintf("%d", time.Now().UnixNano()),
				Target:    target,
				Text:      msgText,
				Timestamp: time.Now().Format("15:04:05"),
				Retries:   0,
				NextRetry: time.Now().Add(2 * time.Second),
			}
			stagingMu.Lock()
			stagingQueue = append(stagingQueue, staged)
			stagingMu.Unlock()

			appendMessage(Message{
				Text:      "[QUEUED - RETRYING] " + msgText,
				Sender:    "Auxk0rd (You)",
				Target:    target.String(),
				Timestamp: time.Now().Format("15:04:05"),
				Class:     "sent staged",
			})
			saveState()
			w.Header().Set("HX-Trigger", "refreshMessages")
			return
		}
		defer stream.Close()

		stream.SetWriteDeadline(time.Now().Add(StreamTimeout))
		_, err = stream.Write([]byte(msgText))
		if err != nil {
			log.Printf("[ERROR] Failed to send payload: %v", err)
			return
		}

		appendMessage(Message{
			Text:      msgText,
			Sender:    "Auxk0rd (You)",
			Target:    target.String(),
			Timestamp: time.Now().Format("15:04:05"),
			Class:     "sent",
		})

		w.Header().Set("HX-Trigger", "refreshMessages")
	})

	port := os.Getenv("APP_PORT")
	if port == "" {
		port = "8080"
	}
	addr := "127.0.0.1:" + port

	srv := &http.Server{
		Addr:         addr,
		Handler:      securityHeaders(mux),
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("[CRITICAL] HTTP server failed: %v", err)
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	saveState()
	srv.Shutdown(appCtx)
	nodeHost.Close()
}
