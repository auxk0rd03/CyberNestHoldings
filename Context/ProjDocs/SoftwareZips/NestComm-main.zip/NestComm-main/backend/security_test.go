package main

import (
	"bytes"
	"crypto/rand"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/libp2p/go-libp2p/core/crypto"
	"github.com/libp2p/go-libp2p/core/network"
	"github.com/libp2p/go-libp2p/core/peer"
)

// TestFinding1_1_LauncherProcessSafety verifies that launcher scripts employ explicit PID tracking,
// safe traps, no destructive fuser port kills, and CWE-377 symlink unlinking.
func TestFinding1_1_LauncherProcessSafety(t *testing.T) {
	paths := []string{"../launcher.sh", "../scripts/launcher.sh"}
	for _, p := range paths {
		content, err := os.ReadFile(p)
		if err != nil {
			t.Fatalf("Failed to read launcher script %s: %v", p, err)
		}
		str := string(content)

		if strings.Contains(str, "fuser -k") || strings.Contains(str, "fuser") {
			t.Errorf("Security Violation in %s: Destructive 'fuser' detected.", p)
		}
		if !strings.Contains(str, "set -euo pipefail") {
			t.Errorf("Security Violation in %s: Missing strict shell mode 'set -euo pipefail'.", p)
		}
		if !strings.Contains(str, "umask 077") && strings.Contains(p, "scripts") {
			t.Errorf("Security Violation in %s: Missing 'umask 077' for secure file permissions.", p)
		}
		if !strings.Contains(str, "kill -0") && strings.Contains(p, "scripts") {
			t.Errorf("Process Violation in %s: Missing explicit PID liveness check.", p)
		}
		if !strings.Contains(str, "-L \"$LOG_FILE\"") && strings.Contains(p, "scripts") {
			t.Errorf("CWE-377 Violation in %s: Missing pre-creation symlink validation check.", p)
		}
	}
}

// TestFinding2_1_OriginAndHostValidation verifies that verifyOrigin rejects DNS rebinding and foreign origins.
func TestFinding2_1_OriginAndHostValidation(t *testing.T) {
	testCases := []struct {
		name    string
		host    string
		origin  string
		allowed bool
	}{
		{"Valid localhost without port", "localhost", "", true},
		{"Valid localhost with port 8080", "localhost:8080", "", true},
		{"Valid loopback IP with port", "127.0.0.1:8080", "", true},
		{"Valid localhost with matching origin", "localhost:8080", "http://localhost:8080", true},
		{"Valid loopback with matching origin", "127.0.0.1:8080", "http://127.0.0.1:8080", true},
		{"Malicious DNS rebinding host", "evil.com", "", false},
		{"Malicious DNS rebinding with port", "attacker.net:8080", "", false},
		{"Malicious remote origin", "localhost:8080", "http://evil.com", false},
		{"Malicious HTTPS remote origin", "localhost:8080", "https://malicious-site.org", false},
		{"Subdomain spoof origin", "127.0.0.1:8080", "http://localhost.attacker.com", false},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			req, err := http.NewRequest("GET", "http://"+tc.host+"/", nil)
			if err != nil {
				t.Fatalf("Failed to create test request: %v", err)
			}
			req.Host = tc.host
			if tc.origin != "" {
				req.Header.Set("Origin", tc.origin)
			}

			allowed := verifyOrigin(req)
			if allowed != tc.allowed {
				t.Errorf("verifyOrigin for host=%q origin=%q returned %v; expected %v", tc.host, tc.origin, allowed, tc.allowed)
			}
		})
	}
}

// TestFinding2_1_TokenProtection verifies that state-mutating and sensitive API routes
// require valid cryptographic session tokens.
func TestFinding2_1_TokenProtection(t *testing.T) {
	localToken = "test-session-secret-token-1234"
	knownPeers = make(map[peer.ID]bool)
	chatLogs = make([]Message, 0)

	// Create test handler with security middleware
	mux := http.NewServeMux()
	mux.HandleFunc("/api/peers", func(w http.ResponseWriter, r *http.Request) {
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	mux.HandleFunc("/api/peers/add", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	mux.HandleFunc("/api/send", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}
		if r.FormValue("token") != localToken {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		w.WriteHeader(http.StatusOK)
	})

	handler := securityHeaders(mux)

	// 1. Missing token
	req := httptest.NewRequest("POST", "http://localhost:8080/api/peers/add", strings.NewReader("peer_id=123"))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	if rr.Code != http.StatusUnauthorized {
		t.Errorf("Expected 401 Unauthorized for missing token, got %d", rr.Code)
	}

	// 2. Invalid token
	req = httptest.NewRequest("POST", "http://localhost:8080/api/send", strings.NewReader("token=wrong&message=hello"))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	rr = httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	if rr.Code != http.StatusUnauthorized {
		t.Errorf("Expected 401 Unauthorized for invalid token, got %d", rr.Code)
	}

	// 3. Valid token
	form := url.Values{}
	form.Set("token", localToken)
	form.Set("peer_id", "12D3KooWSpa5Z9urbZhpFJWDbDLhG1VxwY8Zg5sbbbHMwcyVpPFK")
	req = httptest.NewRequest("POST", "http://localhost:8080/api/peers/add", strings.NewReader(form.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	rr = httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	if rr.Code != http.StatusOK {
		t.Errorf("Expected 200 OK for valid token, got %d", rr.Code)
	}
}

// TestFinding2_2_DynamicCryptographicIdentity asserts that the cryptographic identity is generated
// using dynamic Ed25519 keypairs, persisted under 0600 permissions, and can be restored.
func TestFinding2_2_DynamicCryptographicIdentity(t *testing.T) {
	tempDir, err := os.MkdirTemp("", "nestcomm_identity_test_*")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	defer os.RemoveAll(tempDir)

	storageDir = tempDir
	masterKey = make([]byte, 32)
	if _, err := rand.Read(masterKey); err != nil {
		t.Fatalf("Failed to generate master key: %v", err)
	}

	priv1 := loadOrGenerateIdentity()
	if priv1 == nil {
		t.Fatal("Failed to generate Ed25519 identity")
	}

	pid1, err := peer.IDFromPrivateKey(priv1)
	if err != nil {
		t.Fatalf("Failed to derive peer ID: %v", err)
	}

	// Verify identity file was written with 0600 permissions
	idPath := filepath.Join(storageDir, IdentityFile)
	info, err := os.Stat(idPath)
	if err != nil {
		t.Fatalf("identity.enc was not created: %v", err)
	}
	if info.Mode().Perm() != 0600 {
		t.Errorf("Expected identity.enc permissions to be 0600, got %o", info.Mode().Perm())
	}

	// Load identity again from disk and assert identity matches exactly
	priv2 := loadOrGenerateIdentity()
	pid2, err := peer.IDFromPrivateKey(priv2)
	if err != nil {
		t.Fatalf("Failed to derive second peer ID: %v", err)
	}

	if pid1 != pid2 {
		t.Errorf("Persisted peer ID mismatch: got %s, expected %s", pid2, pid1)
	}
}

// TestFinding3_1_NoAutomatedPackageInstallation ensures no sudo or apt commands are run automatically.
func TestFinding3_1_NoAutomatedPackageInstallation(t *testing.T) {
	paths := []string{"../launcher.sh", "../scripts/launcher.sh"}
	for _, p := range paths {
		content, err := os.ReadFile(p)
		if err != nil {
			t.Fatalf("Failed to read script %s: %v", p, err)
		}
		str := string(content)
		if strings.Contains(str, "sudo apt") || strings.Contains(str, "apt-get install") {
			t.Errorf("Privilege Violation in %s: Automated package installation detected.", p)
		}
	}
}

// TestFinding3_2_SecureStorageAndSymlinkHardening verifies that AES-256-GCM encryption
// handles payloads securely and resists ciphertext tampering.
func TestFinding3_2_SecureStorageAndSymlinkHardening(t *testing.T) {
	masterKey = make([]byte, 32)
	rand.Read(masterKey)

	plaintext := []byte("Classified CyberNest Labs Payload 2026")
	ciphertext, err := encryptPayload(plaintext)
	if err != nil {
		t.Fatalf("Payload encryption failed: %v", err)
	}

	// Valid decryption
	decrypted, err := decryptPayload(ciphertext)
	if err != nil {
		t.Fatalf("Payload decryption failed: %v", err)
	}
	if !bytes.Equal(decrypted, plaintext) {
		t.Errorf("Decrypted payload mismatch: got %q, expected %q", decrypted, plaintext)
	}

	// Tampered ciphertext
	tampered := make([]byte, len(ciphertext))
	copy(tampered, ciphertext)
	tampered[len(tampered)-1] ^= 0xFF
	if _, err := decryptPayload(tampered); err == nil {
		t.Error("Expected decryption failure on tampered ciphertext, but succeeded")
	}

	// Truncated ciphertext
	if _, err := decryptPayload([]byte("short")); err == nil {
		t.Error("Expected error on truncated ciphertext, but succeeded")
	}
}

// TestFinding4_1_InputValidationAndOversizedPayload verifies bounded inputs and MaxBytesReader drops.
func TestFinding4_1_InputValidationAndOversizedPayload(t *testing.T) {
	localToken = "test-token-bounds"

	handler := securityHeaders(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
		err := r.ParseForm()
		if err != nil {
			http.Error(w, "Body Too Large", http.StatusRequestEntityTooLarge)
			return
		}
		targetID := strings.TrimSpace(r.FormValue("peer_id"))
		if len(targetID) < 8 || len(targetID) > 128 {
			http.Error(w, "Invalid Peer ID length", http.StatusBadRequest)
			return
		}
		w.WriteHeader(http.StatusOK)
	}))

	// 1. Oversized 10MB payload (should trigger 413 / error)
	hugeBody := strings.Repeat("A", 10*1024*1024)
	req := httptest.NewRequest("POST", "http://localhost:8080/api/peers/add", strings.NewReader("peer_id="+hugeBody))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	if rr.Code != http.StatusRequestEntityTooLarge && rr.Code != http.StatusBadRequest {
		t.Errorf("Expected 413 or 400 for 10MB payload, got %d", rr.Code)
	}

	// 2. Short Peer ID (< 8 chars)
	req = httptest.NewRequest("POST", "http://localhost:8080/api/peers/add", strings.NewReader("peer_id=short"))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	rr = httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	if rr.Code != http.StatusBadRequest {
		t.Errorf("Expected 400 Bad Request for short peer ID, got %d", rr.Code)
	}
}

// TestFinding4_2_ServerSecurityHeaders asserts strict CSP and security headers on responses.
func TestFinding4_2_ServerSecurityHeaders(t *testing.T) {
	dummy := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	handler := securityHeaders(dummy)

	req := httptest.NewRequest("GET", "http://localhost:8080/", nil)
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	headers := map[string]string{
		"X-Content-Type-Options": "nosniff",
		"X-Frame-Options":        "DENY",
		"Cache-Control":          "no-store, no-cache, must-revalidate",
		"Pragma":                 "no-cache",
	}

	for k, expected := range headers {
		got := rr.Header().Get(k)
		if got != expected {
			t.Errorf("Expected header %s to be %q, got %q", k, expected, got)
		}
	}

	csp := rr.Header().Get("Content-Security-Policy")
	if !strings.Contains(csp, "default-src 'self'") {
		t.Errorf("Content-Security-Policy missing 'default-src 'self'': %s", csp)
	}
}

// TestStoreAndForwardOfflineStagingQueue asserts that offline messages are properly structured,
// encrypted, and queued with exponential backoff logic.
func TestStoreAndForwardOfflineStagingQueue(t *testing.T) {
	tempDir, err := os.MkdirTemp("", "nestcomm_staging_test_*")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	defer os.RemoveAll(tempDir)

	storageDir = tempDir
	masterKey = make([]byte, 32)
	rand.Read(masterKey)

	// Mock peer target
	_, pub, _ := crypto.GenerateEd25519Key(rand.Reader)
	mockPeer, _ := peer.IDFromPublicKey(pub)

	staged := StagedMessage{
		ID:        "msg-001",
		Target:    mockPeer,
		Text:      "Encrypted Tactical Offline Payload",
		Timestamp: "12:00:00",
		Retries:   2,
		NextRetry: time.Now().Add(4 * time.Second),
	}

	stagingMu.Lock()
	stagingQueue = []StagedMessage{staged}
	stagingMu.Unlock()

	saveState()

	// Verify encrypted queue file exists with 0600 permissions
	qPath := filepath.Join(storageDir, QueueFile)
	info, err := os.Stat(qPath)
	if err != nil {
		t.Fatalf("queue.enc was not created: %v", err)
	}
	if info.Mode().Perm() != 0600 {
		t.Errorf("Expected queue.enc permissions to be 0600, got %o", info.Mode().Perm())
	}

	// Reset in-memory queue and reload from disk
	stagingMu.Lock()
	stagingQueue = nil
	stagingMu.Unlock()

	loadState()

	stagingMu.Lock()
	defer stagingMu.Unlock()
	if len(stagingQueue) != 1 {
		t.Fatalf("Expected 1 staged message loaded from disk, got %d", len(stagingQueue))
	}
	loaded := stagingQueue[0]
	if loaded.ID != staged.ID || loaded.Target != staged.Target || loaded.Text != staged.Text {
		t.Errorf("Staged message corrupted upon load: got %+v, expected %+v", loaded, staged)
	}
	if loaded.Retries != 2 {
		t.Errorf("Expected retries=2, got %d", loaded.Retries)
	}
}

// TestConnectionGaterAuthorization confirms that unlisted inbound handshakes are blocked
// when knownPeers is populated, while authorized peers pass through.
func TestConnectionGaterAuthorization(t *testing.T) {
	_, pub1, _ := crypto.GenerateEd25519Key(rand.Reader)
	authorizedPeer, _ := peer.IDFromPublicKey(pub1)

	_, pub2, _ := crypto.GenerateEd25519Key(rand.Reader)
	unauthorizedPeer, _ := peer.IDFromPublicKey(pub2)

	peersMu.Lock()
	knownPeers = map[peer.ID]bool{
		authorizedPeer: true,
	}
	peersMu.Unlock()

	gater := &nestCommGater{}

	// Inbound connection from unauthorized peer must be rejected
	if gater.InterceptSecured(network.DirInbound, unauthorizedPeer, nil) {
		t.Error("ConnectionGater failed to drop unauthorized inbound handshake")
	}

	// Inbound connection from authorized peer must be allowed
	if !gater.InterceptSecured(network.DirInbound, authorizedPeer, nil) {
		t.Error("ConnectionGater unexpectedly dropped authorized inbound handshake")
	}

	// Outbound connection to any peer is permitted
	if !gater.InterceptSecured(network.DirOutbound, unauthorizedPeer, nil) {
		t.Error("ConnectionGater should permit outbound connection attempts")
	}
}

func TestCMMCComplianceAndCWE22Hardening(t *testing.T) {
	if _, err := SanitizeRelativePath("../etc/passwd"); err == nil {
		t.Fatal("Expected CWE-22 rejection for ../etc/passwd")
	}
	if _, err := SanitizeRelativePath("logs/session.log"); err != nil {
		t.Fatalf("Expected valid relative path, got %v", err)
	}
	StartDeadManSwitch120s(func() {})
	ConfirmDeadManSwitch()

	mux := http.NewServeMux()
	registerComplianceRoutes(mux)
	for _, ep := range []string{"/api/compliance/cmmc", "/api/compliance/stig", "/api/export/stix", "/api/export/taxii", "/api/network-sense"} {
		req := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:8080"+ep, nil)
		rr := httptest.NewRecorder()
		mux.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET %s returned %d", ep, rr.Code)
		}
	}
}
