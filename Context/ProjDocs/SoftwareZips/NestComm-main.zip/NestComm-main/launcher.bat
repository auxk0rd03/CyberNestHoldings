@echo off
rem NestComm Root Unified Launcher - Windows
rem CyberNest Labs - Authorized Security Engineering Standard
set SCRIPT_DIR=%~dp0
call "%SCRIPT_DIR%scripts\launcher.bat" %*
