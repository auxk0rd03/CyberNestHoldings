#!/usr/bin/env bash
# NestComm Root Unified Launcher - Linux / Pop!_OS
# CyberNest Labs - Authorized Security Engineering Standard
set -euo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/scripts/launcher.sh" "$@"
