@echo off
REM NestComm Cross-Platform Setup - Windows
REM Authored by Auxk0rd

echo Installing NestComm as a user startup task...
schtasks /create /tn "NestCommDaemon" /tr "\"%~dp0launcher.bat\"" /sc onlogon /f

echo Setup complete. NestComm will launch on user logon.
pause
