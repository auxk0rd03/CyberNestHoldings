#!/bin/bash
# NestComm Cross-Platform Setup - Pop!_OS / Linux
# Authored by Auxk0rd
set -euo pipefail

CURRENT_USER="${SUDO_USER:-$USER}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "Installing NestComm Systemd service for user: ${CURRENT_USER}..."

cat << EOF | sudo tee /etc/systemd/system/nestcomm.service
[Unit]
Description=NestComm P2P Daemon (CyberNest Labs)
After=network.target

[Service]
Type=simple
WorkingDirectory=${BASE_DIR}/scripts
ExecStart=/bin/bash ${BASE_DIR}/scripts/launcher.sh
Restart=on-failure
User=${CURRENT_USER}
Environment=APP_PORT=8080

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
echo "Systemd unit created at /etc/systemd/system/nestcomm.service"
echo "Enable and start with: sudo systemctl enable --now nestcomm"
