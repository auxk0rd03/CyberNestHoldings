@echo off
setlocal enabledelayedexpansion

if "%APP_PORT%"=="" set APP_PORT=8080
set SCRIPT_DIR=%~dp0
set LOG_DIR=%SCRIPT_DIR%logs

for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c%%a%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a%%b)
set LOG_FILE=%LOG_DIR%\launcher_%mydate%_%mytime%.log

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
icacls "%LOG_DIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1

echo [%DATE% %TIME%] [INFO] Starting NestComm launcher sequence... >> "%LOG_FILE%"
echo [%DATE% %TIME%] [INFO] Starting NestComm launcher sequence...

rem 1. Dependency checks
set BACKEND_DIR=%SCRIPT_DIR%..\backend
if not exist "%BACKEND_DIR%\main.exe" (
    where go >nul 2>nul
    if %ERRORLEVEL% neq 0 (
        echo [%DATE% %TIME%] [ERROR] Go is not installed and backend binary not found. >> "%LOG_FILE%"
        echo [ERROR] Go is not installed and backend binary not found. Manual installation required.
        pause
        exit /b 1
    )
)
echo [%DATE% %TIME%] [INFO] Dependencies verified. >> "%LOG_FILE%"

rem 2. Check if port is available
netstat -ano | findstr /R /C:":%APP_PORT% .*LISTENING" >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [%DATE% %TIME%] [WARN] Port %APP_PORT% is occupied. Allocating dynamic port... >> "%LOG_FILE%"
    for /f %%p in ('powershell -NoProfile -Command "$l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0); $l.Start(); $p = $l.LocalEndpoint.Port; $l.Stop(); Write-Output $p"') do (
        set APP_PORT=%%p
    )
    echo [%DATE% %TIME%] [INFO] Dynamically assigned port: !APP_PORT! >> "%LOG_FILE%"
)

rem 3. Launch Backend
echo [%DATE% %TIME%] [INFO] Starting application on port !APP_PORT!... >> "%LOG_FILE%"
echo [%DATE% %TIME%] [INFO] Starting application on port !APP_PORT!...
pushd "%BACKEND_DIR%"
if exist "main.exe" (
    start "NestComm-Backend" /B main.exe %* >> "%LOG_FILE%" 2>&1
) else (
    start "NestComm-Backend" /B go run . %* >> "%LOG_FILE%" 2>&1
)
popd

rem 4. Readiness polling
echo [%DATE% %TIME%] [INFO] Waiting for backend readiness... >> "%LOG_FILE%"
set READY=0
for /l %%i in (1,1,30) do (
    timeout /t 1 /nobreak >nul
    powershell -NoProfile -Command "$client = New-Object System.Net.Sockets.TcpClient; try { $client.Connect('127.0.0.1', !APP_PORT!); exit 0 } catch { exit 1 } finally { $client.Close() }" >nul 2>nul
    if !ERRORLEVEL! equ 0 (
        set READY=1
        goto :ready
    )
)

:ready
if !READY! equ 1 (
    echo [%DATE% %TIME%] [INFO] Backend is responsive. Launching web dashboard... >> "%LOG_FILE%"
    start http://127.0.0.1:!APP_PORT!
) else (
    echo [%DATE% %TIME%] [WARN] Backend initialization delayed. Navigate manually to http://127.0.0.1:!APP_PORT! >> "%LOG_FILE%"
)

echo [INFO] NestComm is running. Keep this window open. Close window to terminate.
pause >nul
