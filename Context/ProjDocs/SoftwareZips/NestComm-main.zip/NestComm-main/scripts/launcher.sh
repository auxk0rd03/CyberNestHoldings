#!/usr/bin/env bash
# NestComm Launcher - Linux / Pop!_OS
# Security: Strict mode & safe process management
set -euo pipefail
IFS=$'\n\t'

umask 077

APP_PORT="${APP_PORT:-8080}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="${SCRIPT_DIR}/logs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${LOG_DIR}/launcher_${TIMESTAMP}.log"

mkdir -p "$LOG_DIR"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE" && chmod 600 "$LOG_FILE"

log() {
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] [INFO] $1" | tee -a "$LOG_FILE"
}

warn() {
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] [WARN] $1" | tee -a "$LOG_FILE"
}

error() {
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] [ERROR] $1" | tee -a "$LOG_FILE" >&2
}

log "Starting NestComm initialization sequence..."

# 1. Dependency checks
if ! command -v go &> /dev/null && [ ! -f "${SCRIPT_DIR}/../backend/main" ] && [ ! -f "${SCRIPT_DIR}/../backend/nestcomm" ]; then
    error "Go compiler is not installed and pre-compiled backend binary not found."
    exit 1
fi
log "Runtime dependencies verified."

# 2. Check if port is already in use; if so, allocate an open ephemeral port
if (echo > /dev/tcp/127.0.0.1/"$APP_PORT") 2>/dev/null; then
    warn "Target port $APP_PORT is already occupied."
    if command -v python3 &> /dev/null; then
        APP_PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("", 0)); print(s.getsockname()[1]); s.close()')
        log "Dynamically allocated alternate port: $APP_PORT"
    else
        error "Port $APP_PORT in use and python3 unavailable for dynamic allocation."
        exit 1
    fi
fi

APP_PID=""

cleanup() {
    trap - SIGINT SIGTERM EXIT
    log "Cleanup initiated. Terminating NestComm child processes..."
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        log "Terminating backend daemon (PID: $APP_PID)..."
        kill -TERM "$APP_PID" 2>/dev/null || true
        for _ in {1..15}; do
            if ! kill -0 "$APP_PID" 2>/dev/null; then
                break
            fi
            sleep 0.1
        done
        kill -KILL "$APP_PID" 2>/dev/null || true
    fi
    log "NestComm sequence terminated cleanly."
}

trap cleanup SIGINT SIGTERM EXIT

# 3. Spawning Backend (FIPS 140-3 & SBOM Generation)
if [ -f "${SCRIPT_DIR}/../../NestSBOM/sbom_cli.py" ]; then
    python3 "${SCRIPT_DIR}/../../NestSBOM/sbom_cli.py" --repo "${SCRIPT_DIR}/.." --out-dir "${SCRIPT_DIR}/.." >/dev/null 2>&1 || true
fi
BACKEND_DIR="${SCRIPT_DIR}/../backend"
log "Starting NestComm backend from ${BACKEND_DIR} on port ${APP_PORT}..."

cd "$BACKEND_DIR"
export GOFIPS=1
export GODEBUG=fips140=on
if [ -f "./main" ]; then
    APP_PORT="$APP_PORT" ./main "$@" >> "$LOG_FILE" 2>&1 &
    APP_PID=$!
elif [ -f "./nestcomm" ]; then
    APP_PORT="$APP_PORT" ./nestcomm "$@" >> "$LOG_FILE" 2>&1 &
    APP_PID=$!
else
    APP_PORT="$APP_PORT" go run . "$@" >> "$LOG_FILE" 2>&1 &
    APP_PID=$!
fi

# 4. Readiness polling
log "Waiting for backend readiness on port $APP_PORT..."
READY=0
for _ in {1..50}; do
    if (echo > /dev/tcp/127.0.0.1/"$APP_PORT") 2>/dev/null; then
        READY=1
        break
    fi
    sleep 0.2
done

if [ "$READY" -eq 1 ]; then
    log "Backend is operational at http://127.0.0.1:${APP_PORT}. Spawning dashboard..."
    if command -v xdg-open &> /dev/null; then
        xdg-open "http://127.0.0.1:${APP_PORT}" >/dev/null 2>&1 || true
    elif command -v python3 &> /dev/null; then
        python3 -m webbrowser "http://127.0.0.1:${APP_PORT}" >/dev/null 2>&1 || true
    fi
else
    warn "Backend initialization delayed. Please navigate manually to http://127.0.0.1:${APP_PORT}"
fi

log "NestComm actively running. Press Ctrl+C to stop."
wait "$APP_PID"
