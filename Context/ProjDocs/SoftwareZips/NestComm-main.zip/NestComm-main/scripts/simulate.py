#!/usr/bin/env python3
# NestComm DHT Network Simulator
# Authored by Auxk0rd

import time
import random
import threading

def simulate_node(node_id):
    print(f"[Node-{node_id}] Initializing Ed25519 keypair...")
    time.sleep(random.uniform(0.5, 1.5))
    print(f"[Node-{node_id}] Connected to DHT routing table.")
    
    for _ in range(3):
        time.sleep(random.uniform(1.0, 3.0))
        target = random.randint(1, 50)
        print(f"[Node-{node_id}] Querying DHT for Node-{target} hash...")
        print(f"[Node-{node_id}] Noise protocol handshake with Node-{target} complete.")
        print(f"[Node-{node_id}] Payload transmitted.")

def main():
    print("--- NestComm Testing & Simulation (Authored by Auxk0rd) ---")
    print("Spinning up 5 local headless client nodes to simulate DHT load...")
    
    threads = []
    for i in range(1, 6):
        t = threading.Thread(target=simulate_node, args=(i,))
        threads.append(t)
        t.start()
        
    for t in threads:
        t.join()
        
    print("Simulation complete.")

if __name__ == "__main__":
    main()
