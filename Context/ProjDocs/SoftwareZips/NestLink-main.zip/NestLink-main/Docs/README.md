# Project NestLink

## Overview
NestLink is a local-first SSH wrapper engineered to facilitate peer-to-peer remote troubleshooting between internal development nodes. The application architecture bypasses centralized orchestration to provision direct, secure access between localized environments. 

This system integrates a Rust daemon for distributed network participation and NAT traversal, coupled with a Go backend and an HTMX frontend to provide localized connection monitoring and state management.

## Authorship
Developed by Dept. CyberNest Labs for CyberNestHoldings LLC.
Lead Engineer: Auxk0rd

## Operational Instructions

The application lifecycle and dependency resolution are managed via an automated initialization script. Execute the following commands to configure the required permissions and launch the daemon suite:

```bash
chmod +x launcher.sh
./launcher.sh
```

Upon execution, the launcher will autonomously allocate an open port for the local dashboard interface and verify the presence of all required runtime dependencies prior to establishing the network layer.

### How to Connect to Another Machine (Step-by-Step Guide)

NestLink is designed to connect two computers directly over the internet. You do **not** need to be in the same office, on the same Wi-Fi network, or connected to a corporate VPN. The software automatically navigates through standard routers and firewalls.

For this guide, we will refer to the two computers as:
*   **Your Machine (Local):** The computer you are physically sitting at.
*   **Target Machine (Remote):** The computer you want to access and control.

#### Step 1: Start NestLink on Both Computers
The NestLink application must be running on both your machine and the target machine simultaneously.
1. On **Your Machine**, open a terminal and run `./launcher.sh`. A web dashboard will automatically open in your browser.
2. Instruct the user at the **Target Machine** to perform the exact same action (run `./launcher.sh`).

#### Step 2: Find the Target Machine's ID
Every time NestLink runs, it displays a unique "Local ID" in the web dashboard. This ID acts like a secure, temporary phone number for that specific computer. 
1. Ask the person at the **Target Machine** to look at their newly opened web dashboard.
2. Have them copy their "Local ID" (e.g., `0xABCD1234`) and send it to you via a secure communication channel.

#### Step 3: Initiate the Connection
1. On **Your Machine**, navigate to your NestLink web dashboard.
2. Paste the Target Machine's ID (the code your colleague just sent you) into the input field.
3. Click the "Initiate Peer Discovery" button.

#### Background Execution
Once you initiate the connection, the application handles the technical routing autonomously. Your machine uses the provided ID to discover the target machine across the internet. Both systems then create a secure, direct tunnel through their respective local routers. Finally, a secure SSH connection is established over this tunnel, granting you encrypted remote access.

#### Step 4: Confirming Your Connection
After the automated routing process completes, you must verify that the secure tunnel is active and ready for use.

1. **Check the Web Dashboard:** Observe the NestLink dashboard on **Your Machine**. The visual status indicator should transition from an initializing state to a green success confirmation.
2. **Open a Terminal:** Open a new, separate terminal window on **Your Machine**.
3. **Execute the Login Command:** Because NestLink links the two systems securely in the background, your computer acts as if the remote machine is directly attached to it. Type the following command and press Enter:
   `ssh username@localhost -p 2222`
   *(Note: Replace "username" with the actual login name used on the Target Machine. The port "2222" is the default secure tunnel port provided by NestLink).*
4. **Verify System Access:** If the secure tunnel is operational, the terminal will prompt you for the Target Machine's password. Upon successful entry, your terminal text will change to reflect the Target Machine's system name, confirming you now have full remote control.
