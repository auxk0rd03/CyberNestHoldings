# System Architecture Review: Project NestLink

**Department:** CyberNest Labs
**Document Type:** Technical Overview

## Executive Operational Intent
NestLink is a zero-hallucination, local-first secure shell wrapper engineered to facilitate peer-to-peer remote troubleshooting between internal CyberNest development nodes. The system explicitly bypasses centralized orchestration dependencies to provision direct, secure access between distinct network environments. It adheres to a strict dependency-minimalist architecture by offloading orchestration routing to a distributed hash table while relying exclusively on native system binary protocols for cryptographic session handling.

## Modular Breakdown
*   **Launcher Service (Shell Environment):** Validates critical system dependencies, dynamically allocates unused network ports via socket testing, initiates the underlying daemon processes asynchronously, and provides an automated invocation of the local dashboard UI. It integrates Timeshift snapshot hooks to ensure rapid state recovery prior to incoming session modifications.
*   **Local Backend (Go):** Provides an isolated, localized HTTP server serving the HTMX dashboard. Exposes internal API endpoints for state polling and connection initiation requests strictly bound to localhost to prevent unauthorized external access.
*   **Network Routing Daemon (Rust):** The core networking logic engine. Manages distributed hash table bootstrapping operations, publishes the local cryptographic identifier to the network, and executes simultaneous UDP hole punching sequences for external Network Address Translation traversal.

## Core Functionality & Workflows
1.  **Initialization Phase:** The primary launcher verifies required dependencies (Go, Rust, Timeshift) and allocates dynamic port space. The backend HTTP server and the Rust network daemon are initialized in parallel background processes.
2.  **Peer Discovery Protocol:** The local Rust daemon hashes a pre-shared cryptographic identifier representing the current machine state and publishes its external network coordinates to the DHT topology.
3.  **Connection Initiation:** An authorized user inputs a target node identifier into the WebGUI. The Go backend processes this input and signals the Rust daemon to query the DHT for the target identifier's current location.
4.  **NAT Traversal and Encrypted Tunneling:** Upon successful coordinate resolution, both nodes perform simultaneous UDP hole punching. A persistent TCP stream is established across the public internet. The standard SSH protocol is then multiplexed over this stream, achieving end-to-end encryption without centralized virtual private networks.

## Codebase Architecture
The repository structure is compartmentalized as follows:
*   `/launcher.sh`: The primary execution entry point, dependency management script, and process orchestrator.
*   `/backend/main.go`: The localized HTTP server and application programming interface logic.
*   `/frontend/index.html`: The HTMX based dashboard providing real-time system state visualization.
*   `/daemon/Cargo.toml` & `/daemon/src/main.rs`: The compiled Rust based network routing and distributed hash table integration layer.
