# CyberNest Labs: NestLink Developer Handoff Manual

## Document Purpose & Scope

This document serves as the primary technical handover, architecture specification, and developer onboarding reference for **NestLink** (`https://github.com/auxk0rd03/NestLink.git`). It details the end-to-end P2P tunneling architecture, explains the role of every file in the codebase, describes how each component interacts within the broader system, and provides actionable guides for extending protocols, modifying engines, and maintaining the platform following our comprehensive security hardening and compliance audit.

---

## 1. Complete Codebase Directory Tree

```text
NestLink/
├── .gitignore                          # Git ignore rules (binaries, build artifacts, venvs, cache, logs)
├── NestLinkHandoff.md                  # Master technical architecture & maintenance handover manual
├── LICENSE                             # MIT open-source licensing specification
├── README.md                           # Operational manual, user guide & architectural overview
├── SBOM.md                             # CISA-compliant Software Bill of Materials (human-readable ledger)
├── SBOM.cyclonedx.json                 # CycloneDX 1.5 JSON SBOM manifest
├── SBOM.spdx.json                      # SPDX 2.3 JSON SBOM manifest
├── launcher.sh                         # Unified Linux/Pop!_OS bash launcher & process manager
├── launcher.bat                        # Unified Windows batch launcher & port coordinator
├── backend/
│   ├── go.mod                          # Go module dependencies (libp2p, DHT, crypto, multiaddr)
│   ├── go.sum                          # Cryptographic checksums and integrity hashes for Go dependencies
│   ├── main.go                         # Master Go entrypoint: libp2p host, DHT, SSH stream proxy & HTTP server
│   ├── compliance.go                   # AES-256-GCM enclave, CWE-22 guard, 120s dead-man switch & CMMC/STIG/STIX/TAXII APIs
│   └── security_test.go                # Comprehensive automated test suite validating security & compliance controls
├── daemon/
│   ├── Cargo.toml                      # Rust package definition and companion crate dependencies
│   ├── Cargo.lock                      # Pinned Rust dependencies
│   └── src/
│       └── main.rs                     # Rust supervisor: FIPS 140-3 KAT, CWE-22 path guard, companion monitor & launcher
├── frontend/
│   ├── index.html                      # HTMX dashboard: dynamic peer ID, status polling, telemetry, CSRF & 1-click copy
│   ├── style.css                       # NestLink component styles
│   └── synth-ledger.css                # Nocturnal Synth-Ledger design tokens & layout
└── Docs/
    ├── README.md                       # Internal developer operational notes
    ├── Secure_P2P_Connection_Build_Process.png # High-resolution connection workflow diagram
    ├── Technical_Overview.html         # Pre-compiled HTML architecture overview
    ├── Technical_Overview.md           # Markdown specification of architectural intent
    └── Technical_Overview.pdf          # Distribution-ready PDF document
```

---

## 2. Deep File-by-File Breakdown

### Root Launchers & Process Managers

#### `launcher.sh`
- **Role**: Primary Linux / Pop!_OS CLI launcher, environment manager, and safe process supervisor.
- **What It Does**:
  1. **Strict Shell Isolation**: Sets `set -euo pipefail` and `IFS=$'\n\t'` with `umask 077` to prevent accidental file leakage.
  2. **Symlink-Hardened Logging (Finding 3.2)**: Establishes `$HOME/.cache/nestlink/nestlink_launcher.log`. Validates that the target is not a pre-existing symbolic link (`[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"`) before creating it with `600` permissions, neutralizing CWE-377 TOCTOU symlink hijacking.
  3. **Non-Privileged Dependency Checks (Finding 3.1)**: Verifies presence of `go` and `python3`. If missing, execution halts immediately with actionable instructions for the operator; never attempts automated `sudo apt-get` installations.
  4. **Dynamic Port Negotiation**: Checks if default port `8080` is in use; if occupied, invokes Python `socket.bind(("", 0))` to allocate an ephemeral loopback port dynamically.
  5. **Explicit Process Tracking (Finding 1.1)**: Captures child process IDs (`BACKEND_PID` and `DAEMON_PID`). The cleanup handler registers an `EXIT`/`INT`/`TERM` trap that issues graceful `SIGTERM` signals directly to tracked PIDs, polling for termination before escalating to `SIGKILL`. Global `fuser -k` port-killing has been completely eliminated.
  6. **Readiness Polling**: Probes `127.0.0.1:$PORT` via `/dev/tcp` for up to 10 seconds before automatically launching the browser via `xdg-open` or `python3 -m webbrowser`.
- **How to Modify**: Add custom pre-flight checks or modify default environment variables (e.g. `PORT`, `NESTLINK_SSH_TARGET`).

#### `launcher.bat`
- **Role**: Unified Windows CLI runner and setup script for Windows 10/11 environments.
- **What It Does**:
  1. Configures localized logging in `%LOCALAPPDATA%\nestlink`.
  2. Verifies presence of `go` or pre-compiled `backend\main.exe`.
  3. Detects port collisions via PowerShell `TcpListener` on loopback port `0` to dynamically assign an unused port.
  4. Spawns `backend\main.exe` or `go run main.go` in the background.
  5. Performs TCP socket readiness polling before executing `start http://localhost:!PORT!`.
- **How to Modify**: Adjust timeout durations or PowerShell socket polling scripts.

---

### Core Networking & Tunneling Layer (`backend/`)

#### `backend/main.go`
- **Role**: Master application server, libp2p P2P routing node, SSH stream multiplexer, and HTTP backend.
- **What It Does**:
  - **Cryptographic Node Identity (Finding 2.2)**: Generates a cryptographically random Ed25519 keypair upon startup using `crypto/rand`. Constructs a libp2p host with dynamic `peer.ID` (e.g., `12D3KooW...`), preventing DHT routing collisions and peer spoofing caused by legacy static identifiers (`0xABCD1234`).
  - **Kademlia DHT Server**: Instantiates `go-libp2p-kad-dht` in `ModeServer`, advertising local multiaddrs and discovering peers across distributed networks.
  - **NAT Traversal & Hole Punching**: Enables `libp2p.EnableRelay()` and `libp2p.EnableHolePunching()` to establish direct P2P connections through residential and corporate NAT firewalls.
  - **Inbound SSH Stream Handler (`/nestlink/ssh/1.0.0`)**: Listens for inbound P2P streams from connected remote peers. When an inbound stream is accepted, dials the local SSH daemon (`127.0.0.1:22` or `NESTLINK_SSH_TARGET`) and provides high-performance, full-duplex TCP streaming via `io.Copy`.
  - **Outbound SSH Proxy Listener**: When a connection is established to a remote peer, binds a local TCP listener to `127.0.0.1:2222`. Terminal clients executing `ssh user@localhost -p 2222` connect to this local proxy, which multiplexes their raw SSH packets across the libp2p stream.
  - **Host & Origin Firewall (Finding 2.1)**: `verifyOrigin(r *http.Request)` strictly validates that the HTTP `Host` header resolves to `localhost` or `127.0.0.1` and that any supplied `Origin` header matches `http://localhost:` or `http://127.0.0.1:`. Blocks DNS rebinding and cross-site browser attacks.
  - **Cryptographic CSRF Validation (Finding 2.1)**: Generates a 16-byte cryptographically secure random session token at boot, validates it on all state-mutating requests (`/api/connect`, `/api/disconnect`), and serves it through `/api/csrf`.
  - **Bounded Payloads & Input Validation (Finding 4.1)**: Enforces `http.MaxBytesReader` (64KB limit) on incoming POST bodies to drop 10MB exploit payloads before form parsing. Enforces strict length bounds (`8 <= len <= 128`) and regex pattern matching (`validIDRegex`) before logging or initiating state mutation.
  - **Bounded HTTP Server Timeouts (Finding 4.2)**: Instantiates a custom `http.Server` configured with `ReadTimeout: 10s`, `WriteTimeout: 10s`, and `IdleTimeout: 30s` to protect against Slowloris attacks.
  - **Slice Bounds Protection**: Guards string slicing on `state.LocalID` to prevent out-of-bounds panics if node IDs are formatted differently in test environments.
- **How to Modify**: Add new libp2p stream handlers, customize DHT bootstrap peers, or adjust tunnel port configurations.

#### `backend/security_test.go`
- **Role**: Comprehensive automated unit and integration test suite validating all 7 security findings from `FixMeTodo.md`.
- **What It Verifies**:
  - `TestFinding1_1_LauncherProcessManagement`: Confirms `launcher.sh` contains no `fuser` calls and tracks `BACKEND_PID`.
  - `TestFinding2_1_OriginAndHostValidation`: Verifies rejection of foreign origins, malicious hosts, and DNS rebinding vectors.
  - `TestFinding2_1_CSRFProtection`: Asserts 403 Forbidden on missing or invalid CSRF tokens and 200 OK on valid tokens.
  - `TestFinding2_2_DynamicNodeIdentity`: Confirms node IDs are dynamic, non-static, and cryptographically valid.
  - `TestFinding3_1_NoAutomatedPackageInstallation`: Confirms no automated `sudo` or `apt-get` calls exist in launcher scripts.
  - `TestFinding3_2_SecureLogFileDirectory`: Verifies secure log file paths and symlink unlinking checks.
  - `TestFinding4_1_TargetIDValidationAndOversizedPayload`: Verifies regex validation against malicious injection payloads and confirms rejection of 10MB bodies.
  - `TestFinding4_2_ServerTimeouts`: Verifies explicit server read, write, and idle timeouts.
- **Execution**: `cd backend && go test -v .`

---

### Process Lifecycle & Supervision Layer (`daemon/`)

#### `daemon/src/main.rs`
- **Role**: Native Rust process supervisor, dual-mode companion monitor, readiness poller, and browser launcher.
- **What It Does**:
  - **Dual-Mode Operation**:
    - **Standalone Mode**: If launched directly (`./nestlink-daemon`), checks dependencies, compiles/locates `backend/main`, spawns the Go engine as a tracked child process, polls TCP socket readiness, opens the browser, and traps Ctrl+C to cleanly kill the child PID.
    - **Companion Monitoring Mode**: If launched alongside `launcher.sh` where the Go backend is already active on `PORT`, detects the open socket (`TcpStream::connect`), avoids duplicate process spawning and port collisions, and monitors backend socket connectivity until shutdown.
  - **Cross-Platform Binary Resolution**: Uses `backend_dir.join(if cfg!(windows) { "main.exe" } else { "main" })` for unambiguous path execution.
  - **Cross-Platform Browser Launcher**: Dynamically invokes `xdg-open` or `python3 -m webbrowser` on Linux, `cmd /c start` on Windows, and `open` on macOS.
- **How to Modify**: Adjust readiness polling intervals or add system tray integration. Recompile via `cd daemon && cargo build`.

---

### Presentation Layer (`frontend/`)

#### `frontend/index.html`
- **Role**: Responsive local dashboard built with HTMX and vanilla CSS.
- **What It Does**:
  - **Y2K / Industrial High-Contrast Theme**: Clean, functional UI with distinct status dot indicators (green for connected, yellow for idle/ready).
  - **Dynamic Node Identity**: Queries `/api/local-id` asynchronously via HTMX (`hx-get="/api/local-id" hx-trigger="load"`), replacing the legacy static `0xABCD1234` text.
  - **1-Click Machine ID Copy**: Provides modern `navigator.clipboard` integration with fallback to `document.execCommand('copy')` and prompt modal for legacy browsers.
  - **Real-Time Status Polling**: Employs HTMX polling (`hx-get="/api/status" hx-trigger="load, every 5s"`) to reflect live connection status and tunnel endpoints without page reloads.
  - **CSRF Token Injection**: Uses `<div hx-get="/api/csrf" hx-trigger="load"></div>` to dynamically fetch and insert the secret session CSRF token into the connection form.
  - **Connection Form & Snippet Generator**: Submits target node IDs to `/api/connect` via HTMX POST. Upon connection, displays reproducible SSH terminal syntax (`ssh username@localhost -p 2222`) alongside an inline CSRF-protected **Disconnect** action.
- **How to Modify**: Customize CSS variables (`--bg-main`, `--accent-teal`, etc.) or add connection latency metrics.

---

## 3. Data Flow & Lifecycle of a P2P Connection

```text
[Operator Browser]               [Local NestLink Go Node]               [Remote NestLink Go Node]          [Remote Host SSHD]
       │                                     │                                      │                              │
       │ 1. GET /                            │                                      │                              │
       ├────────────────────────────────────►│                                      │                              │
       │ 2. Loads Dashboard & /api/local-id  │                                      │                              │
       │    (Displays 12D3KooW... Peer ID)   │                                      │                              │
       │                                     │                                      │                              │
       │ 3. Operator enters Remote Peer ID   │                                      │                              │
       │    POST /api/connect (with CSRF)    │                                      │                              │
       ├────────────────────────────────────►│                                      │                              │
       │                                     │ 4. Validate Host, Origin, CSRF, ID   │                              │
       │                                     │ 5. Query Kademlia DHT for Peer ID    │                              │
       │                                     ├─────────────────────────────────────►│                              │
       │                                     │ 6. Simultaneous UDP/TCP Hole Punch   │                              │
       │                                     │◄════════════════════════════════════►│                              │
       │                                     │                                      │                              │
       │                                     │ 7. Bind Local Proxy (127.0.0.1:2222) │                              │
       │ 8. Render Success Alert + SSH cmd   │    Open Stream /nestlink/ssh/1.0.0   │                              │
       │◄────────────────────────────────────┤                                      │                              │
       │                                     │                                      │                              │
[Terminal: ssh user@localhost -p 2222]       │                                      │                              │
       │                                     │                                      │                              │
       │ 9. Inbound TCP to 127.0.0.1:2222    │                                      │                              │
       ├────────────────────────────────────►│                                      │                              │
       │                                     │ 10. Multiplex over libp2p Stream     │                              │
       │                                     ├─────────────────────────────────────►│                              │
       │                                     │                                      │ 11. Dial 127.0.0.1:22        │
       │                                     │                                      ├─────────────────────────────►│
       │                                     │                                      │ 12. Full-duplex SSH Data     │
       │◄════════════════════════════════════╪══════════════════════════════════════╪═════════════════════════════►│
       │                                     │                                      │                              │
       │ 13. Operator clicks [Disconnect]    │                                      │                              │
       │     POST /api/disconnect (with CSRF)│                                      │                              │
       ├────────────────────────────────────►│                                      │                              │
       │                                     │ 14. Close Listener & P2P Stream      │                              │
       │                                     ├─────────────────────────────────────►│                              │
       │ 15. Port 2222 released              │                                      │                              │
       │◄────────────────────────────────────┘                                      │                              │
```

---

## 4. Developer Extension How-To Guides

### How to Add a Custom libp2p Protocol Handler
1. Open `backend/main.go`.
2. Define your stream handler function:
   ```go
   func handleDiagnosticsStream(stream network.Stream) {
       defer stream.Close()
       logger.Printf("Diagnostics stream requested by: %s", stream.Conn().RemotePeer())
       info := fmt.Sprintf("NestLink Node: %s | Uptime: %s\n", nodeHost.ID(), time.Since(startTime))
       _, _ = stream.Write([]byte(info))
   }
   ```
3. Register the stream handler on the libp2p host:
   ```go
   nodeHost.SetStreamHandler("/nestlink/diagnostics/1.0.0", handleDiagnosticsStream)
   ```
4. Rebuild the backend:
   ```bash
   cd backend && go build -o main .
   ```

### How to Configure a Custom SSH Target Service
By default, NestLink forwards incoming tunnel connections to the local OpenSSH daemon at `127.0.0.1:22`. To forward connections to an alternative port (e.g. Docker container or testing daemon on port `2200`):
```bash
export NESTLINK_SSH_TARGET="127.0.0.1:2200"
./launcher.sh
```

### How to Add a New Allowed Node ID Format
1. Open `backend/main.go`.
2. Locate the regular expression definition:
   ```go
   validIDRegex = regexp.MustCompile(`^(/ip[46]/[^\s]+|0x[0-9A-Fa-f]{8,64}|12D3Koo[0-9A-Za-z]+|[0-9A-Za-z]{30,64})$`)
   ```
3. Append your new format pattern within the non-capturing group.
4. Run `cd backend && go test -v -run TestFinding4_1 .` to verify validation compliance.

---

## 5. Security-Hardened Architecture & Threat Defense Protocol

Following the static and dynamic architecture audit, NestLink implements defense-in-depth security across every operational layer:

### 5.1 Defense Against CSRF & Local Host Manipulation
- **Threat Vector**: Malicious websites open in the operator's browser executing background AJAX/fetch POST requests against `http://localhost:8080/api/connect` to force connections to untrusted nodes without consent.
- **Defensive Safeguards**:
  - `verifyOrigin()` checks `r.Host` against `localhost` and `127.0.0.1`, mitigating DNS rebinding attacks.
  - Validates `Origin` header to ensure it begins with `http://localhost:` or `http://127.0.0.1:`.
  - Enforces cryptographically random session CSRF tokens (`crypto/rand`) generated at boot and injected into the DOM.

### 5.2 Defense Against Process Hijacking & TOCTOU Collisions
- **Threat Vector**: Shutdown traps executing `fuser -k -n tcp "$PORT"` terminating unrelated system services if port collisions occur during shutdown.
- **Defensive Safeguards**:
  - Completely eliminated `fuser -k`.
  - Child processes are tracked strictly via explicit PIDs (`BACKEND_PID`, `DAEMON_PID`).
  - Cleanup functions dispatch targeted `SIGTERM` signals only to verified child processes.

### 5.3 Defense Against Symlink Attacks (CWE-377)
- **Threat Vector**: Attackers pre-creating symbolic links at predictable `/tmp` log paths to corrupt protected files during elevated execution.
- **Defensive Safeguards**:
  - Logs are restricted to user-scoped directories (`$HOME/.cache/nestlink`).
  - Directory is initialized with `mkdir -p -m 700` and `umask 077`.
  - `launcher.sh` executes `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"` before creating logs with `chmod 600`.

### 5.4 Defense Against Memory Exhaustion & Slowloris DoS
- **Threat Vector**: Unbounded POST request bodies (e.g. 10MB payloads) and dangling HTTP connections exhausting memory buffers and socket descriptors.
- **Defensive Safeguards**:
  - All mutating endpoints wrap `r.Body` with `http.MaxBytesReader(w, r.Body, 64*1024)`.
  - Custom `http.Server` enforces `ReadTimeout: 10s`, `WriteTimeout: 10s`, and `IdleTimeout: 30s`.

---

## 6. Audit Remediation Ledger & Bug Fix Summary

| Finding | Severity | Functional Domain | Root Cause | Solution & Verification |
| :--- | :--- | :--- | :--- | :--- |
| **1.1** | **CRITICAL** | Process Management | `fuser -k -n tcp "$PORT"` in cleanup trap killed arbitrary host services. | Removed `fuser`; track and terminate explicit `BACKEND_PID` and `DAEMON_PID`. Verified in `TestFinding1_1`. |
| **2.1** | **HIGH** | Authentication / CSRF | POST endpoints lacked Origin verification and CSRF token protection. | Implemented `verifyOrigin()` for Host/Origin and dynamic session CSRF tokens. Verified in `TestFinding2_1`. |
| **2.2** | **HIGH** | Cryptography / Identity | Local node ID hardcoded to static `0xABCD1234`, causing DHT collisions. | Replaced with dynamic Ed25519 keypair and libp2p `peer.ID`. Dynamic endpoint `/api/local-id`. Verified in `TestFinding2_2`. |
| **3.1** | **MEDIUM** | Privilege Management | `launcher.sh` executed unprompted `sudo apt-get install -y`. | Removed all automated package installations; require explicit manual operator action. Verified in `TestFinding3_1`. |
| **3.2** | **MEDIUM** | File System Security | Predictable log path in `/tmp` exposed to symlink hijacking (CWE-377). | Relocated logs to `$HOME/.cache/nestlink` with 700/600 permissions and symlink checks. Verified in `TestFinding3_2`. |
| **4.1** | **LOW** | Input Validation | `target_id` lacked character and length limits, allowing 10MB payloads. | Added `http.MaxBytesReader(64KB)`, regex filtering, and 8-128 character length checks. Verified in `TestFinding4_1`. |
| **4.2** | **LOW** | Denial of Service | Unbounded `http.ListenAndServe()` vulnerable to Slowloris attacks. | Instantiated custom `http.Server` with 10s read, 10s write, and 30s idle timeouts. Verified in `TestFinding4_2`. |

---

## 7. Maintenance & Operational Commands

```bash
# 1. Run full automated security and compliance unit test suite
cd backend && go test -v .

# 2. Compile standalone Go backend binary
cd backend && go build -o main .

# 3. Run Rust supervisor unit tests and compile release binary
cd daemon && cargo test && cargo build --release

# 4. Launch NestLink in development mode
./launcher.sh

# 5. Launch with custom port and custom SSH target
PORT=9090 NESTLINK_SSH_TARGET="127.0.0.1:2222" ./launcher.sh

# 6. View real-time security log streams
tail -f "$HOME/.cache/nestlink/nestlink_launcher.log"
```

---
*CyberNest Labs Internal Tools Group — Authorized Security Engineering Standard.*
