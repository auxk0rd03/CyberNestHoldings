# Project NestLink

[![Security: Hardened](https://img.shields.io/badge/Security-Hardened-6a9f6f.svg)](#security-architecture--hardening)
[![Network: libp2p](https://img.shields.io/badge/Network-libp2p%20DHT-5fa8a0.svg)](#network--tunneling-architecture)
[![UI: HTMX](https://img.shields.io/badge/Frontend-HTMX%20Local-eedba6.svg)](#user-interface--dashboard)

## Executive Overview
**NestLink** is an enterprise-grade, local-first secure shell (SSH) tunneling engine engineered to facilitate peer-to-peer (P2P) remote troubleshooting between internal CyberNest development nodes. NestLink explicitly bypasses centralized orchestration servers, cloud relays, and commercial VPNs by establishing direct, end-to-end encrypted cryptographic tunnels across distinct network boundaries using libp2p Kademlia Distributed Hash Table (DHT) discovery and automated Network Address Translation (NAT) hole punching.

The platform couples a high-performance **Go networking core** (`backend/main.go`), an ultra-lightweight **Rust lifecycle supervisor** (`daemon/src/main.rs`), and an unstyled, high-contrast **HTMX local dashboard** (`frontend/index.html`) to deliver instant, zero-configuration remote access with strict host isolation.

---

## Authorship & Maintenance
* **Organization:** CyberNest Labs / CyberNestHoldings LLC
* **Project Lead:** Auxk0rd (`auxk0rd@cybernestlabs.com`)
* **Target Platforms:** Linux (Pop!_OS / Ubuntu / Debian), Windows 10/11, macOS

---

## Network & Tunneling Architecture

NestLink eliminates central points of failure and third-party metadata collection:

1. **Cryptographic Node Identity:** Upon every initialization, NestLink generates a cryptographically secure, ephemeral Ed25519 keypair via `crypto/rand`. The resulting libp2p `peer.ID` (e.g. `12D3KooW...`) acts as the node's global, routable identity.
2. **DHT Peer Routing & Discovery:** Nodes announce their multiaddrs (e.g. `/ip4/<IP>/tcp/<PORT>/p2p/<PeerID>`) to a decentralized Kademlia DHT (`/nestlink/kad/1.0.0`). When connecting to a peer, the target ID is resolved without centralized directory lookups.
3. **NAT Traversal & Hole Punching:** Incorporates libp2p AutoNAT and DCUtR (Direct Connection Upgrade through Relay) hole punching protocols to establish direct bidirectional UDP/TCP sockets across firewalls and NAT perimeters.
4. **Multiplexed SSH Transport:** When a remote tunnel is established, a local TCP proxy listener binds to `127.0.0.1:2222`. Inbound SSH packets from standard terminal clients are multiplexed through the secure libp2p stream protocol `/nestlink/ssh/1.0.0`. On the target machine, inbound streams are proxied locally into the native host SSH daemon (`127.0.0.1:22` or custom `NESTLINK_SSH_TARGET`).

---

## Security Architecture & Hardening

Following a comprehensive static and dynamic security audit, NestLink implements defense-in-depth safeguards across all system boundaries:

* **Session CSRF Protection:** Cryptographically secure 16-byte random session tokens (`crypto/rand`) protect state-mutating endpoints (`/api/connect`, `/api/disconnect`). Cross-Site Request Forgery attacks from malicious websites open in the operator's browser are blocked.
* **Host & Origin Firewall:** Strict HTTP request validation ensures requests originate exclusively from the local loopback interface (`localhost` or `127.0.0.1`), preventing cross-origin abuse and DNS rebinding attacks.
* **Bounded Request Streams:** POST handlers enforce `http.MaxBytesReader` (capped at 64KB), dropping oversized or malformed payloads before memory allocation or form deserialization can occur.
* **Strict Parameter Sanitization:** Target Peer IDs and Multiaddrs undergo strict regex (`^(/ip[46]/[^\s]+|0x[0-9A-Fa-f]{8,64}|12D3Koo[0-9A-Za-z]+|[0-9A-Za-z]{30,64})$`) and length validation (`8 <= len <= 128`) prior to logging or state mutation, neutralizing log injection and memory bloat.
* **Slowloris & Connection Governance:** The local HTTP server configures explicit timeout thresholds (`ReadTimeout: 10s`, `WriteTimeout: 10s`, `IdleTimeout: 30s`) to prevent connection pool exhaustion.
* **Predictable File Path Hardening (CWE-377):** Log files are written strictly to user-scoped directories (`$HOME/.cache/nestlink/nestlink_launcher.log` on Linux, `%LOCALAPPDATA%\nestlink` on Windows) under `umask 077` and `chmod 600`. Symlinks are explicitly verified and removed before log initialization.
* **Strict Process PID Tracking:** Replaced all global process-killing commands (`fuser -k`) with direct PID tracking (`BACKEND_PID` and `DAEMON_PID`). Shutdown traps terminate only explicitly spawned child processes.
* **Privilege Demarcation:** Removed all automated `sudo` / `apt-get` package installations. Operators retain full sovereignty over system dependencies.
* **AES-256-GCM Enclave Identity & Keyring (`backend/compliance.go`):** Persists node Ed25519 keys inside an AES-256-GCM encrypted enclave (`$HOME/.cache/nestlink/identity.enc`, `0600`) backed by a 256-bit enclave master key (`master.key`).
* **120-Second Transactional Dead-Man's Switch:** Automatically rolls back and releases local tunnel bindings if an initiated tunnel mutation is not confirmed by an active SSH session within 120 seconds.
* **CWE-22 Multi-Stage Path Sanitization:** Both the Go backend (`SanitizeRelativePath` / `SafeResolveUnder`) and Rust supervisor (`sanitize_relative_path` / `safe_resolve_under`) enforce boundary-checked path resolution and reject symlinks and directory traversal.
* **FIPS 140-3, CMMC 2.0, DISA STIG & Threat Intelligence Telemetry:** Built-in compliance attestation and export endpoints (`/api/compliance/cmmc`, `/api/compliance/stig`, `/api/export/stix`, `/api/export/taxii`, `/api/network-sense`, `/api/sbom`) plus CycloneDX 1.5 and SPDX 2.3 Software Bills of Materials.

---

## Quick Start & Operational Instructions (`CN-DIR-2026-004` Bi-Launcher Specification)

NestLink implements **CyberNest Labs Architecture Specification // Standard 004 (`CN-DIR-2026-004`)**: the **Dual-Native Orchestration Architecture (Bi-Launcher Specification)** providing 1:1 behavioral parity across Pop!_OS / Linux (`dev.sh` / `launcher.sh`) and Windows 10/11 Pro & Enterprise (`dev.bat` / `launcher.bat`).

### Universal Command Parity Contract

| Subcommand | Linux / Pop!_OS (`./dev.sh` / `./launcher.sh`) | Windows 10/11 (`.\dev.bat` / `.\launcher.bat`) | Operational Behavior |
| :--- | :--- | :--- | :--- |
| `setup` | `./dev.sh setup` | `.\dev.bat setup` | Verifies Go, Cargo, and Python 3 runtimes and runtime path boundaries. |
| `build` | `./dev.sh build` | `.\dev.bat build` | Compiles Go backend (`bin/nestlink[.exe]`) & Rust supervisor (`bin/nestlink-daemon[.exe]`) + generates CISA SBOMs. |
| `run` / `serve` | `./dev.sh serve` | `.\dev.bat serve` | Launches local Nocturnal Synth-Ledger WebGUI on `http://127.0.0.1:8080` with `CWE-114` PID tracking. |
| `cli` | `./dev.sh cli` | `.\dev.bat cli` | Executes a single-sweep diagnostic & compliance audit and emits JSON report to stdout. |
| `simulate` | `./dev.sh simulate` | `.\dev.bat simulate` | Executes P2P SSH tunnel fault-injection & degradation simulation and exports offline report to `exports/`. |
| `test` | `./dev.sh test` | `.\dev.bat test` | Executes polyglot automated test suite (Go security tests, Rust daemon tests). |
| `fmt` | `./dev.sh fmt` | `.\dev.bat fmt` | Formats all Go (`go fmt ./...`) and Rust (`cargo fmt`) source code. |

### Quick Start Examples

**Linux / Pop!_OS:**
```bash
./dev.sh build        # Compiles native Go FIPS 140-3 backend and Rust supervisor
./dev.sh cli          # Single-sweep CLI diagnostic audit
./dev.sh simulate     # Automated fault-injection audit and offline export
./dev.sh test         # Automated security & unit test suite
./dev.sh serve        # Launches local WebGUI at http://127.0.0.1:8080
```

**Windows 10/11 (Command Prompt or PowerShell):**
```cmd
dev.bat build         :: Compiles bin\nestlink.exe and bin\nestlink-daemon.exe
dev.bat cli           :: Single-sweep CLI diagnostic audit
dev.bat simulate      :: Automated fault-injection audit and offline export
dev.bat test          :: Automated security & unit test suite
dev.bat serve         :: Launches local WebGUI at http://127.0.0.1:8080
```

**Windows:**
```cmd
launcher.bat
```

**Custom Port Override:**
```bash
PORT=9090 ./launcher.sh
```

Upon boot, the launcher allocates an available port for the WebGUI, initializes the Go networking core, starts the companion supervisor, and automatically opens `http://localhost:<PORT>` in the default browser.

---

### 2. Establishing a Remote Troubleshooting Session

Connecting two computers requires **no central accounts, no port forwarding, and no VPNs**:

```text
[Your Computer (Local)]                                     [Colleague's Computer (Target)]
        │                                                                  │
        │ 1. Start ./launcher.sh                                           │ 1. Start ./launcher.sh
        │ 2. View Dashboard                                                │ 2. Copies Local Peer ID:
        │                                                                  │    12D3KooWFExample...
        │ 3. Paste Target Peer ID ◄────────────────────────────────────────┤ (Shared via Signal/Slack)
        │ 4. Click [Connect]                                               │
        │                                                                  │
        │ 5. libp2p DHT Discovery & NAT Hole Punch                         │
        │    ◄════════════════════════════════════════════════════════════►│
        │                                                                  │
        │ 6. Outbound Proxy Active (127.0.0.1:2222)                        │ Inbound Stream Active
        │                                                                  │ (Proxied to 127.0.0.1:22)
        ▼                                                                  ▼
[Terminal: ssh user@localhost -p 2222] ══════════════════════════════► [Target Shell Session]
```

#### Step 1: Start NestLink on Both Machines
Both the engineer and the colleague must have NestLink running concurrently.

#### Step 2: Exchange Cryptographic Peer IDs
1. On the **Target Machine**, locate the **Machine ID** in the dashboard card (e.g. `12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN`).
2. Click **Copy** and send the identifier to the engineer via a secure internal channel.

#### Step 3: Initiate Connection from Your Machine
1. On **Your Machine**, open the NestLink dashboard.
2. Paste the target's Peer ID into the **Remote Machine ID** input field.
3. Click **Connect**.
4. The dashboard will transition to an active status confirmation displaying the connection banner and SSH syntax.

#### Step 4: Open Terminal SSH Session
Open a new terminal window on **Your Machine** and execute:
```bash
ssh <target_username>@localhost -p 2222
```
*(Replace `<target_username>` with the user account on the target system).*

Enter the remote machine's password or authenticate using SSH keys. You now have full interactive shell access over an encrypted, peer-to-peer transport.

#### Step 5: Terminating Session
Click **Disconnect** on the web dashboard or close `launcher.sh` (`Ctrl+C`). Local ports and sockets will be cleanly released.

---

## Environment Variables & Configuration

| Variable | Default | Description |
| :--- | :--- | :--- |
| `PORT` | `8080` (auto-incremented if busy) | HTTP port bound by the localized WebGUI. |
| `NESTLINK_SSH_TARGET` | `127.0.0.1:22` | Host SSH service target for inbound proxy streams. |
| `LOG_DIR` | `$HOME/.cache/nestlink` | Secure directory for application log streams. |

---

## Verification & Automated Test Suite

NestLink includes an automated unit, security, and compliance test suite validating all audit findings and CMMC/FIPS/CWE controls:

```bash
cd backend
go test -v .
```

To run Rust supervisor unit tests and end-to-end compilation checks:
```bash
# Build Go networking & compliance backend
cd backend && go build -o main .

# Test and build Rust supervisor daemon
cd ../daemon && cargo test && cargo build
```

---

## Repository Structure

```text
NestLink/
├── README.md                           # Operational manual & security documentation
├── NestLinkHandoff.md                  # Comprehensive technical architecture & developer manual
├── SBOM.md                             # CISA-compliant human-readable Software Bill of Materials
├── SBOM.cyclonedx.json                 # CycloneDX 1.5 JSON SBOM manifest
├── SBOM.spdx.json                      # SPDX 2.3 JSON SBOM manifest
├── launcher.sh                         # Hardened Linux/Pop!_OS 1-click launcher & lifecycle orchestrator
├── launcher.bat                        # Hardened Windows 1-click launcher
├── LICENSE                             # Project licensing terms
├── backend/
│   ├── go.mod                          # Go module dependencies (libp2p, DHT, crypto)
│   ├── go.sum                          # Cryptographic checksums for pinned Go packages
│   ├── main.go                         # Core libp2p P2P engine, SSH stream proxy, and HTTP server
│   ├── compliance.go                   # AES-256-GCM enclave, CWE-22 guard, 120s dead-man switch & CMMC/STIG/STIX/TAXII APIs
│   └── security_test.go                # Automated test suite for security audit & compliance controls
├── daemon/
│   ├── Cargo.toml                      # Rust package definition and dependencies
│   ├── Cargo.lock                      # Pinned Rust dependencies
│   └── src/
│       └── main.rs                     # Process supervisor, FIPS 140-3 KAT self-test, CWE-22 guard & browser launcher
├── frontend/
│   ├── index.html                      # HTMX dashboard with real-time status polling, telemetry & CSRF protection
│   ├── style.css                       # NestLink component stylesheet
│   └── synth-ledger.css                # Nocturnal Synth-Ledger design tokens & layout
└── Docs/
    ├── README.md                       # Supplemental internal operational notes
    ├── Technical_Overview.md           # System architecture overview
    ├── Technical_Overview.html         # Formatted architecture document
    ├── Technical_Overview.pdf          # Compiled PDF documentation
    └── Secure_P2P_Connection_Build_Process.png # High-resolution architecture workflow diagram
```

---
*CyberNest Labs — Internal Tools Group. Strictly Authorized Engineering Standard.*
