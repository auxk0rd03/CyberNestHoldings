package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"flag"
	"fmt"
	"html"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"regexp"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/libp2p/go-libp2p"
	dht "github.com/libp2p/go-libp2p-kad-dht"
	"github.com/libp2p/go-libp2p/core/crypto"
	"github.com/libp2p/go-libp2p/core/host"
	"github.com/libp2p/go-libp2p/core/network"
	"github.com/libp2p/go-libp2p/core/peer"
	"github.com/libp2p/go-libp2p/core/peerstore"
	"github.com/multiformats/go-multiaddr"
)

type NodeState struct {
	mu           sync.Mutex
	LocalID      string
	FullAddr     string
	ConnectedID  string
	TunnelActive bool
	TunnelPort   string
	CSRFToken    string
	listener     net.Listener
	activeCancel context.CancelFunc
}

var (
	validIDRegex = regexp.MustCompile(`^(/ip[46]/[^\s]+|0x[0-9A-Fa-f]{8,64}|12D3Koo[0-9A-Za-z]+|[0-9A-Za-z]{30,64})$`)
	nodeHost     host.Host
	kadDHT       *dht.IpfsDHT
	appCtx       context.Context
	logger       *log.Logger
)

func generateRandomHex(bytesCount int) string {
	b := make([]byte, bytesCount)
	if _, err := rand.Read(b); err != nil {
		return fmt.Sprintf("0x%X", time.Now().UnixNano())
	}
	return "0x" + hex.EncodeToString(b)
}

func verifyOrigin(r *http.Request) bool {
	host := r.Host
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	if host != "localhost" && host != "127.0.0.1" {
		return false
	}
	origin := r.Header.Get("Origin")
	if origin != "" && !strings.HasPrefix(origin, "http://localhost:") && !strings.HasPrefix(origin, "http://127.0.0.1:") {
		return false
	}
	return true
}


func handleSSHStream(stream network.Stream) {
	remote := stream.Conn().RemotePeer()
	logger.Printf("Inbound SSH proxy stream from peer: %s", remote)
	defer stream.Close()

	sshTarget := os.Getenv("NESTLINK_SSH_TARGET")
	if sshTarget == "" {
		sshTarget = "127.0.0.1:22"
	}

	localConn, err := net.DialTimeout("tcp", sshTarget, 3*time.Second)
	if err != nil {
		logger.Printf("Local SSH service unreachable at %s: %v", sshTarget, err)
		banner := fmt.Sprintf("SSH-2.0-NestLink_P2P_Tunnel_Established\r\n[NestLink] Tunnel operational to %s, but local SSH service (%s) is offline.\r\n", remote, sshTarget)
		_, _ = stream.Write([]byte(banner))
		return
	}
	defer localConn.Close()

	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		_, _ = io.Copy(localConn, stream)
		if tc, ok := localConn.(*net.TCPConn); ok {
			_ = tc.CloseWrite()
		}
	}()
	go func() {
		defer wg.Done()
		_, _ = io.Copy(stream, localConn)
		_ = stream.CloseWrite()
	}()
	wg.Wait()
}

func main() {
	port := flag.String("port", "8080", "Port to run the web GUI backend on")
	tunnelPort := flag.String("tunnel-port", "2222", "Local TCP port to bind the outgoing SSH tunnel proxy to")
	flag.Parse()

	logger = log.New(os.Stdout, "[NestLink-Backend] ", log.LstdFlags)

	var cancel context.CancelFunc
	appCtx, cancel = context.WithCancel(context.Background())
	defer cancel()

	// 1. Initialize libp2p node identity (AES-256-GCM persisted Ed25519 enclave) and networking
	priv, err := LoadOrGenerateIdentity()
	if err != nil {
		priv, _, err = crypto.GenerateEd25519Key(rand.Reader)
		if err != nil {
			logger.Fatalf("Failed to generate node identity: %v", err)
		}
	}

	nodeHost, err = libp2p.New(
		libp2p.Identity(priv),
		libp2p.ListenAddrStrings("/ip4/0.0.0.0/tcp/0"),
		libp2p.EnableRelay(),
		libp2p.EnableHolePunching(),
	)
	if err != nil {
		logger.Fatalf("Failed to instantiate libp2p host: %v", err)
	}

	localPeerID := nodeHost.ID().String()
	var fullAddr string
	for _, a := range nodeHost.Addrs() {
		if strings.Contains(a.String(), "127.0.0.1") {
			fullAddr = fmt.Sprintf("%s/p2p/%s", a.String(), localPeerID)
			break
		}
	}
	if fullAddr == "" && len(nodeHost.Addrs()) > 0 {
		fullAddr = fmt.Sprintf("%s/p2p/%s", nodeHost.Addrs()[0].String(), localPeerID)
	}

	logger.Printf("Node initialized. Peer Identity: %s", localPeerID)
	if fullAddr != "" {
		logger.Printf("Local Multiaddr: %s", fullAddr)
	}

	nodeHost.SetStreamHandler("/nestlink/ssh/1.0.0", handleSSHStream)

	kadDHT, err = dht.New(appCtx, nodeHost, dht.Mode(dht.ModeServer))
	if err != nil {
		logger.Fatalf("DHT instantiation failed: %v", err)
	}
	if err := kadDHT.Bootstrap(appCtx); err != nil {
		logger.Printf("DHT bootstrap warning: %v", err)
	}

	state := &NodeState{
		LocalID:      localPeerID,
		FullAddr:     fullAddr,
		ConnectedID:  "",
		TunnelActive: false,
		TunnelPort:   *tunnelPort,
		CSRFToken:    generateRandomHex(16),
	}

	mux := http.NewServeMux()

	mux.Handle("/", http.FileServer(http.Dir("../frontend")))

	mux.HandleFunc("/api/local-id", func(w http.ResponseWriter, r *http.Request) {
		state.mu.Lock()
		defer state.mu.Unlock()
		w.Header().Set("Content-Type", "text/plain")
		if r.URL.Query().Get("full") == "1" && state.FullAddr != "" {
			fmt.Fprint(w, state.FullAddr)
		} else {
			fmt.Fprint(w, state.LocalID)
		}
	})

	mux.HandleFunc("/api/csrf", func(w http.ResponseWriter, r *http.Request) {
		if !verifyOrigin(r) {
			http.Error(w, "Forbidden Origin", http.StatusForbidden)
			return
		}
		state.mu.Lock()
		defer state.mu.Unlock()
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprintf(w, `<input type="hidden" name="csrf_token" value="%s">`, html.EscapeString(state.CSRFToken))
	})

	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		state.mu.Lock()
		defer state.mu.Unlock()

		w.Header().Set("Content-Type", "text/html")
		if state.TunnelActive && state.ConnectedID != "" {
			fmt.Fprintf(w, `<div class="status-indicator active">
				<span class="status-dot green"></span>
				<span>Tunnel active to peer <strong>%s</strong> on port %s</span>
			</div>`, html.EscapeString(state.ConnectedID), html.EscapeString(state.TunnelPort))
		} else {
			displayID := state.LocalID
			if len(displayID) > 12 {
				displayID = displayID[:12] + "..."
			}
			fmt.Fprintf(w, `<div class="status-indicator idle">
				<span class="status-dot yellow"></span>
				<span>Node ready (Peer: %s)</span>
			</div>`, html.EscapeString(displayID))
		}
	})

	mux.HandleFunc("/api/connect", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}

		if !verifyOrigin(r) {
			http.Error(w, "Forbidden Origin", http.StatusForbidden)
			return
		}

		// Enforce maximum body size to drop oversized/malicious payloads before processing
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)

		if err := r.ParseForm(); err != nil {
			w.Header().Set("Content-Type", "text/html")
			w.WriteHeader(http.StatusBadRequest)
			fmt.Fprintf(w, `<div class="alert alert-error">Failed to read form submission: payload exceeds limits or is malformed.</div>`)
			return
		}

		state.mu.Lock()
		expectedCSRF := state.CSRFToken
		localID := state.LocalID
		tPort := state.TunnelPort
		state.mu.Unlock()

		w.Header().Set("Content-Type", "text/html")

		if r.FormValue("csrf_token") != expectedCSRF {
			w.WriteHeader(http.StatusForbidden)
			fmt.Fprintf(w, `<div class="alert alert-error">
				<div class="alert-title">Security Violation</div>
				<p>Invalid or missing CSRF token. Request rejected.</p>
			</div>`)
			return
		}

		targetID := strings.TrimSpace(r.FormValue("target_id"))

		// Enforce strict length bounds and character set validation before logging or state mutation
		if len(targetID) < 8 || len(targetID) > 128 || !validIDRegex.MatchString(targetID) {
			w.WriteHeader(http.StatusBadRequest)
			fmt.Fprintf(w, `<div class="alert alert-error">
				<div class="alert-title">Invalid Target ID</div>
				<p>Remote Machine ID must be a valid Peer ID, Multiaddr, or hexadecimal string between 8 and 128 characters.</p>
			</div>`)
			return
		}

		logger.Printf("Connect requested for validated target ID: '%s'", targetID)

		if strings.EqualFold(targetID, localID) {
			fmt.Fprintf(w, `<div class="alert alert-warning">
				<div class="alert-title">Cannot Connect to Self</div>
				<p>The target ID you entered belongs to this local machine. Please enter a remote peer ID.</p>
			</div>`)
			return
		}

		// Decode or parse Target Peer ID / Multiaddr
		var targetPID peer.ID
		if strings.HasPrefix(targetID, "/") {
			maddr, err := multiaddr.NewMultiaddr(targetID)
			if err != nil {
				fmt.Fprintf(w, `<div class="alert alert-error">Invalid Multiaddr format: %v</div>`, err)
				return
			}
			info, err := peer.AddrInfoFromP2pAddr(maddr)
			if err != nil {
				fmt.Fprintf(w, `<div class="alert alert-error">Could not parse peer info from Multiaddr: %v</div>`, err)
				return
			}
			targetPID = info.ID
			nodeHost.Peerstore().AddAddrs(info.ID, info.Addrs, peerstore.PermanentAddrTTL)
			go func() {
				_ = nodeHost.Connect(appCtx, *info)
			}()
		} else {
			var err error
			targetPID, err = peer.Decode(targetID)
			if err != nil {
				logger.Printf("Could not directly decode '%s' as Peer ID; attempting DHT lookup: %v", targetID, err)
			}
		}

		// Start local TCP tunnel listener
		listener, err := net.Listen("tcp", "127.0.0.1:"+tPort)
		if err != nil {
			fmt.Fprintf(w, `<div class="alert alert-error">
				<div class="alert-title">Port Binding Error</div>
				<p>Failed to bind local tunnel port %s: %v. Please ensure port %s is free.</p>
			</div>`, html.EscapeString(tPort), err, html.EscapeString(tPort))
			return
		}

		tunnelCtx, tunnelCancel := context.WithCancel(appCtx)

		state.mu.Lock()
		if state.listener != nil {
			_ = state.listener.Close()
		}
		if state.activeCancel != nil {
			state.activeCancel()
		}
		state.ConnectedID = targetID
		state.TunnelActive = true
		state.listener = listener
		state.activeCancel = tunnelCancel
		state.mu.Unlock()

		StartDeadManSwitch120s(func() {
			state.mu.Lock()
			defer state.mu.Unlock()
			if state.TunnelActive && state.ConnectedID == targetID {
				if state.listener != nil {
					_ = state.listener.Close()
					state.listener = nil
				}
				if state.activeCancel != nil {
					state.activeCancel()
					state.activeCancel = nil
				}
				state.ConnectedID = ""
				state.TunnelActive = false
				logger.Printf("Dead-Man's Switch (120s) triggered: unconfirmed tunnel to %s rolled back.", targetID)
			}
		})

		// Background worker accepting local SSH client connections on 127.0.0.1:2222
		go func(l net.Listener, target peer.ID, ctx context.Context) {
			defer l.Close()
			for {
				clientConn, err := l.Accept()
				if err != nil {
					select {
					case <-ctx.Done():
						return
					default:
						logger.Printf("Tunnel listener closed: %v", err)
						return
					}
				}
				ConfirmDeadManSwitch()

				go func(c net.Conn) {
					defer c.Close()
					logger.Printf("New local SSH client attached. Routing stream to %s...", target)
					streamCtx, sCancel := context.WithTimeout(ctx, 10*time.Second)
					defer sCancel()

					// Attempt to open P2P stream
					stream, err := nodeHost.NewStream(streamCtx, target, "/nestlink/ssh/1.0.0")
					if err != nil {
						logger.Printf("Failed to open P2P tunnel stream to %s: %v", target, err)
						msg := fmt.Sprintf("SSH-2.0-NestLink_Tunnel_Error\r\n[NestLink] Failed to establish P2P stream to %s: %v\r\n", target, err)
						_, _ = c.Write([]byte(msg))
						return
					}
					defer stream.Close()

					var wg sync.WaitGroup
					wg.Add(2)
					go func() {
						defer wg.Done()
						_, _ = io.Copy(stream, c)
						_ = stream.CloseWrite()
					}()
					go func() {
						defer wg.Done()
						_, _ = io.Copy(c, stream)
						if tc, ok := c.(*net.TCPConn); ok {
							_ = tc.CloseWrite()
						}
					}()
					wg.Wait()
				}(clientConn)
			}
		}(listener, targetPID, tunnelCtx)

		// Asynchronously resolve and connect in background
		go func(pid peer.ID) {
			if pid != "" {
				dhtCtx, dCancel := context.WithTimeout(appCtx, 15*time.Second)
				defer dCancel()
				if peerInfo, err := kadDHT.FindPeer(dhtCtx, pid); err == nil {
					_ = nodeHost.Connect(dhtCtx, peerInfo)
				}
			}
		}(targetPID)

		logger.Printf("P2P SSH proxy listener bound on 127.0.0.1:%s for peer %s", tPort, targetID)

		fmt.Fprintf(w, `<div class="alert alert-success fade-in">
			<div class="alert-title">Connected Successfully</div>
			<p>Direct secure P2P tunnel established with remote peer <strong>%s</strong>.</p>
			<div class="cmd-snippet">
				<span class="cmd-label">Run this SSH command in your terminal:</span>
				<code>ssh username@localhost -p %s</code>
			</div>
			<form hx-post="/api/disconnect" hx-target="#connection-response">
				<input type="hidden" name="csrf_token" value="%s">
				<button type="submit" class="btn btn-secondary btn-sm mt-3">Disconnect</button>
			</form>
		</div>`, html.EscapeString(targetID), html.EscapeString(tPort), html.EscapeString(expectedCSRF))
	})

	mux.HandleFunc("/api/disconnect", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}

		if !verifyOrigin(r) {
			http.Error(w, "Forbidden Origin", http.StatusForbidden)
			return
		}

		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)

		if err := r.ParseForm(); err != nil {
			w.Header().Set("Content-Type", "text/html")
			w.WriteHeader(http.StatusBadRequest)
			fmt.Fprintf(w, `<div class="alert alert-error">Failed to read form submission.</div>`)
			return
		}

		state.mu.Lock()
		expectedCSRF := state.CSRFToken
		if r.FormValue("csrf_token") != expectedCSRF {
			state.mu.Unlock()
			w.Header().Set("Content-Type", "text/html")
			w.WriteHeader(http.StatusForbidden)
			fmt.Fprintf(w, `<div class="alert alert-error">Security Violation: Invalid CSRF token.</div>`)
			return
		}

		prevID := state.ConnectedID
		tPort := state.TunnelPort
		if state.listener != nil {
			_ = state.listener.Close()
			state.listener = nil
		}
		if state.activeCancel != nil {
			state.activeCancel()
			state.activeCancel = nil
		}
		state.ConnectedID = ""
		state.TunnelActive = false
		state.mu.Unlock()
		ConfirmDeadManSwitch()

		logger.Printf("Disconnected session with %s. Port %s released.", prevID, tPort)
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprintf(w, `<div class="alert alert-neutral fade-in">
			<div class="alert-title">Disconnected</div>
			<p>The peer connection was closed and local port %s has been released.</p>
		</div>`, html.EscapeString(tPort))
	})

	registerComplianceRoutes(mux, state)

	srv := &http.Server{
		Addr:         "127.0.0.1:" + *port,
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  30 * time.Second,
	}

	go func() {
		logger.Printf("Backend starting on port %s", *port)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatalf("Server error: %v", err)
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	state.mu.Lock()
	if state.listener != nil {
		_ = state.listener.Close()
	}
	state.mu.Unlock()

	_ = srv.Shutdown(appCtx)
	_ = nodeHost.Close()
}
