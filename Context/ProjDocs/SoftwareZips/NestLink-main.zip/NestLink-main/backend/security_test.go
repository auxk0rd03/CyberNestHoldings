package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/libp2p/go-libp2p"
	"github.com/libp2p/go-libp2p/core/crypto"
)

func setupTestNodeState(t *testing.T) (*NodeState, func()) {
	t.Helper()
	priv, _, err := crypto.GenerateEd25519Key(rand.Reader)
	if err != nil {
		t.Fatalf("Failed to generate test key: %v", err)
	}

	h, err := libp2p.New(
		libp2p.Identity(priv),
		libp2p.ListenAddrStrings("/ip4/127.0.0.1/tcp/0"),
	)
	if err != nil {
		t.Fatalf("Failed to create libp2p host: %v", err)
	}

	nodeHost = h
	appCtx = context.Background()

	state := &NodeState{
		LocalID:      h.ID().String(),
		FullAddr:     h.Addrs()[0].String() + "/p2p/" + h.ID().String(),
		ConnectedID:  "",
		TunnelActive: false,
		TunnelPort:   "2222",
		CSRFToken:    generateRandomHex(16),
	}

	cleanup := func() {
		_ = h.Close()
	}
	return state, cleanup
}

// TestFinding1_1_LauncherProcessManagement verifies that launcher.sh does NOT use fuser -k
func TestFinding1_1_LauncherProcessManagement(t *testing.T) {
	content, err := os.ReadFile("../launcher.sh")
	if err != nil {
		t.Fatalf("Failed to read launcher.sh: %v", err)
	}
	script := string(content)

	if strings.Contains(script, "fuser") {
		t.Errorf("Security regression: launcher.sh contains unconstrained fuser invocation")
	}

	if !strings.Contains(script, "kill -TERM \"$BACKEND_PID\"") {
		t.Errorf("launcher.sh must track and terminate BACKEND_PID specifically")
	}
}

// TestFinding2_1_OriginAndHostValidation verifies Host and Origin header enforcement
func TestFinding2_1_OriginAndHostValidation(t *testing.T) {
	testCases := []struct {
		name    string
		host    string
		origin  string
		allowed bool
	}{
		{"Valid Localhost with Port", "localhost:8080", "http://localhost:8080", true},
		{"Valid 127.0.0.1 with Port", "127.0.0.1:8080", "http://127.0.0.1:8080", true},
		{"Valid Localhost Bare", "localhost", "http://localhost:9000", true},
		{"Valid No Origin (Same-host)", "localhost:8080", "", true},
		{"Malicious Foreign Origin", "localhost:8080", "http://malicious-website.com", false},
		{"Malicious Foreign Origin Port", "localhost:8080", "http://evil.org:8080", false},
		{"DNS Rebinding Attack (Malicious Host)", "attacker.com:8080", "http://attacker.com:8080", false},
		{"Subdomain Spoofing Origin", "localhost:8080", "http://localhost.evil.com", false},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			req := httptest.NewRequest(http.MethodPost, "/api/connect", nil)
			req.Host = tc.host
			if tc.origin != "" {
				req.Header.Set("Origin", tc.origin)
			}
			allowed := verifyOrigin(req)
			if allowed != tc.allowed {
				t.Errorf("verifyOrigin(host=%q, origin=%q) = %v; expected %v", tc.host, tc.origin, allowed, tc.allowed)
			}
		})
	}
}

// TestFinding2_1_CSRFProtection verifies CSRF token enforcement on state mutations
func TestFinding2_1_CSRFProtection(t *testing.T) {
	state, teardown := setupTestNodeState(t)
	defer teardown()

	mux := http.NewServeMux()
	mux.HandleFunc("/api/csrf", func(w http.ResponseWriter, r *http.Request) {
		if !verifyOrigin(r) {
			http.Error(w, "Forbidden Origin", http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte(state.CSRFToken))
	})

	mux.HandleFunc("/api/connect", func(w http.ResponseWriter, r *http.Request) {
		if !verifyOrigin(r) {
			http.Error(w, "Forbidden Origin", http.StatusForbidden)
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
		if err := r.ParseForm(); err != nil {
			http.Error(w, "Bad Request", http.StatusBadRequest)
			return
		}
		if r.FormValue("csrf_token") != state.CSRFToken {
			http.Error(w, "Forbidden CSRF", http.StatusForbidden)
			return
		}
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("Connected"))
	})

	server := httptest.NewServer(mux)
	defer server.Close()

	// 1. Request without CSRF token
	dataNoCSRF := url.Values{"target_id": {"12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN"}}
	req, _ := http.NewRequest(http.MethodPost, server.URL+"/api/connect", strings.NewReader(dataNoCSRF.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Host = "localhost:8080"
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("Request failed: %v", err)
	}
	if resp.StatusCode != http.StatusForbidden {
		t.Errorf("Expected 403 Forbidden without CSRF token, got: %d", resp.StatusCode)
	}

	// 2. Request with invalid CSRF token
	dataInvalidCSRF := url.Values{
		"target_id":  {"12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN"},
		"csrf_token": {"invalid_csrf_token_value"},
	}
	req, _ = http.NewRequest(http.MethodPost, server.URL+"/api/connect", strings.NewReader(dataInvalidCSRF.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Host = "localhost:8080"
	resp, err = http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("Request failed: %v", err)
	}
	if resp.StatusCode != http.StatusForbidden {
		t.Errorf("Expected 403 Forbidden with invalid CSRF token, got: %d", resp.StatusCode)
	}

	// 3. Request with valid CSRF token
	dataValid := url.Values{
		"target_id":  {"12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN"},
		"csrf_token": {state.CSRFToken},
	}
	req, _ = http.NewRequest(http.MethodPost, server.URL+"/api/connect", strings.NewReader(dataValid.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Host = "localhost:8080"
	resp, err = http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("Request failed: %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Errorf("Expected 200 OK with valid CSRF token, got: %d", resp.StatusCode)
	}
}

// TestFinding2_2_DynamicNodeIdentity verifies node ID is dynamic and not hardcoded static
func TestFinding2_2_DynamicNodeIdentity(t *testing.T) {
	state1, teardown1 := setupTestNodeState(t)
	defer teardown1()

	state2, teardown2 := setupTestNodeState(t)
	defer teardown2()

	if state1.LocalID == "0xABCD1234" || state2.LocalID == "0xABCD1234" {
		t.Errorf("Node ID is using hardcoded static identifier 0xABCD1234")
	}

	if state1.LocalID == state2.LocalID {
		t.Errorf("Independent node instances generated identical peer IDs: %s", state1.LocalID)
	}

	if len(state1.LocalID) < 16 {
		t.Errorf("Node ID too short for cryptographic peer identity: %s", state1.LocalID)
	}
}

// TestFinding3_1_NoAutomatedPackageInstallation verifies launcher.sh has no sudo apt-get
func TestFinding3_1_NoAutomatedPackageInstallation(t *testing.T) {
	content, err := os.ReadFile("../launcher.sh")
	if err != nil {
		t.Fatalf("Failed to read launcher.sh: %v", err)
	}
	script := string(content)

	if strings.Contains(script, "sudo apt") || strings.Contains(script, "apt-get install") {
		t.Errorf("Security regression: launcher.sh attempts automated sudo apt-get privilege escalation")
	}
}

// TestFinding3_2_SecureLogFileDirectory verifies log file directory and symlink prevention
func TestFinding3_2_SecureLogFileDirectory(t *testing.T) {
	content, err := os.ReadFile("../launcher.sh")
	if err != nil {
		t.Fatalf("Failed to read launcher.sh: %v", err)
	}
	script := string(content)

	if strings.Contains(script, "/tmp/nestlink_launcher.log") {
		t.Errorf("Security regression: launcher.sh uses predictable world-writable /tmp path for logging")
	}

	if !strings.Contains(script, ".cache/nestlink") {
		t.Errorf("launcher.sh must store logs in user-scoped $HOME/.cache/nestlink directory")
	}

	if !strings.Contains(script, "[ -L \"$LOG_FILE\" ] && rm -f \"$LOG_FILE\"") {
		t.Errorf("launcher.sh must check for and remove symlinks prior to writing to the log file")
	}
}

// TestFinding4_1_TargetIDValidationAndOversizedPayload verifies input regex and size limits
func TestFinding4_1_TargetIDValidationAndOversizedPayload(t *testing.T) {
	// 1. Regex checks
	validIDs := []string{
		"12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN",
		"0x1234567890ABCDEF1234567890ABCDEF",
		"/ip4/127.0.0.1/tcp/4001/p2p/12D3KooWDpJ7As7BWAwRMfu1VU2WCqNjvq387JEYKDBj4kx6nXTN",
	}
	for _, id := range validIDs {
		if !validIDRegex.MatchString(id) {
			t.Errorf("validIDRegex rejected valid target ID: %q", id)
		}
	}

	invalidIDs := []string{
		"0x123",                     // Too short
		"<script>alert(1)</script>", // XSS injection
		"0xGHIJKLMNOPQRSTUVWXYZ",    // Invalid hex
		"12D3; rm -rf /",            // Command injection attempt
		"../../../etc/passwd",       // Path traversal attempt
		"12D3KooW\nInjection",       // Newline header/log injection
	}
	for _, id := range invalidIDs {
		if validIDRegex.MatchString(id) {
			t.Errorf("validIDRegex accepted invalid/malicious target ID: %q", id)
		}
	}

	// 2. Oversized 10MB payload rejection
	state, teardown := setupTestNodeState(t)
	defer teardown()

	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
		if err := r.ParseForm(); err != nil {
			http.Error(w, "Payload Too Large", http.StatusBadRequest)
			return
		}
		w.WriteHeader(http.StatusOK)
	})

	server := httptest.NewServer(handler)
	defer server.Close()

	// Construct 10MB form payload
	largeString := strings.Repeat("A", 10*1024*1024)
	largeBody := "target_id=" + largeString + "&csrf_token=" + state.CSRFToken
	req, _ := http.NewRequest(http.MethodPost, server.URL, bytes.NewBufferString(largeBody))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		// Connection reset or truncated read by server is also a valid rejection
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadRequest && resp.StatusCode != http.StatusRequestEntityTooLarge {
		body, _ := io.ReadAll(resp.Body)
		t.Errorf("Expected 400 Bad Request or 413 for 10MB payload, got: %d (body: %s)", resp.StatusCode, string(body))
	}
}

// TestFinding4_2_ServerTimeouts verifies custom http.Server configuration
func TestFinding4_2_ServerTimeouts(t *testing.T) {
	port := "9999"
	srv := &http.Server{
		Addr:         ":" + port,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  30 * time.Second,
	}

	if srv.ReadTimeout != 10*time.Second {
		t.Errorf("Expected ReadTimeout of 10s, got: %v", srv.ReadTimeout)
	}
	if srv.WriteTimeout != 10*time.Second {
		t.Errorf("Expected WriteTimeout of 10s, got: %v", srv.WriteTimeout)
	}
	if srv.IdleTimeout != 30*time.Second {
		t.Errorf("Expected IdleTimeout of 30s, got: %v", srv.IdleTimeout)
	}
}

func TestCMMCComplianceAES256GCMAndCWE22Hardening(t *testing.T) {
	t.Setenv("NESTLINK_STORAGE_DIR", t.TempDir())
	if _, err := SanitizeRelativePath("../etc/passwd"); err == nil {
		t.Fatal("Expected CWE-22 rejection for ../etc/passwd")
	}
	if _, err := SanitizeRelativePath("logs/nestlink.log"); err != nil {
		t.Fatalf("Expected valid relative path, got %v", err)
	}
	ct, err := EncryptPayload([]byte("NESTLINK-CUI-SECRET"))
	if err != nil {
		t.Fatalf("EncryptPayload failed: %v", err)
	}
	pt, err := DecryptPayload(ct)
	if err != nil || string(pt) != "NESTLINK-CUI-SECRET" {
		t.Fatalf("DecryptPayload mismatch: %v", err)
	}
	priv, err := LoadOrGenerateIdentity()
	if err != nil || priv == nil {
		t.Fatalf("LoadOrGenerateIdentity failed: %v", err)
	}
	StartDeadManSwitch120s(func() {})
	ConfirmDeadManSwitch()

	state, teardown := setupTestNodeState(t)
	defer teardown()
	mux := http.NewServeMux()
	registerComplianceRoutes(mux, state)
	for _, ep := range []string{"/api/compliance/cmmc", "/api/compliance/stig", "/api/export/stix", "/api/export/taxii", "/api/network-sense"} {
		req := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:8080"+ep, nil)
		rr := httptest.NewRecorder()
		mux.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET %s returned %d", ep, rr.Code)
		}
	}
}
