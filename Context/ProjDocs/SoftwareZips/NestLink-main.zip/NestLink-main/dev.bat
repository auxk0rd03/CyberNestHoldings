@echo off
rem ==============================================================================
rem CyberNest Labs // NestLink Dual-Native Orchestration Launcher (Windows 10/11)
rem Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
rem Security: CMMC 2.0 Level 2 / FIPS 140-3 / DISA STIG / CWE-22, 78, 114, 377
rem ==============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
set "SCRIPT_DIR=%~dp0"

rem --- User Cache Preservation Under Admin Elevation (CN-DIR-2026-004 Sec 3.2) ---
if "%USERPROFILE%"=="" set "USERPROFILE=%SystemDrive%\Users\%USERNAME%"
if "%LOCALAPPDATA%"=="" set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
if "%CARGO_HOME%"=="" set "CARGO_HOME=%USERPROFILE%\.cargo"
if "%RUSTUP_HOME%"=="" set "RUSTUP_HOME=%USERPROFILE%\.rustup"
if "%GOPATH%"=="" set "GOPATH=%USERPROFILE%\go"
if "%GOMODCACHE%"=="" set "GOMODCACHE=%GOPATH%\pkg\mod"
if "%GOCACHE%"=="" set "GOCACHE=%LOCALAPPDATA%\go-build"
set "PATH=%CARGO_HOME%\bin;%GOPATH%\bin;%PATH%"

set "GOFIPS=1"
set "GODEBUG=fips140=on"

rem --- Hardened Session Logging & Symlink/Reparse-Point Guard (CWE-377) ---
set "LOG_DIR=%LOCALAPPDATA%\nestlink"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
icacls "%LOG_DIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1
set "LOG_FILE=%LOG_DIR%\session.log"
if exist "%LOG_FILE%" (
    fsutil reparsepoint query "%LOG_FILE%" >nul 2>&1
    if !ERRORLEVEL! equ 0 (
        del /f /q "%LOG_FILE%" >nul 2>&1
    )
)
type nul >> "%LOG_FILE%"
icacls "%LOG_FILE%" /inheritance:r /grant:r "%USERNAME%:F" >nul 2>&1

set "SUBCMD=%~1"
if "%SUBCMD%"=="" set "SUBCMD=run"

if /I "%SUBCMD%"=="setup" goto :cmd_setup
if /I "%SUBCMD%"=="build" goto :cmd_build
if /I "%SUBCMD%"=="run" goto :cmd_run
if /I "%SUBCMD%"=="serve" goto :cmd_run
if /I "%SUBCMD%"=="cli" goto :cmd_cli
if /I "%SUBCMD%"=="--cli" goto :cmd_cli
if /I "%SUBCMD%"=="simulate" goto :cmd_simulate
if /I "%SUBCMD%"=="--simulate" goto :cmd_simulate
if /I "%SUBCMD%"=="test" goto :cmd_test
if /I "%SUBCMD%"=="fmt" goto :cmd_fmt

echo Usage: dev.bat {setup^|build^|run^|serve^|cli^|simulate^|test^|fmt}
exit /b 1

:cmd_setup
echo ==> [NestLink] Verifying polyglot toolchains...
where go >nul 2>&1 || (echo [ERROR] Go compiler missing from PATH. && exit /b 1)
where cargo >nul 2>&1 || (echo [WARN] Rust/Cargo missing from PATH. Pure-Go operations active.)
where python >nul 2>&1 || (echo [WARN] Python interpreter not detected.)
go version
cargo --version 2>nul
python --version 2>nul
echo [+] Toolchain prerequisites verified.
exit /b 0

:cmd_build
echo ==> [NestLink] Building Go FIPS 140-3 backend and Rust supervisor...
if not exist "bin" mkdir "bin"
pushd backend
set GOFIPS=1
set GODEBUG=fips140=on
go build -ldflags="-s -w" -o ..\bin\nestlink.exe .
if !ERRORLEVEL! neq 0 (popd & echo [!] Go compilation failed. & exit /b !ERRORLEVEL!)
copy /y ..\bin\nestlink.exe main.exe >nul 2>&1
popd
echo [+] Go backend compiled -> bin\nestlink.exe

if exist "daemon\Cargo.toml" (
    pushd daemon
    cargo build --release --quiet 2>nul || cargo build --release
    if exist "target\release\nestlink-daemon.exe" (
        copy /y target\release\nestlink-daemon.exe ..\bin\nestlink-daemon.exe >nul
        echo [+] Rust supervisor compiled -> bin\nestlink-daemon.exe
    )
    popd
)

if exist "..\NestSBOM\sbom_cli.py" (
    python ..\NestSBOM\sbom_cli.py --repo . --out-dir . >nul 2>&1
    echo [+] Generated CycloneDX 1.5, SPDX 2.3, and CISA SBOMs.
)
exit /b 0

:cmd_run
if not exist "bin\nestlink.exe" (
    call :cmd_build
    if !ERRORLEVEL! neq 0 exit /b !ERRORLEVEL!
)

set "PORT=8080"
netstat -ano | findstr /R /C:":!PORT! .*LISTENING" >nul 2>&1
if !ERRORLEVEL! equ 0 (
    echo [WARN] Port !PORT! occupied. Allocating dynamic ephemeral port...
    for /f %%p in ('powershell -NoProfile -Command "$l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0); $l.Start(); $p = $l.LocalEndpoint.Port; $l.Stop(); Write-Output $p"') do (
        set "PORT=%%p"
    )
)

echo ==> Starting NestLink Web Server on http://127.0.0.1:!PORT! ...
start http://127.0.0.1:!PORT!
set "GOFIPS=1"
set "GODEBUG=fips140=on"
bin\nestlink.exe -port !PORT!
exit /b !ERRORLEVEL!

:cmd_cli
if not exist "bin\nestlink.exe" (
    call :cmd_build
    if !ERRORLEVEL! neq 0 exit /b !ERRORLEVEL!
)
set "GOFIPS=1"
set "GODEBUG=fips140=on"
bin\nestlink.exe -cli
exit /b !ERRORLEVEL!

:cmd_simulate
if not exist "bin\nestlink.exe" (
    call :cmd_build
    if !ERRORLEVEL! neq 0 exit /b !ERRORLEVEL!
)
set "GOFIPS=1"
set "GODEBUG=fips140=on"
bin\nestlink.exe -simulate -export
exit /b !ERRORLEVEL!

:cmd_test
echo ==> Running Go unit and compliance tests...
pushd backend
set "GOFIPS=1"
set "GODEBUG=fips140=on"
go test -v ./...
if !ERRORLEVEL! neq 0 (popd & exit /b !ERRORLEVEL!)
popd

if exist "daemon\Cargo.toml" (
    echo ==> Running Rust supervisor tests...
    pushd daemon
    cargo test
    if !ERRORLEVEL! neq 0 (popd & exit /b !ERRORLEVEL!)
    popd
)
echo [+] All test suites executed successfully.
exit /b 0

:cmd_fmt
echo ==> Formatting Go source code...
pushd backend
go fmt ./...
popd
if exist "daemon\Cargo.toml" (
    echo ==> Formatting Rust source code...
    pushd daemon
    cargo fmt
    popd
)
exit /b 0
