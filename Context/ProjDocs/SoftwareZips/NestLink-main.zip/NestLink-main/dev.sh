#!/usr/bin/env bash
# ==============================================================================
# CyberNest Labs // NestLink Standardized POSIX Entrypoint (dev.sh)
# Delegates to launcher.sh per CN-DIR-2026-004 Bi-Launcher Specification
# ==============================================================================
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${ROOT_DIR}/launcher.sh" "$@"
