@echo off
setlocal enabledelayedexpansion

if "%PORT%"=="" set PORT=8080
set SCRIPT_DIR=%~dp0
set LOG_DIR=%LOCALAPPDATA%\nestlink
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c%%a%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a%%b)
set LOG_FILE=%LOG_DIR%\nestlink_launcher_%mydate%_%mytime%.log

echo [%DATE% %TIME%] [INFO] Starting NestLink launcher sequence... >> "%LOG_FILE%"
echo [%DATE% %TIME%] [INFO] Starting NestLink launcher sequence...

rem 1. Dependency checks
set BACKEND_DIR=%SCRIPT_DIR%backend
if not exist "%BACKEND_DIR%\main.exe" (
    where go >nul 2>nul
    if %ERRORLEVEL% neq 0 (
        echo [%DATE% %TIME%] [ERROR] Go compiler not found and pre-compiled binary missing. >> "%LOG_FILE%"
        echo [ERROR] Go is not installed and backend\main.exe is missing. Manual installation required.
        pause
        exit /b 1
    )
)
echo [%DATE% %TIME%] [INFO] Dependencies verified. >> "%LOG_FILE%"

rem 2. Check if port is available
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [%DATE% %TIME%] [WARN] Port %PORT% is occupied. Allocating dynamic port... >> "%LOG_FILE%"
    for /f %%p in ('powershell -NoProfile -Command "$l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0); $l.Start(); $p = $l.LocalEndpoint.Port; $l.Stop(); Write-Output $p"') do (
        set PORT=%%p
    )
    echo [%DATE% %TIME%] [INFO] Dynamically assigned port: !PORT! >> "%LOG_FILE%"
)

rem 3. Launch Backend
echo [%DATE% %TIME%] [INFO] Starting application on port !PORT!... >> "%LOG_FILE%"
echo [%DATE% %TIME%] [INFO] Starting application on port !PORT!...
pushd "%BACKEND_DIR%"
if exist "main.exe" (
    start "NestLink-Backend" /B main.exe -port !PORT! %* >> "%LOG_FILE%" 2>&1
) else (
    start "NestLink-Backend" /B go run . -port !PORT! %* >> "%LOG_FILE%" 2>&1
)
popd

rem 4. Readiness polling
echo [%DATE% %TIME%] [INFO] Waiting for backend readiness... >> "%LOG_FILE%"
set READY=0
for /l %%i in (1,1,30) do (
    timeout /t 1 /nobreak >nul
    powershell -NoProfile -Command "$client = New-Object System.Net.Sockets.TcpClient; try { $client.Connect('127.0.0.1', !PORT!); exit 0 } catch { exit 1 } finally { $client.Close() }" >nul 2>nul
    if !ERRORLEVEL! equ 0 (
        set READY=1
        goto :ready
    )
)

:ready
if !READY! equ 1 (
    echo [%DATE% %TIME%] [INFO] Backend is responsive. Launching web dashboard... >> "%LOG_FILE%"
    start http://localhost:!PORT!
) else (
    echo [%DATE% %TIME%] [WARN] Backend initialization delayed. Navigate manually to http://localhost:!PORT! >> "%LOG_FILE%"
)

echo [INFO] NestLink is operational. Keep this window open. Close window to terminate.
pause >nul
