@echo off
rem ==============================================================================
rem NestLink Root Unified Launcher - Windows
rem Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
rem ==============================================================================
call "%~dp0dev.bat" %*
exit /b %ERRORLEVEL%
