#!/bin/bash
# NestLink 1-Click Launcher - Linux / Pop!_OS
# Security: Strict mode & safe process management
set -euo pipefail
IFS=$'\n\t'

umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$HOME/.cache/nestlink"
mkdir -p -m 700 "$LOG_DIR"
LOG_FILE="$LOG_DIR/nestlink_launcher.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE" && chmod 600 "$LOG_FILE"

log() {
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] [INFO] $1" | tee -a "$LOG_FILE"
}

warn() {
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] [WARN] $1" | tee -a "$LOG_FILE"
}

error() {
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] [ERROR] $1" | tee -a "$LOG_FILE" >&2
}

log "Starting NestLink initialization sequence..."

check_deps() {
    local deps=("go" "python3")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null && [ ! -f "${SCRIPT_DIR}/backend/main" ]; then
            error "Required dependency '$dep' is not installed or not in PATH."
            exit 1
        else
            log "Dependency '$dep' verified."
        fi
    done
}

check_deps

PORT="${PORT:-8080}"
if (echo > /dev/tcp/127.0.0.1/"$PORT") 2>/dev/null; then
    warn "Target port $PORT is occupied. Allocating dynamic port..."
    PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("", 0)); print(s.getsockname()[1]); s.close()')
fi
log "Assigned WebGUI port: $PORT"

BACKEND_PID=""
DAEMON_PID=""

cleanup() {
    trap - EXIT INT TERM
    log "Cleanup initiated. Terminating NestLink background child processes..."
    if [ -n "$BACKEND_PID" ] && kill -0 "$BACKEND_PID" 2>/dev/null; then
        kill -TERM "$BACKEND_PID" 2>/dev/null || true
        for _ in {1..10}; do
            if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
                break
            fi
            sleep 0.1
        done
        kill -KILL "$BACKEND_PID" 2>/dev/null || true
    fi
    if [ -n "$DAEMON_PID" ] && kill -0 "$DAEMON_PID" 2>/dev/null; then
        kill -TERM "$DAEMON_PID" 2>/dev/null || true
    fi
    log "NestLink sequence terminated safely."
}
trap cleanup EXIT INT TERM

# System snapshot check
if command -v timeshift &> /dev/null; then
    log "Timeshift is available on this system."
else
    log "Timeshift not installed; proceeding with localized process boundaries."
fi

log "Starting Go Backend on port $PORT (GOFIPS=1)..."
cd "${SCRIPT_DIR}/backend"
export GOFIPS=1
export GODEBUG=fips140=on
if [ -f "./main" ]; then
    ./main -port "$PORT" >> "$LOG_FILE" 2>&1 &
    BACKEND_PID=$!
else
    go run . -port "$PORT" >> "$LOG_FILE" 2>&1 &
    BACKEND_PID=$!
fi

# If compiled daemon binary exists, start companion supervisor
if [ -f "${SCRIPT_DIR}/daemon/target/debug/nestlink-daemon" ]; then
    log "Starting NestLink companion daemon..."
    PORT="$PORT" "${SCRIPT_DIR}/daemon/target/debug/nestlink-daemon" >> "$LOG_FILE" 2>&1 &
    DAEMON_PID=$!
fi

# Readiness polling
log "Waiting for backend readiness on port $PORT..."
READY=0
for _ in {1..50}; do
    if (echo > /dev/tcp/127.0.0.1/"$PORT") 2>/dev/null; then
        READY=1
        break
    fi
    sleep 0.2
done

if [ "$READY" -eq 1 ]; then
    log "NestLink is operational at http://localhost:$PORT. Spawning WebGUI..."
    if command -v xdg-open &> /dev/null; then
        xdg-open "http://localhost:$PORT" >/dev/null 2>&1 || true
    elif command -v python3 &> /dev/null; then
        python3 -m webbrowser "http://localhost:$PORT" >/dev/null 2>&1 || true
    fi
else
    warn "Backend initialization delayed. Please navigate manually to http://localhost:$PORT"
fi

log "NestLink actively running. Press Ctrl+C to stop."
wait "$BACKEND_PID"
