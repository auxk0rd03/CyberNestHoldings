#!/usr/bin/env bash
# ==============================================================================
# CyberNest Labs // NestLink Dual-Native Orchestration Launcher (Linux / Pop!_OS)
# Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
# Security: CMMC 2.0 Level 2 / FIPS 140-3 / DISA STIG / CWE-22, 78, 114, 377
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# --- Sudo User & Toolchain Cache Preservation (CN-DIR-2026-004 Section 3.2) ---
REAL_USER="${SUDO_USER:-${USER:-$(id -un)}}"
REAL_HOME="$(getent passwd "$REAL_USER" 2>/dev/null | cut -d: -f6 || echo "${HOME:-/tmp}")"
if [ -z "$REAL_HOME" ] || [ ! -d "$REAL_HOME" ]; then
    REAL_HOME="${HOME:-/tmp}"
fi
export CARGO_HOME="${CARGO_HOME:-$REAL_HOME/.cargo}"
export RUSTUP_HOME="${RUSTUP_HOME:-$REAL_HOME/.rustup}"
export GOPATH="${GOPATH:-$REAL_HOME/go}"
export GOMODCACHE="${GOMODCACHE:-$GOPATH/pkg/mod}"
export GOCACHE="${GOCACHE:-$REAL_HOME/.cache/go-build}"
export PATH="$CARGO_HOME/bin:$GOPATH/bin:/usr/local/go/bin:$PATH"

export GOFIPS=1
export GODEBUG=fips140=on

# --- Hardened Session Logging in user-scoped $HOME/.cache/nestlink (CWE-377 Defense) ---
LOG_DIR="$REAL_HOME/.cache/nestlink"
mkdir -p -m 700 "$LOG_DIR"
chmod 700 "$LOG_DIR" 2>/dev/null || true
LOG_FILE="$LOG_DIR/nestlink_launcher.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE" && chmod 600 "$LOG_FILE"

log() {
    echo "[$(date -u +'%Y-%m-%dT%H:%M:%SZ')] [INFO] [NestLink] $1" | tee -a "$LOG_FILE"
}

warn() {
    echo "[$(date -u +'%Y-%m-%dT%H:%M:%SZ')] [WARN] [NestLink] $1" | tee -a "$LOG_FILE"
}

error() {
    echo "[$(date -u +'%Y-%m-%dT%H:%M:%SZ')] [ERROR] [NestLink] $1" | tee -a "$LOG_FILE" >&2
}

BACKEND_PID=""
DAEMON_PID=""

cleanup() {
    trap - EXIT INT TERM
    if [ -n "$BACKEND_PID" ] && kill -0 "$BACKEND_PID" 2>/dev/null; then
        log "Terminating child backend daemon (PID: $BACKEND_PID)..."
        kill -TERM "$BACKEND_PID" 2>/dev/null || true
        for _ in {1..15}; do
            if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
                break
            fi
            sleep 0.1
        done
        kill -KILL "$BACKEND_PID" 2>/dev/null || true
    fi
    if [ -n "$DAEMON_PID" ] && kill -0 "$DAEMON_PID" 2>/dev/null; then
        kill -TERM "$DAEMON_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT INT TERM

check_toolchains() {
    log "Verifying NestLink Dual-Native toolchain prerequisites (CN-DIR-2026-004)..."
    for tool in go cargo python3; do
        if command -v "$tool" &>/dev/null; then
            log "Verified $tool -> $(command -v "$tool")"
        else
            warn "$tool not found in PATH."
        fi
    done
    go version 2>/dev/null || true
    cargo --version 2>/dev/null || true
    python3 --version 2>/dev/null || true
}

build_binaries() {
    mkdir -p bin
    log "Building NestLink Go FIPS 140-3 backend and Rust supervisor..."
    (cd backend && GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0 go build -ldflags="-s -w" -o ../bin/nestlink .)
    cp -f bin/nestlink backend/main 2>/dev/null || true
    log "Compiled Go backend -> bin/nestlink"

    if [ -d "daemon" ] && [ -f "daemon/Cargo.toml" ]; then
        (cd daemon && (cargo build --release --quiet 2>/dev/null || cargo build --release))
        if [ -f "daemon/target/release/nestlink-daemon" ]; then
            cp -f daemon/target/release/nestlink-daemon bin/nestlink-daemon
            log "Compiled Rust supervisor daemon -> bin/nestlink-daemon"
        fi
    fi

    if [ -f "../NestSBOM/sbom_cli.py" ]; then
        python3 ../NestSBOM/sbom_cli.py --repo . --out-dir . >/dev/null 2>&1 || true
        log "Updated CycloneDX 1.5 and SPDX 2.3 SBOM manifests."
    fi
}

allocate_port() {
    PORT="${PORT:-8080}"
    if (echo > /dev/tcp/127.0.0.1/"$PORT") 2>/dev/null; then
        warn "Target port $PORT is occupied. Allocating dynamic port..."
        PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("", 0)); print(s.getsockname()[1]); s.close()')
    fi
    log "Assigned loopback port: $PORT"
}

SUBCMD="${1:-run}"

case "$SUBCMD" in
    setup)
        check_toolchains
        chmod +x launcher.sh dev.sh 2>/dev/null || true
        log "Toolchain setup and script permissions verified."
        ;;
    build)
        check_toolchains
        build_binaries
        ;;
    run|serve)
        if [ ! -f "bin/nestlink" ]; then
            build_binaries
        fi
        allocate_port
        log "Launching NestLink WebGUI server on http://127.0.0.1:${PORT} (GOFIPS=1)..."
        PORT="$PORT" ./bin/nestlink -port "$PORT" >> "$LOG_FILE" 2>&1 &
        BACKEND_PID=$!
        
        # Poll readiness and launch browser
        for _ in {1..30}; do
            if (echo > /dev/tcp/127.0.0.1/"$PORT") 2>/dev/null; then
                log "NestLink operational at http://127.0.0.1:${PORT}"
                if command -v xdg-open &>/dev/null; then
                    xdg-open "http://127.0.0.1:${PORT}" >/dev/null 2>&1 || true
                elif command -v python3 &>/dev/null; then
                    python3 -m webbrowser "http://127.0.0.1:${PORT}" >/dev/null 2>&1 || true
                fi
                break
            fi
            sleep 0.2
        done
        wait "$BACKEND_PID"
        ;;
    cli|--cli)
        if [ ! -f "bin/nestlink" ]; then
            build_binaries
        fi
        ./bin/nestlink -cli
        ;;
    simulate|--simulate)
        if [ ! -f "bin/nestlink" ]; then
            build_binaries
        fi
        ./bin/nestlink -simulate -export
        ;;
    test)
        log "Executing Go FIPS 140-3 security & compliance test suite..."
        (cd backend && GOFIPS=1 GODEBUG=fips140=on go test -v ./...)
        if [ -d "daemon" ]; then
            log "Executing Rust daemon supervisor unit tests..."
            (cd daemon && (cargo test --quiet 2>/dev/null || cargo test))
        fi
        log "All Go and Rust test suites passed."
        ;;
    fmt)
        log "Formatting Go and Rust source trees..."
        (cd backend && go fmt ./...)
        if [ -d "daemon" ]; then
            (cd daemon && cargo fmt)
        fi
        log "Source formatting complete."
        ;;
    *)
        echo "Usage: $0 {setup|build|run|serve|cli|simulate|test|fmt}"
        exit 1
        ;;
esac
