# CyberNest Labs: NestPatch Formal Developer Handoff & Architecture Manual

* **Project**: NestPatch (Single-IP Automated Military-Grade VLAN Provisioner, Field Network Configurator & Hardening Manager)
* **Corporate Governance**: CyberNest Holdings LLC / CyberNest Labs
* **Leadership**: Co-Founder, President & Chief Architect William R. Moore (Auxk0rd), Co-Founder & CEO James D. Jarrell (JD)
* **Architecture Standard**: RPGS + TUI (`Context/backendguide_md.md` & `Context/nestpatch_architecture_specification.md`)
* **Operational Profile**: 100% Air-Gapped, Zero-Cloud, Zero-CDN, Pure Terminal Field Engineering System

---

## 1. Document Purpose & Scope

This Developer Handoff Manual (`CodeBase/Handoff.md`) serves as the authoritative onboarding and maintenance reference for engineers maintaining or extending **NestPatch**.

### Architectural Executive Summary

NestPatch automates **Single-IP Zero-Touch Military-Grade VLAN Provisioning** across both physical wired Ethernet (`IEEE 802.3`) and wireless Wi-Fi (`IEEE 802.11`) networks without cloud dependencies or web server overhead. Its responsibilities are strictly partitioned across the four RPGS runtime tiers:

1. **Shell (`CodeBase/launcher.sh`)**: Enforces `set -euo pipefail`, `IFS=$'\n\t'`, and `umask 077`. Manages isolated `.venv` bootstrapping, symlink-hardened logging (`~/.cache/nestpatch/session.log`), offline compilation of native Rust and Go engines, explicit child PID tracking (`APP_PID`), and clean TTY teardown (`tput cnorm`).
2. **Python (`CodeBase/app/`)**: Orchestrates the high-contrast **CyberNest Aero-Sunset** Terminal User Interface (`Textual` + `Rich`), inspects local kernel routing and `/sys/class/net` to detect Wired vs. Wireless ingress paths (`network_sense.py`), persists state to an air-gapped SQLite WAL database (`database.py`), and coordinates boundary-aware `STDIN`/`STDOUT` subprocess IPC (`engine_bridge.py`) with transparent pure-Python fallbacks (`app/fallbacks/`).
3. **Rust (`CodeBase/engines/patch_auditor/`)**: Compiled with release LTO (`lto = true`, `codegen-units = 1`, `panic = "abort"`, `strip = true`) and zero external network dependencies. Executes linear-time $O(n)$ configuration AST parsing, evaluates Shannon Entropy $H(X)$ to expose leaked secrets, scores configurations against DISA STIG / NSA hardening rules, and synthesizes collision-free Military-Grade VLAN command payloads.
4. **Go (`CodeBase/engines/batch_dispatcher/`)**: Compiled statically (`CGO_ENABLED=0 go build -ldflags="-s -w"`). Fingerprints target network hardware over SSH/SNMP, maps interface and wireless radio topologies, executes transactional SSHv2 VLAN deployments protected by a 120-second dead-man's switch rollback timer, manages bounded Goroutine worker pools (2–8 workers), and dials out-of-band RS-232 serial consoles.

---

## 2. Complete Codebase Directory Tree

```text
NestPatch/
├── .gitignore                                  # Git ignore rules (binaries, venvs, caches, target/, logs, DBs)
├── launcher.sh                                 # Root POSIX delegation wrapper -> CodeBase/launcher.sh
├── README.md                                   # Root field operator manual, compliance posture & CLI runbook
├── SBOM.md                                     # Root CISA-compliant Software Bill of Materials ledger
├── SBOM.cyclonedx.json                         # Root CycloneDX 1.5 JSON SBOM manifest
├── SBOM.spdx.json                              # Root SPDX 2.3 JSON SBOM manifest
├── Context/
│   ├── backendguide_md.md                      # CyberNest RPGS universal architectural specification
│   └── nestpatch_architecture_specification.md # Master NestPatch architectural & functional blueprint
└── CodeBase/
    ├── launcher.sh                             # Hardened POSIX entrypoint, compiler & TUI process supervisor
    ├── requirements.txt                        # Pinned Python TUI dependencies (textual, rich, aiosqlite, pydantic)
    ├── Handoff.md                              # This formal developer onboarding & architecture manual
    ├── README.md                               # Field operator manual, CLI runbook & keybinding reference
    ├── SBOM.md                                 # CISA-compliant human-readable Software Bill of Materials
    ├── SBOM.cyclonedx.json                     # CycloneDX 1.5 JSON SBOM manifest
    ├── SBOM.spdx.json                          # SPDX 2.3 JSON SBOM manifest
    ├── app/
    │   ├── __init__.py                         # Application package version & metadata marker
    │   ├── main.py                             # Root Python entrypoint (TUI launcher + headless CLI flags)
    │   ├── core/
    │   │   ├── __init__.py                     # Core subsystem package marker
    │   │   ├── config.py                       # Paths, Aero-Sunset color tokens, STIG constants & vendor profiles
    │   │   ├── database.py                     # Async/Sync SQLite WAL persistence (devices, vlans, audits, rollbacks)
    │   │   ├── network_sense.py                # Local NIC inspector (Wired 802.3 vs Wireless 802.11 path detector)
    │   │   ├── security.py                     # IP/VLAN validators, path traversal guards, anti-lockout & SHA-256
    │   │   ├── vlan_orchestrator.py            # Master 5-stage Single-IP Auto-VLAN pipeline coordinator
    │   │   └── engine_bridge.py                # Boundary-aware STDIN/STDOUT JSON IPC adapter + Python fallbacks
    │   ├── tui/
    │   │   ├── __init__.py                     # TUI package marker
    │   │   ├── app.py                          # Master Textual App, screen router & global keybinding controller
    │   │   ├── screens/
    │   │   │   ├── __init__.py                 # Screens package export marker
    │   │   │   ├── quick_vlan.py               # [F2] Primary Screen: Single-IP Military-Grade VLAN Provisioner
    │   │   │   ├── audit.py                    # [F3] Config AST Auditor, Shannon Entropy H(X) & STIG Inspector
    │   │   │   ├── dispatch.py                 # [F4] Bounded Goroutine Batch VLAN Dispatcher & RS-232 Serial Console
    │   │   │   └── inventory.py                # [F5] SQLite Device Inventory, VLAN Topology & Rollback Ledger
    │   │   ├── widgets/
    │   │   │   ├── __init__.py                 # Widgets package export marker
    │   │   │   ├── header.py                   # Tactical CyberNest Labs header & live WIRED/WIRELESS link badge
    │   │   │   ├── ip_command_bar.py           # Single-IP input bar, VLAN selector, platform selector & deploy trigger
    │   │   │   ├── pipeline_stepper.py         # 5-phase visual progress tracker (Sense->Probe->Audit->Synthesize->Lock)
    │   │   │   ├── log_stream.py               # Real-time ANSI TrueColor execution & IPC stream window
    │   │   │   └── vlan_matrix.py              # Target telemetry card & interactive STIG hardening matrix table
    │   │   └── styles/
    │   │       └── nestpatch.tcss              # Textual CSS stylesheet mapping CyberNest Aero-Sunset color tokens
    │   └── fallbacks/
    │       ├── __init__.py                     # Pure-Python fallback package marker
    │       ├── python_auditor.py               # Pure-Python AST parser, Shannon entropy & STIG VLAN synthesizer
    │       └── python_dispatcher.py            # Pure-Python target fingerprinter, transactional deployer & batch worker
    ├── bin/
    │   ├── .gitkeep                            # Directory placeholder for compiled native binaries
    │   ├── batch_dispatcher                    # [Compiled Go binary] Fingerprinter, SSH/SNMP/Wireless/Serial worker
    │   └── patch_auditor                       # [Compiled Rust binary] Zero-panic STIG auditor & VLAN synthesizer
    ├── engines/
    │   ├── batch_dispatcher/
    │   │   ├── go.mod                          # Go 1.22+ module definition (zero external dependencies, zero CGO)
    │   │   ├── go.sum                          # Offline checksum ledger
    │   │   ├── main.go                         # Go STDIN JSON envelope router, FIPS 140-3 KAT & bounded worker pool
    │   │   ├── compliance.go                   # FIPS 140-3 AES-256-GCM/Ed25519 KAT, CWE-22/346/377 & CMMC attestation
    │   │   ├── security_test.go                # Automated Go test suite verifying FIPS 140-3, CWE-22 & dead-man switch
    │   │   ├── fingerprint.go                  # Target IP OS/Vendor fingerprinter & running-config harvester
    │   │   ├── ssh_transactional.go            # Transactional SSHv2 VLAN deployer with dead-man's rollback & jitter
    │   │   ├── wireless_controller.go          # Wireless AP / WLC SSID-to-VLAN binder & 802.11w/isolation handler
    │   │   ├── snmp_worker.go                  # SNMP IF-MIB / Q-BRIDGE-MIB interface topology mapper
    │   │   └── serial_worker.go                # Out-of-band RS-232 / USB FTDI UART console bootstrap dialer
    │   └── patch_auditor/
    │       ├── Cargo.toml                      # Rust crate manifest (LTO, codegen-units=1, panic="abort", strip=true)
    │       ├── Cargo.lock                      # Offline Cargo lockfile
    │       └── src/
    │           ├── main.rs                     # Zero-panic STDIN/STDOUT JSON parser, router & serializer
    │           ├── entropy.rs                  # Shannon Entropy H(X) secret & credential leak detector
    │           ├── parser.rs                   # Linear-time O(n) single-pass running-config AST & VLAN extractor
    │           ├── rules.rs                    # DISA STIG & NSA Layer 2, Layer 3, Wireless & Mgmt compliance engine
    │           └── synthesizer.rs              # Collision-free Military-Grade VLAN configuration generator
    └── tests/
        ├── __init__.py                         # Test suite package marker
        ├── test_security.py                    # Unit tests: IP/VLAN validation, path traversal & anti-lockout guard
        ├── test_engine_bridge.py               # Unit tests: extract_outermost_json() & automatic Python fallbacks
        ├── test_vlan_synthesizer.py            # Unit tests: Wired & Wireless STIG VLAN synthesis & entropy math
        └── test_tui_headless.py                # Headless Textual pilot integration tests across all screens & rollback
```

---

## 3. Deep File-by-File Operational Breakdown

### 3.1 Root Entrypoints & Configuration

#### `CodeBase/launcher.sh`
* **Role**: Primary POSIX bootloader, virtual environment provisioner, native binary compiler, and process lifecycle guardian.
* **What It Does**: Enforces `set -euo pipefail`, `IFS=$'\n\t'`, and `umask 077`. Creates `${HOME}/.cache/nestpatch` with `0700` permissions, purges any symlink at `session.log` (`[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"`), bootstraps `.venv` without `sudo`, compiles `engines/batch_dispatcher` (`CGO_ENABLED=0 go build -ldflags="-s -w"`) and `engines/patch_auditor` (`cargo build --release`), and launches `app.main` attached to the foreground terminal while trapping `EXIT`/`INT`/`TERM` to restore the cursor (`tput cnorm`).
* **How to Modify**: Add new CLI subcommands in the bottom `case "${1:-run}"` block. Never introduce `fuser -k`, `killall`, or automated `sudo` invocations.

#### `CodeBase/requirements.txt`
* **Role**: Pinned Python dependency manifest for the isolated `.venv` environment.
* **What It Does**: Specifies `textual`, `rich`, `aiosqlite`, and `pydantic` with zero web server (FastAPI/Uvicorn/HTMX) dependencies.
* **How to Modify**: Append version-pinned pure-Python packages and run `./launcher.sh build` to synchronize `.venv`.

#### `CodeBase/app/main.py`
* **Role**: Python application entrypoint bridging `launcher.sh` to either the interactive Textual TUI or headless CLI execution.
* **What It Does**: Parses CLI arguments (`--provision-ip`, `--vlan-id`, `--vendor`, `--health-check`), ensures `~/.cache/nestpatch` exists, and either runs `VlanProvisioningOrchestrator` headless emitting structured JSON or boots `NestPatchApp().run()`.
* **How to Modify**: Add new CLI flags inside `parse_args()` and handle them in `main()` prior to `NestPatchApp().run()`.

---

### 3.2 Python Core Subsystem (`CodeBase/app/core/`)

#### `CodeBase/app/core/config.py`
* **Role**: Centralized configuration constants, filesystem paths, Aero-Sunset color tokens, and DISA STIG security defaults.
* **What It Does**: Defines `USER_CACHE_DIR`, `DB_PATH`, `RUST_AUDITOR_BIN`, `GO_DISPATCHER_BIN`, `AERO_SUNSET_TOKENS`, `RESERVED_VLANS = (1, 999, 1002, 1003, 1004, 1005)`, `BLACKHOLE_VLAN_ID = 999`, `DEFAULT_ENTROPY_THRESHOLD = 3.55`, and supported vendor/auth profiles.
* **How to Modify**: Add new vendor tuples to `SUPPORTED_VENDORS` or adjust default VLAN allocation pool bounds (`DEFAULT_VLAN_POOL_START` / `DEFAULT_VLAN_POOL_END`).

#### `CodeBase/app/core/network_sense.py`
* **Role**: Local OS network stack and physical medium inspector (`WIRED_802_3` vs. `WIRELESS_802_11`).
* **What It Does**: Implements `validate_target_ip()` and `detect_ingress_medium(target_ip)`. Queries the Linux kernel routing table via `ip -o route get <target_ip>` (using explicit argument lists, never `shell=True`), reads `/sys/class/net/<iface>/address` for the operator's hardware MAC, checks `/sys/class/net/<iface>/wireless` and `phy80211` to classify wired vs. wireless links, and queries `iwgetid -r` for the active Wi-Fi SSID.
* **How to Modify**: Extend `IngressPathProfile` if additional local interface attributes (such as MTU or 802.1Q local sub-interfaces) need to be passed to the Rust synthesizer.

#### `CodeBase/app/core/security.py`
* **Role**: Input sanitization, IP/VLAN validation, path traversal defense, and anti-lockout verification.
* **What It Does**: Implements `validate_ip_address()`, `validate_vlan_id()` (blocking reserved VLANs `1, 999, 1002-1005`), `validate_serial_device_node()` (restricting UART paths to `/dev/ttyUSB*`, `/dev/ttyACM*`, `/dev/ttyS*`), `validate_safe_export_path()` (blocking CWE-22 path traversal and CWE-377 symlinks), `verify_anti_lockout_guard()`, and `compute_sha256_digest()`.
* **How to Modify**: Add stricter organizational IP subnet allowlists inside `validate_ip_address()` or additional protected uplink checks in `verify_anti_lockout_guard()`.

#### `CodeBase/app/core/database.py`
* **Role**: Air-gapped SQLite WAL relational persistence manager (`NestPatchDatabase`).
* **What It Does**: Initializes and queries four relational tables in `~/.cache/nestpatch/nestpatch_enclave.db` (`0600` permissions): `devices`, `provisioned_vlans`, `audits`, and `rollbacks`. Provides async methods (`record_provisioning_transaction`, `record_standalone_audit`, `mark_rollback_executed`, `list_provisioned_vlans`, `list_devices`, `list_rollbacks`).
* **How to Modify**: Add new schema columns in `SCHEMA_SQL` and expose corresponding async query methods on `NestPatchDatabase`.

#### `CodeBase/app/core/engine_bridge.py`
* **Role**: Boundary-aware `STDIN`/`STDOUT` subprocess IPC adapter with transparent pure-Python fallback routing.
* **What It Does**: Implements `extract_outermost_json(raw_text)` (scanning `STDOUT` for the outermost `{...}` or `[...]` block while ignoring compiler or diagnostic banners), `run_engine_binary()`, `invoke_rust_auditor_async()`, and `invoke_go_dispatcher_async()`. Streams all payloads over `STDIN` (`subprocess.run(..., input=stdin_str)`) to prevent CWE-400 OS `ARG_MAX` overflows and offloads blocking subprocess calls via `loop.run_in_executor()`.
* **How to Modify**: Register additional binary wrappers following the `invoke_rust_auditor` pattern, always pairing each binary with a deterministic fallback function in `app/fallbacks/`.

#### `CodeBase/app/core/vlan_orchestrator.py`
* **Role**: Master 5-stage pipeline orchestrator for Single-IP Automated Military-Grade VLAN Provisioning.
* **What It Does**: Implements `VlanProvisioningOrchestrator.execute_single_ip_pipeline()` and `execute_emergency_rollback()`. Sequentially coordinates Phase 1 (`detect_ingress_medium`), Phase 2 (`invoke_go_dispatcher_async` fingerprint), Phase 3 & 4 (`invoke_rust_auditor_async` AST audit, Shannon entropy scan, and STIG VLAN synthesis + `verify_anti_lockout_guard`), and Phase 5 (`invoke_go_dispatcher_async` transactional deploy + SQLite persistence), emitting live stage and log callbacks to the TUI.
* **How to Modify**: Hook custom pre-deployment or post-deployment verification callbacks into `execute_single_ip_pipeline()`.

---

### 3.3 Pure-Python Fallbacks (`CodeBase/app/fallbacks/`)

#### `CodeBase/app/fallbacks/python_auditor.py`
* **Role**: Pure-Python fallback implementation of the Rust `patch_auditor` binary.
* **What It Does**: Implements `calculate_shannon_entropy()`, `scan_config_entropy()`, `parse_and_audit_config()`, `select_safe_vlan_id()`, and `synthesize_military_grade_vlan_py()`, returning the exact JSON schema produced by the native Rust engine.
* **How to Modify**: Keep any new vendor synthesis branches or STIG rules synchronized between `engines/patch_auditor/src/` and this module.

#### `CodeBase/app/fallbacks/python_dispatcher.py`
* **Role**: Pure-Python fallback implementation of the Go `batch_dispatcher` binary.
* **What It Does**: Implements `fallback_fingerprint_target()`, `fallback_deploy_vlan()`, and `fallback_batch_dispatcher()` (supporting `fingerprint`, `deploy`, `batch_dispatch`, `rollback`, and `serial_bootstrap` actions).
* **How to Modify**: Mirror any new JSON fields added to `engines/batch_dispatcher/` in `fallback_batch_dispatcher()`.

---

### 3.4 Python Textual TUI Layer (`CodeBase/app/tui/`)

#### `CodeBase/app/tui/app.py`
* **Role**: Master Textual `App` subclass (`NestPatchApp`), screen installer, and global keybinding router.
* **What It Does**: Loads `styles/nestpatch.tcss`, binds `F2` (`quick_vlan`), `F3` (`audit`), `F4` (`dispatch`), `F5` (`inventory`), `Ctrl+R` (`emergency_rollback`), and `F10` (`quit`), and wires shared `NestPatchDatabase` and `VlanProvisioningOrchestrator` instances across all screens.
* **How to Modify**: Register new screens in `on_mount()` via `self.install_screen()` and add corresponding `Binding` entries to `BINDINGS`.

#### `CodeBase/app/tui/styles/nestpatch.tcss`
* **Role**: Textual CSS stylesheet implementing the **CyberNest Aero-Sunset** visual identity.
* **What It Does**: Maps `--bg-space` (`#0d0814`), `--bg-surface` (`#241936`), `--accent-purple` (`#8142db`), `--accent-magenta` (`#c93b93`), `--accent-orange` (`#ff7536`), `--text-main` (`#f0e6f7`), `--text-muted` (`#a695b8`), and `--status-critical` (`#ff3366`) to all TUI containers, tables, inputs, and buttons.
* **How to Modify**: Add widget-specific styling rules using the defined `$accent-*` and `$bg-*` variables; never introduce hardcoded non-palette colors.

#### `CodeBase/app/tui/widgets/header.py`
* **Role**: Top branded CyberNest Labs banner and live connection medium indicator (`NestPatchHeader`).
* **What It Does**: Displays the application title, active function-key screen tab (`F2`–`F5`), and the real-time ingress link badge (`[LINK: WIRED 802.3 (eth0)]` or `[LINK: WIRELESS 802.11 (wlan0 // SSID)]`).
* **How to Modify**: Call `update_medium()` or `set_active_tab()` to dynamically update header badges.

#### `CodeBase/app/tui/widgets/ip_command_bar.py`
* **Role**: Single-IP input command bar and deployment trigger widget (`IPCommandBar`).
* **What It Does**: Renders the Target Device IP input field, optional VLAN ID input (`AUTO`), vendor platform selector, authentication profile selector, and the `>>> DEPLOY MILITARY-GRADE SECURE VLAN (ENTER) <<<` button. Emits `IPCommandBar.DeployRequested` on Enter or button click.
* **How to Modify**: Add new input controls inside `compose()` and include their values in `IPCommandBar.DeployRequested`.

#### `CodeBase/app/tui/widgets/pipeline_stepper.py`
* **Role**: Visual 5-stage progress tracker widget (`PipelineStepper`).
* **What It Does**: Renders the five pipeline stages (`1. MEDIUM SENSE`, `2. OS FINGERPRINT`, `3. RUST AUDIT`, `4. SYNTHESIS`, `5. LOCK & COMMIT`) with live state transitions (`IDLE`, `ACTIVE`, `OK`, `ERR`) and stage telemetry captions.
* **How to Modify**: Update `STAGE_NAMES` or customize badge colors in `_refresh_view()`.

#### `CodeBase/app/tui/widgets/log_stream.py`
* **Role**: Real-time ANSI TrueColor execution terminal stream (`LogStreamWidget`).
* **What It Does**: Subclasses Textual `RichLog` to render timestamped IPC and command execution logs color-coded by subsystem tag (`SENSE`, `PROBE`, `RUST`, `WARN`, `SYNTH`, `GO`, `LOCK`, `ROLLBACK`).
* **How to Modify**: Adjust color mappings in `append_log()` or call `get_plain_transcript()` to export log history.

#### `CodeBase/app/tui/widgets/vlan_matrix.py`
* **Role**: Target Device Telemetry card and interactive DISA STIG Hardening Matrix (`VlanMatrixWidget`).
* **What It Does**: Displays the live summary of the target IP, protected local ingress interface, allocated VLAN ID & subnet CIDR, suspended Blackhole VLAN 999, wired/wireless security posture, dead-man rollback status, and a `DataTable` of enforced STIG controls.
* **How to Modify**: Expand `update_from_pipeline_result()` to display additional device telemetry metrics.

#### `CodeBase/app/tui/screens/quick_vlan.py`
* **Role**: Primary `F2` screen (`QuickVlanScreen`) for Single-IP Automated Military-Grade VLAN Provisioning.
* **What It Does**: Composes `NestPatchHeader`, `IPCommandBar`, `PipelineStepper`, `VlanMatrixWidget`, and `LogStreamWidget`. Handles `IPCommandBar.DeployRequested` by invoking `VlanProvisioningOrchestrator.execute_single_ip_pipeline()` and updating all panes in real time.
* **How to Modify**: Add supplementary keybindings or detail modals directly to `QuickVlanScreen`.

#### `CodeBase/app/tui/screens/audit.py`
* **Role**: `F3` Configuration & Shannon Entropy $H(X)$ Auditor screen (`AuditScreen`).
* **What It Does**: Provides an interactive `TextArea` for device running-configs, streams the configuration over `STDIN` to the Rust `patch_auditor` engine, and renders two side-by-side `DataTable` views: DISA STIG / NSA compliance rule findings and Shannon Entropy $H(X)$ secret leak detections.
* **How to Modify**: Add custom configuration presets or report export buttons in `compose()`.

#### `CodeBase/app/tui/screens/dispatch.py`
* **Role**: `F4` Bounded Batch VLAN Dispatcher & Out-of-Band RS-232 Serial Console screen (`DispatchScreen`).
* **What It Does**: Accepts comma-separated target IPs, synthesizes a hardened VLAN payload via Rust, dispatches it concurrently across a bounded Go Goroutine worker pool (2–8 workers), and provides an out-of-band RS-232 serial console bootstrap trigger (`/dev/ttyUSB0`).
* **How to Modify**: Expose additional serial framing options or custom command batch templates in `run_serial_bootstrap()`.

#### `CodeBase/app/tui/screens/inventory.py`
* **Role**: `F5` Air-Gapped SQLite Enclave Inventory & Rollback Ledger screen (`InventoryScreen`).
* **What It Does**: Queries `NestPatchDatabase` to display all provisioned Military-Grade VLANs, discovered wired/wireless nodes, cryptographic SHA-256 commit hashes, and transactional rollback checkpoints, with a 1-click `REVERT LATEST VLAN DEPLOYMENT (CTRL+R)` button.
* **How to Modify**: Add filtering by subnet or vendor platform in `refresh_tables()`.

---

### 3.5 Rust Engine (`CodeBase/engines/patch_auditor/`)

#### `CodeBase/engines/patch_auditor/Cargo.toml`
* **Role**: Rust crate manifest configured for deterministic, air-gapped static release builds.
* **What It Does**: Enforces `opt-level = 3`, `lto = true`, `codegen-units = 1`, `panic = "abort"`, `strip = true`, and zero external internet crate dependencies so compilation succeeds 100% offline.
* **How to Modify**: Keep `[dependencies]` free of network-fetched crates to preserve air-gapped build determinism.

#### `CodeBase/engines/patch_auditor/src/main.rs`
* **Role**: Zero-panic Rust `STDIN`/`STDOUT` JSON entrypoint and orchestrator.
* **What It Does**: Includes a self-contained recursive-descent JSON parser and serializer, reads the JSON request envelope from `STDIN`, invokes `parse_running_config()`, `scan_config_entropy()`, `evaluate_stig_compliance()`, and `synthesize_military_grade_vlan()`, and emits a single compact JSON object to `STDOUT`.
* **How to Modify**: Extract additional request fields from `parsed_root` and append new output keys to `output_json`.

#### `CodeBase/engines/patch_auditor/src/entropy.rs`
* **Role**: Shannon Entropy $H(X)$ secret and credential leak scanner.
* **What It Does**: Computes $H(X) = -\sum P(x_i) \log_2 P(x_i)$ in bits per byte via `calculate_shannon_entropy()`, redacts sensitive tokens via `redact_token()`, and scans configurations for Cisco Type-7/Type-0 passwords, SNMPv1/v2c community strings, WPA pre-shared keys, and high-entropy cryptographic material.
* **How to Modify**: Add new credential keyword patterns in `scan_config_entropy()` or adjust the default entropy threshold.

#### `CodeBase/engines/patch_auditor/src/parser.rs`
* **Role**: Linear-time $O(n)$ single-pass running-configuration AST and VLAN extractor.
* **What It Does**: Parses device configurations into `ConfigAst` and `InterfaceNode` structs without backtracking regular expressions, extracting hostname, vendor platform, occupied VLAN IDs, interface port modes, native VLANs, and global security flags.
* **How to Modify**: Add new vendor syntax recognizers inside the single-pass line loop in `parse_running_config()`.

#### `CodeBase/engines/patch_auditor/src/rules.rs`
* **Role**: DISA STIG and NSA Layer 2, Layer 3, Wireless 802.11, and Control Plane compliance evaluator.
* **What It Does**: Evaluates `ConfigAst` against 8 core STIG/NSA directives (`DISA-STIG-L2-001` through `DISA-STIG-MGMT-008`), returning per-rule `PASS`/`FAIL`/`WARN` findings and an aggregate `compliance_score` (0–100%).
* **How to Modify**: Append new `StigRuleFinding` evaluations to `evaluate_stig_compliance()`.

#### `CodeBase/engines/patch_auditor/src/synthesizer.rs`
* **Role**: Vendor-specific Military-Grade Secure VLAN configuration synthesizer.
* **What It Does**: Implements `select_safe_vlan_id()` (strictly reserving `1, 999, 1002..=1005`) and `synthesize_military_grade_vlan()`, generating complete forward and rollback command sequences for Cisco IOS-XE/Arista EOS, Juniper JunOS, and OpenWrt/Enterprise 802.11 Wireless APs.
* **How to Modify**: Add a new `match req.vendor_platform.as_str()` arm in `synthesize_military_grade_vlan()`.

---

### 3.6 Go Engine (`CodeBase/engines/batch_dispatcher/`)

#### `CodeBase/engines/batch_dispatcher/main.go`
* **Role**: Go `STDIN`/`STDOUT` JSON router and bounded Goroutine worker pool coordinator.
* **What It Does**: Decodes `EnvelopeRequest` from `STDIN` and routes to `FingerprintTargetDevice` (`fingerprint`), `ExecuteTransactionalVlanDeploy` (`deploy` / `rollback`), `executeBoundedBatch` (`batch_dispatch` with 2–8 bounded Goroutine workers), or `ExecuteSerialBootstrap` (`serial_bootstrap`).
* **How to Modify**: Add new `case` branches inside `switch req.Action` in `main()`.

#### `CodeBase/engines/batch_dispatcher/fingerprint.go`
* **Role**: Target IP OS/Vendor fingerprinter and configuration harvester.
* **What It Does**: Performs bounded-timeout TCP banner probing (`probeTCPBanner`), identifies the target platform (`cisco_ios`, `arista_eos`, `juniper_junos`, `openwrt_wireless`), collects SNMP interface and wireless radio tables, and returns the harvested `running_config`.
* **How to Modify**: Add new banner heuristics and platform templates in `FingerprintTargetDevice()`.

#### `CodeBase/engines/batch_dispatcher/ssh_transactional.go`
* **Role**: Transactional SSHv2 VLAN dispatcher with dead-man's switch rollback timer and jitter pacing.
* **What It Does**: Arms the 120-second transactional rollback timer, paces command execution using crypto-random jitter (`getJitter` via `crypto/rand`), verifies post-deployment management socket survival, cancels the revert timer, and computes a SHA-256 audit digest (`computeAuditHash`).
* **How to Modify**: Adjust jitter bounds or add custom post-commit verification probes in `ExecuteTransactionalVlanDeploy()`.

#### `CodeBase/engines/batch_dispatcher/wireless_controller.go`
* **Role**: Wireless 802.11 AP / WLC SSID-to-VLAN binding and Layer 2 Client Isolation controller.
* **What It Does**: Maps active wireless radios (`InspectWirelessController`) and generates 802.11w Protected Management Frames (PMF) and WPA3-SAE client isolation telemetry (`BuildWirelessHardeningTranscript`).
* **How to Modify**: Extend `WirelessRadioInfo` with additional 802.11ax/be channel and BSSID fields.

#### `CodeBase/engines/batch_dispatcher/snmp_worker.go`
* **Role**: SNMP `IF-MIB` and `Q-BRIDGE-MIB` interface topology mapper.
* **What It Does**: Returns structured `SNMPInterfaceInfo` records detailing interface operational states, PVID VLANs, trunk/access modes, and protected ingress port markers.
* **How to Modify**: Expand `PollSNMPInterfaces()` to include LLDP neighbor descriptors.

#### `CodeBase/engines/batch_dispatcher/serial_worker.go`
* **Role**: Out-of-band RS-232 / USB FTDI UART console bootstrap dialer.
* **What It Does**: Inspects `/dev/ttyUSB*` / `/dev/ttyS*` hardware descriptors and dispatches out-of-band recovery and Blackhole VLAN bootstrap commands at the configured baud rate (default `115200 8N1`).
* **How to Modify**: Add custom UART framing or hardware flow-control flags to `SerialBootstrapRequest`.

---

### 3.7 Automated Test Suite (`CodeBase/tests/`)

#### `CodeBase/tests/test_security.py`
* **Role**: Unit tests for IP validation, reserved VLAN blocking, path traversal guards, and anti-lockout verification.
* **What It Does**: Tests `validate_ip_address`, `validate_vlan_id`, `validate_serial_device_node`, `validate_safe_export_path`, `verify_anti_lockout_guard`, and `detect_ingress_medium`.
* **How to Modify**: Add new test methods to `TestSecurityValidation`.

#### `CodeBase/tests/test_engine_bridge.py`
* **Role**: Unit tests for `extract_outermost_json()` and transparent pure-Python engine fallbacks.
* **What It Does**: Verifies that noisy `STDOUT` streams are cleanly parsed and that `invoke_rust_auditor` and `invoke_go_dispatcher` seamlessly fall back to Python when `bin/` is empty.
* **How to Modify**: Add additional malformed JSON edge cases to `TestEngineBridge`.

#### `CodeBase/tests/test_vlan_synthesizer.py`
* **Role**: Unit tests for collision-free VLAN selection, Shannon entropy math, and wired/wireless STIG command synthesis.
* **What It Does**: Verifies wired Cisco IOS-XE DAI/Snooping/Blackhole VLAN 999 generation and wireless OpenWrt WPA3-SAE/802.11w PMF/Client Isolation synthesis.
* **How to Modify**: Add test cases for new vendor platforms in `TestVlanSynthesizer`.

#### `CodeBase/tests/test_tui_headless.py`
* **Role**: Headless Textual pilot integration test suite.
* **What It Does**: Boots `NestPatchApp` in headless mode, runs a full 5-stage Single-IP VLAN deployment, verifies SQLite persistence, navigates across `F2`, `F3`, `F4`, and `F5`, and triggers an emergency rollback (`Ctrl+R`).
* **How to Modify**: Add new `pilot.press()` interactions inside `TestNestPatchTuiHeadless`.

---

## 4. End-to-End Data Flow & Lifecycle of a Single-IP Secure VLAN Deployment

```text
+--------------------+      +-----------------------+      +-------------------------+      +-------------------------+
| Operator (TUI F2)  |      | Python Orchestrator   |      | Go: batch_dispatcher    |      | Rust: patch_auditor     |
+--------------------+      +-----------------------+      +-------------------------+      +-------------------------+
          |                             |                               |                                |
          | 1. Enter IP "192.168.1.1"   |                               |                                |
          |---------------------------> |                               |                                |
          |                             | 2. detect_ingress_medium()    |                                |
          |                             |    (`ip -o route get` + sysfs)|                                |
          |                             |    Marks egress NIC/IP/SSID   |                                |
          |                             |    as PROTECTED               |                                |
          |                             |                               |                                |
          |                             | 3. STDIN JSON {"action":      |                                |
          |                             |    "fingerprint", ...}        |                                |
          |                             |-----------------------------> |                                |
          |                             |                               | 4. Probe SSH/SNMP & harvest    |
          |                             |                               |    running-config + VLAN table |
          |                             | <-----------------------------|                                |
          |                             |    STDOUT JSON (Outer-Bound)  |                                |
          |                             |                               |                                |
          |                             | 5. STDIN JSON {"action": "audit_and_synthesize", ...}          |
          |                             |--------------------------------------------------------------> |
          |                             |                               |                                | 6. O(n) AST Parse
          |                             |                               |                                | 7. Shannon Entropy H(X)
          |                             |                               |                                | 8. STIG Compliance Eval
          |                             |                               |                                | 9. Synthesize VLAN 401
          |                             |                               |                                |    + Blackhole VLAN 999
          |                             | <--------------------------------------------------------------|
          |                             |    STDOUT JSON (Commands + Rollback + STIG + Entropy Findings) |
          |                             |                               |                                |
          |                             | 10. verify_anti_lockout_guard()                                |
          |                             | 11. STDIN JSON {"action":     |                                |
          |                             |     "deploy", "commands":...} |                                |
          |                             |-----------------------------> |                                |
          |                             |                               | 12. Arm 120s Dead-Man Rollback |
          |                             |                               | 13. Apply STIG VLAN w/ jitter  |
          |                             |                               | 14. Verify socket reachability |
          |                             |                               | 15. Cancel revert & SHA-256    |
          |                             | <-----------------------------|                                |
          |                             |    STDOUT JSON (SUCCESS_LOCKED + Audit Hash)                   |
          |                             |                               |                                |
          |                             | 16. Persist to SQLite WAL (`nestpatch_enclave.db`)             |
          | <---------------------------|                               |                                |
          | 17. Update Stepper, Matrix & ANSI Log Stream                                                 |
+--------------------+      +-----------------------+      +-------------------------+      +-------------------------+
```

---

## 5. Developer Extension How-To Guides

### 5.1 How to Add a New Vendor Platform to the Rust Military-Grade VLAN Synthesizer (`synthesizer.rs`)
1. Open `CodeBase/engines/patch_auditor/src/synthesizer.rs`.
2. In `synthesize_military_grade_vlan(req: &VlanSynthesisRequest)`, add a new branch to `match req.vendor_platform.as_str()` (e.g., `"fortiswitch"`):
   ```rust
   "fortiswitch" => {
       cmds.extend(vec![
           "config switch vlan".to_string(),
           format!("edit {}", vlan_id),
           format!("set description \"{}\"", vlan_name),
           "set dhcp-snooping enable".to_string(),
           "set igmp-snooping enable".to_string(),
           "next".to_string(),
           "end".to_string(),
       ]);
       rollback.push(format!("config switch vlan\ndelete {}\nend", vlan_id));
   }
   ```
3. Mirror the branch in `CodeBase/app/fallbacks/python_auditor.py` and register the display option in `SUPPORTED_VENDORS` inside `CodeBase/app/core/config.py`.
4. Run `./launcher.sh build && ./launcher.sh test`.

### 5.2 How to Add a New Secret Detection or DISA STIG Compliance Rule with Entropy Threshold (`rules.rs` & `entropy.rs`)
1. Open `CodeBase/engines/patch_auditor/src/entropy.rs` and add any new credential context keywords in `scan_config_entropy()`.
2. Open `CodeBase/engines/patch_auditor/src/parser.rs` and add a boolean posture flag to `ConfigAst` (e.g., `pub has_lldp_disabled_on_edge: bool`).
3. Open `CodeBase/engines/patch_auditor/src/rules.rs` and append a new `StigRuleFinding` inside `evaluate_stig_compliance()`:
   ```rust
   findings.push(StigRuleFinding {
       rule_id: "DISA-STIG-L2-009".to_string(),
       category: "Layer 2 Recon Prevention".to_string(),
       title: "Disable CDP and LLDP on Untrusted Access Edges".to_string(),
       severity: "MEDIUM".to_string(),
       status: if ast.has_lldp_disabled_on_edge { "PASS".to_string() } else { "WARN".to_string() },
       description: "Evaluates whether link-layer discovery protocols are suppressed on edge ports.".to_string(),
       remediation: "Configure 'no cdp enable' and 'no lldp transmit' on access interfaces.".to_string(),
   });
   ```

### 5.3 How to Add a New Wireless Controller or Switch Driver to the Go Dispatcher (`fingerprint.go` / `wireless_controller.go`)
1. Open `CodeBase/engines/batch_dispatcher/fingerprint.go` and add banner recognition criteria in `FingerprintTargetDevice()`.
2. Open `CodeBase/engines/batch_dispatcher/wireless_controller.go` and extend `InspectWirelessController()` and `BuildWirelessHardeningTranscript()` with the vendor-specific WLC telemetry.
3. Recompile via `./launcher.sh build`.

### 5.4 How to Add a Custom Aero-Sunset Widget or Screen to the Python Textual TUI (`app/tui/`)
1. Create a new widget module under `CodeBase/app/tui/widgets/` or screen module under `CodeBase/app/tui/screens/`.
2. Style the component in `CodeBase/app/tui/styles/nestpatch.tcss` using strictly the Aero-Sunset variables (`$bg-space`, `$bg-surface`, `$accent-purple`, `$accent-magenta`, `$accent-orange`, `$text-main`, `$text-muted`, `$status-critical`).
3. Register the screen in `CodeBase/app/tui/app.py` inside `on_mount()` via `self.install_screen()` and bind a function key in `BINDINGS`.

---

## 6. Security-Hardened Architecture & Federal Compliance Remediation Ledger

| Threat Vector / Standard | CWE / Control ID | Impacted Component | Root Cause / Requirement | Enforced Mitigation Pattern | Verification Method |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Management Self-Lockout** | CWE-284 | `network_sense.py`, `security.py`, `ssh_transactional.go` | Re-tagging the active wired switch port or wireless SSID severs the operator's session. | Kernel route inspection (`ip -o route get`) marks ingress NIC/IP/SSID as protected; `verify_anti_lockout_guard()` validates ACLs; Go arms a 120s dead-man's rollback timer. | `tests/test_security.py` & `tests/test_tui_headless.py` |
| **802.1Q VLAN Hopping** | CWE-285 / V-220650 | `synthesizer.rs`, `python_auditor.py` | Leaving ports in Default VLAN 1 or sharing native trunk VLANs with access VLANs. | Reserves `VLAN 1` and `VLAN 999`; suspends `VLAN 999` (`CN_BLACKHOLE_DEAD_VLAN`) for unused ports and native trunks; enforces `switchport nonegotiate`. | `tests/test_vlan_synthesizer.py` |
| **Wireless Station Sniffing** | CWE-319 / V-220670 | `synthesizer.rs`, `wireless_controller.go` | Compromised wireless station attacking peer clients on the same SSID/VLAN. | Enforces Layer 2 Wireless Client Isolation (`isolate='1'` / `client-isolation enable`), mandatory 802.11w PMF (`ieee80211w='2'`), and WPA3-SAE. | `tests/test_vlan_synthesizer.py` |
| **Path Traversal & Zip Slip** | CWE-22 | `security.py`, `compliance.go`, `main.rs` | Unsanitized relative paths or serial device descriptors escaping base directories. | Multi-stage `sanitize_relative_path()`, `safe_resolve_under()`, and `ValidateSerialDeviceNode()` across Python, Go, and Rust. | `tests/test_security.py`, `security_test.go`, `main.rs` |
| **Host / DNS Rebinding** | CWE-346 | `security.py`, `compliance.go` | Untrusted `Host` or `Origin` headers targeting local loopback services. | Strict `verify_host_and_origin()` and `VerifyLoopbackOrigin()` restricting access to `127.0.0.1` and `localhost`. | `tests/test_security.py` & `security_test.go` |
| **OS Argument & Payload DoS** | CWE-400 | `engine_bridge.py`, `security.py`, `main.go` | Passing unbounded payloads via CLI arguments or STDIN pipes. | Streams JSON strictly over `STDIN`/`STDOUT` with `io.LimitReader` (8 MB IPC cap) and `enforce_payload_cap()` (64 KB request cap). | `tests/test_engine_bridge.py` & `tests/test_security.py` |
| **Symlink Hijacking** | CWE-377 | `launcher.sh`, `security.py`, `compliance.go` | Predictable `/tmp` log files allowing TOCTOU symlink overwrites. | Isolates logs and SQLite DB to `${HOME}/.cache/nestpatch` (`0700` dir, `0600` files) with `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"` and `umask 077`. | `tests/test_security.py` & `security_test.go` |
| **Destructive Process Kills** | CWE-114 | `launcher.sh` | Cleanup scripts running `fuser -k` or `killall` and killing unrelated host processes. | Zero `fuser` or `killall` usage; tracks explicit `APP_PID` and dispatches targeted `SIGTERM` with `tput cnorm` terminal cursor restoration. | `launcher.sh` inspection |
| **Catastrophic ReDoS** | CWE-1333 | `engines/patch_auditor` | Backtracking regex engines stalling on adversarial configuration dumps. | Single-pass $O(n)$ deterministic AST parser (`parser.rs`) and linear-time Shannon entropy scanner (`entropy.rs`) in compiled Rust. | `tests/test_vlan_synthesizer.py` |
| **CMMC 2.0 & FIPS 140-3 Enclave** | MP.L2-3.8.1 / IA.L2-3.5.2 | `database.py`, `security.py`, `compliance.go`, `main.rs` | Unencrypted CUI at rest or static credentials in local storage. | Authenticated AES-256-GCM SQLite WAL field encryption, dynamic Ed25519 enclave keypairs (`identity.enc`, `0600`), `GOFIPS=1` builds, and startup KAT self-tests. | `./launcher.sh test` & `./launcher.sh run --compliance-check` |

---

## 7. Dual-Native Orchestration & Maintenance Commands (`CN-DIR-2026-004`)

NestPatch adheres to **CyberNest Labs Architecture Specification // Standard 004 (`CN-DIR-2026-004`)**: Dual-Native Orchestration Architecture (Bi-Launcher Specification). Universal command parity is maintained across both Linux (`./dev.sh` / `./launcher.sh`) and Windows (`.\dev.bat` / `.\launcher.bat`):

| Subcommand | Linux / Pop!_OS (`./dev.sh` / `./launcher.sh`) | Windows 10/11 (`.\dev.bat` / `.\launcher.bat`) | Operational Behavior |
| :--- | :--- | :--- | :--- |
| `setup` | `./dev.sh setup` | `.\dev.bat setup` | Verifies Go, Cargo, Python 3 runtimes and runtime path boundaries. |
| `build` | `./dev.sh build` | `.\dev.bat build` | Compiles Rust `patch_auditor[.exe]` & Go `batch_dispatcher[.exe]` (`GOFIPS=1`) + regenerates CISA SBOMs. |
| `run` / `serve` | `./dev.sh run` | `.\dev.bat run` | Launches interactive Textual TUI (`CWE-114` PID tracking, terminal state restore). |
| `cli` | `./dev.sh cli` | `.\dev.bat cli` | Executes non-interactive single-sweep diagnostic & compliance check to stdout. |
| `simulate` | `./dev.sh simulate` | `.\dev.bat simulate` | Executes simulated network fault & VLAN provisioning audit with exported report. |
| `test` | `./dev.sh test` | `.\dev.bat test` | Executes full polyglot test suite (Go, Rust, and Python unittest suite). |
| `fmt` | `./dev.sh fmt` | `.\dev.bat fmt` | Formats all Go (`go fmt ./...`) and Rust (`cargo fmt`) source code. |

```bash
# 1. Compile native Go (batch_dispatcher) and Rust (patch_auditor) binaries into ./bin/
./dev.sh build        # Windows: .\dev.bat build

# 2. Execute the complete Go, Rust, Python & Headless Textual TUI verification suite
./dev.sh test         # Windows: .\dev.bat test

# 3. Launch the interactive CyberNest Aero-Sunset Terminal UI
./dev.sh run          # Windows: .\dev.bat run

# 4. Execute a non-interactive CLI single-sweep diagnostic
./dev.sh cli          # Windows: .\dev.bat cli

# 5. Execute simulated network fault & VLAN provisioning audit
./dev.sh simulate     # Windows: .\dev.bat simulate

# 6. Execute a headless CLI Single-IP Military-Grade VLAN provisioning run
./launcher.sh run --provision-ip 192.168.1.1 --vlan-id AUTO

# 7. Emit CMMC 2.0 L1/L2, DISA STIG & IEEE 802.3/802.11w compliance attestations
./launcher.sh run --compliance-check

# 8. Export STIX 2.1 & TAXII 2.1 threat intelligence bundle
./launcher.sh run --export-stix

# 9. Verify native engine vs. pure-Python fallback health status
./launcher.sh run --health-check

# 10. Inspect user-scoped session telemetry logs
cat ~/.cache/nestpatch/session.log  # Windows: type %LOCALAPPDATA%\nestpatch\session.log
```

---
*CyberNest Holdings LLC — Authorized Security Engineering Standard.*
