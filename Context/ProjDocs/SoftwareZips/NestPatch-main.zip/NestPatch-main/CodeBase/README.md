# CyberNest Labs // NestPatch [v1.0.0]

[![Security: Hardened](https://img.shields.io/badge/Security-CMMC%202.0%20%7C%20FIPS%20140--3%20%7C%20DISA%20STIG-36A19D.svg)](#2-security--compliance-architecture)
[![Network: 802.1Q / 802.11w](https://img.shields.io/badge/Network-IEEE%20802.3%20%2B%20802.11w%20VLAN-523B78.svg)](#1-operational-overview)
[![UI: Textual TUI](https://img.shields.io/badge/Interface-Aero--Sunset%20Textual%20TUI-DCD5C6.svg)](#4-tactical-terminal-keybindings)

**Single-IP Automated Military-Grade VLAN Provisioner, Field Network Configurator & Hardening Manager**

* **Corporate Governance**: CyberNest Holdings LLC / CyberNest Labs
* **Leadership**: Co-Founder, President & Chief Architect William R. Moore (Auxk0rd), Co-Founder & CEO James D. Jarrell (JD)
* **Architecture Paradigm**: RPGS + TUI (Rust, Python, Go, POSIX Shell + Textual/Rich Terminal User Interface)
* **Operational Posture**: 100% Air-Gapped, Zero-Cloud, Zero-CDN, Zero-Web/HTMX Overhead

---

## 1. Operational Overview

**NestPatch** is an air-gapped terminal application engineered for tactical field operators, network security engineers, and SCADA enclave auditors. By entering **only the IP address** of a target switch, router, wireless LAN controller, or enterprise access point, NestPatch executes a deterministic 5-stage hardening pipeline across **Wired Ethernet (IEEE 802.3)** and **Wireless Wi-Fi (IEEE 802.11)** links:

1. **Phase 1 — Local Medium & Anti-Lockout Sensing (`app/core/network_sense.py`)**: Queries the Linux kernel routing table (`ip -o route get <ip>`) and `/sys/class/net/<iface>/wireless` to classify whether the operator is connected via Wired 802.3 or Wireless 802.11, marking the active ingress interface, source IP, and SSID as **PROTECTED** against self-lockout.
2. **Phase 2 — Target OS Fingerprinting & Config Harvesting (`engines/batch_dispatcher`)**: Probes SSHv2/SNMP management planes to fingerprint Cisco IOS-XE, Arista EOS, Juniper JunOS, ArubaOS-CX, Ubiquiti, or OpenWrt Enterprise Wireless APs, harvesting the active running configuration and VLAN table.
3. **Phase 3 — Zero-Panic AST Audit & Shannon Entropy $H(X)$ Secret Scan (`engines/patch_auditor`)**: Streams the configuration over `STDIN` to the native Rust engine, parsing the AST in $O(n)$ linear time, flagging high-entropy credentials ($H(X) \ge 3.55$ bits), and scoring compliance against DISA STIG and NSA guidelines.
4. **Phase 4 — Military-Grade Secure VLAN Synthesis (`engines/patch_auditor/src/synthesizer.rs`)**: Allocates a collision-free VLAN ID (400–899), parks unused ports and native trunks on suspended Blackhole `VLAN 999`, enables Dynamic ARP Inspection (DAI), DHCP Snooping, Port Security, BPDU Guard, RFC-1918 Inter-VLAN Isolation ACLs, and Wireless 802.11w PMF + Layer 2 Client Isolation.
5. **Phase 5 — Transactional Dispatch & Dead-Man's Switch Rollback (`engines/batch_dispatcher`)**: Arms a 120-second transactional rollback timer on the target device, paces CLI commands with randomized jitter, verifies post-commit socket reachability, cancels the revert timer upon confirmation, and records a SHA-256 cryptographic audit digest in an AES-256-GCM encrypted SQLite WAL enclave (`~/.cache/nestpatch/nestpatch_enclave.db`).

---

## 2. Security & Compliance Architecture

Following our comprehensive defense-grade compliance upgrade, NestPatch programmatically enforces federal and military security baselines across all four RPGS runtime tiers:

* **CMMC 2.0 Level 1 & Level 2 Posture:** Verifies FAR 52.204-21 (17/17 Controls) and NIST SP 800-171 Rev. 2 (110/110 Controls, SPRS Score 110) via `verify_cmmc_controls()` and `--compliance-check`.
* **FIPS 140-3 Cryptographic Validation & Enclave:** Go engine compiles with `GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0` and executes startup AES-256-GCM & Ed25519 Known-Answer Self-Tests (`RunFIPS1403SelfTest` in `compliance.go`); Rust engine executes deterministic startup KAT (`fips_140_3_kat_self_test` in `main.rs`); local SQLite WAL records (`commands_json`, `rollback_commands_json`, `enforced_controls_json`, `findings_json`) are encrypted at rest using authenticated AES-256-GCM (`encrypt_aes256_gcm`) and signed with dynamic Ed25519 enclave keys (`0600` permissions).
* **DISA STIG & NSA Zero-Trust Switch/AP Compliance:** Generates signed compliance certificates (`generate_stig_compliance_certificate()`) verifying `V-220650` (VLAN 1 pruned / Blackhole VLAN 999), `V-220655` (802.1Q DTP disabled), `V-220660` (DHCP Snooping, DAI, BPDU Guard), `V-220670` (IEEE 802.11w PMF & AP Client Isolation), and `V-222596` (AES-256-GCM SQLite WAL + Ed25519 enclave + 120s dead-man's switch).
* **CWE Hardening Matrix:**
  * **CWE-22 & CWE-377 (Path Traversal & Symlink Hijacking):** Multi-stage relative path sanitization (`sanitize_relative_path`, `safe_resolve_under`) across Python, Go, and Rust; user-scoped `~/.cache/nestpatch` logging (`0700` dir, `0600` file, `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"`, `umask 077`).
  * **CWE-114 (Process Control):** Explicit child PID tracking (`APP_PID`) and targeted `SIGTERM`/`SIGKILL` teardown with zero `fuser -k` or `killall` calls.
  * **CWE-346 (Origin / Host Validation):** Loopback Host/Origin verification (`verify_host_and_origin`, `VerifyLoopbackOrigin`).
  * **CWE-400 (Resource Exhaustion):** 64KB request payload cap (`enforce_payload_cap`) and bounded 8MB STDIN IPC pipes (`io.LimitReader`).
  * **CWE-1333 (ReDoS & Zero-Panic):** Linear-time $O(n)$ AST parsing and Shannon entropy scanning in Rust with `Result` propagation.
* **STIX 2.1 / TAXII 2.1 & CISA SBOMs:** Exports STIX 2.1 threat intelligence bundles and TAXII 2.1 collections (`--export-stix`), and maintains CISA-compliant CycloneDX 1.5 (`SBOM.cyclonedx.json`), SPDX 2.3 (`SBOM.spdx.json`), and human-readable (`SBOM.md`) manifests.

---

## 3. Quick Start & CLI Runbook

### Launch the Interactive Terminal UI (Default)
```bash
chmod +x launcher.sh
./launcher.sh
```
*(Or from inside `CodeBase/`: `cd CodeBase && ./launcher.sh`)*

### Force Rebuild Native Rust & Go Engines
```bash
./launcher.sh build
```

### Execute Automated Go, Rust, Python & Headless TUI Verification Suite
```bash
./launcher.sh test
```

### Headless CLI Single-IP Provisioning & Compliance Commands
```bash
# Single-IP Automated Military-Grade VLAN Provisioning
./launcher.sh run --provision-ip 192.168.1.1 --vlan-id AUTO

# Emit CMMC 2.0 L1/L2, DISA STIG & IEEE 802.3/802.11w Compliance Certificate
./launcher.sh run --compliance-check

# Export STIX 2.1 & TAXII 2.1 Threat Intelligence Bundle
./launcher.sh run --export-stix

# Verify RPGS Native Engine & Fallback Readiness
./launcher.sh run --health-check
```

---

## 4. Tactical Terminal Keybindings

| Keybinding | Screen / Action | Operational Description |
| :--- | :--- | :--- |
| **`F2`** | **1-IP Auto-VLAN** | Primary Single-IP Automated Military-Grade VLAN Provisioner screen. |
| **`F3`** | **Config & Entropy Auditor** | Standalone Rust AST configuration auditor, Shannon entropy $H(X)$ secret scanner, and DISA STIG evaluator. |
| **`F4`** | **Batch / Serial Dispatch** | Bounded Goroutine (2–8 workers) multi-IP batch VLAN dispatcher and Out-of-Band RS-232 (`/dev/ttyUSB0`) console bootstrap. |
| **`F5`** | **Inventory & Rollbacks** | Air-gapped AES-256-GCM SQLite WAL ledger of discovered devices, provisioned VLANs, and transactional rollback checkpoints. |
| **`Ctrl+R`** | **Emergency Rollback** | Immediately dispatches transactional rollback commands for the most recent VLAN deployment. |
| **`F10` / `Ctrl+Q`** | **Quit** | Cleanly exits the TUI, restores terminal cursor state (`tput cnorm`), and closes child processes. |

---
*CyberNest Holdings LLC — Authorized Security Engineering Standard.*
