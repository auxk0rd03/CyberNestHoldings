"""
CyberNest Labs — NestPatch Application Package.
Single-IP Automated Military-Grade VLAN Provisioner & Hardening Manager.
"""

__version__ = "1.0.0"
__author__ = "CyberNest Holdings LLC (William R. Moore / Auxk0rd & James D. Jarrell / JD)"
