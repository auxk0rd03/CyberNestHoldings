"""
NestPatch Core Orchestration, Security, Persistence & IPC Package.
"""
