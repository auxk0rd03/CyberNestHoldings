"""
NestPatch Central Configuration, Aero-Sunset Color Tokens, STIG Baselines & Limits.
CyberNest Holdings LLC — Authorized Security Engineering Standard.
"""
import os
from pathlib import Path
from typing import Dict, Tuple

APP_NAME = "nestpatch"
APP_TITLE = "CYBERNEST LABS // NESTPATCH"
APP_SUBTITLE = "Single-IP Automated Military-Grade VLAN Provisioner & Hardening Manager [v1.0.0]"
APP_VERSION = "1.0.0"

# Base filesystem paths
CODEBASE_DIR: Path = Path(__file__).resolve().parent.parent.parent
BIN_DIR: Path = CODEBASE_DIR / "bin"
STYLES_DIR: Path = CODEBASE_DIR / "app" / "tui" / "styles"

_default_cache = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), APP_NAME) if os.name == "nt" else os.path.expanduser(f"~/.cache/{APP_NAME}")
# User-scoped air-gapped cache & encrypted SQLite storage (~/.cache/nestpatch or %LOCALAPPDATA%\nestpatch)
USER_CACHE_DIR: Path = Path(
    os.environ.get("NESTPATCH_DATA_DIR", _default_cache)
)
DB_PATH: Path = USER_CACHE_DIR / "nestpatch_enclave.db"
SESSION_LOG_PATH: Path = USER_CACHE_DIR / "session.log"

_EXE_SUFFIX = ".exe" if os.name == "nt" else ""
# Native compiled binary paths
RUST_AUDITOR_BIN: Path = BIN_DIR / f"patch_auditor{_EXE_SUFFIX}"
GO_DISPATCHER_BIN: Path = BIN_DIR / f"batch_dispatcher{_EXE_SUFFIX}"

# CyberNest Aero-Sunset Palette Tokens (Section 5.1 of Specification)
AERO_SUNSET_TOKENS: Dict[str, str] = {
    "bg_space": "#0d0814",
    "bg_surface": "#241936",
    "accent_purple": "#8142db",
    "accent_magenta": "#c93b93",
    "accent_orange": "#ff7536",
    "text_main": "#f0e6f7",
    "text_muted": "#a695b8",
    "status_critical": "#ff3366",
}

# Military-Grade VLAN & STIG Security Defaults
RESERVED_VLANS: Tuple[int, ...] = (1, 999, 1002, 1003, 1004, 1005)
BLACKHOLE_VLAN_ID: int = 999
BLACKHOLE_VLAN_NAME: str = "CN_BLACKHOLE_DEAD_VLAN"
DEFAULT_VLAN_POOL_START: int = 400
DEFAULT_VLAN_POOL_END: int = 899
DEFAULT_DEADMAN_REVERT_SECS: int = 120
DEFAULT_ENTROPY_THRESHOLD: float = 3.55
MAX_CONFIG_PAYLOAD_BYTES: int = 8 * 1024 * 1024  # 8 MB ceiling for STDIN streams

SUPPORTED_VENDORS: Tuple[Tuple[str, str], ...] = (
    ("Auto-Detect (Fingerprint Target IP)", ""),
    ("Cisco IOS-XE / Catalyst / NX-OS", "cisco_ios"),
    ("Arista EOS CloudVision / Leaf", "arista_eos"),
    ("Juniper JunOS Enterprise", "juniper_junos"),
    ("OpenWrt / Enterprise 802.11ax Wireless AP", "openwrt_wireless"),
    ("ArubaOS-CX / Wireless Controller", "aruba_os"),
    ("Ubiquiti EdgeOS / UniFi Switch", "ubiquiti"),
)

AUTH_PROFILES: Tuple[Tuple[str, str], ...] = (
    ("SSHv2 Ed25519 Key / Tactical Admin", "ssh_ed25519_admin"),
    ("SSHv2 + TACACS+ Enclave Profile", "ssh_tacacs_enclave"),
    ("SNMPv3 AuthPriv + SSHv2 Hybrid", "snmpv3_ssh_hybrid"),
    ("Out-of-Band RS-232 / USB Serial", "serial_oob_console"),
)


def ensure_storage_directories() -> Path:
    """Ensures user-scoped directory (~/.cache/nestpatch) exists with 0700 permissions."""
    USER_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(USER_CACHE_DIR, 0o700)
    except OSError:
        pass
    return USER_CACHE_DIR
