"""
NestPatch Air-Gapped SQLite Relational Persistence Engine (database.py).
Manages discovered devices, provisioned Military-Grade VLANs, STIG compliance audits,
and transactional dead-man's switch rollback ledgers.
"""
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import aiosqlite

from app.core.config import DB_PATH, ensure_storage_directories
from app.core.security import decrypt_aes256_gcm, encrypt_aes256_gcm


def _encrypt_json_list(data: Any) -> str:
    """Encrypts a JSON-serializable list/object using authenticated AES-256-GCM (MP.L2-3.8.1)."""
    raw_json = json.dumps(data if data is not None else []).encode("utf-8")
    return encrypt_aes256_gcm(raw_json)


def _decrypt_json_list(payload: str) -> List[Any]:
    """Decrypts an AES-256-GCM token or falls back to legacy plaintext JSON array."""
    if not payload:
        return []
    try:
        decrypted = decrypt_aes256_gcm(payload).decode("utf-8")
        return json.loads(decrypted)
    except Exception:
        try:
            return json.loads(payload)
        except Exception:
            return []

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS devices (
    target_ip TEXT PRIMARY KEY,
    hostname TEXT NOT NULL,
    vendor_platform TEXT NOT NULL,
    hardware_model TEXT NOT NULL,
    os_version TEXT NOT NULL,
    medium_type TEXT NOT NULL,
    egress_interface TEXT NOT NULL,
    operator_source_ip TEXT NOT NULL,
    operator_mac TEXT NOT NULL,
    wireless_ssid TEXT,
    compliance_score INTEGER DEFAULT 0,
    last_seen_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS provisioned_vlans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_ip TEXT NOT NULL,
    vlan_id INTEGER NOT NULL,
    blackhole_vlan_id INTEGER NOT NULL,
    vlan_name TEXT NOT NULL,
    subnet_cidr TEXT NOT NULL,
    gateway_ip TEXT NOT NULL,
    medium_type TEXT NOT NULL,
    vendor_platform TEXT NOT NULL,
    dai_enabled INTEGER DEFAULT 1,
    dhcp_snooping INTEGER DEFAULT 1,
    bpdu_guard INTEGER DEFAULT 1,
    client_isolation INTEGER DEFAULT 0,
    pmf_80211w INTEGER DEFAULT 0,
    status TEXT NOT NULL,
    audit_hash TEXT NOT NULL,
    commands_json TEXT NOT NULL,
    rollback_commands_json TEXT NOT NULL,
    enforced_controls_json TEXT NOT NULL,
    provisioned_at_utc TEXT NOT NULL,
    FOREIGN KEY(target_ip) REFERENCES devices(target_ip) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_ip TEXT NOT NULL,
    hostname TEXT NOT NULL,
    vendor_platform TEXT NOT NULL,
    compliance_score INTEGER NOT NULL,
    passed_rules INTEGER NOT NULL,
    failed_rules INTEGER NOT NULL,
    warning_rules INTEGER NOT NULL,
    entropy_count INTEGER NOT NULL,
    findings_json TEXT NOT NULL,
    entropy_findings_json TEXT NOT NULL,
    audited_at_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rollbacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_ip TEXT NOT NULL,
    vlan_id INTEGER NOT NULL,
    vlan_name TEXT NOT NULL,
    revert_timer_secs INTEGER NOT NULL,
    rollback_commands_json TEXT NOT NULL,
    rollback_status TEXT NOT NULL,
    audit_hash TEXT NOT NULL,
    created_at_utc TEXT NOT NULL
);
"""


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


class NestPatchDatabase:
    """Provides both synchronous and asynchronous SQLite access for TUI and CLI flows."""

    def __init__(self, db_path: Optional[Path] = None) -> None:
        ensure_storage_directories()
        self.db_path: Path = db_path or DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_sync()

    def init_sync(self) -> None:
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.executescript(SCHEMA_SQL)
            conn.commit()
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass

    async def init_async(self) -> None:
        async with aiosqlite.connect(str(self.db_path)) as db:
            await db.executescript(SCHEMA_SQL)
            await db.commit()

    async def record_provisioning_transaction(
        self,
        sense: Dict[str, Any],
        fingerprint: Dict[str, Any],
        audit_synth: Dict[str, Any],
        deploy: Dict[str, Any],
    ) -> int:
        """Persists a full 5-stage Single-IP VLAN provisioning pipeline execution."""
        now = _utc_now()
        target_ip = sense.get("target_ip") or fingerprint.get("target_ip") or "192.168.1.1"
        medium = sense.get("medium_type", "WIRED_802_3")
        is_wireless = 1 if (medium == "WIRELESS_802_11" or audit_synth.get("vendor_platform") == "openwrt_wireless") else 0

        async with aiosqlite.connect(str(self.db_path)) as db:
            await db.execute(
                """
                INSERT INTO devices (
                    target_ip, hostname, vendor_platform, hardware_model, os_version,
                    medium_type, egress_interface, operator_source_ip, operator_mac,
                    wireless_ssid, compliance_score, last_seen_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(target_ip) DO UPDATE SET
                    hostname=excluded.hostname,
                    vendor_platform=excluded.vendor_platform,
                    hardware_model=excluded.hardware_model,
                    os_version=excluded.os_version,
                    medium_type=excluded.medium_type,
                    egress_interface=excluded.egress_interface,
                    operator_source_ip=excluded.operator_source_ip,
                    operator_mac=excluded.operator_mac,
                    wireless_ssid=excluded.wireless_ssid,
                    compliance_score=excluded.compliance_score,
                    last_seen_utc=excluded.last_seen_utc
                """,
                (
                    target_ip,
                    audit_synth.get("hostname") or fingerprint.get("hostname", "UNKNOWN"),
                    audit_synth.get("vendor_platform") or fingerprint.get("vendor_platform", "cisco_ios"),
                    fingerprint.get("hardware_model", "Enterprise Switch"),
                    fingerprint.get("os_version", "IOS-XE"),
                    medium,
                    sense.get("egress_interface", "eth0"),
                    sense.get("source_ip", "0.0.0.0"),
                    sense.get("local_mac", "00:00:00:00:00:00"),
                    sense.get("wireless_ssid"),
                    int(audit_synth.get("compliance_score", 0)),
                    now,
                ),
            )

            cursor = await db.execute(
                """
                INSERT INTO provisioned_vlans (
                    target_ip, vlan_id, blackhole_vlan_id, vlan_name, subnet_cidr,
                    gateway_ip, medium_type, vendor_platform, dai_enabled, dhcp_snooping,
                    bpdu_guard, client_isolation, pmf_80211w, status, audit_hash,
                    commands_json, rollback_commands_json, enforced_controls_json, provisioned_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    target_ip,
                    int(audit_synth.get("allocated_vlan_id", 400)),
                    int(audit_synth.get("blackhole_vlan_id", 999)),
                    str(audit_synth.get("vlan_name", "CN_MIL_SEC_400")),
                    str(audit_synth.get("isolated_subnet_cidr", "10.240.150.0/24")),
                    str(audit_synth.get("gateway_address", "10.240.150.1")),
                    medium,
                    str(audit_synth.get("vendor_platform", "cisco_ios")),
                    1,
                    1,
                    1,
                    is_wireless,
                    is_wireless,
                    str(deploy.get("status", "SUCCESS_LOCKED")),
                    str(deploy.get("audit_hash", "")),
                    _encrypt_json_list(audit_synth.get("commands", [])),
                    _encrypt_json_list(audit_synth.get("rollback_commands", [])),
                    _encrypt_json_list(audit_synth.get("enforced_controls", [])),
                    now,
                ),
            )
            vlan_row_id = cursor.lastrowid or 0

            await db.execute(
                """
                INSERT INTO audits (
                    target_ip, hostname, vendor_platform, compliance_score,
                    passed_rules, failed_rules, warning_rules, entropy_count,
                    findings_json, entropy_findings_json, audited_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    target_ip,
                    str(audit_synth.get("hostname", "UNKNOWN")),
                    str(audit_synth.get("vendor_platform", "cisco_ios")),
                    int(audit_synth.get("compliance_score", 0)),
                    int(audit_synth.get("passed_rules", 0)),
                    int(audit_synth.get("failed_rules", 0)),
                    int(audit_synth.get("warning_rules", 0)),
                    len(audit_synth.get("entropy_findings", [])),
                    _encrypt_json_list(audit_synth.get("findings", [])),
                    _encrypt_json_list(audit_synth.get("entropy_findings", [])),
                    now,
                ),
            )

            await db.execute(
                """
                INSERT INTO rollbacks (
                    target_ip, vlan_id, vlan_name, revert_timer_secs,
                    rollback_commands_json, rollback_status, audit_hash, created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    target_ip,
                    int(audit_synth.get("allocated_vlan_id", 400)),
                    str(audit_synth.get("vlan_name", "CN_MIL_SEC_400")),
                    int(deploy.get("revert_timer_secs", 120)),
                    _encrypt_json_list(audit_synth.get("rollback_commands", [])),
                    "ARMED_VERIFIED_COMMITTED",
                    str(deploy.get("audit_hash", "")),
                    now,
                ),
            )
            await db.commit()
            return int(vlan_row_id)

    async def record_standalone_audit(self, target_ip: str, audit_res: Dict[str, Any]) -> int:
        now = _utc_now()
        async with aiosqlite.connect(str(self.db_path)) as db:
            cur = await db.execute(
                """
                INSERT INTO audits (
                    target_ip, hostname, vendor_platform, compliance_score,
                    passed_rules, failed_rules, warning_rules, entropy_count,
                    findings_json, entropy_findings_json, audited_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    target_ip,
                    str(audit_res.get("hostname", "STANDALONE-CFG")),
                    str(audit_res.get("vendor_platform", "cisco_ios")),
                    int(audit_res.get("compliance_score", 0)),
                    int(audit_res.get("passed_rules", 0)),
                    int(audit_res.get("failed_rules", 0)),
                    int(audit_res.get("warning_rules", 0)),
                    len(audit_res.get("entropy_findings", [])),
                    _encrypt_json_list(audit_res.get("findings", [])),
                    _encrypt_json_list(audit_res.get("entropy_findings", [])),
                    now,
                ),
            )
            await db.commit()
            return int(cur.lastrowid or 0)

    async def mark_rollback_executed(self, rollback_id: int) -> Optional[Dict[str, Any]]:
        async with aiosqlite.connect(str(self.db_path)) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM rollbacks WHERE id = ?", (rollback_id,)) as cur:
                row = await cur.fetchone()
                if not row:
                    return None
                record = dict(row)
            await db.execute(
                "UPDATE rollbacks SET rollback_status = 'ROLLED_BACK_REVERTED' WHERE id = ?",
                (rollback_id,),
            )
            await db.execute(
                "UPDATE provisioned_vlans SET status = 'ROLLED_BACK' WHERE target_ip = ? AND vlan_id = ?",
                (record["target_ip"], record["vlan_id"]),
            )
            await db.commit()
            record["rollback_commands"] = _decrypt_json_list(record.get("rollback_commands_json", ""))
            return record

    async def list_provisioned_vlans(self, limit: int = 50) -> List[Dict[str, Any]]:
        async with aiosqlite.connect(str(self.db_path)) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM provisioned_vlans ORDER BY id DESC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
                result = []
                for r in rows:
                    item = dict(r)
                    item["commands"] = _decrypt_json_list(item.get("commands_json", ""))
                    item["rollback_commands"] = _decrypt_json_list(item.get("rollback_commands_json", ""))
                    item["enforced_controls"] = _decrypt_json_list(item.get("enforced_controls_json", ""))
                    result.append(item)
                return result

    async def list_devices(self, limit: int = 50) -> List[Dict[str, Any]]:
        async with aiosqlite.connect(str(self.db_path)) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM devices ORDER BY last_seen_utc DESC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
                return [dict(r) for r in rows]

    async def list_rollbacks(self, limit: int = 50) -> List[Dict[str, Any]]:
        async with aiosqlite.connect(str(self.db_path)) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM rollbacks ORDER BY id DESC LIMIT ?", (limit,)
            ) as cur:
                rows = await cur.fetchall()
                out = []
                for r in rows:
                    d = dict(r)
                    d["rollback_commands"] = _decrypt_json_list(d.get("rollback_commands_json", ""))
                    out.append(d)
                return out
