"""
NestPatch Resilient Boundary-Aware Subprocess IPC Bridge (engine_bridge.py).
Streams payloads strictly over STDIN/STDOUT (mitigating CWE-400 ARG_MAX overflow),
parses outermost valid JSON via `extract_outermost_json()`, and automatically falls
back to pure-Python implementations when compiled Rust/Go binaries are absent.
"""
import asyncio
import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from app.core.config import BIN_DIR, GO_DISPATCHER_BIN, MAX_CONFIG_PAYLOAD_BYTES, RUST_AUDITOR_BIN
from app.fallbacks.python_auditor import synthesize_military_grade_vlan_py
from app.fallbacks.python_dispatcher import fallback_batch_dispatcher


def extract_outermost_json(raw_text: str) -> Any:
    """
    Scans stdout for the outermost valid JSON structure ({...} or [...]),
    ignoring preceding compiler warnings, debug lines, or panic traces.
    """
    if not raw_text or not raw_text.strip():
        raise ValueError("No valid JSON payload detected in empty stdout stream.")
    decoder = json.JSONDecoder()
    for match in re.finditer(r"[\{\[]", raw_text):
        start_idx = match.start()
        try:
            obj, _ = decoder.raw_decode(raw_text[start_idx:])
            return obj
        except json.JSONDecodeError:
            continue
    raise ValueError("No valid JSON payload detected in stdout stream.")


def check_engine_health() -> Dict[str, Dict[str, Any]]:
    """Checks whether the native Rust and Go binaries exist and are executable."""
    rust_ok = os.path.isfile(RUST_AUDITOR_BIN) and os.access(RUST_AUDITOR_BIN, os.X_OK)
    go_ok = os.path.isfile(GO_DISPATCHER_BIN) and os.access(GO_DISPATCHER_BIN, os.X_OK)
    return {
        "rust_auditor": {
            "binary": str(RUST_AUDITOR_BIN),
            "online": rust_ok,
            "mode": "NATIVE_RUST" if rust_ok else "PYTHON_FALLBACK",
        },
        "go_dispatcher": {
            "binary": str(GO_DISPATCHER_BIN),
            "online": go_ok,
            "mode": "NATIVE_GO" if go_ok else "PYTHON_FALLBACK",
        },
    }


def run_engine_binary(
    binary_name: str,
    args: List[str],
    fallback_handler: Callable[..., Dict[str, Any]],
    timeout_secs: int = 45,
    stdin_payload: Optional[Dict[str, Any]] = None,
    bin_dir_override: Optional[Path] = None,
    *fallback_args: Any,
    **fallback_kwargs: Any,
) -> Dict[str, Any]:
    """
    Executes compiled binary engines over STDIN/STDOUT with automatic transparent fallback
    to pure Python implementations if binaries are missing, exit non-zero, or fail JSON parsing.
    """
    target_bin_dir = bin_dir_override if bin_dir_override is not None else BIN_DIR
    bin_path = os.path.join(str(target_bin_dir), binary_name)

    if not os.path.isfile(bin_path) or not os.access(bin_path, os.X_OK):
        return fallback_handler(*fallback_args, **fallback_kwargs)

    stdin_str: Optional[str] = None
    if stdin_payload is not None:
        stdin_str = json.dumps(stdin_payload)
        if len(stdin_str.encode("utf-8")) > MAX_CONFIG_PAYLOAD_BYTES:
            raise ValueError("Configuration payload exceeds maximum STDIN buffer limit (8 MB).")

    cmd = [bin_path] + list(args)
    try:
        proc = subprocess.run(
            cmd,
            input=stdin_str,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout_secs,
            check=True,
        )
        parsed = extract_outermost_json(proc.stdout)
        if isinstance(parsed, dict) and parsed.get("status") == "ERROR":
            return fallback_handler(*fallback_args, **fallback_kwargs)
        return parsed
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError, OSError):
        return fallback_handler(*fallback_args, **fallback_kwargs)


def invoke_rust_auditor(
    payload: Dict[str, Any],
    timeout_secs: int = 30,
    bin_dir_override: Optional[Path] = None,
) -> Dict[str, Any]:
    """Synchronous wrapper for `bin/patch_auditor` with `python_auditor` fallback."""
    return run_engine_binary(
        "patch_auditor",
        [],
        synthesize_military_grade_vlan_py,
        timeout_secs,
        payload,
        bin_dir_override,
        payload,
    )


def invoke_go_dispatcher(
    payload: Dict[str, Any],
    timeout_secs: int = 45,
    bin_dir_override: Optional[Path] = None,
) -> Dict[str, Any]:
    """Synchronous wrapper for `bin/batch_dispatcher` with `python_dispatcher` fallback."""
    return run_engine_binary(
        "batch_dispatcher",
        [],
        fallback_batch_dispatcher,
        timeout_secs,
        payload,
        bin_dir_override,
        payload,
    )


async def invoke_rust_auditor_async(
    payload: Dict[str, Any],
    timeout_secs: int = 30,
    bin_dir_override: Optional[Path] = None,
) -> Dict[str, Any]:
    """Non-blocking asyncio executor wrapper for the Rust Patch Auditor & Synthesizer."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, invoke_rust_auditor, payload, timeout_secs, bin_dir_override
    )


async def invoke_go_dispatcher_async(
    payload: Dict[str, Any],
    timeout_secs: int = 45,
    bin_dir_override: Optional[Path] = None,
) -> Dict[str, Any]:
    """Non-blocking asyncio executor wrapper for the Go Batch Dispatcher."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, invoke_go_dispatcher, payload, timeout_secs, bin_dir_override
    )
