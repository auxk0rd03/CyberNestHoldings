"""
NestPatch Master 5-Stage Single-IP Automated Military-Grade VLAN Orchestrator.
Coordinates:
  Stage 1: Local Medium & Anti-Lockout Sensing (network_sense.py)
  Stage 2: Target IP Fingerprinting & Discovery (Go: batch_dispatcher)
  Stage 3: Zero-Panic Config Audit & Entropy Analysis (Rust: patch_auditor)
  Stage 4: Military-Grade VLAN Synthesis (Rust: synthesizer.rs)
  Stage 5: Transactional Dispatch & Dead-Man's Switch Rollback Verification (Go: batch_dispatcher)
"""
import asyncio
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from app.core.config import DEFAULT_DEADMAN_REVERT_SECS, DEFAULT_ENTROPY_THRESHOLD
from app.core.database import NestPatchDatabase
from app.core.engine_bridge import invoke_go_dispatcher_async, invoke_rust_auditor_async
from app.core.network_sense import detect_ingress_medium
from app.core.security import validate_ip_address, validate_vlan_id, verify_anti_lockout_guard

StageCallback = Optional[Callable[[int, str, str], None]]
LogCallback = Optional[Callable[[str, str], None]]


def _ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


class VlanProvisioningOrchestrator:
    """Executes the deterministic 5-stage Single-IP Military-Grade VLAN Pipeline."""

    def __init__(self, database: Optional[NestPatchDatabase] = None) -> None:
        self.db = database or NestPatchDatabase()

    async def execute_single_ip_pipeline(
        self,
        raw_target_ip: str,
        desired_vlan_input: Optional[str | int] = "AUTO",
        vendor_hint: str = "",
        auth_profile: str = "ssh_ed25519_admin",
        revert_timer_secs: int = DEFAULT_DEADMAN_REVERT_SECS,
        fast_mode: bool = True,
        on_stage: StageCallback = None,
        on_log: LogCallback = None,
    ) -> Dict[str, Any]:
        def emit_stage(stage_idx: int, status: str, detail: str = "") -> None:
            if on_stage:
                on_stage(stage_idx, status, detail)

        def emit_log(tag: str, message: str) -> None:
            if on_log:
                on_log(tag, f"{_ts()} [{tag}] {message}")

        # Validate inputs before touching any network interface
        target_ip = validate_ip_address(raw_target_ip)
        desired_vlan_id = validate_vlan_id(desired_vlan_input)

        # ======================================================================
        # STAGE 1: Local Medium & Anti-Lockout Sensing (network_sense.py)
        # ======================================================================
        emit_stage(1, "ACTIVE", "Inspecting kernel route & NIC medium...")
        emit_log("SENSE", f"Querying local kernel routing table for target {target_ip}...")
        loop = asyncio.get_running_loop()
        ingress_profile = await loop.run_in_executor(None, detect_ingress_medium, target_ip)
        sense_dict = ingress_profile.to_dict()

        medium_badge = (
            f"WIRELESS 802.11 ({ingress_profile.wireless_ssid})"
            if ingress_profile.medium_type == "WIRELESS_802_11"
            else "WIRED 802.3 ETHERNET"
        )
        emit_log(
            "SENSE",
            f"Egress via {ingress_profile.egress_interface} [{medium_badge}] | Src IP: {ingress_profile.source_ip} (PROTECTED)",
        )
        emit_stage(1, "OK", f"{ingress_profile.egress_interface} ({ingress_profile.medium_type})")

        # ======================================================================
        # STAGE 2: Target IP Fingerprinting & Discovery (Go: batch_dispatcher)
        # ======================================================================
        emit_stage(2, "ACTIVE", "Probing SSH/SNMP banners & harvesting config...")
        emit_log("PROBE", f"Dispatching Go fingerprinter against {target_ip}...")
        fp_req = {
            "action": "fingerprint",
            "target_ip": target_ip,
            "medium_type": ingress_profile.medium_type,
            "auth_profile": auth_profile,
            "vendor_hint": vendor_hint,
            "timeout_ms": 250,
        }
        fp_res = await invoke_go_dispatcher_async(fp_req)
        for line in fp_res.get("probe_transcript", []):
            emit_log("PROBE", line.replace("[PROBE] ", "").replace("[FINGERPRINT] ", "").replace("[HARVEST] ", ""))
        emit_stage(2, "OK", f"{fp_res.get('hardware_model', 'Switch')} ({fp_res.get('vendor_platform', 'cisco_ios')})")

        # ======================================================================
        # STAGE 3 & 4: Zero-Panic Audit & Military-Grade VLAN Synthesis (Rust)
        # ======================================================================
        emit_stage(3, "ACTIVE", "Streaming config to Rust AST & Shannon Entropy engine...")
        emit_log("RUST", "Streaming harvested running-config over STDIN to bin/patch_auditor...")
        rust_req = {
            "action": "audit_and_synthesize",
            "target_ip": target_ip,
            "vendor_platform": vendor_hint or fp_res.get("vendor_platform", "cisco_ios"),
            "medium_type": ingress_profile.medium_type,
            "operator_mac": ingress_profile.local_mac,
            "operator_source_ip": ingress_profile.source_ip,
            "wireless_ssid": ingress_profile.wireless_ssid,
            "desired_vlan_id": desired_vlan_id,
            "existing_vlans": fp_res.get("existing_vlans", [1, 10, 20, 100]),
            "entropy_threshold": DEFAULT_ENTROPY_THRESHOLD,
            "running_config": fp_res.get("running_config", ""),
        }
        audit_synth = await invoke_rust_auditor_async(rust_req)

        parse_ms = audit_synth.get("parse_time_ms", 1.2)
        emit_log(
            "RUST",
            f"AST parsed in {parse_ms}ms (O(n) Thompson NFA) | Pre-Hardening STIG Score: {audit_synth.get('compliance_score', 0)}%",
        )

        for ef in audit_synth.get("entropy_findings", []):
            emit_log(
                "WARN",
                f"H(X)={ef['entropy_bits']} bits secret on line {ef['line_number']}: {ef['secret_type']} ({ef['redacted_preview']})",
            )

        emit_stage(3, "OK", f"Score {audit_synth.get('compliance_score', 0)}% | {len(audit_synth.get('entropy_findings', []))} Entropy Alerts")

        # Stage 4: Military-Grade VLAN Synthesis Verification
        emit_stage(4, "ACTIVE", "Synthesizing DISA STIG / NSA VLAN payload...")
        allocated_vlan = int(audit_synth.get("allocated_vlan_id", 400))
        subnet_cidr = audit_synth.get("isolated_subnet_cidr", "10.240.150.0/24")
        commands: List[str] = list(audit_synth.get("commands", []))

        verify_anti_lockout_guard(
            target_ip=target_ip,
            operator_source_ip=ingress_profile.source_ip,
            commands=commands,
            blackhole_vlan=int(audit_synth.get("blackhole_vlan_id", 999)),
        )

        emit_log(
            "SYNTH",
            f"Allocated VLAN {allocated_vlan} ({subnet_cidr}) + Blackhole VLAN {audit_synth.get('blackhole_vlan_id', 999)} ({len(commands)} STIG commands)",
        )
        emit_stage(4, "OK", f"VLAN {allocated_vlan} ({len(commands)} cmds)")

        # ======================================================================
        # STAGE 5: Transactional Dispatch & Rollback Guard (Go: batch_dispatcher)
        # ======================================================================
        emit_stage(5, "ACTIVE", f"Arming {revert_timer_secs}s Dead-Man Rollback & deploying...")
        emit_log("GO", f"Arming {revert_timer_secs}s transactional Dead-Man Rollback on {target_ip}...")
        deploy_req = {
            "action": "deploy",
            "target_ip": target_ip,
            "medium_type": ingress_profile.medium_type,
            "vendor_platform": audit_synth.get("vendor_platform", "cisco_ios"),
            "allocated_vlan_id": allocated_vlan,
            "commands": commands,
            "rollback_commands": audit_synth.get("rollback_commands", []),
            "revert_timer_secs": revert_timer_secs,
            "fast_mode": fast_mode,
        }
        deploy_res = await invoke_go_dispatcher_async(deploy_req)

        for t_line in deploy_res.get("transcript", []):
            # Keep log window concise while showing key execution milestones
            if any(k in t_line for k in ("[GUARD]", "[WIRELESS]", "[VERIFY]", "[COMMIT]", "[AUDIT]")) or "vlan " in t_line.lower():
                emit_log("GO", t_line)

        emit_stage(5, "OK", f"LOCKED ({deploy_res.get('reachability_check', 'PASSED_NO_LOCKOUT')})")

        # Persist complete record to local SQLite database
        record_id = await self.db.record_provisioning_transaction(
            sense=sense_dict,
            fingerprint=fp_res,
            audit_synth=audit_synth,
            deploy=deploy_res,
        )
        emit_log(
            "LOCK",
            f"Military-Grade VLAN {allocated_vlan} committed on {target_ip} (Ledger ID #{record_id}, Hash {deploy_res.get('audit_hash', '')[:16]})",
        )

        return {
            "record_id": record_id,
            "target_ip": target_ip,
            "sense": sense_dict,
            "fingerprint": fp_res,
            "audit_synth": audit_synth,
            "deploy": deploy_res,
        }

    async def execute_emergency_rollback(
        self,
        rollback_id: Optional[int] = None,
        on_log: LogCallback = None,
    ) -> Dict[str, Any]:
        """Triggers an immediate transactional rollback of the latest or specified VLAN deployment."""
        rollbacks = await self.db.list_rollbacks(limit=10)
        if not rollbacks:
            raise ValueError("No active rollback records found in the local ledger.")

        target_rb = rollbacks[0]
        if rollback_id is not None:
            for r in rollbacks:
                if int(r["id"]) == int(rollback_id):
                    target_rb = r
                    break

        if on_log:
            on_log(
                "ROLLBACK",
                f"{_ts()} [ROLLBACK] Initiating emergency revert for {target_rb['target_ip']} (VLAN {target_rb['vlan_id']})...",
            )

        res = await invoke_go_dispatcher_async(
            {
                "action": "rollback",
                "target_ip": target_rb["target_ip"],
                "allocated_vlan_id": target_rb["vlan_id"],
                "rollback_commands": target_rb["rollback_commands"],
                "revert_timer_secs": 60,
                "fast_mode": True,
            }
        )
        await self.db.mark_rollback_executed(int(target_rb["id"]))
        if on_log:
            on_log(
                "ROLLBACK",
                f"{_ts()} [ROLLBACK] Reverted VLAN {target_rb['vlan_id']} on {target_rb['target_ip']} -> {res.get('status')}",
            )
        return res
