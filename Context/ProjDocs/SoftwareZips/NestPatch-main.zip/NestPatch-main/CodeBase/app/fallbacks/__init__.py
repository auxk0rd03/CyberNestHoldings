"""
NestPatch Pure-Python Fallback Engines.
Provides 100% functional continuity when Rust or Go native binaries are absent.
"""
