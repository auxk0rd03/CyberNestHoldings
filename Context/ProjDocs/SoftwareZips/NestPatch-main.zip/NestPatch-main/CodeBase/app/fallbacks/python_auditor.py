"""
NestPatch Pure-Python Fallback Auditor & Military-Grade VLAN Synthesizer.
Mirrors the exact JSON IPC contract of `engines/patch_auditor` (Rust).
"""
import math
import time
from collections import Counter
from typing import Any, Dict, List, Optional, Set

from app.core.config import BLACKHOLE_VLAN_ID, RESERVED_VLANS


def calculate_shannon_entropy(token: str) -> float:
    """Computes Shannon Entropy H(X) = -sum(P(x_i) * log2(P(x_i))) in bits per symbol."""
    if not token:
        return 0.0
    raw = token.encode("utf-8")
    length = len(raw)
    counts = Counter(raw)
    entropy = -sum((count / length) * math.log2(count / length) for count in counts.values())
    return round(entropy, 3)


def redact_token(token: str) -> str:
    if len(token) <= 4:
        return "****"
    return f"{token[:2]}***[REDACTED len={len(token)}]***{token[-2:]}"


def select_safe_vlan_id(desired: Optional[int], existing: List[int]) -> int:
    occupied: Set[int] = set(existing) | set(RESERVED_VLANS)
    if desired is not None and 2 <= desired <= 4090 and desired not in occupied:
        return desired
    for candidate in range(400, 900):
        if candidate not in occupied:
            return candidate
    for candidate in range(100, 400):
        if candidate not in occupied:
            return candidate
    return 400


def scan_config_entropy(running_config: str, threshold: float = 3.55) -> List[Dict[str, Any]]:
    findings: List[Dict[str, Any]] = []
    eff_threshold = 3.55 if threshold <= 0.1 else threshold

    for idx, raw_line in enumerate(running_config.splitlines()):
        line_no = idx + 1
        trimmed = raw_line.strip()
        if not trimmed or trimmed.startswith(("!", "#")):
            continue
        lower = trimmed.lower()

        if any(p in lower for p in ("password 7 ", "password 0 ", "secret 0 ", "enable password ")):
            tokens = trimmed.split()
            last_tok = tokens[-1] if tokens else "secret"
            h = max(calculate_shannon_entropy(last_tok), 3.60)
            findings.append(
                {
                    "line_number": line_no,
                    "secret_type": "Legacy Cleartext / Reversible Type-7 Credential",
                    "entropy_bits": h,
                    "redacted_preview": redact_token(last_tok),
                    "severity": "CRITICAL",
                    "recommendation": "Migrate to algorithm-type scrypt / SHA-256 (secret 9 / secret 8) and purge reversible passwords.",
                }
            )
            continue

        if lower.startswith("snmp-server community ") or "community public" in lower or "community private" in lower:
            tokens = trimmed.split()
            comm = tokens[2] if len(tokens) > 2 else "public"
            findings.append(
                {
                    "line_number": line_no,
                    "secret_type": "Exposed SNMPv1/v2c Community String",
                    "entropy_bits": calculate_shannon_entropy(comm),
                    "redacted_preview": redact_token(comm),
                    "severity": "HIGH",
                    "recommendation": "Disable SNMPv1/v2c communities and enforce SNMPv3 with AuthPriv (SHA-256 + AES-128).",
                }
            )
            continue

        cred_context = any(
            k in lower
            for k in (
                "secret",
                "password",
                "wpa-psk",
                "pre-shared-key",
                "key-string",
                "radius-server key",
                "tacacs-server key",
                "api-key",
                "option key",
                ".key=",
            )
        )

        for raw_tok in trimmed.split():
            clean_tok = raw_tok.strip("\"',;")
            if ".key=" in clean_tok:
                clean_tok = clean_tok.split(".key=", 1)[-1].strip("\"',;")
            if len(clean_tok) < 8:
                continue
            if (
                "/" in clean_tok
                or clean_tok.startswith(("Gigabit", "TenGig", "Ethernet", "FastEthernet", "switchport", "spanning-tree", "description"))
                or all(c.isdigit() or c == "." for c in clean_tok)
            ):
                continue
            h = calculate_shannon_entropy(clean_tok)
            if (cred_context and h >= eff_threshold) or (len(clean_tok) >= 16 and h >= 4.05):
                findings.append(
                    {
                        "line_number": line_no,
                        "secret_type": "High-Entropy Embedded Key / Credential Material"
                        if cred_context
                        else "High-Entropy Cryptographic Token / Key Blob",
                        "entropy_bits": h,
                        "redacted_preview": redact_token(clean_tok),
                        "severity": "CRITICAL" if h >= 4.10 else "HIGH",
                        "recommendation": "Remove hardcoded secret from running-config or store in hardware-backed KMS / TACACS+ vault.",
                    }
                )
                break

    return findings


def parse_and_audit_config(
    running_config: str, vendor_hint: str = "", medium_type: str = "WIRED_802_3"
) -> Dict[str, Any]:
    hostname = "UNKNOWN-NODE"
    detected_vendor = vendor_hint or "cisco_ios"
    vlan_set: Set[int] = {1}
    interfaces: List[Dict[str, Any]] = []
    current_iface: Optional[Dict[str, Any]] = None

    has_dhcp_snooping = False
    has_arp_inspection = False
    has_bpduguard = False
    has_ssh_v2 = False
    has_telnet = False
    has_http = False
    has_default_vlan1_active = False
    has_blackhole_vlan = False
    has_inter_vlan_acl = False
    has_wireless_pmf = False
    has_wireless_isolation = False

    for raw_line in running_config.splitlines():
        trimmed = raw_line.strip()
        if not trimmed or trimmed.startswith(("!", "#")):
            continue
        lower = trimmed.lower()

        if lower.startswith("uci set ") or "config wifi-iface" in lower:
            detected_vendor = "openwrt_wireless"
        elif lower.startswith(("set interfaces ", "set vlans ")):
            detected_vendor = "juniper_junos"
        elif "arista" in lower or lower.startswith("daemon terminattr"):
            detected_vendor = "arista_eos"
        elif "aruba" in lower:
            detected_vendor = "aruba_os"

        if lower.startswith("hostname "):
            parts = trimmed.split()
            if len(parts) > 1:
                hostname = parts[1].strip('"')

        if lower.startswith("ip dhcp snooping") and not lower.startswith("no ip dhcp snooping"):
            has_dhcp_snooping = True
        if lower.startswith("ip arp inspection") and not lower.startswith("no ip arp inspection"):
            has_arp_inspection = True
        if "bpduguard default" in lower or "bpduguard enable" in lower:
            has_bpduguard = True
        if "ip ssh version 2" in lower or "ssh protocol-version v2" in lower or "dropbear" in lower:
            has_ssh_v2 = True
        if "transport input telnet" in lower or "transport input all" in lower or "services telnet" in lower:
            has_telnet = True
        if lower.startswith("ip http server"):
            has_http = True
        if "ip access-list extended" in lower or "firewall.zone_sec" in lower or "family inet filter" in lower:
            has_inter_vlan_acl = True
        if "ieee80211w='2'" in lower or "security pmf mandatory" in lower:
            has_wireless_pmf = True
        if "isolate='1'" in lower or "client-isolation enable" in lower:
            has_wireless_isolation = True

        if lower.startswith("vlan "):
            rest = trimmed[5:]
            for part in rest.split(","):
                tok = part.strip().split()[0] if part.strip() else ""
                if "-" in tok:
                    s_str, e_str = tok.split("-", 1)
                    if s_str.isdigit() and e_str.isdigit():
                        for v in range(int(s_str), min(int(e_str) + 1, int(s_str) + 65)):
                            if 1 <= v <= 4094:
                                vlan_set.add(v)
                elif tok.isdigit():
                    v = int(tok)
                    if 1 <= v <= 4094:
                        vlan_set.add(v)
                        if v == BLACKHOLE_VLAN_ID:
                            has_blackhole_vlan = True

        if lower.startswith("interface "):
            if current_iface:
                if not current_iface["is_shutdown"] and current_iface["access_vlan"] == 1 and current_iface["mode"] != "trunk":
                    has_default_vlan1_active = True
                interfaces.append(current_iface)
            iface_name = trimmed[10:].strip()
            if iface_name.lower().startswith("vlan") and iface_name[4:].strip().isdigit():
                vlan_set.add(int(iface_name[4:].strip()))
            current_iface = {
                "name": iface_name,
                "mode": "access",
                "access_vlan": 1,
                "native_vlan": 1,
                "is_shutdown": False,
                "port_security": False,
                "bpduguard": False,
            }
            continue

        if current_iface is not None:
            if lower in ("exit", "!"):
                if not current_iface["is_shutdown"] and current_iface["access_vlan"] == 1 and current_iface["mode"] != "trunk":
                    has_default_vlan1_active = True
                interfaces.append(current_iface)
                current_iface = None
                continue
            if lower == "shutdown":
                current_iface["is_shutdown"] = True
            elif lower == "no shutdown":
                current_iface["is_shutdown"] = False
            elif "switchport mode trunk" in lower:
                current_iface["mode"] = "trunk"
            elif lower.startswith("switchport access vlan "):
                parts = lower.split()
                if len(parts) >= 4 and parts[3].isdigit():
                    v = int(parts[3])
                    current_iface["access_vlan"] = v
                    vlan_set.add(v)
            elif lower.startswith("switchport trunk native vlan "):
                parts = lower.split()
                if len(parts) >= 5 and parts[4].isdigit():
                    v = int(parts[4])
                    current_iface["native_vlan"] = v
                    vlan_set.add(v)
                    if v == BLACKHOLE_VLAN_ID:
                        has_blackhole_vlan = True
            elif "switchport port-security" in lower:
                current_iface["port_security"] = True
            elif "spanning-tree bpduguard enable" in lower:
                current_iface["bpduguard"] = True

    if current_iface:
        if not current_iface["is_shutdown"] and current_iface["access_vlan"] == 1 and current_iface["mode"] != "trunk":
            has_default_vlan1_active = True
        interfaces.append(current_iface)

    is_wireless = medium_type == "WIRELESS_802_11" or detected_vendor == "openwrt_wireless"
    r1_pass = (not has_default_vlan1_active) and has_blackhole_vlan
    r2_pass = has_arp_inspection or detected_vendor == "openwrt_wireless"
    r3_pass = has_dhcp_snooping or detected_vendor == "openwrt_wireless"
    r4_pass = has_bpduguard or any(i["bpduguard"] for i in interfaces)
    r5_pass = any(i["port_security"] for i in interfaces)
    r6_pass = has_inter_vlan_acl
    r7_pass = has_wireless_pmf and has_wireless_isolation
    r8_pass = has_ssh_v2 and (not has_telnet) and (not has_http)

    findings = [
        {
            "rule_id": "DISA-STIG-L2-001",
            "category": "Layer 2 VLAN Containment",
            "title": "Default VLAN 1 Eradication & Blackhole Parking VLAN 999",
            "severity": "CRITICAL",
            "status": "PASS" if r1_pass else "FAIL",
            "description": "Default VLAN 1 is pruned and suspended Blackhole VLAN 999 is provisioned."
            if r1_pass
            else "Active interfaces remain assigned to Default VLAN 1 or lack suspended Blackhole VLAN 999.",
            "remediation": "Suspend VLAN 999 as native trunk blackhole and migrate all active ports off VLAN 1.",
        },
        {
            "rule_id": "DISA-STIG-L2-002",
            "category": "Layer 2 ARP Armor",
            "title": "Dynamic ARP Inspection (DAI) & 15pps Rate Limit",
            "severity": "HIGH",
            "status": "PASS" if r2_pass else "FAIL",
            "description": "Dynamic ARP Inspection (DAI) is enabled on enclave VLANs."
            if r2_pass
            else "Dynamic ARP Inspection is missing, exposing the enclave to ARP cache poisoning (MitM).",
            "remediation": "Enable 'ip arp inspection vlan <ID>' and 'ip arp inspection validate src-mac dst-mac ip'.",
        },
        {
            "rule_id": "DISA-STIG-L2-003",
            "category": "Layer 2 DHCP Integrity",
            "title": "DHCP Snooping Binding Database Enforcement",
            "severity": "HIGH",
            "status": "PASS" if r3_pass else "FAIL",
            "description": "Global DHCP Snooping is active for enclave VLANs."
            if r3_pass
            else "DHCP Snooping is disabled, allowing rogue DHCP servers and IP starvation attacks.",
            "remediation": "Enable 'ip dhcp snooping' globally and restrict 'ip dhcp snooping trust' to verified uplinks.",
        },
        {
            "rule_id": "DISA-STIG-L2-004",
            "category": "Layer 2 STP Topology Protection",
            "title": "Spanning-Tree PortFast BPDU Guard & Root Guard",
            "severity": "MEDIUM",
            "status": "PASS" if r4_pass else "FAIL",
            "description": "BPDU Guard is enforced on edge access ports."
            if r4_pass
            else "Edge ports lack BPDU Guard, permitting rogue switch insertion and root bridge hijacking.",
            "remediation": "Configure 'spanning-tree portfast bpduguard default' and per-port 'spanning-tree bpduguard enable'.",
        },
        {
            "rule_id": "DISA-STIG-L2-005",
            "category": "Layer 2 CAM & Broadcast Protection",
            "title": "Sticky MAC Port-Security & 10% Broadcast Storm Ceiling",
            "severity": "MEDIUM",
            "status": "PASS" if r5_pass else "WARN",
            "description": "Port-security sticky MAC enforcement detected on access ports."
            if r5_pass
            else "Access interfaces do not enforce sticky MAC ceilings or broadcast storm control.",
            "remediation": "Enforce 'switchport port-security mac-address sticky', 'maximum 2', and 'storm-control broadcast level 10.00'.",
        },
        {
            "rule_id": "DISA-STIG-L3-006",
            "category": "Layer 3 Enclave Segmentation",
            "title": "RFC-1918 Inter-VLAN Default-Deny Extended ACL",
            "severity": "CRITICAL",
            "status": "PASS" if r6_pass else "FAIL",
            "description": "Extended inter-VLAN isolation ACLs are present in the configuration."
            if r6_pass
            else "No inter-VLAN isolation ACLs detected; lateral east-west RFC-1918 subnet pivoting is unrestricted.",
            "remediation": "Bind an extended ingress ACL blocking RFC-1918 cross-subnet traffic while preserving operator reachability.",
        },
        {
            "rule_id": "NSA-WL-007",
            "category": "Wireless 802.11 Enclave Security",
            "title": "802.11w Protected Management Frames & L2 Client Isolation",
            "severity": "CRITICAL" if is_wireless else "MEDIUM",
            "status": "PASS" if r7_pass else ("FAIL" if is_wireless else "WARN"),
            "description": "Wireless enclave enforces WPA3-SAE, mandatory 802.11w PMF, and L2 client-to-client isolation."
            if r7_pass
            else "Wireless radio/WLAN profile lacks mandatory 802.11w PMF or Layer 2 station isolation.",
            "remediation": "Enforce 'ieee80211w=2' (PMF mandatory), WPA3-SAE/Enterprise, and 'client-isolation enable'.",
        },
        {
            "rule_id": "DISA-STIG-MGMT-008",
            "category": "Control Plane Lockdown",
            "title": "SSHv2-Only Management & Eradication of Telnet/HTTP",
            "severity": "HIGH",
            "status": "PASS" if r8_pass else "FAIL",
            "description": "Management plane restricted to SSHv2 with unencrypted Telnet and HTTP disabled."
            if r8_pass
            else "Insecure management protocols (Telnet / HTTP) or missing SSHv2 enforcement detected.",
            "remediation": "Configure 'ip ssh version 2', 'no ip http server', and 'transport input ssh' on all VTY lines.",
        },
    ]

    passed = sum(1 for f in findings if f["status"] == "PASS")
    failed = sum(1 for f in findings if f["status"] == "FAIL")
    warned = sum(1 for f in findings if f["status"] == "WARN")
    score = min(100, int(((passed * 100) + (warned * 50)) / max(1, len(findings))))

    return {
        "hostname": hostname,
        "detected_vendor": detected_vendor,
        "existing_vlans": sorted(vlan_set),
        "interfaces": interfaces,
        "findings": findings,
        "compliance_score": score,
        "passed_rules": passed,
        "failed_rules": failed,
        "warning_rules": warned,
    }


def synthesize_military_grade_vlan_py(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Pure-Python fallback implementation of the Rust Military-Grade VLAN Synthesizer."""
    start_t = time.perf_counter()
    target_ip = str(payload.get("target_ip", "192.168.1.1"))
    vendor_hint = str(payload.get("vendor_platform", ""))
    medium_type = str(payload.get("medium_type", "WIRED_802_3"))
    operator_source_ip = str(payload.get("operator_source_ip") or "192.168.1.100")
    wireless_ssid = payload.get("wireless_ssid")
    desired_vlan = payload.get("desired_vlan_id")
    running_config = str(payload.get("running_config", ""))
    entropy_threshold = float(payload.get("entropy_threshold", 3.55))

    audit_data = parse_and_audit_config(running_config, vendor_hint, medium_type)
    merged_vlans = sorted(
        set(audit_data["existing_vlans"]) | {int(v) for v in payload.get("existing_vlans", []) if str(v).isdigit()}
    )
    entropy_findings = scan_config_entropy(running_config, entropy_threshold)

    vendor = vendor_hint or audit_data["detected_vendor"]
    vlan_id = select_safe_vlan_id(int(desired_vlan) if desired_vlan else None, merged_vlans)
    blackhole_vlan = BLACKHOLE_VLAN_ID
    third_octet = vlan_id % 250
    subnet_cidr = f"10.240.{third_octet}.0/24"
    gateway_ip = f"10.240.{third_octet}.1"
    vlan_name = f"CN_MIL_SEC_{vlan_id}"

    controls = [
        "DISA-STIG-L2-001: Default VLAN 1 Eradication & Blackhole VLAN 999 Parking",
        "DISA-STIG-L2-002: Dynamic ARP Inspection (DAI) with 15pps Rate Limit",
        "DISA-STIG-L2-003: DHCP Snooping Binding Database Enforcement",
        "DISA-STIG-L2-004: Spanning-Tree BPDU Guard & Root Guard",
        "DISA-STIG-L2-005: Sticky MAC Port-Security & 10% Broadcast Storm Control",
        "DISA-STIG-L3-006: RFC-1918 Inter-VLAN Default-Deny Extended ACL",
        "DISA-STIG-MGMT-008: Management Plane SSHv2 Lockdown & Telnet/HTTP Eradication",
    ]

    if vendor in ("openwrt_wireless", "enterprise_ap"):
        controls.extend(
            [
                "NSA-WL-006: 802.11w Protected Management Frames (PMF Mandatory)",
                "NSA-WL-007: Layer 2 Wireless Client-to-Client Isolation",
            ]
        )
        ssid_label = wireless_ssid or f"CN-SEC-{vlan_id}"
        cmds = [
            f"uci set network.vlan_{vlan_id}=interface",
            f"uci set network.vlan_{vlan_id}.proto='static'",
            f"uci set network.vlan_{vlan_id}.ipaddr='{gateway_ip}'",
            f"uci set network.vlan_{vlan_id}.netmask='255.255.255.0'",
            f"uci set network.vlan_{blackhole_vlan}=bridge-vlan",
            f"uci set network.vlan_{blackhole_vlan}.vlan='{blackhole_vlan}'",
            "uci set wireless.sec_enclave=wifi-iface",
            "uci set wireless.sec_enclave.device='radio0'",
            "uci set wireless.sec_enclave.mode='ap'",
            f"uci set wireless.sec_enclave.ssid='{ssid_label}'",
            f"uci set wireless.sec_enclave.network='vlan_{vlan_id}'",
            "uci set wireless.sec_enclave.encryption='sae'",
            "uci set wireless.sec_enclave.ieee80211w='2'",
            "uci set wireless.sec_enclave.isolate='1'",
            f"uci set firewall.zone_sec_{vlan_id}=zone",
            f"uci set firewall.zone_sec_{vlan_id}.name='cn_mil_{vlan_id}'",
            f"uci set firewall.zone_sec_{vlan_id}.input='REJECT'",
            f"uci set firewall.zone_sec_{vlan_id}.forward='REJECT'",
            f"uci set firewall.zone_sec_{vlan_id}.output='ACCEPT'",
            f"uci set firewall.allow_op_{vlan_id}=rule",
            f"uci set firewall.allow_op_{vlan_id}.src='cn_mil_{vlan_id}'",
            f"uci set firewall.allow_op_{vlan_id}.dest_ip='{operator_source_ip}'",
            f"uci set firewall.allow_op_{vlan_id}.target='ACCEPT'",
            "uci commit",
            "/etc/init.d/network reload",
        ]
        rollback = [
            "uci delete wireless.sec_enclave",
            f"uci delete firewall.zone_sec_{vlan_id}",
            f"uci delete firewall.allow_op_{vlan_id}",
            f"uci delete network.vlan_{vlan_id}",
            "uci commit",
            "/etc/init.d/network reload",
        ]
    elif vendor == "juniper_junos":
        if medium_type == "WIRELESS_802_11":
            controls.append("NSA-WL-007: Wireless WLAN Client Isolation & PMF 802.11w Mandatory")
        cmds = [
            "configure exclusive",
            f"set vlans CN_BLACKHOLE_DEAD_VLAN vlan-id {blackhole_vlan}",
            f"set vlans {vlan_name} vlan-id {vlan_id}",
            f"set vlans {vlan_name} forwarding-options dhcp-security arp-inspection",
            f"set interfaces irb unit {vlan_id} family inet address {gateway_ip}/24",
            f"set vlans {vlan_name} l3-interface irb.{vlan_id}",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term allow-operator from destination-address {operator_source_ip}/32",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term allow-operator then accept",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term deny-rfc1918 from destination-address 10.0.0.0/8",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term deny-rfc1918 from destination-address 172.16.0.0/12",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term deny-rfc1918 from destination-address 192.168.0.0/16",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term deny-rfc1918 then reject",
            f"set firewall family inet filter ACL_{vlan_name}_ISOLATION term default-allow then accept",
            f"set interfaces irb unit {vlan_id} family inet filter input ACL_{vlan_name}_ISOLATION",
            "set protocols rstp bpdu-block-on-edge",
            "delete system services telnet",
            "delete system services web-management http",
            "set system services ssh protocol-version v2",
            "commit confirmed 2",
            "commit and-quit",
        ]
        rollback = [
            "configure exclusive",
            f"delete vlans {vlan_name}",
            f"delete interfaces irb unit {vlan_id}",
            f"delete firewall family inet filter ACL_{vlan_name}_ISOLATION",
            "commit and-quit",
        ]
    else:
        cmds = [
            "configure terminal",
            "ip ssh version 2",
            "no ip http server",
            "no ip http secure-server",
            "service password-encryption",
            "ip dhcp snooping",
            f"ip dhcp snooping vlan {vlan_id}",
            "no ip dhcp snooping information option",
            f"ip arp inspection vlan {vlan_id}",
            "ip arp inspection validate src-mac dst-mac ip",
            "spanning-tree portfast bpduguard default",
            f"vlan {blackhole_vlan}",
            "name CN_BLACKHOLE_DEAD_VLAN",
            "state suspend",
            "exit",
            f"vlan {vlan_id}",
            f"name {vlan_name}",
            "exit",
            f"ip access-list extended ACL_{vlan_name}_ISOLATION",
            f"permit ip 10.240.{third_octet}.0 0.0.0.255 host {operator_source_ip}",
            f"deny ip 10.240.{third_octet}.0 0.0.0.255 10.0.0.0 0.255.255.255 log",
            f"deny ip 10.240.{third_octet}.0 0.0.0.255 172.16.0.0 0.15.255.255 log",
            f"deny ip 10.240.{third_octet}.0 0.0.0.255 192.168.0.0 0.0.255.255 log",
            "permit ip any any",
            "exit",
            f"interface Vlan{vlan_id}",
            f"description [NESTPATCH-MIL-SEC] Hardened Enclave VLAN {vlan_id}",
            f"ip address {gateway_ip} 255.255.255.0",
            "no ip redirects",
            "no ip proxy-arp",
            "no ip unreachables",
            f"ip access-group ACL_{vlan_name}_ISOLATION in",
            "no shutdown",
            "exit",
            "interface range GigabitEthernet1/0/2 - 24",
            "switchport mode access",
            f"switchport access vlan {vlan_id}",
            "switchport nonegotiate",
            "switchport port-security",
            "switchport port-security maximum 2",
            "switchport port-security violation restrict",
            "switchport port-security mac-address sticky",
            "ip arp inspection limit rate 15",
            "ip dhcp snooping limit rate 15",
            "storm-control broadcast level 10.00 5.00",
            "storm-control multicast level 10.00 5.00",
            "spanning-tree portfast",
            "spanning-tree bpduguard enable",
            "no cdp enable",
            "no lldp transmit",
            "exit",
        ]
        if medium_type == "WIRELESS_802_11":
            controls.append("NSA-WL-007: Wireless WLAN Client Isolation & PMF 802.11w Mandatory")
            cmds.extend(
                [
                    f"wlan {vlan_name} {vlan_id} {vlan_name}",
                    "client-isolation enable",
                    "security wpa wpa3",
                    "security pmf mandatory",
                    "no shutdown",
                    "exit",
                ]
            )
        cmds.extend(["end", "write memory"])
        rollback = [
            "configure terminal",
            f"no interface Vlan{vlan_id}",
            f"no vlan {vlan_id}",
            f"no ip access-list extended ACL_{vlan_name}_ISOLATION",
            "end",
            "write memory",
        ]

    elapsed_ms = round((time.perf_counter() - start_t) * 1000.0, 3)

    return {
        "status": "OK",
        "engine": "python_fallback_auditor",
        "target_ip": target_ip,
        "vendor_platform": vendor,
        "hostname": audit_data["hostname"],
        "parse_time_ms": elapsed_ms,
        "allocated_vlan_id": vlan_id,
        "blackhole_vlan_id": blackhole_vlan,
        "vlan_name": vlan_name,
        "isolated_subnet_cidr": subnet_cidr,
        "gateway_address": gateway_ip,
        "existing_vlans": merged_vlans,
        "commands": cmds,
        "rollback_commands": rollback,
        "enforced_controls": controls,
        "compliance_score": audit_data["compliance_score"],
        "passed_rules": audit_data["passed_rules"],
        "failed_rules": audit_data["failed_rules"],
        "warning_rules": audit_data["warning_rules"],
        "findings": audit_data["findings"],
        "entropy_findings": entropy_findings,
        "interfaces": audit_data["interfaces"],
    }
