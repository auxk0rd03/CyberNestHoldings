"""
NestPatch Terminal User Interface (TUI) Package.
Styled with the CyberNest Aero-Sunset 24-bit TrueColor terminal palette.
"""
