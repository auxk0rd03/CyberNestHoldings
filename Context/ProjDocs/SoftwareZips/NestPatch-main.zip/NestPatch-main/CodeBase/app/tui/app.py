"""
NestPatch Master Textual Application Orchestrator (app/tui/app.py).
Manages screen routing, global tactical keybindings (F2-F5, Ctrl+R, F10),
and the CyberNest Aero-Sunset stylesheet.
"""
from pathlib import Path
from typing import Optional

from textual.app import App
from textual.binding import Binding

from app.core.config import APP_SUBTITLE, APP_TITLE, STYLES_DIR
from app.core.database import NestPatchDatabase
from app.core.vlan_orchestrator import VlanProvisioningOrchestrator
from app.tui.screens.audit import AuditScreen
from app.tui.screens.dispatch import DispatchScreen
from app.tui.screens.inventory import InventoryScreen
from app.tui.screens.quick_vlan import QuickVlanScreen


class NestPatchApp(App):
    """Master Textual TUI Application for NestPatch Single-IP VLAN Provisioning."""

    TITLE = APP_TITLE
    SUB_TITLE = APP_SUBTITLE
    CSS_PATH = str(STYLES_DIR / "nestpatch.tcss")

    BINDINGS = [
        Binding("f2", "switch_mode_screen('quick_vlan')", "1-IP Auto-VLAN", show=True),
        Binding("f3", "switch_mode_screen('audit')", "Config & Entropy Auditor", show=True),
        Binding("f4", "switch_mode_screen('dispatch')", "Batch/Serial", show=True),
        Binding("f5", "switch_mode_screen('inventory')", "Inventory", show=True),
        Binding("ctrl+r", "emergency_rollback", "Emergency Rollback", show=True),
        Binding("f10", "quit", "Quit", show=True),
        Binding("ctrl+q", "quit", "Quit", show=False),
    ]

    def __init__(self, db_path: Optional[Path] = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.db = NestPatchDatabase(db_path=db_path)
        self.orchestrator = VlanProvisioningOrchestrator(database=self.db)

    def on_mount(self) -> None:
        self.install_screen(QuickVlanScreen(self.orchestrator), name="quick_vlan")
        self.install_screen(AuditScreen(self.db), name="audit")
        self.install_screen(DispatchScreen(), name="dispatch")
        self.install_screen(InventoryScreen(self.db, self.orchestrator), name="inventory")
        self.push_screen("quick_vlan")

    def action_switch_mode_screen(self, screen_name: str) -> None:
        self.switch_screen(screen_name)

    async def action_emergency_rollback(self) -> None:
        current = self.screen
        if isinstance(current, QuickVlanScreen):
            await current.trigger_emergency_rollback()
        else:
            try:
                await self.orchestrator.execute_emergency_rollback()
                if isinstance(current, InventoryScreen):
                    await current.refresh_tables()
            except Exception:
                pass
