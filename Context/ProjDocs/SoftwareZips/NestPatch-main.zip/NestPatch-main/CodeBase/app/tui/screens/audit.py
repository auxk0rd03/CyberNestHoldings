"""
NestPatch F3 Screen: Device Configuration Auditor, Shannon Entropy Inspector & STIG Reports (audit.py).
Streams raw network configurations to the Rust `patch_auditor` engine over STDIN.
"""
from typing import Any, Dict
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, DataTable, Input, Label, Static, TextArea

from app.core.database import NestPatchDatabase
from app.core.engine_bridge import invoke_rust_auditor_async
from app.core.security import sanitize_cli_text
from app.tui.widgets.header import NestPatchHeader

SAMPLE_UNHARDENED_CONFIG = """! Sample Unhardened Enterprise Switch Configuration
hostname CN-EDGE-SW04
enable password 7 0822455D0A16544541
username field_eng secret 0 N3stP@tch#MilSec99!Key2026
snmp-server community public RO
ip http server
vlan 1
vlan 10
interface GigabitEthernet1/0/1
 switchport mode trunk
 switchport trunk native vlan 1
 no shutdown
exit
interface GigabitEthernet1/0/2
 switchport mode access
 switchport access vlan 1
 no shutdown
exit
line vty 0 4
 transport input telnet ssh
exit
"""


class AuditScreen(Screen):
    """F3 Screen: Deep AST Config Auditor, Shannon Entropy H(X) Scanner & DISA STIG Evaluator."""

    def __init__(self, database: NestPatchDatabase, **kwargs) -> None:
        super().__init__(**kwargs)
        self.db = database
        self.last_audit: Dict[str, Any] = {}

    def compose(self) -> ComposeResult:
        yield NestPatchHeader(active_tab="F3", id="audit-header")
        with Vertical(classes="panel-box"):
            yield Static(
                "[bold #c93b93]ZERO-PANIC RUST CONFIGURATION & SHANNON ENTROPY H(X) AUDITOR[/]",
                classes="section-title",
            )
            with Horizontal(classes="command-row"):
                yield Label("Device IP / Label:", classes="field-label")
                yield Input(value="192.168.1.10", id="audit-target-ip")
                yield Label("  Entropy H(X) Threshold:", classes="field-label")
                yield Input(value="3.55", id="audit-entropy-threshold")
                yield Button("RUN RUST STIG + ENTROPY AUDIT", id="btn-run-audit", classes="btn-deploy")
            yield TextArea(SAMPLE_UNHARDENED_CONFIG, id="audit-config-textarea")

        with Horizontal(id="main-workspace-split"):
            with Vertical(id="left-telemetry-pane"):
                yield Static(
                    "[bold #c93b93]DISA STIG / NSA COMPLIANCE FINDINGS[/]",
                    classes="section-title",
                )
                yield DataTable(id="audit-stig-table")
            with Vertical(id="right-stream-pane"):
                yield Static(
                    "[bold #ff7536]SHANNON ENTROPY H(X) SECRET LEAK DETECTIONS[/]",
                    classes="section-title",
                )
                yield DataTable(id="audit-entropy-table")
        yield Static(
            "[bold #c93b93]AUDITOR STATUS: [READY][/] | Paste or edit running-config above and press RUN RUST STIG + ENTROPY AUDIT",
            id="status-footer-bar",
        )

    async def on_mount(self) -> None:
        stig_table = self.query_one("#audit-stig-table", DataTable)
        stig_table.cursor_type = "row"
        stig_table.add_columns("Rule ID", "Severity", "Status", "Title / Remediation")

        ent_table = self.query_one("#audit-entropy-table", DataTable)
        ent_table.cursor_type = "row"
        ent_table.add_columns("Line", "H(X) Bits", "Severity", "Secret Type", "Redacted Preview")

        await self.run_audit()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-run-audit":
            await self.run_audit()

    async def run_audit(self) -> Dict[str, Any]:
        target_ip = self.query_one("#audit-target-ip", Input).value.strip() or "192.168.1.10"
        thresh_raw = self.query_one("#audit-entropy-threshold", Input).value.strip() or "3.55"
        try:
            threshold = float(thresh_raw)
        except ValueError:
            threshold = 3.55

        cfg_text = sanitize_cli_text(self.query_one("#audit-config-textarea", TextArea).text)

        payload = {
            "action": "audit_only",
            "target_ip": target_ip,
            "entropy_threshold": threshold,
            "running_config": cfg_text,
        }
        res = await invoke_rust_auditor_async(payload)
        self.last_audit = res
        await self.db.record_standalone_audit(target_ip, res)

        stig_table = self.query_one("#audit-stig-table", DataTable)
        stig_table.clear()
        for f in res.get("findings", []):
            stig_table.add_row(
                f.get("rule_id", ""),
                f.get("severity", ""),
                f.get("status", ""),
                f"{f.get('title', '')} -> {f.get('remediation', '')}",
            )

        ent_table = self.query_one("#audit-entropy-table", DataTable)
        ent_table.clear()
        for ef in res.get("entropy_findings", []):
            ent_table.add_row(
                str(ef.get("line_number", 0)),
                f"{ef.get('entropy_bits', 0.0):.3f}",
                ef.get("severity", "HIGH"),
                ef.get("secret_type", ""),
                ef.get("redacted_preview", ""),
            )

        footer = self.query_one("#status-footer-bar", Static)
        footer.update(
            f"[bold #c93b93]AUDITOR: [COMPLETE in {res.get('parse_time_ms', 1.0)}ms][/] | "
            f"Host: [bold #f0e6f7]{res.get('hostname', 'NODE')}[/] | "
            f"STIG Score: [bold #ff7536]{res.get('compliance_score', 0)}%[/] | "
            f"Secret Leaks Flagged: [bold #ff3366]{len(res.get('entropy_findings', []))}[/]"
        )
        return res
