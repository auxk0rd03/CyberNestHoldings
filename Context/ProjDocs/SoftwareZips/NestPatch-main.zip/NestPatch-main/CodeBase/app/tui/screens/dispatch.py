"""
NestPatch F4 Screen: Bounded Batch VLAN Trunking & Out-of-Band RS-232 Serial Console (dispatch.py).
Interfaces with the Go `batch_dispatcher` bounded Goroutine worker pool and serial UART dialer.
"""
from typing import Any, Dict, List
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, DataTable, Input, Label, Static

from app.core.engine_bridge import invoke_go_dispatcher_async, invoke_rust_auditor_async
from app.core.security import validate_ip_address, validate_serial_device_node, validate_vlan_id
from app.tui.widgets.header import NestPatchHeader
from app.tui.widgets.log_stream import LogStreamWidget


class DispatchScreen(Screen):
    """F4 Screen: Multi-IP Bounded Worker Pool Batch Provisioning & RS-232 Serial Bootstrap."""

    def compose(self) -> ComposeResult:
        yield NestPatchHeader(active_tab="F4", id="dispatch-header")
        with Vertical(classes="panel-box"):
            yield Static(
                "[bold #c93b93]GO BOUNDED WORKER POOL BATCH VLAN DISPATCHER & OOB RS-232 SERIAL CONSOLE[/]",
                classes="section-title",
            )
            with Horizontal(classes="command-row"):
                yield Label("Batch Target IPs (CSV):", classes="field-label")
                yield Input(
                    value="192.168.1.11, 192.168.1.12, 192.168.1.13",
                    id="batch-targets-input",
                )
                yield Label("  VLAN ID:", classes="field-label")
                yield Input(value="420", id="batch-vlan-input")
                yield Label("  Workers (2-8):", classes="field-label")
                yield Input(value="4", id="batch-workers-input")
                yield Button("DISPATCH BATCH VLAN", id="btn-batch-dispatch", classes="btn-deploy")
            with Horizontal(classes="command-row"):
                yield Label("OOB Serial UART:", classes="field-label")
                yield Input(value="/dev/ttyUSB0", id="serial-device-input")
                yield Label("  Baud Rate:", classes="field-label")
                yield Input(value="115200", id="serial-baud-input")
                yield Button("BOOTSTRAP OOB SERIAL", id="btn-serial-bootstrap")

        with Horizontal(id="main-workspace-split"):
            with Vertical(id="left-telemetry-pane"):
                yield Static(
                    "[bold #c93b93]BATCH WORKER EXECUTION LEDGER[/]",
                    classes="section-title",
                )
                yield DataTable(id="batch-results-table")
            with Vertical(id="right-stream-pane"):
                yield Static(
                    "[bold #ff7536]GO GOROUTINE & SERIAL UART TELEMETRY[/]",
                    classes="section-title",
                )
                yield LogStreamWidget(id="dispatch-log-stream")
        yield Static(
            "[bold #c93b93]DISPATCHER: [STANDBY][/] | Bounded Goroutine Worker Pool (2-8 Workers) + RS-232 FTDI Serial Ready",
            id="status-footer-bar",
        )

    def on_mount(self) -> None:
        table = self.query_one("#batch-results-table", DataTable)
        table.cursor_type = "row"
        table.add_columns("Target IP", "Status", "Rollback Guard", "Applied Cmds", "SHA-256 Digest")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-batch-dispatch":
            await self.run_batch_dispatch()
        elif event.button.id == "btn-serial-bootstrap":
            await self.run_serial_bootstrap()

    async def run_batch_dispatch(self) -> Dict[str, Any]:
        log_win = self.query_one("#dispatch-log-stream", LogStreamWidget)
        raw_ips = self.query_one("#batch-targets-input", Input).value
        raw_vlan = self.query_one("#batch-vlan-input", Input).value
        raw_workers = self.query_one("#batch-workers-input", Input).value

        try:
            targets: List[str] = [
                validate_ip_address(part) for part in raw_ips.split(",") if part.strip()
            ]
            if not targets:
                raise ValueError("Provide at least one valid target IP address.")
            vlan_id = validate_vlan_id(raw_vlan) or 420
            workers = max(2, min(8, int(raw_workers.strip() or "4")))
        except Exception as exc:
            log_win.append_log("ERROR", f"Batch input validation error: {exc}")
            return {"status": "ERROR", "error": str(exc)}

        log_win.append_log(
            "SYNTH",
            f"Synthesizing DISA STIG VLAN {vlan_id} template for {len(targets)} nodes via Rust engine...",
        )
        synth_res = await invoke_rust_auditor_async(
            {
                "action": "synthesize_only",
                "target_ip": targets[0],
                "vendor_platform": "cisco_ios",
                "desired_vlan_id": vlan_id,
                "existing_vlans": [1, 10, 20],
                "running_config": "",
            }
        )

        log_win.append_log(
            "GO",
            f"Dispatching across {len(targets)} targets with {workers} bounded Goroutine workers...",
        )
        batch_res = await invoke_go_dispatcher_async(
            {
                "action": "batch_dispatch",
                "targets": targets,
                "medium_type": "WIRED_802_3",
                "vendor_platform": "cisco_ios",
                "allocated_vlan_id": synth_res.get("allocated_vlan_id", vlan_id),
                "commands": synth_res.get("commands", []),
                "rollback_commands": synth_res.get("rollback_commands", []),
                "revert_timer_secs": 120,
                "max_workers": workers,
                "fast_mode": True,
            }
        )

        table = self.query_one("#batch-results-table", DataTable)
        table.clear()
        for item in batch_res.get("results", []):
            table.add_row(
                item.get("target_ip", ""),
                item.get("status", "SUCCESS_LOCKED"),
                "120s ARMED & VERIFIED" if item.get("rollback_armed") else "N/A",
                str(item.get("applied_count", 0)),
                item.get("audit_hash", "")[:18],
            )
            log_win.append_log(
                "LOCK",
                f"Target {item.get('target_ip')} -> {item.get('status')} ({item.get('applied_count')} commands, SHA256: {item.get('audit_hash', '')[:12]})",
            )

        return batch_res

    async def run_serial_bootstrap(self) -> Dict[str, Any]:
        log_win = self.query_one("#dispatch-log-stream", LogStreamWidget)
        raw_dev = self.query_one("#serial-device-input", Input).value
        raw_baud = self.query_one("#serial-baud-input", Input).value

        try:
            dev_node = validate_serial_device_node(raw_dev)
            baud = int(raw_baud.strip() or "115200")
        except Exception as exc:
            log_win.append_log("ERROR", f"Serial validation error: {exc}")
            return {"status": "ERROR", "error": str(exc)}

        res = await invoke_go_dispatcher_async(
            {
                "action": "serial_bootstrap",
                "device_node": dev_node,
                "baud_rate": baud,
                "commands": [
                    "enable",
                    "configure terminal",
                    "vlan 999",
                    "name CN_BLACKHOLE_DEAD_VLAN",
                    "state suspend",
                    "exit",
                    "ip ssh version 2",
                    "end",
                    "write memory",
                ],
            }
        )
        for line in res.get("transcript", []):
            log_win.append_log("GO", line)
        return res
