"""
NestPatch F5 Screen: Discovered Wired/Wireless Nodes, Provisioned VLAN Topologies & Rollback Ledger (inventory.py).
"""
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, DataTable, Static

from app.core.database import NestPatchDatabase
from app.core.vlan_orchestrator import VlanProvisioningOrchestrator
from app.tui.widgets.header import NestPatchHeader


class InventoryScreen(Screen):
    """F5 Screen: Air-Gapped SQLite Ledger of Discovered Nodes, Provisioned VLANs & Rollbacks."""

    def __init__(
        self,
        database: NestPatchDatabase,
        orchestrator: VlanProvisioningOrchestrator,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.db = database
        self.orchestrator = orchestrator

    def compose(self) -> ComposeResult:
        yield NestPatchHeader(active_tab="F5", id="inventory-header")
        with Vertical(classes="panel-box"):
            with Horizontal(classes="command-row"):
                yield Static(
                    "[bold #c93b93]AIR-GAPPED SQLITE ENCLAVE INVENTORY & TRANSACTIONAL ROLLBACK LEDGER[/]",
                    classes="section-title",
                )
                yield Button("REFRESH LEDGER", id="btn-refresh-inventory")
                yield Button(
                    "REVERT LATEST VLAN DEPLOYMENT (CTRL+R)",
                    id="btn-execute-rollback",
                    classes="btn-critical",
                )

        with Horizontal(id="main-workspace-split"):
            with Vertical(id="left-telemetry-pane"):
                yield Static(
                    "[bold #c93b93]PROVISIONED MILITARY-GRADE VLANS[/]",
                    classes="section-title",
                )
                yield DataTable(id="inventory-vlans-table")
            with Vertical(id="right-stream-pane"):
                yield Static(
                    "[bold #ff7536]DISCOVERED NODES & TRANSACTIONAL ROLLBACK GUARD[/]",
                    classes="section-title",
                )
                yield DataTable(id="inventory-rollbacks-table")
        yield Static(
            "[bold #c93b93]STORAGE: [SQLITE WAL ENCLAVE ONLINE][/] | Local air-gapped ledger persistence active",
            id="status-footer-bar",
        )

    async def on_mount(self) -> None:
        v_table = self.query_one("#inventory-vlans-table", DataTable)
        v_table.cursor_type = "row"
        v_table.add_columns("ID", "Target IP", "VLAN", "Subnet CIDR", "Medium", "Status")

        r_table = self.query_one("#inventory-rollbacks-table", DataTable)
        r_table.cursor_type = "row"
        r_table.add_columns("RB#", "Target IP", "VLAN Name", "Timer", "State", "SHA-256")

        await self.refresh_tables()

    async def on_screen_resume(self) -> None:
        await self.refresh_tables()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-refresh-inventory":
            await self.refresh_tables()
        elif event.button.id == "btn-execute-rollback":
            try:
                await self.orchestrator.execute_emergency_rollback()
                await self.refresh_tables()
            except Exception as exc:
                footer = self.query_one("#status-footer-bar", Static)
                footer.update(f"[bold #ff3366]ROLLBACK NOTICE:[/] {exc}")

    async def refresh_tables(self) -> None:
        vlans = await self.db.list_provisioned_vlans(limit=50)
        rollbacks = await self.db.list_rollbacks(limit=50)

        v_table = self.query_one("#inventory-vlans-table", DataTable)
        v_table.clear()
        for v in vlans:
            v_table.add_row(
                str(v.get("id", "")),
                v.get("target_ip", ""),
                f"VLAN {v.get('vlan_id')} (BH:{v.get('blackhole_vlan_id')})",
                v.get("subnet_cidr", ""),
                v.get("medium_type", ""),
                v.get("status", ""),
            )

        r_table = self.query_one("#inventory-rollbacks-table", DataTable)
        r_table.clear()
        for r in rollbacks:
            r_table.add_row(
                str(r.get("id", "")),
                r.get("target_ip", ""),
                r.get("vlan_name", ""),
                f"{r.get('revert_timer_secs', 120)}s",
                r.get("rollback_status", ""),
                str(r.get("audit_hash", ""))[:14],
            )

        footer = self.query_one("#status-footer-bar", Static)
        footer.update(
            f"[bold #c93b93]LEDGER SYNCHRONIZED:[/] {len(vlans)} Provisioned VLANs | "
            f"{len(rollbacks)} Transactional Rollback Checkpoints"
        )
