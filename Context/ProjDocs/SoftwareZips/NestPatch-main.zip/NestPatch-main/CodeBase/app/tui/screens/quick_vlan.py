"""
NestPatch Primary Screen: Single-IP Automated Military-Grade VLAN Provisioner (quick_vlan.py).
Implements the 5-stage Single-IP workflow per Section 5.2 of the Architecture Specification.
"""
from typing import Any, Dict
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Static

from app.core.engine_bridge import check_engine_health
from app.core.vlan_orchestrator import VlanProvisioningOrchestrator
from app.tui.widgets.header import NestPatchHeader
from app.tui.widgets.ip_command_bar import IPCommandBar
from app.tui.widgets.log_stream import LogStreamWidget
from app.tui.widgets.pipeline_stepper import PipelineStepper
from app.tui.widgets.vlan_matrix import VlanMatrixWidget


class QuickVlanScreen(Screen):
    """Primary F2 Screen: 1-Input Target IP Military-Grade VLAN Provisioner."""

    def __init__(self, orchestrator: VlanProvisioningOrchestrator, **kwargs) -> None:
        super().__init__(**kwargs)
        self.orchestrator = orchestrator
        self.last_result: Dict[str, Any] = {}

    def compose(self) -> ComposeResult:
        yield NestPatchHeader(active_tab="F2", id="screen-header")
        yield IPCommandBar(id="ip-command-bar")
        yield PipelineStepper(id="pipeline-stepper")
        with Horizontal(id="main-workspace-split"):
            with Vertical(id="left-telemetry-pane"):
                yield VlanMatrixWidget(id="vlan-matrix-widget")
            with Vertical(id="right-stream-pane"):
                yield Static(
                    "[bold #c93b93]REAL-TIME EXECUTION & IPC STREAM[/]",
                    classes="section-title",
                )
                yield LogStreamWidget(id="log-stream-widget")
        yield Static("", id="status-footer-bar")

    def on_mount(self) -> None:
        self._update_footer_status("READY")

    def _update_footer_status(self, state_label: str) -> None:
        health = check_engine_health()
        rust_mode = "ONLINE" if health["rust_auditor"]["online"] else "PY-FALLBACK"
        go_mode = "ONLINE" if health["go_dispatcher"]["online"] else "PY-FALLBACK"
        footer = self.query_one("#status-footer-bar", Static)
        footer.update(
            f"[bold #c93b93]STATUS: [{state_label}][/] | "
            f"[bold #ff7536]ENGINES: RUST [{rust_mode}] GO [{go_mode}][/] | "
            f"[#a695b8]F2:1-IP VLAN  F3:AUDITOR  F4:BATCH/SERIAL  F5:INVENTORY  CTRL+R:ROLLBACK  F10:QUIT[/]"
        )

    async def on_ipcommand_bar_deploy_requested(
        self, event: IPCommandBar.DeployRequested
    ) -> None:
        await self.execute_provisioning(
            target_ip=event.target_ip,
            vlan_id=event.vlan_id,
            vendor_hint=event.vendor_hint,
            auth_profile=event.auth_profile,
        )

    async def execute_provisioning(
        self,
        target_ip: str,
        vlan_id: str = "AUTO",
        vendor_hint: str = "",
        auth_profile: str = "ssh_ed25519_admin",
    ) -> Dict[str, Any]:
        stepper = self.query_one("#pipeline-stepper", PipelineStepper)
        log_win = self.query_one("#log-stream-widget", LogStreamWidget)
        matrix = self.query_one("#vlan-matrix-widget", VlanMatrixWidget)
        header = self.query_one("#screen-header", NestPatchHeader)

        stepper.reset_pipeline()
        self._update_footer_status("PROVISIONING")

        def handle_stage(stage_idx: int, status: str, detail: str) -> None:
            stepper.update_stage(stage_idx, status, detail)

        def handle_log(tag: str, message: str) -> None:
            log_win.append_log(tag, message)

        try:
            result = await self.orchestrator.execute_single_ip_pipeline(
                raw_target_ip=target_ip,
                desired_vlan_input=vlan_id,
                vendor_hint=vendor_hint,
                auth_profile=auth_profile,
                fast_mode=True,
                on_stage=handle_stage,
                on_log=handle_log,
            )
            self.last_result = result
            sense = result.get("sense", {})
            header.update_medium(
                sense.get("medium_type", "WIRED_802_3"),
                sense.get("egress_interface", "eth0"),
                sense.get("wireless_ssid"),
            )
            matrix.update_from_pipeline_result(result)
            self._update_footer_status("LOCKED // VERIFIED")
            return result
        except Exception as exc:
            log_win.append_log("ERROR", f"Pipeline halted: {exc}")
            stepper.update_stage(1, "ERR", str(exc))
            self._update_footer_status("ALERT // HALTED")
            return {"status": "ERROR", "error": str(exc)}

    async def trigger_emergency_rollback(self) -> Dict[str, Any]:
        log_win = self.query_one("#log-stream-widget", LogStreamWidget)
        self._update_footer_status("ROLLING BACK")
        try:
            res = await self.orchestrator.execute_emergency_rollback(
                on_log=lambda tag, msg: log_win.append_log(tag, msg)
            )
            self._update_footer_status("ROLLED BACK")
            return res
        except Exception as exc:
            log_win.append_log("ERROR", f"Rollback error: {exc}")
            self._update_footer_status("ROLLBACK ERR")
            return {"status": "ERROR", "error": str(exc)}
