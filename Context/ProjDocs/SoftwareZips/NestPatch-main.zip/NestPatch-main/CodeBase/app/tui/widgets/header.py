"""
NestPatch Tactical Branded Header & Connection Medium Badge Widget (header.py).
Displays CyberNest Labs branding, active screen indicator, and live WIRED / WIRELESS link badge.
"""
from textual.app import ComposeResult
from textual.widgets import Static


class NestPatchHeader(Static):
    """Top tactical banner displaying CyberNest Labs identity, keybindings, and medium status."""

    def __init__(self, active_tab: str = "F2", medium_label: str = "WIRED 802.3", **kwargs) -> None:
        super().__init__(**kwargs)
        self.active_tab = active_tab
        self.medium_label = medium_label

    def compose(self) -> ComposeResult:
        yield Static("", id="header-top-row")
        yield Static("", id="header-nav-row")

    def on_mount(self) -> None:
        self._refresh_banner()

    def update_medium(self, medium_type: str, iface: str = "", ssid: str | None = None) -> None:
        if medium_type == "WIRELESS_802_11":
            ssid_tag = f" // {ssid}" if ssid else ""
            self.medium_label = f"WIRELESS 802.11 ({iface or 'wlan0'}{ssid_tag})"
        else:
            self.medium_label = f"WIRED 802.3 ({iface or 'eth0'})"
        self._refresh_banner()

    def set_active_tab(self, tab_key: str) -> None:
        self.active_tab = tab_key
        self._refresh_banner()

    def _refresh_banner(self) -> None:
        top = self.query_one("#header-top-row", Static)
        nav = self.query_one("#header-nav-row", Static)

        top.update(
            f"[bold #c93b93][CYBERNEST LABS][/] [bold #f0e6f7]NestPatch // Automated Military-Grade VLAN Provisioner [v1.0.0][/]   "
            f"[bold #ff7536][LINK: {self.medium_label}][/]"
        )

        tabs = [
            ("F2", "1-IP Auto-VLAN"),
            ("F3", "Config & Entropy Auditor"),
            ("F4", "Batch/Serial Dispatch"),
            ("F5", "Inventory & Rollbacks"),
            ("Ctrl+R", "Emergency Rollback"),
            ("F10/Q", "Quit"),
        ]
        rendered_tabs = []
        for key, label in tabs:
            if key == self.active_tab:
                rendered_tabs.append(f"[bold #f0e6f7 on #8142db] [{key}: {label}] [/]")
            else:
                rendered_tabs.append(f"[#a695b8][{key}: {label}][/]")
        nav.update("  ".join(rendered_tabs))
