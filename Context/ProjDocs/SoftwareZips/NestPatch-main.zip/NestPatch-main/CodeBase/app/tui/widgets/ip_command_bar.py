"""
NestPatch Single-IP Command Bar Widget (ip_command_bar.py).
Provides the 1-Input Target IP field, optional VLAN ID override ('AUTO'),
vendor profile selector, and the primary Military-Grade VLAN deployment trigger.
"""
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.widgets import Button, Input, Label, Select, Static

from app.core.config import AUTH_PROFILES, SUPPORTED_VENDORS


class IPCommandBar(Static):
    """Interactive Single-IP input bar for automated Military-Grade VLAN deployment."""

    class DeployRequested(Message):
        """Dispatched when the operator presses Enter or clicks the Deploy button."""

        def __init__(
            self,
            target_ip: str,
            vlan_id: str,
            vendor_hint: str,
            auth_profile: str,
        ) -> None:
            super().__init__()
            self.target_ip = target_ip
            self.vlan_id = vlan_id
            self.vendor_hint = vendor_hint
            self.auth_profile = auth_profile

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static(
                "[bold #c93b93]SINGLE-IP AUTOMATED MILITARY-GRADE SECURE VLAN DEPLOYMENT[/]  "
                "[#a695b8](DISA STIG / NSA Layer 2 + Layer 3 + Wireless 802.11w PMF & Client Isolation)[/]",
                classes="section-title",
            )
            with Horizontal(classes="command-row"):
                yield Label("Target Device IP:", classes="field-label")
                yield Input(
                    value="192.168.1.1",
                    placeholder="e.g. 192.168.1.1 or 10.10.0.254",
                    id="input-target-ip",
                )
                yield Label("  VLAN ID:", classes="field-label")
                yield Input(
                    value="AUTO",
                    placeholder="AUTO or 2..4090",
                    id="input-vlan-id",
                )
                yield Label("  Platform:", classes="field-label")
                yield Select(
                    options=[(label, val) for label, val in SUPPORTED_VENDORS],
                    value="",
                    allow_blank=False,
                    id="select-vendor",
                )
                yield Label("  Auth:", classes="field-label")
                yield Select(
                    options=[(label, val) for label, val in AUTH_PROFILES],
                    value="ssh_ed25519_admin",
                    allow_blank=False,
                    id="select-auth",
                )
            with Horizontal(classes="command-row"):
                yield Button(
                    ">>> DEPLOY MILITARY-GRADE SECURE VLAN (ENTER) <<<",
                    id="btn-deploy-vlan",
                    classes="btn-deploy",
                )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-deploy-vlan":
            self.trigger_deploy()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id in ("input-target-ip", "input-vlan-id"):
            self.trigger_deploy()

    def trigger_deploy(self) -> None:
        ip_val = self.query_one("#input-target-ip", Input).value.strip()
        vlan_val = self.query_one("#input-vlan-id", Input).value.strip() or "AUTO"
        vendor_sel = self.query_one("#select-vendor", Select).value
        auth_sel = self.query_one("#select-auth", Select).value
        self.post_message(
            self.DeployRequested(
                target_ip=ip_val,
                vlan_id=vlan_val,
                vendor_hint=str(vendor_sel or ""),
                auth_profile=str(auth_sel or "ssh_ed25519_admin"),
            )
        )
