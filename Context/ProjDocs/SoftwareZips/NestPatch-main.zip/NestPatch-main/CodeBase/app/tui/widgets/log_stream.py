"""
NestPatch Real-Time ANSI Execution & IPC Stream Widget (log_stream.py).
Displays timestamped telemetry from Python Sense, Go Fingerprinter/Dispatcher, and Rust Auditor.
"""
from typing import List
from textual.widgets import RichLog


class LogStreamWidget(RichLog):
    """Scrollable high-contrast RichLog window for live IPC and command stream telemetry."""

    def __init__(self, **kwargs) -> None:
        super().__init__(highlight=True, markup=True, wrap=True, max_lines=500, **kwargs)
        self._history: List[str] = []

    def on_mount(self) -> None:
        self.append_log(
            "INIT",
            "NestPatch Air-Gapped TUI Engine ready. Enter a single target IP above and press ENTER.",
        )

    def append_log(self, tag: str, message: str) -> None:
        tag_upper = tag.upper()
        if tag_upper in ("WARN", "ERR", "ERROR", "ROLLBACK"):
            color = "#ff3366"
        elif tag_upper in ("LOCK", "SYNTH", "COMMIT"):
            color = "#c93b93"
        elif tag_upper in ("RUST", "GO", "PROBE"):
            color = "#ff7536"
        else:
            color = "#f0e6f7"

        formatted = f"[bold {color}]{message}[/]"
        self._history.append(message)
        self.write(formatted)

    def get_plain_transcript(self) -> List[str]:
        return list(self._history)
