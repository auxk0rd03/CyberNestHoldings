"""
NestPatch 5-Stage Pipeline Stepper Widget (pipeline_stepper.py).
Visualizes the 5 deterministic phases:
  [1. MEDIUM SENSE] -> [2. OS FINGERPRINT] -> [3. RUST AUDIT] -> [4. SYNTHESIS] -> [5. LOCK]
"""
from typing import Dict
from textual.app import ComposeResult
from textual.widgets import Static


STAGE_NAMES: Dict[int, str] = {
    1: "1. MEDIUM SENSE",
    2: "2. OS FINGERPRINT",
    3: "3. RUST AUDIT",
    4: "4. SYNTHESIS",
    5: "5. LOCK & COMMIT",
}


class PipelineStepper(Static):
    """Renders real-time 5-stage progress badges in the Aero-Sunset theme."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.stage_states: Dict[int, str] = {i: "IDLE" for i in range(1, 6)}
        self.stage_detail: str = "Awaiting Single-IP Target Input..."

    def compose(self) -> ComposeResult:
        yield Static("", id="stepper-line-1")
        yield Static("", id="stepper-line-2")

    def on_mount(self) -> None:
        self._refresh_view()

    def reset_pipeline(self) -> None:
        self.stage_states = {i: "IDLE" for i in range(1, 6)}
        self.stage_detail = "Initializing 5-stage Military-Grade VLAN pipeline..."
        self._refresh_view()

    def update_stage(self, stage_idx: int, status: str, detail: str = "") -> None:
        if stage_idx in self.stage_states:
            self.stage_states[stage_idx] = status.upper()
        if detail:
            self.stage_detail = detail
        self._refresh_view()

    def _refresh_view(self) -> None:
        parts = []
        for idx in range(1, 6):
            st = self.stage_states[idx]
            name = STAGE_NAMES[idx]
            if st == "OK":
                parts.append(f"[bold #f0e6f7 on #c93b93] [{name}: OK] [/]")
            elif st == "ACTIVE":
                parts.append(f"[bold #0d0814 on #ff7536] [{name}: ACTIVE] [/]")
            elif st == "ERR":
                parts.append(f"[bold #f0e6f7 on #ff3366] [{name}: ERR] [/]")
            else:
                parts.append(f"[#a695b8][{name}: IDLE][/]")

        line1 = " [bold #8142db]->[/] ".join(parts)
        line2 = f"[bold #c93b93]PIPELINE TELEMETRY:[/] [#f0e6f7]{self.stage_detail}[/]"

        self.query_one("#stepper-line-1", Static).update(line1)
        self.query_one("#stepper-line-2", Static).update(line2)
