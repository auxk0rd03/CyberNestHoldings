"""
NestPatch Target Device Telemetry & Hardening Matrix Widget (vlan_matrix.py).
Displays target device attributes, allocated VLAN, Blackhole VLAN 999, wired/wireless
defenses, and STIG compliance posture.
"""
from typing import Any, Dict
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import DataTable, Static


class VlanMatrixWidget(Static):
    """Displays the Target Device Telemetry summary card and interactive STIG Hardening Matrix."""

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static(
                "[bold #c93b93]TARGET DEVICE TELEMETRY & HARDENING MATRIX[/]",
                classes="section-title",
            )
            yield Static(
                "[#a695b8]Target IP        :[/] [#f0e6f7]Awaiting Target IP...[/]\n"
                "[#a695b8]Local Ingress    :[/] [#f0e6f7]Auto-Sense Standby[/]\n"
                "[#a695b8]Allocated VLAN   :[/] [#f0e6f7]Pending Synthesis[/]\n"
                "[#a695b8]Blackhole VLAN   :[/] [#f0e6f7]VLAN 999 (Unused Ports Parked)[/]\n"
                "[#a695b8]Wired Defenses   :[/] [#c93b93]DAI [READY] | Snooping [READY] | BPDU Guard [READY][/]\n"
                "[#a695b8]Wireless Defense :[/] [#c93b93]L2 Client Isolation [READY] | PMF 802.11w [READY][/]\n"
                "[#a695b8]Rollback Guard   :[/] [#ff7536]120s Transactional Dead-Man Revert Armed[/]",
                id="telemetry-summary-card",
            )
            yield DataTable(id="matrix-controls-table")

    def on_mount(self) -> None:
        table = self.query_one("#matrix-controls-table", DataTable)
        table.cursor_type = "row"
        table.add_columns("Control ID", "Security Posture / Enforced Directive", "Status")
        table.add_row("DISA-STIG-L2-001", "Default VLAN 1 Eradication & Blackhole VLAN 999 Parking", "STANDBY")
        table.add_row("DISA-STIG-L2-002", "Dynamic ARP Inspection (DAI) + 15pps Rate Limit", "STANDBY")
        table.add_row("DISA-STIG-L2-003", "DHCP Snooping Binding Database Enforcement", "STANDBY")
        table.add_row("DISA-STIG-L2-004", "Spanning-Tree PortFast BPDU Guard & Root Guard", "STANDBY")
        table.add_row("DISA-STIG-L3-006", "RFC-1918 Inter-VLAN Default-Deny Extended ACL", "STANDBY")
        table.add_row("NSA-WL-007", "802.11w PMF Mandatory & L2 Wireless Client Isolation", "STANDBY")

    def update_from_pipeline_result(self, result: Dict[str, Any]) -> None:
        sense = result.get("sense", {})
        fp = result.get("fingerprint", {})
        synth = result.get("audit_synth", {})
        deploy = result.get("deploy", {})

        target_ip = result.get("target_ip", "192.168.1.1")
        hw = fp.get("hardware_model", "Enterprise Switch")
        os_ver = fp.get("os_version", "IOS-XE")
        egress = sense.get("egress_interface", "eth0")
        src_ip = sense.get("source_ip", "0.0.0.0")
        medium = sense.get("medium_type", "WIRED_802_3")
        vlan_id = synth.get("allocated_vlan_id", 400)
        subnet = synth.get("isolated_subnet_cidr", "10.240.150.0/24")
        gw = synth.get("gateway_address", "10.240.150.1")
        bh_vlan = synth.get("blackhole_vlan_id", 999)
        revert_s = deploy.get("revert_timer_secs", 120)
        audit_hash = deploy.get("audit_hash", "")[:20]

        card = self.query_one("#telemetry-summary-card", Static)
        card.update(
            f"[#a695b8]Target IP        :[/] [bold #f0e6f7]{target_ip}[/] [#ff7536]({hw} // {os_ver})[/]\n"
            f"[#a695b8]Local Ingress    :[/] [bold #f0e6f7]{egress}[/] ({src_ip} // {medium} // [bold #c93b93]PROTECTED[/])\n"
            f"[#a695b8]Allocated VLAN   :[/] [bold #c93b93]VLAN {vlan_id}[/] ({subnet} // GW {gw})\n"
            f"[#a695b8]Blackhole VLAN   :[/] [bold #ff7536]VLAN {bh_vlan}[/] (Suspended // Native Trunk & Unused Ports Parked)\n"
            f"[#a695b8]Wired Defenses   :[/] [bold #c93b93]DAI [ON] | DHCP Snooping [ON] | Sticky MAC [ON] | BPDU [ON][/]\n"
            f"[#a695b8]Wireless Defense :[/] [bold #c93b93]L2 Client Isolation [ON] | 802.11w PMF [ON] | WPA3-SAE [ON][/]\n"
            f"[#a695b8]Rollback Guard   :[/] [bold #ff7536]{revert_s}s Dead-Man Verified & Committed[/] (SHA256: {audit_hash})"
        )

        table = self.query_one("#matrix-controls-table", DataTable)
        table.clear()
        for ctrl in synth.get("enforced_controls", []):
            if ":" in ctrl:
                cid, desc = ctrl.split(":", 1)
            else:
                cid, desc = "STIG-CTRL", ctrl
            table.add_row(cid.strip(), desc.strip(), "ENFORCED [LOCKED]")
