@echo off
rem ==============================================================================
rem CyberNest Labs // NestPatch Windows 10/11 Orchestrator (dev.bat)
rem Standard: CN-DIR-2026-004 (Dual-Native Orchestration Architecture)
rem Security: CMMC 2.0 / FIPS 140-3 / DISA STIG / CWE-22, 114, 377
rem ==============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

rem --- User Cache Preservation Under Admin Elevation (Section 3.2) ---
if "%USERPROFILE%"=="" set "USERPROFILE=%SystemDrive%\Users\%USERNAME%"
if "%LOCALAPPDATA%"=="" set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
if "%CARGO_HOME%"=="" set "CARGO_HOME=%USERPROFILE%\.cargo"
if "%RUSTUP_HOME%"=="" set "RUSTUP_HOME=%USERPROFILE%\.rustup"
if "%GOPATH%"=="" set "GOPATH=%USERPROFILE%\go"
if "%GOMODCACHE%"=="" set "GOMODCACHE=%GOPATH%\pkg\mod"
if "%GOCACHE%"=="" set "GOCACHE=%LOCALAPPDATA%\go-build"
set "PATH=%CARGO_HOME%\bin;%GOPATH%\bin;%PATH%"

set "GOFIPS=1"
set "GODEBUG=fips140=on"

rem --- Hardened Enclave Logging & ACLs (CWE-377) ---
set "CACHE_DIR=%LOCALAPPDATA%\nestpatch"
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
icacls "%CACHE_DIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1

set "LOG_FILE=%CACHE_DIR%\session.log"
if exist "%LOG_FILE%" (
    fsutil reparsepoint query "%LOG_FILE%" >nul 2>&1 && del /f /q "%LOG_FILE%"
)
type nul >> "%LOG_FILE%"
icacls "%LOG_FILE%" /inheritance:r /grant:r "%USERNAME%:F" >nul 2>&1

set "CMD=%~1"
if "%CMD%"=="" set "CMD=run"

if /I "%CMD%"=="setup" goto :cmd_setup
if /I "%CMD%"=="build" goto :cmd_build
if /I "%CMD%"=="run" goto :cmd_run
if /I "%CMD%"=="serve" goto :cmd_run
if /I "%CMD%"=="cli" goto :cmd_cli
if /I "%CMD%"=="simulate" goto :cmd_simulate
if /I "%CMD%"=="test" goto :cmd_test
if /I "%CMD%"=="fmt" goto :cmd_fmt

echo Usage: %~nx0 {setup^|build^|run^|serve^|cli^|simulate^|test^|fmt}
exit /b 1

:cmd_setup
echo ==> [SETUP] Verifying Windows 10/11 polyglot toolchains...
where go >nul 2>&1 || (echo [WARN] Go compiler missing from PATH.)
where cargo >nul 2>&1 || (echo [WARN] Rust/Cargo missing from PATH.)
where python >nul 2>&1 || (echo [ERROR] Python 3 missing from PATH. & exit /b 1)
go version 2>nul
cargo --version 2>nul
python --version 2>nul

if not exist ".venv" (
    echo [INFO] Creating Python virtual environment...
    python -m venv .venv
)
call .venv\Scripts\activate.bat
if exist "requirements.txt" (
    python -c "import textual, rich, aiosqlite, pydantic" >nul 2>&1
    if !ERRORLEVEL! neq 0 (
        pip install -q -r requirements.txt
    )
)
echo [+] Setup complete.
exit /b 0

:do_build
if not exist "bin" mkdir "bin"
call :cmd_setup >nul 2>&1

if exist "engines\batch_dispatcher" (
    echo ==> Compiling Go batch_dispatcher engine (Static, GOFIPS=1)...
    pushd engines\batch_dispatcher
    set "GOFIPS=1"
    set "GODEBUG=fips140=on"
    set "CGO_ENABLED=0"
    go build -ldflags="-s -w" -o ..\..\bin\batch_dispatcher.exe . 2>nul
    popd
)

if exist "engines\patch_auditor" (
    echo ==> Compiling Rust patch_auditor engine (Release LTO)...
    pushd engines\patch_auditor
    cargo build --release --quiet 2>nul || cargo build --release
    if exist "target\release\patch_auditor.exe" (
        copy /y target\release\patch_auditor.exe ..\..\bin\patch_auditor.exe >nul
    )
    popd
)

if exist "..\..\NestSBOM\sbom_cli.py" (
    python ..\..\NestSBOM\sbom_cli.py --repo . --out-dir . >nul 2>&1
    python ..\..\NestSBOM\sbom_cli.py --repo .. --out-dir .. >nul 2>&1
)
exit /b 0

:cmd_build
call :do_build
exit /b %ERRORLEVEL%

:cmd_run
call :do_build
echo ==> Launching NestPatch Aero-Sunset TUI...
if exist ".venv\Scripts\activate.bat" call .venv\Scripts\activate.bat
python -u -m app.main
exit /b %ERRORLEVEL%

:cmd_cli
call :do_build
if exist ".venv\Scripts\activate.bat" call .venv\Scripts\activate.bat
python -u -m app.main --cli
exit /b %ERRORLEVEL%

:cmd_simulate
call :do_build
if exist ".venv\Scripts\activate.bat" call .venv\Scripts\activate.bat
python -u -m app.main --simulate --export
exit /b %ERRORLEVEL%

:cmd_test
call :do_build
if exist ".venv\Scripts\activate.bat" call .venv\Scripts\activate.bat
if exist "engines\batch_dispatcher" (
    echo ==> Running Go batch_dispatcher tests...
    pushd engines\batch_dispatcher
    go test -v .
    popd
)
if exist "engines\patch_auditor" (
    echo ==> Running Rust patch_auditor tests...
    pushd engines\patch_auditor
    cargo test
    popd
)
echo ==> Running Python & Headless TUI unit tests...
python -m unittest discover -s tests -v
exit /b %ERRORLEVEL%

:cmd_fmt
echo ==> Formatting Go and Rust codebases...
if exist "engines\batch_dispatcher" (
    pushd engines\batch_dispatcher
    go fmt .
    popd
)
if exist "engines\patch_auditor" (
    pushd engines\patch_auditor
    cargo fmt
    popd
)
exit /b 0
