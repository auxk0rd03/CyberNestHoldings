#!/usr/bin/env bash
# ==============================================================================
# NestPatch Standardized POSIX Entrypoint (dev.sh)
# Delegates to launcher.sh per CN-DIR-2026-004 Bi-Launcher Specification
# ==============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/launcher.sh" "$@"
