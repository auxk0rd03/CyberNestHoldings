module cybernest.local/nestpatch/batch_dispatcher

go 1.22
