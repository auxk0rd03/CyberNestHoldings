// ==============================================================================
// NestPatch Go Engine — JSON STDIN Router & Bounded Worker Pool (main.go)
// CyberNest Holdings LLC — Authorized Security Engineering Standard
// ==============================================================================
package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sync"
)

type EnvelopeRequest struct {
	Action           string   `json:"action"`
	TargetIP         string   `json:"target_ip"`
	Targets          []string `json:"targets"`
	MediumType       string   `json:"medium_type"`
	VendorPlatform   string   `json:"vendor_platform"`
	VendorHint       string   `json:"vendor_hint"`
	AuthProfile      string   `json:"auth_profile"`
	AllocatedVlanID  int      `json:"allocated_vlan_id"`
	Commands         []string `json:"commands"`
	RollbackCommands []string `json:"rollback_commands"`
	RevertTimerSecs  int      `json:"revert_timer_secs"`
	FastMode         bool     `json:"fast_mode"`
	DeviceNode       string   `json:"device_node"`
	BaudRate         int      `json:"baud_rate"`
	MaxWorkers       int      `json:"max_workers"`
	TimeoutMs        int      `json:"timeout_ms"`
}

type BatchDispatchResponse struct {
	Status  string            `json:"status"`
	Engine  string            `json:"engine"`
	Workers int               `json:"workers"`
	Results []ProvisionResult `json:"results"`
}

func executeBoundedBatch(req EnvelopeRequest) BatchDispatchResponse {
	workers := req.MaxWorkers
	if workers < 2 {
		workers = 2
	}
	if workers > 8 {
		workers = 8
	}

	targets := req.Targets
	if len(targets) == 0 && req.TargetIP != "" {
		targets = []string{req.TargetIP}
	}

	jobs := make(chan ProvisionJob, len(targets))
	results := make(chan ProvisionResult, len(targets))

	var wg sync.WaitGroup
	activeWorkers := workers
	if len(targets) < activeWorkers && len(targets) > 0 {
		activeWorkers = len(targets)
	}

	for w := 0; w < activeWorkers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				results <- ExecuteTransactionalVlanDeploy(j)
			}
		}()
	}

	for _, ip := range targets {
		jobs <- ProvisionJob{
			Action:           "deploy",
			TargetIP:         ip,
			MediumType:       req.MediumType,
			VendorPlatform:   req.VendorPlatform,
			AllocatedVlanID:  req.AllocatedVlanID,
			Commands:         req.Commands,
			RollbackCommands: req.RollbackCommands,
			RevertTimerSecs:  req.RevertTimerSecs,
			FastMode:         true,
		}
	}
	close(jobs)
	wg.Wait()
	close(results)

	var out []ProvisionResult
	for res := range results {
		out = append(out, res)
	}

	return BatchDispatchResponse{
		Status:  "OK",
		Engine:  "go_batch_dispatcher",
		Workers: activeWorkers,
		Results: out,
	}
}

func emitJSON(v any) {
	enc := json.NewEncoder(os.Stdout)
	if err := enc.Encode(v); err != nil {
		fmt.Fprintf(os.Stderr, "[BATCH_DISPATCHER_ERR] Failed encoding JSON: %v\n", err)
		fmt.Println(`{"status":"ERROR","engine":"go_batch_dispatcher","error":"JSON encode failure"}`)
	}
}

func main() {
	if err := RunFIPS1403SelfTest(); err != nil {
		fmt.Fprintf(os.Stderr, "[BATCH_DISPATCHER_ERR] FIPS 140-3 KAT failed: %v\n", err)
		fmt.Println(`{"status":"ERROR","engine":"go_batch_dispatcher","error":"FIPS 140-3 self-test failure"}`)
		return
	}

	rawBytes, err := io.ReadAll(io.LimitReader(os.Stdin, MaxStdinPayloadBytes))
	if err != nil {
		fmt.Fprintf(os.Stderr, "[BATCH_DISPATCHER_ERR] Failed reading STDIN: %v\n", err)
		fmt.Println(`{"status":"ERROR","engine":"go_batch_dispatcher","error":"STDIN read error"}`)
		return
	}

	var req EnvelopeRequest
	if err := json.Unmarshal(rawBytes, &req); err != nil {
		fmt.Fprintf(os.Stderr, "[BATCH_DISPATCHER_ERR] Invalid JSON on STDIN: %v\n", err)
		fmt.Println(`{"status":"ERROR","engine":"go_batch_dispatcher","error":"Invalid JSON input"}`)
		return
	}

	switch req.Action {
	case "compliance_check":
		emitJSON(GenerateComplianceAttestation())

	case "fingerprint":
		res := FingerprintTargetDevice(FingerprintRequest{
			TargetIP:    req.TargetIP,
			MediumType:  req.MediumType,
			AuthProfile: req.AuthProfile,
			VendorHint:  req.VendorHint,
			TimeoutMs:   req.TimeoutMs,
		})
		emitJSON(res)

	case "serial_bootstrap":
		res := ExecuteSerialBootstrap(SerialBootstrapRequest{
			DeviceNode: req.DeviceNode,
			BaudRate:   req.BaudRate,
			Commands:   req.Commands,
		})
		emitJSON(res)

	case "batch_dispatch":
		res := executeBoundedBatch(req)
		emitJSON(res)

	case "rollback":
		res := ExecuteTransactionalVlanDeploy(ProvisionJob{
			Action:           "rollback",
			TargetIP:         req.TargetIP,
			MediumType:       req.MediumType,
			VendorPlatform:   req.VendorPlatform,
			AllocatedVlanID:  req.AllocatedVlanID,
			Commands:         req.RollbackCommands,
			RollbackCommands: nil,
			RevertTimerSecs:  60,
			FastMode:         true,
		})
		res.Status = "ROLLED_BACK"
		emitJSON(res)

	default:
		// Default: Single-IP Transactional VLAN Deployment
		res := ExecuteTransactionalVlanDeploy(ProvisionJob{
			Action:           "deploy",
			TargetIP:         req.TargetIP,
			MediumType:       req.MediumType,
			VendorPlatform:   req.VendorPlatform,
			AllocatedVlanID:  req.AllocatedVlanID,
			Commands:         req.Commands,
			RollbackCommands: req.RollbackCommands,
			RevertTimerSecs:  req.RevertTimerSecs,
			FastMode:         req.FastMode,
		})
		emitJSON(res)
	}
}
