// ==============================================================================
// NestPatch Go Engine — Automated Security & Compliance Test Suite (security_test.go)
// ==============================================================================
package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestFIPS1403SelfTest(t *testing.T) {
	if err := RunFIPS1403SelfTest(); err != nil {
		t.Fatalf("FIPS 140-3 KAT failed: %v", err)
	}
}

func TestCWE22PathSanitization(t *testing.T) {
	clean, err := SanitizeRelativePath("exports/stig_report.json")
	if err != nil || clean != "exports/stig_report.json" {
		t.Fatalf("expected valid relative path, got %q (err=%v)", clean, err)
	}

	badInputs := []string{
		"../etc/passwd",
		"/etc/shadow",
		"a\\b\\c",
		"-flag",
		"C:/Windows/System32",
		"",
	}
	for _, bad := range badInputs {
		if _, err := SanitizeRelativePath(bad); err == nil {
			t.Errorf("expected CWE-22 error for input %q", bad)
		}
	}

	tmpDir := t.TempDir()
	resolved, err := SafeResolveUnder(tmpDir, "sub/report.json")
	if err != nil {
		t.Fatalf("SafeResolveUnder failed: %v", err)
	}
	if filepath.Dir(resolved) != filepath.Join(tmpDir, "sub") {
		t.Fatalf("unexpected resolved path: %s", resolved)
	}

	// Verify symlink rejection (CWE-377)
	targetFile := filepath.Join(tmpDir, "real.txt")
	_ = os.WriteFile(targetFile, []byte("ok"), 0o600)
	symFile := filepath.Join(tmpDir, "sym.txt")
	if err := os.Symlink(targetFile, symFile); err == nil {
		if _, err := SafeResolveUnder(tmpDir, "sym.txt"); err == nil {
			t.Errorf("expected symlink rejection (CWE-377)")
		}
	}
}

func TestSerialDeviceNodeValidation(t *testing.T) {
	if dev, err := ValidateSerialDeviceNode("/dev/ttyUSB0"); err != nil || dev != "/dev/ttyUSB0" {
		t.Fatalf("expected valid /dev/ttyUSB0, got %q (err=%v)", dev, err)
	}
	if _, err := ValidateSerialDeviceNode("/etc/passwd"); err == nil {
		t.Errorf("expected error for /etc/passwd serial device")
	}
	res := ExecuteSerialBootstrap(SerialBootstrapRequest{
		DeviceNode: "../etc/passwd",
		BaudRate:   115200,
		Commands:   []string{"show version"},
	})
	if res.Status != "ERROR" {
		t.Errorf("expected ERROR status for invalid serial device node, got %s", res.Status)
	}
}

func TestLoopbackOriginFirewall(t *testing.T) {
	if !VerifyLoopbackOrigin("127.0.0.1:8080", "http://127.0.0.1:8080") {
		t.Errorf("expected localhost origin to pass")
	}
	if VerifyLoopbackOrigin("evil.example.com", "http://evil.example.com") {
		t.Errorf("expected untrusted host/origin to be blocked")
	}
}

func TestTransactionalDeadManSwitchDeploy(t *testing.T) {
	res := ExecuteTransactionalVlanDeploy(ProvisionJob{
		Action:          "deploy",
		TargetIP:        "192.168.1.1",
		MediumType:      "WIRED_802_3",
		VendorPlatform:  "cisco_ios",
		AllocatedVlanID: 401,
		Commands:        []string{"vlan 401", "name CN_MIL_SEC_401"},
		RevertTimerSecs: 120,
		FastMode:        true,
	})
	if res.Status != "SUCCESS_LOCKED" || !res.RollbackArmed || res.RevertTimerSecs != 120 {
		t.Fatalf("unexpected transactional deploy result: %+v", res)
	}
	if len(res.AuditHash) != 64 {
		t.Fatalf("expected 64-char SHA-256 audit hash, got %q", res.AuditHash)
	}
}
