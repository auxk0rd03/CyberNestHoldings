// ==============================================================================
// NestPatch Rust Engine — Shannon Entropy Secret & Credential Auditor (entropy.rs)
// Computes H(X) = - sum( P(x_i) * log2(P(x_i)) ) in O(n) linear time.
// ==============================================================================

use std::collections::HashMap;

#[derive(Clone, Debug)]
pub struct EntropyFinding {
    pub line_number: usize,
    pub secret_type: String,
    pub entropy_bits: f64,
    pub redacted_preview: String,
    pub severity: String,
    pub recommendation: String,
}

/// Computes Shannon Entropy H(X) in bits per symbol for a given byte slice.
pub fn calculate_shannon_entropy(input: &str) -> f64 {
    let bytes = input.as_bytes();
    if bytes.is_empty() {
        return 0.0;
    }
    let len = bytes.len() as f64;
    let mut freq: HashMap<u8, usize> = HashMap::new();
    for &b in bytes {
        *freq.entry(b).or_insert(0) += 1;
    }

    let mut entropy = 0.0_f64;
    for &count in freq.values() {
        let p = (count as f64) / len;
        if p > 0.0 {
            entropy -= p * p.log2();
        }
    }
    (entropy * 1000.0).round() / 1000.0
}

/// Redacts a candidate secret token while retaining prefix/suffix context for auditing.
pub fn redact_token(token: &str) -> String {
    let chars: Vec<char> = token.chars().collect();
    if chars.len() <= 4 {
        return "****".to_string();
    }
    let prefix: String = chars.iter().take(2).collect();
    let suffix: String = chars.iter().skip(chars.len().saturating_sub(2)).collect();
    format!("{}***[REDACTED len={}]***{}", prefix, chars.len(), suffix)
}

/// Scans a full device running configuration for high-entropy credentials, weak hashes,
/// plaintext SNMP community strings, WPA pre-shared keys, and private keys.
pub fn scan_config_entropy(running_config: &str, threshold: f64) -> Vec<EntropyFinding> {
    let mut findings = Vec::new();
    let effective_threshold = if threshold <= 0.1 { 3.55 } else { threshold };

    for (idx, raw_line) in running_config.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('!') || trimmed.starts_with('#') {
            continue;
        }
        let lower = trimmed.to_ascii_lowercase();

        // 1. Detect legacy Cisco Type 7 / Type 0 reversible or cleartext passwords
        if lower.contains("password 7 ")
            || lower.contains("password 0 ")
            || lower.contains("secret 0 ")
            || lower.contains("enable password ")
        {
            let tokens: Vec<&str> = trimmed.split_whitespace().collect();
            if let Some(last_tok) = tokens.last() {
                let h = calculate_shannon_entropy(last_tok);
                findings.push(EntropyFinding {
                    line_number: line_no,
                    secret_type: "Legacy Cleartext / Reversible Type-7 Credential".to_string(),
                    entropy_bits: h.max(3.60),
                    redacted_preview: redact_token(last_tok),
                    severity: "CRITICAL".to_string(),
                    recommendation: "Migrate to algorithm-type scrypt / SHA-256 (secret 9 / secret 8) and purge reversible passwords.".to_string(),
                });
                continue;
            }
        }

        // 2. Detect insecure SNMPv1/v2c community strings
        if lower.starts_with("snmp-server community ") || lower.contains("community public") || lower.contains("community private") {
            let tokens: Vec<&str> = trimmed.split_whitespace().collect();
            let comm_tok = tokens.get(2).copied().unwrap_or("public");
            let h = calculate_shannon_entropy(comm_tok);
            findings.push(EntropyFinding {
                line_number: line_no,
                secret_type: "Exposed SNMPv1/v2c Community String".to_string(),
                entropy_bits: h,
                redacted_preview: redact_token(comm_tok),
                severity: "HIGH".to_string(),
                recommendation: "Disable SNMPv1/v2c communities and enforce SNMPv3 with AuthPriv (SHA-256 + AES-128).".to_string(),
            });
            continue;
        }

        // 3. Inspect sensitive credential keywords for high-entropy secrets
        let credential_context = lower.contains("secret")
            || lower.contains("password")
            || lower.contains("wpa-psk")
            || lower.contains("pre-shared-key")
            || lower.contains("key-string")
            || lower.contains("radius-server key")
            || lower.contains("tacacs-server key")
            || lower.contains("api-key")
            || lower.contains("option key");

        for raw_tok in trimmed.split_whitespace() {
            let clean_tok = raw_tok.trim_matches(|c: char| c == '"' || c == '\'' || c == ';' || c == ',');
            if clean_tok.len() < 8 {
                continue;
            }
            // Skip known benign CLI syntax tokens or IP/MAC addresses
            if clean_tok.contains('/')
                || clean_tok.starts_with("Gigabit")
                || clean_tok.starts_with("TenGig")
                || clean_tok.starts_with("Ethernet")
                || clean_tok.starts_with("FastEthernet")
                || clean_tok.starts_with("switchport")
                || clean_tok.starts_with("spanning-tree")
                || clean_tok.starts_with("description")
                || clean_tok.chars().all(|c| c.is_ascii_digit() || c == '.')
            {
                continue;
            }

            let h = calculate_shannon_entropy(clean_tok);
            if (credential_context && h >= effective_threshold) || (clean_tok.len() >= 16 && h >= 4.05) {
                findings.push(EntropyFinding {
                    line_number: line_no,
                    secret_type: if credential_context {
                        "High-Entropy Embedded Key / Credential Material".to_string()
                    } else {
                        "High-Entropy Cryptographic Token / Key Blob".to_string()
                    },
                    entropy_bits: h,
                    redacted_preview: redact_token(clean_tok),
                    severity: if h >= 4.10 { "CRITICAL".to_string() } else { "HIGH".to_string() },
                    recommendation: "Remove hardcoded secret from running-config or store in hardware-backed KMS / TACACS+ vault.".to_string(),
                });
                break;
            }
        }
    }

    findings
}
