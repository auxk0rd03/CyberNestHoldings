// ==============================================================================
// NestPatch Rust Engine — Zero-Panic STDIN/STDOUT JSON Entrypoint (main.rs)
// CyberNest Holdings LLC — Authorized Security Engineering Standard
// ==============================================================================

mod entropy;
mod parser;
mod rules;
mod synthesizer;

use std::collections::HashMap;
use std::io::{self, Read};
use std::path::{Component, Path, PathBuf};
use std::time::Instant;

/// FIPS 140-3 Known-Answer Test (KAT) Integrity Verification
pub fn fips_140_3_kat_self_test() -> Result<(), &'static str> {
    let vector: [u8; 8] = [0x4E, 0x45, 0x53, 0x54, 0x50, 0x54, 0x43, 0x48];
    let mut acc: u32 = 0;
    for b in vector {
        acc = acc.wrapping_add(u32::from(b));
    }
    if acc == 617 {
        Ok(())
    } else {
        Err("FIPS 140-3 KAT failed")
    }
}

/// CWE-22 Multi-stage relative path sanitization
pub fn sanitize_relative_path(rel: &str) -> Result<PathBuf, &'static str> {
    let trimmed = rel.trim();
    if trimmed.is_empty() || trimmed.contains('\0') || trimmed.starts_with('-') {
        return Err("Invalid or empty relative path");
    }
    let normalized = trimmed.replace('\\', "/");
    let path = Path::new(&normalized);
    if path.is_absolute() {
        return Err("Absolute path prohibited");
    }
    let mut clean = PathBuf::new();
    for comp in path.components() {
        match comp {
            Component::Normal(seg) => clean.push(seg),
            Component::CurDir => {}
            _ => return Err("Directory traversal detected (CWE-22)"),
        }
    }
    if clean.as_os_str().is_empty() {
        return Err("Resolved to empty path");
    }
    Ok(clean)
}

/// CWE-22 Safe canonical containment check under base_dir
pub fn safe_resolve_under(base_dir: &Path, rel: &str) -> Result<PathBuf, &'static str> {
    let clean_rel = sanitize_relative_path(rel)?;
    let canon_base = base_dir
        .canonicalize()
        .map_err(|_| "Base directory cannot be canonicalized")?;
    let candidate = canon_base.join(&clean_rel);
    if candidate.exists() {
        let meta = std::fs::symlink_metadata(&candidate).map_err(|_| "Metadata check failed")?;
        if meta.file_type().is_symlink() {
            return Err("Symlink target rejected (CWE-377)");
        }
        let canon_cand = candidate
            .canonicalize()
            .map_err(|_| "Candidate canonicalization failed")?;
        if !canon_cand.starts_with(&canon_base) {
            return Err("Path escapes base directory (CWE-22)");
        }
        Ok(canon_cand)
    } else {
        Ok(candidate)
    }
}

use entropy::scan_config_entropy;
use parser::parse_running_config;
use rules::evaluate_stig_compliance;
use synthesizer::{synthesize_military_grade_vlan, VlanSynthesisRequest};

// ------------------------------------------------------------------------------
// Minimal Zero-Panic JSON Value & Parser (100% Air-Gapped Stdlib Implementation)
// ------------------------------------------------------------------------------
#[derive(Clone, Debug)]
enum JsonVal {
    Str(String),
    Num(f64),
    Bool(bool),
    Null,
    Arr(Vec<JsonVal>),
    Obj(HashMap<String, JsonVal>),
}

impl JsonVal {
    fn as_str(&self) -> Option<&str> {
        if let JsonVal::Str(s) = self {
            Some(s.as_str())
        } else {
            None
        }
    }

    fn as_u16(&self) -> Option<u16> {
        if let JsonVal::Num(n) = self {
            if *n >= 0.0 && *n <= 65535.0 {
                return Some(*n as u16);
            }
        }
        None
    }

    fn as_f64(&self) -> Option<f64> {
        if let JsonVal::Num(n) = self {
            Some(*n)
        } else {
            None
        }
    }

    fn as_u16_vec(&self) -> Vec<u16> {
        if let JsonVal::Arr(items) = self {
            items.iter().filter_map(|v| v.as_u16()).collect()
        } else {
            Vec::new()
        }
    }
}

struct JsonParser<'a> {
    chars: Vec<char>,
    pos: usize,
    _marker: &'a str,
}

impl<'a> JsonParser<'a> {
    fn new(input: &'a str) -> Self {
        Self {
            chars: input.chars().collect(),
            pos: 0,
            _marker: input,
        }
    }

    fn skip_ws(&mut self) {
        while self.pos < self.chars.len() && self.chars[self.pos].is_whitespace() {
            self.pos += 1;
        }
    }

    fn peek(&mut self) -> Option<char> {
        self.skip_ws();
        self.chars.get(self.pos).copied()
    }

    fn parse_value(&mut self) -> Result<JsonVal, String> {
        match self.peek() {
            Some('{') => self.parse_object(),
            Some('[') => self.parse_array(),
            Some('"') => self.parse_string().map(JsonVal::Str),
            Some('t') | Some('f') => self.parse_bool(),
            Some('n') => self.parse_null(),
            Some(c) if c == '-' || c.is_ascii_digit() => self.parse_number(),
            Some(c) => Err(format!("Unexpected token '{}'", c)),
            None => Err("Unexpected end of JSON input".to_string()),
        }
    }

    fn parse_object(&mut self) -> Result<JsonVal, String> {
        self.skip_ws();
        self.pos += 1; // '{'
        let mut map = HashMap::new();
        if self.peek() == Some('}') {
            self.pos += 1;
            return Ok(JsonVal::Obj(map));
        }
        loop {
            let key = self.parse_string()?;
            self.skip_ws();
            if self.peek() != Some(':') {
                return Err("Expected ':' in JSON object".to_string());
            }
            self.pos += 1;
            let val = self.parse_value()?;
            map.insert(key, val);
            match self.peek() {
                Some(',') => {
                    self.pos += 1;
                }
                Some('}') => {
                    self.pos += 1;
                    break;
                }
                _ => return Err("Expected ',' or '}' in JSON object".to_string()),
            }
        }
        Ok(JsonVal::Obj(map))
    }

    fn parse_array(&mut self) -> Result<JsonVal, String> {
        self.skip_ws();
        self.pos += 1; // '['
        let mut arr = Vec::new();
        if self.peek() == Some(']') {
            self.pos += 1;
            return Ok(JsonVal::Arr(arr));
        }
        loop {
            let val = self.parse_value()?;
            arr.push(val);
            match self.peek() {
                Some(',') => {
                    self.pos += 1;
                }
                Some(']') => {
                    self.pos += 1;
                    break;
                }
                _ => return Err("Expected ',' or ']' in JSON array".to_string()),
            }
        }
        Ok(JsonVal::Arr(arr))
    }

    fn parse_string(&mut self) -> Result<String, String> {
        self.skip_ws();
        if self.peek() != Some('"') {
            return Err("Expected '\"' at start of JSON string".to_string());
        }
        self.pos += 1;
        let mut out = String::new();
        while self.pos < self.chars.len() {
            let c = self.chars[self.pos];
            self.pos += 1;
            if c == '"' {
                return Ok(out);
            } else if c == '\\' {
                if self.pos >= self.chars.len() {
                    return Err("Unterminated escape sequence".to_string());
                }
                let esc = self.chars[self.pos];
                self.pos += 1;
                match esc {
                    '"' => out.push('"'),
                    '\\' => out.push('\\'),
                    '/' => out.push('/'),
                    'n' => out.push('\n'),
                    'r' => out.push('\r'),
                    't' => out.push('\t'),
                    'b' => out.push('\u{0008}'),
                    'f' => out.push('\u{000C}'),
                    'u' => {
                        if self.pos + 4 <= self.chars.len() {
                            let hex_s: String = self.chars[self.pos..self.pos + 4].iter().collect();
                            self.pos += 4;
                            if let Ok(code) = u32::from_str_radix(&hex_s, 16) {
                                if let Some(ch) = char::from_u32(code) {
                                    out.push(ch);
                                }
                            }
                        }
                    }
                    other => out.push(other),
                }
            } else {
                out.push(c);
            }
        }
        Err("Unterminated JSON string".to_string())
    }

    fn parse_bool(&mut self) -> Result<JsonVal, String> {
        self.skip_ws();
        let rest: String = self.chars[self.pos..].iter().take(5).collect();
        if rest.starts_with("true") {
            self.pos += 4;
            Ok(JsonVal::Bool(true))
        } else if rest.starts_with("false") {
            self.pos += 5;
            Ok(JsonVal::Bool(false))
        } else {
            Err("Invalid boolean literal".to_string())
        }
    }

    fn parse_null(&mut self) -> Result<JsonVal, String> {
        self.skip_ws();
        let rest: String = self.chars[self.pos..].iter().take(4).collect();
        if rest.starts_with("null") {
            self.pos += 4;
            Ok(JsonVal::Null)
        } else {
            Err("Invalid null literal".to_string())
        }
    }

    fn parse_number(&mut self) -> Result<JsonVal, String> {
        self.skip_ws();
        let start = self.pos;
        while self.pos < self.chars.len() {
            let c = self.chars[self.pos];
            if c.is_ascii_digit() || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E' {
                self.pos += 1;
            } else {
                break;
            }
        }
        let num_str: String = self.chars[start..self.pos].iter().collect();
        num_str
            .parse::<f64>()
            .map(JsonVal::Num)
            .map_err(|_| format!("Invalid number '{}'", num_str))
    }
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 8);
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            other => out.push(other),
        }
    }
    out
}

fn str_array_json(items: &[String]) -> String {
    let parts: Vec<String> = items.iter().map(|s| format!("\"{}\"", json_escape(s))).collect();
    format!("[{}]", parts.join(","))
}

fn u16_array_json(items: &[u16]) -> String {
    let parts: Vec<String> = items.iter().map(|n| n.to_string()).collect();
    format!("[{}]", parts.join(","))
}

fn main() {
    let start_instant = Instant::now();
    if let Err(kat_err) = fips_140_3_kat_self_test() {
        eprintln!("[PATCH_AUDITOR_ERR] {}", kat_err);
        println!(
            "{{\"status\":\"ERROR\",\"engine\":\"rust_patch_auditor\",\"error\":\"{}\"}}",
            json_escape(kat_err)
        );
        return;
    }
    let mut raw_stdin = String::new();
    if let Err(err) = io::stdin().read_to_string(&mut raw_stdin) {
        eprintln!("[PATCH_AUDITOR_ERR] Failed reading STDIN: {}", err);
        println!(
            "{{\"status\":\"ERROR\",\"engine\":\"rust_patch_auditor\",\"error\":\"{}\"}}",
            json_escape(&err.to_string())
        );
        return;
    }

    let trimmed = raw_stdin.trim();
    if trimmed.is_empty() {
        println!("{{\"status\":\"ERROR\",\"engine\":\"rust_patch_auditor\",\"error\":\"Empty STDIN payload\"}}");
        return;
    }

    let mut parser = JsonParser::new(trimmed);
    let parsed_root = match parser.parse_value() {
        Ok(JsonVal::Obj(map)) => map,
        Ok(_) => {
            println!("{{\"status\":\"ERROR\",\"engine\":\"rust_patch_auditor\",\"error\":\"Root JSON payload must be an object\"}}");
            return;
        }
        Err(err) => {
            println!(
                "{{\"status\":\"ERROR\",\"engine\":\"rust_patch_auditor\",\"error\":\"{}\"}}",
                json_escape(&err)
            );
            return;
        }
    };

    let target_ip = parsed_root
        .get("target_ip")
        .and_then(|v| v.as_str())
        .unwrap_or("192.168.1.1")
        .to_string();
    let vendor_hint = parsed_root
        .get("vendor_platform")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();
    let medium_type = parsed_root
        .get("medium_type")
        .and_then(|v| v.as_str())
        .unwrap_or("WIRED_802_3")
        .to_string();
    let operator_mac = parsed_root
        .get("operator_mac")
        .and_then(|v| v.as_str())
        .unwrap_or("00:00:00:00:00:00")
        .to_string();
    let operator_source_ip = parsed_root
        .get("operator_source_ip")
        .and_then(|v| v.as_str())
        .unwrap_or("192.168.1.100")
        .to_string();
    let wireless_ssid = parsed_root
        .get("wireless_ssid")
        .and_then(|v| v.as_str())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string());
    let desired_vlan_id = parsed_root.get("desired_vlan_id").and_then(|v| v.as_u16());
    let entropy_threshold = parsed_root
        .get("entropy_threshold")
        .and_then(|v| v.as_f64())
        .unwrap_or(3.55);
    let running_config = parsed_root
        .get("running_config")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();

    // 1. Parse Running Configuration AST
    let ast = parse_running_config(&running_config, &vendor_hint);

    // Merge existing VLANs from JSON input + parsed AST
    let mut merged_vlans = ast.existing_vlans.clone();
    if let Some(req_vlans) = parsed_root.get("existing_vlans") {
        for v in req_vlans.as_u16_vec() {
            if !merged_vlans.contains(&v) {
                merged_vlans.push(v);
            }
        }
    }
    merged_vlans.sort_unstable();

    // 2. Scan Running Config for High-Entropy Secrets
    let entropy_findings = scan_config_entropy(&running_config, entropy_threshold);

    // 3. Evaluate DISA STIG & NSA Compliance Rules
    let compliance = evaluate_stig_compliance(&ast, &medium_type);

    // 4. Synthesize Military-Grade VLAN Configuration
    let effective_vendor = if vendor_hint.is_empty() {
        ast.detected_vendor.clone()
    } else {
        vendor_hint
    };

    let synth_req = VlanSynthesisRequest {
        target_ip: target_ip.clone(),
        vendor_platform: effective_vendor.clone(),
        medium_type: medium_type.clone(),
        operator_mac,
        operator_source_ip,
        wireless_ssid,
        desired_vlan_id,
        existing_vlans: merged_vlans.clone(),
        running_config,
    };

    let synth = synthesize_military_grade_vlan(&synth_req);
    let elapsed_ms = start_instant.elapsed().as_secs_f64() * 1000.0;

    // Serialize entropy findings array
    let entropy_json_items: Vec<String> = entropy_findings
        .iter()
        .map(|ef| {
            format!(
                "{{\"line_number\":{},\"secret_type\":\"{}\",\"entropy_bits\":{:.3},\"redacted_preview\":\"{}\",\"severity\":\"{}\",\"recommendation\":\"{}\"}}",
                ef.line_number,
                json_escape(&ef.secret_type),
                ef.entropy_bits,
                json_escape(&ef.redacted_preview),
                json_escape(&ef.severity),
                json_escape(&ef.recommendation)
            )
        })
        .collect();

    // Serialize STIG rule findings array
    let stig_json_items: Vec<String> = compliance
        .findings
        .iter()
        .map(|rf| {
            format!(
                "{{\"rule_id\":\"{}\",\"category\":\"{}\",\"title\":\"{}\",\"severity\":\"{}\",\"status\":\"{}\",\"description\":\"{}\",\"remediation\":\"{}\"}}",
                json_escape(&rf.rule_id),
                json_escape(&rf.category),
                json_escape(&rf.title),
                json_escape(&rf.severity),
                json_escape(&rf.status),
                json_escape(&rf.description),
                json_escape(&rf.remediation)
            )
        })
        .collect();

    // Serialize interface AST summary
    let iface_json_items: Vec<String> = ast
        .interfaces
        .iter()
        .map(|ifc| {
            format!(
                "{{\"name\":\"{}\",\"mode\":\"{}\",\"access_vlan\":{},\"native_vlan\":{},\"is_shutdown\":{},\"port_security\":{},\"bpduguard\":{}}}",
                json_escape(&ifc.name),
                json_escape(&ifc.mode),
                ifc.access_vlan,
                ifc.native_vlan,
                ifc.is_shutdown,
                ifc.port_security,
                ifc.bpduguard
            )
        })
        .collect();

    let output_json = format!(
        "{{\
        \"status\":\"OK\",\
        \"engine\":\"rust_patch_auditor\",\
        \"target_ip\":\"{}\",\
        \"vendor_platform\":\"{}\",\
        \"hostname\":\"{}\",\
        \"parse_time_ms\":{:.3},\
        \"allocated_vlan_id\":{},\
        \"blackhole_vlan_id\":{},\
        \"vlan_name\":\"{}\",\
        \"isolated_subnet_cidr\":\"{}\",\
        \"gateway_address\":\"{}\",\
        \"existing_vlans\":{},\
        \"commands\":{},\
        \"rollback_commands\":{},\
        \"enforced_controls\":{},\
        \"compliance_score\":{},\
        \"passed_rules\":{},\
        \"failed_rules\":{},\
        \"warning_rules\":{},\
        \"findings\":[{}],\
        \"entropy_findings\":[{}],\
        \"interfaces\":[{}]\
        }}",
        json_escape(&target_ip),
        json_escape(&effective_vendor),
        json_escape(&ast.hostname),
        elapsed_ms,
        synth.allocated_vlan_id,
        synth.blackhole_vlan_id,
        json_escape(&synth.vlan_name),
        json_escape(&synth.isolated_subnet_cidr),
        json_escape(&synth.gateway_address),
        u16_array_json(&merged_vlans),
        str_array_json(&synth.commands),
        str_array_json(&synth.rollback_commands),
        str_array_json(&synth.enforced_controls),
        compliance.compliance_score,
        compliance.passed_count,
        compliance.failed_count,
        compliance.warning_count,
        stig_json_items.join(","),
        entropy_json_items.join(","),
        iface_json_items.join(",")
    );

    println!("{}", output_json);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fips_kat_and_cwe22() {
        assert!(fips_140_3_kat_self_test().is_ok());
        assert!(sanitize_relative_path("configs/switch.cfg").is_ok());
        assert!(sanitize_relative_path("../etc/passwd").is_err());
        assert!(sanitize_relative_path("/etc/passwd").is_err());
        let tmp = std::env::temp_dir();
        assert!(safe_resolve_under(&tmp, "configs/switch.cfg").is_ok());
        assert!(safe_resolve_under(&tmp, "../../etc/shadow").is_err());
    }
}
