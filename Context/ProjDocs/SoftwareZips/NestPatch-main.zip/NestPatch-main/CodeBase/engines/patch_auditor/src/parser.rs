// ==============================================================================
// NestPatch Rust Engine — Zero-Panic Running-Config AST & VLAN Extractor (parser.rs)
// Linear-time O(n) single-pass deterministic configuration parser.
// ==============================================================================

use std::collections::BTreeSet;

#[derive(Clone, Debug)]
pub struct InterfaceNode {
    pub name: String,
    pub mode: String, // "access", "trunk", "routed", "wireless", "unknown"
    pub access_vlan: u16,
    pub native_vlan: u16,
    pub is_shutdown: bool,
    pub dhcp_snooping_trust: bool,
    pub arp_inspection_trust: bool,
    pub port_security: bool,
    pub bpduguard: bool,
    pub client_isolation: bool,
}

#[derive(Clone, Debug)]
pub struct ConfigAst {
    pub hostname: String,
    pub detected_vendor: String,
    pub existing_vlans: Vec<u16>,
    pub existing_subnets: Vec<String>,
    pub interfaces: Vec<InterfaceNode>,
    pub has_dhcp_snooping: bool,
    pub has_arp_inspection: bool,
    pub has_bpduguard_default: bool,
    pub has_ssh_v2: bool,
    pub has_telnet_enabled: bool,
    pub has_http_server: bool,
    pub has_default_vlan1_active: bool,
    pub has_blackhole_vlan: bool,
    pub has_inter_vlan_acl: bool,
    pub has_wireless_pmf: bool,
    pub has_wireless_isolation: bool,
    pub total_lines: usize,
}

/// Parses a network device configuration in O(n) single-pass linear time without regex backtracking.
pub fn parse_running_config(config: &str, vendor_hint: &str) -> ConfigAst {
    let mut hostname = "UNKNOWN-NODE".to_string();
    let mut detected_vendor = if vendor_hint.is_empty() {
        "cisco_ios".to_string()
    } else {
        vendor_hint.to_string()
    };

    let mut vlan_set: BTreeSet<u16> = BTreeSet::new();
    vlan_set.insert(1); // VLAN 1 exists by default on IEEE 802.1Q bridges

    let mut subnets: Vec<String> = Vec::new();
    let mut interfaces: Vec<InterfaceNode> = Vec::new();
    let mut current_iface: Option<InterfaceNode> = None;

    let mut has_dhcp_snooping = false;
    let mut has_arp_inspection = false;
    let mut has_bpduguard_default = false;
    let mut has_ssh_v2 = false;
    let mut has_telnet_enabled = false;
    let mut has_http_server = false;
    let mut has_default_vlan1_active = false;
    let mut has_blackhole_vlan = false;
    let mut has_inter_vlan_acl = false;
    let mut has_wireless_pmf = false;
    let mut has_wireless_isolation = false;

    let lines: Vec<&str> = config.lines().collect();

    for raw_line in &lines {
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('!') || trimmed.starts_with('#') {
            continue;
        }
        let lower = trimmed.to_ascii_lowercase();

        // Detect vendor signatures if not explicitly set
        if lower.starts_with("uci set ")
            || lower.contains("config wifi-iface")
            || lower.contains("option encryption")
        {
            detected_vendor = "openwrt_wireless".to_string();
        } else if lower.starts_with("set interfaces ") || lower.starts_with("set vlans ") {
            detected_vendor = "juniper_junos".to_string();
        } else if lower.contains("arista") || lower.starts_with("daemon terminattr") {
            detected_vendor = "arista_eos".to_string();
        } else if lower.contains("aruba") || lower.starts_with("wlan ssid-profile") {
            detected_vendor = "aruba_os".to_string();
        }

        // Extract hostname
        if lower.starts_with("hostname ") {
            let parts: Vec<&str> = trimmed.split_whitespace().collect();
            if let Some(h) = parts.get(1) {
                hostname = (*h).trim_matches('"').to_string();
            }
        } else if lower.contains("system.hostname=") {
            if let Some(eq_idx) = trimmed.find('=') {
                hostname = trimmed[eq_idx + 1..]
                    .trim_matches(|c| c == '\'' || c == '"')
                    .to_string();
            }
        }

        // Global security posture checks
        if lower.starts_with("ip dhcp snooping") && !lower.starts_with("no ip dhcp snooping") {
            has_dhcp_snooping = true;
        }
        if lower.starts_with("ip arp inspection") && !lower.starts_with("no ip arp inspection") {
            has_arp_inspection = true;
        }
        if lower.contains("bpduguard default") || lower.contains("bpduguard enable") {
            has_bpduguard_default = true;
        }
        if lower.contains("ip ssh version 2")
            || lower.contains("ssh server v2")
            || lower.contains("dropbear")
        {
            has_ssh_v2 = true;
        }
        if lower.contains("transport input telnet")
            || lower.contains("transport input all")
            || lower.starts_with("telnet server enable")
        {
            has_telnet_enabled = true;
        }
        if lower.starts_with("ip http server") {
            has_http_server = true;
        }
        if lower.contains("ip access-list extended")
            || lower.contains("firewall.zone_sec")
            || lower.contains("Access-List")
        {
            has_inter_vlan_acl = true;
        }
        if lower.contains("ieee80211w='2'")
            || lower.contains("ieee80211w '2'")
            || lower.contains("security pmf mandatory")
        {
            has_wireless_pmf = true;
        }
        if lower.contains("isolate='1'")
            || lower.contains("option isolate '1'")
            || lower.contains("client-isolation enable")
        {
            has_wireless_isolation = true;
        }

        // Extract VLAN definitions
        if lower.starts_with("vlan ") {
            let rest = &trimmed[5..];
            for part in rest.split(',') {
                let token = part.trim();
                if let Some((start_s, end_s)) = token.split_once('-') {
                    if let (Ok(s), Ok(e)) =
                        (start_s.trim().parse::<u16>(), end_s.trim().parse::<u16>())
                    {
                        if s <= e && e <= 4094 {
                            for v in s..=e.min(s.saturating_add(64)) {
                                vlan_set.insert(v);
                            }
                        }
                    }
                } else if let Ok(v) = token.split_whitespace().next().unwrap_or("").parse::<u16>() {
                    if (1..=4094).contains(&v) {
                        vlan_set.insert(v);
                        if v == 999 {
                            has_blackhole_vlan = true;
                        }
                    }
                }
            }
        } else if lower.contains("vlan_") {
            // OpenWrt / UCI style network.vlan_400
            if let Some(pos) = lower.find("vlan_") {
                let after = &lower[pos + 5..];
                let digits: String = after.chars().take_while(|c| c.is_ascii_digit()).collect();
                if let Ok(v) = digits.parse::<u16>() {
                    if (1..=4094).contains(&v) {
                        vlan_set.insert(v);
                    }
                }
            }
        }

        // Extract interface blocks
        if lower.starts_with("interface ") {
            if let Some(prev) = current_iface.take() {
                if !prev.is_shutdown && prev.access_vlan == 1 && prev.mode != "trunk" {
                    has_default_vlan1_active = true;
                }
                interfaces.push(prev);
            }
            let iface_name = trimmed[10..].trim().to_string();
            if let Some(stripped) = iface_name.to_ascii_lowercase().strip_prefix("vlan") {
                if let Ok(v) = stripped.trim().parse::<u16>() {
                    if (1..=4094).contains(&v) {
                        vlan_set.insert(v);
                    }
                }
            }
            current_iface = Some(InterfaceNode {
                name: iface_name,
                mode: "access".to_string(),
                access_vlan: 1,
                native_vlan: 1,
                is_shutdown: false,
                dhcp_snooping_trust: false,
                arp_inspection_trust: false,
                port_security: false,
                bpduguard: false,
                client_isolation: false,
            });
            continue;
        }

        // Inside an interface block
        if let Some(ref mut iface) = current_iface {
            if lower == "exit" || lower == "!" {
                let finished = current_iface.take();
                if let Some(node) = finished {
                    if !node.is_shutdown && node.access_vlan == 1 && node.mode != "trunk" {
                        has_default_vlan1_active = true;
                    }
                    interfaces.push(node);
                }
                continue;
            }
            if lower == "shutdown" {
                iface.is_shutdown = true;
            } else if lower == "no shutdown" {
                iface.is_shutdown = false;
            } else if lower.contains("switchport mode trunk") {
                iface.mode = "trunk".to_string();
            } else if lower.contains("switchport mode access") {
                iface.mode = "access".to_string();
            } else if lower.starts_with("switchport access vlan ") {
                if let Some(v_str) = lower.split_whitespace().nth(3) {
                    if let Ok(v) = v_str.parse::<u16>() {
                        iface.access_vlan = v;
                        vlan_set.insert(v);
                    }
                }
            } else if lower.starts_with("switchport trunk native vlan ") {
                if let Some(v_str) = lower.split_whitespace().nth(4) {
                    if let Ok(v) = v_str.parse::<u16>() {
                        iface.native_vlan = v;
                        vlan_set.insert(v);
                        if v == 999 {
                            has_blackhole_vlan = true;
                        }
                    }
                }
            } else if lower.contains("switchport port-security") {
                iface.port_security = true;
            } else if lower.contains("spanning-tree bpduguard enable") {
                iface.bpduguard = true;
            } else if lower.contains("ip dhcp snooping trust") {
                iface.dhcp_snooping_trust = true;
            } else if lower.contains("ip arp inspection trust") {
                iface.arp_inspection_trust = true;
            } else if lower.starts_with("ip address ") {
                let parts: Vec<&str> = trimmed.split_whitespace().collect();
                if let Some(ip_str) = parts.get(2) {
                    if ip_str.contains('.') {
                        subnets.push((*ip_str).to_string());
                    }
                }
                if iface.name.to_ascii_lowercase() == "vlan1" && !iface.is_shutdown {
                    has_default_vlan1_active = true;
                }
            }
        }
    }

    if let Some(last) = current_iface.take() {
        if !last.is_shutdown && last.access_vlan == 1 && last.mode != "trunk" {
            has_default_vlan1_active = true;
        }
        interfaces.push(last);
    }

    ConfigAst {
        hostname,
        detected_vendor,
        existing_vlans: vlan_set.into_iter().collect(),
        existing_subnets: subnets,
        interfaces,
        has_dhcp_snooping,
        has_arp_inspection,
        has_bpduguard_default,
        has_ssh_v2,
        has_telnet_enabled,
        has_http_server,
        has_default_vlan1_active,
        has_blackhole_vlan,
        has_inter_vlan_acl,
        has_wireless_pmf,
        has_wireless_isolation,
        total_lines: lines.len(),
    }
}
