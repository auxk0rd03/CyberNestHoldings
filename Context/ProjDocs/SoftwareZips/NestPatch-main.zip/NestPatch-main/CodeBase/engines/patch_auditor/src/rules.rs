// ==============================================================================
// NestPatch Rust Engine — DISA STIG & NSA Hardening Compliance Evaluator (rules.rs)
// Evaluates Layer 2, Layer 3, Wireless 802.11, and Control Plane STIG controls.
// ==============================================================================

use crate::parser::ConfigAst;

#[derive(Clone, Debug)]
pub struct StigRuleFinding {
    pub rule_id: String,
    pub category: String,
    pub title: String,
    pub severity: String,
    pub status: String, // "PASS", "FAIL", "WARN"
    pub description: String,
    pub remediation: String,
}

#[derive(Clone, Debug)]
pub struct ComplianceAuditSummary {
    pub compliance_score: u8,
    pub passed_count: usize,
    pub failed_count: usize,
    pub warning_count: usize,
    pub findings: Vec<StigRuleFinding>,
}

pub fn evaluate_stig_compliance(ast: &ConfigAst, medium_type: &str) -> ComplianceAuditSummary {
    let mut findings = Vec::new();
    let is_wireless = medium_type == "WIRELESS_802_11" || ast.detected_vendor == "openwrt_wireless";

    // Rule 1: DISA-STIG-L2-001 (Default VLAN 1 Eradication & Blackhole Parking VLAN 999)
    let r1_pass = !ast.has_default_vlan1_active && ast.has_blackhole_vlan;
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-L2-001".to_string(),
        category: "Layer 2 VLAN Containment".to_string(),
        title: "Default VLAN 1 Eradication & Blackhole Parking VLAN 999".to_string(),
        severity: "CRITICAL".to_string(),
        status: if r1_pass { "PASS".to_string() } else { "FAIL".to_string() },
        description: if r1_pass {
            "Default VLAN 1 is pruned and suspended Blackhole VLAN 999 is provisioned.".to_string()
        } else {
            "Active interfaces remain assigned to Default VLAN 1 or lack suspended Blackhole VLAN 999.".to_string()
        },
        remediation: "Suspend VLAN 999 as native trunk blackhole and migrate all active ports off VLAN 1.".to_string(),
    });

    // Rule 2: DISA-STIG-L2-002 (Dynamic ARP Inspection)
    let r2_pass = ast.has_arp_inspection || ast.detected_vendor == "openwrt_wireless";
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-L2-002".to_string(),
        category: "Layer 2 ARP Armor".to_string(),
        title: "Dynamic ARP Inspection (DAI) & 15pps Rate Limit".to_string(),
        severity: "HIGH".to_string(),
        status: if r2_pass { "PASS".to_string() } else { "FAIL".to_string() },
        description: if r2_pass {
            "Dynamic ARP Inspection (DAI) is enabled on enclave VLANs.".to_string()
        } else {
            "Dynamic ARP Inspection is missing, exposing the enclave to ARP cache poisoning (MitM).".to_string()
        },
        remediation: "Enable 'ip arp inspection vlan <ID>' and 'ip arp inspection validate src-mac dst-mac ip'.".to_string(),
    });

    // Rule 3: DISA-STIG-L2-003 (DHCP Snooping Binding Enforcement)
    let r3_pass = ast.has_dhcp_snooping || ast.detected_vendor == "openwrt_wireless";
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-L2-003".to_string(),
        category: "Layer 2 DHCP Integrity".to_string(),
        title: "DHCP Snooping Binding Database Enforcement".to_string(),
        severity: "HIGH".to_string(),
        status: if r3_pass { "PASS".to_string() } else { "FAIL".to_string() },
        description: if r3_pass {
            "Global DHCP Snooping is active for enclave VLANs.".to_string()
        } else {
            "DHCP Snooping is disabled, allowing rogue DHCP servers and IP starvation attacks.".to_string()
        },
        remediation: "Enable 'ip dhcp snooping' globally and restrict 'ip dhcp snooping trust' to verified uplinks.".to_string(),
    });

    // Rule 4: DISA-STIG-L2-004 (Spanning Tree BPDU Guard & Root Guard)
    let r4_pass = ast.has_bpduguard_default || ast.interfaces.iter().any(|i| i.bpduguard);
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-L2-004".to_string(),
        category: "Layer 2 STP Topology Protection".to_string(),
        title: "Spanning-Tree PortFast BPDU Guard & Root Guard".to_string(),
        severity: "MEDIUM".to_string(),
        status: if r4_pass { "PASS".to_string() } else { "FAIL".to_string() },
        description: if r4_pass {
            "BPDU Guard is enforced on edge access ports.".to_string()
        } else {
            "Edge ports lack BPDU Guard, permitting rogue switch insertion and root bridge hijacking.".to_string()
        },
        remediation: "Configure 'spanning-tree portfast bpduguard default' and per-port 'spanning-tree bpduguard enable'.".to_string(),
    });

    // Rule 5: DISA-STIG-L2-005 (Switchport Port-Security & Storm Control)
    let has_portsec = ast.interfaces.iter().any(|i| i.port_security);
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-L2-005".to_string(),
        category: "Layer 2 CAM & Broadcast Protection".to_string(),
        title: "Sticky MAC Port-Security & 10% Broadcast Storm Ceiling".to_string(),
        severity: "MEDIUM".to_string(),
        status: if has_portsec { "PASS".to_string() } else { "WARN".to_string() },
        description: if has_portsec {
            "Port-security sticky MAC enforcement detected on access ports.".to_string()
        } else {
            "Access interfaces do not enforce sticky MAC ceilings or broadcast storm control.".to_string()
        },
        remediation: "Enforce 'switchport port-security mac-address sticky', 'maximum 2', and 'storm-control broadcast level 10.00'.".to_string(),
    });

    // Rule 6: DISA-STIG-L3-006 (RFC-1918 Inter-VLAN Default-Deny Extended ACL)
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-L3-006".to_string(),
        category: "Layer 3 Enclave Segmentation".to_string(),
        title: "RFC-1918 Inter-VLAN Default-Deny Extended ACL".to_string(),
        severity: "CRITICAL".to_string(),
        status: if ast.has_inter_vlan_acl { "PASS".to_string() } else { "FAIL".to_string() },
        description: if ast.has_inter_vlan_acl {
            "Extended inter-VLAN isolation ACLs are present in the configuration.".to_string()
        } else {
            "No inter-VLAN isolation ACLs detected; lateral east-west RFC-1918 subnet pivoting is unrestricted.".to_string()
        },
        remediation: "Bind an extended ingress ACL blocking RFC-1918 cross-subnet traffic while preserving operator reachability.".to_string(),
    });

    // Rule 7: NSA-WL-007 (Wireless 802.11w PMF & Layer 2 Client Isolation)
    let wl_pass = ast.has_wireless_pmf && ast.has_wireless_isolation;
    findings.push(StigRuleFinding {
        rule_id: "NSA-WL-007".to_string(),
        category: "Wireless 802.11 Enclave Security".to_string(),
        title: "802.11w Protected Management Frames & L2 Client Isolation".to_string(),
        severity: if is_wireless { "CRITICAL".to_string() } else { "MEDIUM".to_string() },
        status: if wl_pass {
            "PASS".to_string()
        } else if is_wireless {
            "FAIL".to_string()
        } else {
            "WARN".to_string()
        },
        description: if wl_pass {
            "Wireless enclave enforces WPA3-SAE, mandatory 802.11w PMF, and L2 client-to-client isolation.".to_string()
        } else {
            "Wireless radio/WLAN profile lacks mandatory 802.11w PMF or Layer 2 station isolation.".to_string()
        },
        remediation: "Enforce 'ieee80211w=2' (PMF mandatory), WPA3-SAE/Enterprise, and 'client-isolation enable'.".to_string(),
    });

    // Rule 8: DISA-STIG-MGMT-008 (Management Plane Lockdown)
    let mgmt_pass = ast.has_ssh_v2 && !ast.has_telnet_enabled && !ast.has_http_server;
    findings.push(StigRuleFinding {
        rule_id: "DISA-STIG-MGMT-008".to_string(),
        category: "Control Plane Lockdown".to_string(),
        title: "SSHv2-Only Management & Eradication of Telnet/HTTP".to_string(),
        severity: "HIGH".to_string(),
        status: if mgmt_pass { "PASS".to_string() } else { "FAIL".to_string() },
        description: if mgmt_pass {
            "Management plane restricted to SSHv2 with unencrypted Telnet and HTTP disabled.".to_string()
        } else {
            "Insecure management protocols (Telnet / HTTP) or missing SSHv2 enforcement detected.".to_string()
        },
        remediation: "Configure 'ip ssh version 2', 'no ip http server', and 'transport input ssh' on all VTY lines.".to_string(),
    });

    let mut passed = 0usize;
    let mut failed = 0usize;
    let mut warned = 0usize;
    for f in &findings {
        match f.status.as_str() {
            "PASS" => passed += 1,
            "FAIL" => failed += 1,
            _ => warned += 1,
        }
    }

    let total = findings.len().max(1);
    let score = (((passed * 100) + (warned * 50)) / total).min(100) as u8;

    ComplianceAuditSummary {
        compliance_score: score,
        passed_count: passed,
        failed_count: failed,
        warning_count: warned,
        findings,
    }
}
