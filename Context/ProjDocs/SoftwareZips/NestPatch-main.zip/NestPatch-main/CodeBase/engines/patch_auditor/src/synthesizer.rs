// ==============================================================================
// NestPatch Rust Engine — Military-Grade Secure VLAN Synthesizer (synthesizer.rs)
// Synthesizes DISA STIG / NSA Layer 2, Layer 3 & Wireless 802.11 VLAN payloads.
// ==============================================================================

use std::collections::HashSet;

#[derive(Clone, Debug)]
pub struct VlanSynthesisRequest {
    pub target_ip: String,
    pub vendor_platform: String, // "cisco_ios", "arista_eos", "juniper_junos", "aruba_os", "openwrt_wireless", "ubiquiti"
    pub medium_type: String,     // "WIRED_802_3" or "WIRELESS_802_11"
    pub operator_mac: String,
    pub operator_source_ip: String,
    pub wireless_ssid: Option<String>,
    pub desired_vlan_id: Option<u16>,
    pub existing_vlans: Vec<u16>,
    pub running_config: String,
}

#[derive(Clone, Debug)]
pub struct VlanSynthesisResponse {
    pub allocated_vlan_id: u16,
    pub blackhole_vlan_id: u16,
    pub vlan_name: String,
    pub isolated_subnet_cidr: String,
    pub gateway_address: String,
    pub commands: Vec<String>,
    pub rollback_commands: Vec<String>,
    pub enforced_controls: Vec<String>,
}

/// Selects a collision-free VLAN ID while strictly reserving default/legacy VLANs
/// (1, 1002-1005) and Blackhole Parking VLAN (999).
pub fn select_safe_vlan_id(desired: Option<u16>, existing: &[u16]) -> u16 {
    let mut occupied: HashSet<u16> = existing.iter().copied().collect();
    for reserved in [1_u16, 999, 1002, 1003, 1004, 1005] {
        occupied.insert(reserved);
    }
    if let Some(id) = desired {
        if (2..=4090).contains(&id) && !occupied.contains(&id) {
            return id;
        }
    }
    for candidate in 400..=899 {
        if !occupied.contains(&candidate) {
            return candidate;
        }
    }
    for candidate in 100..=399 {
        if !occupied.contains(&candidate) {
            return candidate;
        }
    }
    400
}

pub fn synthesize_military_grade_vlan(req: &VlanSynthesisRequest) -> VlanSynthesisResponse {
    let vlan_id = select_safe_vlan_id(req.desired_vlan_id, &req.existing_vlans);
    let blackhole_vlan: u16 = 999;
    let third_octet = (vlan_id % 250) as u8;
    let subnet_cidr = format!("10.240.{}.0/24", third_octet);
    let gateway_ip = format!("10.240.{}.1", third_octet);
    let vlan_name = format!("CN_MIL_SEC_{}", vlan_id);
    let safe_operator_ip =
        if req.operator_source_ip.is_empty() || req.operator_source_ip == "0.0.0.0" {
            "192.168.1.100".to_string()
        } else {
            req.operator_source_ip.clone()
        };

    let mut cmds = Vec::new();
    let mut rollback = Vec::new();
    let mut controls = vec![
        "DISA-STIG-L2-001: Default VLAN 1 Eradication & Blackhole VLAN 999 Parking".to_string(),
        "DISA-STIG-L2-002: Dynamic ARP Inspection (DAI) with 15pps Rate Limit".to_string(),
        "DISA-STIG-L2-003: DHCP Snooping Binding Database Enforcement".to_string(),
        "DISA-STIG-L2-004: Spanning-Tree BPDU Guard & Root Guard".to_string(),
        "DISA-STIG-L2-005: Sticky MAC Port-Security & 10% Broadcast Storm Control".to_string(),
        "DISA-STIG-L3-006: RFC-1918 Inter-VLAN Default-Deny Extended ACL".to_string(),
        "DISA-STIG-MGMT-008: Management Plane SSHv2 Lockdown & Telnet/HTTP Eradication".to_string(),
    ];

    match req.vendor_platform.as_str() {
        "openwrt_wireless" | "enterprise_ap" => {
            controls.push(
                "NSA-WL-006: 802.11w Protected Management Frames (PMF Mandatory)".to_string(),
            );
            controls.push("NSA-WL-007: Layer 2 Wireless Client-to-Client Isolation".to_string());
            let ssid_label = req
                .wireless_ssid
                .clone()
                .unwrap_or_else(|| format!("CN-SEC-{}", vlan_id));
            cmds.extend(vec![
                format!("uci set network.vlan_{}=interface", vlan_id),
                format!("uci set network.vlan_{}.proto='static'", vlan_id),
                format!("uci set network.vlan_{}.ipaddr='{}'", vlan_id, gateway_ip),
                format!("uci set network.vlan_{}.netmask='255.255.255.0'", vlan_id),
                format!("uci set network.vlan_{}=bridge-vlan", blackhole_vlan),
                format!(
                    "uci set network.vlan_{}.vlan='{}'",
                    blackhole_vlan, blackhole_vlan
                ),
                "uci set wireless.sec_enclave=wifi-iface".to_string(),
                "uci set wireless.sec_enclave.device='radio0'".to_string(),
                "uci set wireless.sec_enclave.mode='ap'".to_string(),
                format!("uci set wireless.sec_enclave.ssid='{}'", ssid_label),
                format!("uci set wireless.sec_enclave.network='vlan_{}'", vlan_id),
                "uci set wireless.sec_enclave.encryption='sae'".to_string(),
                "uci set wireless.sec_enclave.ieee80211w='2'".to_string(),
                "uci set wireless.sec_enclave.isolate='1'".to_string(),
                format!("uci set firewall.zone_sec_{}=zone", vlan_id),
                format!(
                    "uci set firewall.zone_sec_{}.name='cn_mil_{}'",
                    vlan_id, vlan_id
                ),
                format!("uci set firewall.zone_sec_{}.input='REJECT'", vlan_id),
                format!("uci set firewall.zone_sec_{}.forward='REJECT'", vlan_id),
                format!("uci set firewall.zone_sec_{}.output='ACCEPT'", vlan_id),
                format!("uci set firewall.allow_op_{}=rule", vlan_id),
                format!(
                    "uci set firewall.allow_op_{}.src='cn_mil_{}'",
                    vlan_id, vlan_id
                ),
                format!(
                    "uci set firewall.allow_op_{}.dest_ip='{}'",
                    vlan_id, safe_operator_ip
                ),
                format!("uci set firewall.allow_op_{}.target='ACCEPT'", vlan_id),
                "uci commit".to_string(),
                "/etc/init.d/network reload".to_string(),
            ]);
            rollback.extend(vec![
                format!("uci delete wireless.sec_enclave"),
                format!("uci delete firewall.zone_sec_{}", vlan_id),
                format!("uci delete firewall.allow_op_{}", vlan_id),
                format!("uci delete network.vlan_{}", vlan_id),
                "uci commit".to_string(),
                "/etc/init.d/network reload".to_string(),
            ]);
        }
        "juniper_junos" => {
            if req.medium_type == "WIRELESS_802_11" {
                controls.push(
                    "NSA-WL-007: Wireless WLAN Client Isolation & PMF 802.11w Mandatory"
                        .to_string(),
                );
            }
            cmds.extend(vec![
                "configure exclusive".to_string(),
                format!("set vlans CN_BLACKHOLE_DEAD_VLAN vlan-id {}", blackhole_vlan),
                format!("set vlans {} vlan-id {}", vlan_name, vlan_id),
                format!("set vlans {} forwarding-options dhcp-security arp-inspection", vlan_name),
                format!("set vlans {} forwarding-options dhcp-security group trusted-uplinks overrides trusted", vlan_name),
                format!("set interfaces irb unit {} family inet address {}/24", vlan_id, gateway_ip),
                format!("set vlans {} l3-interface irb.{}", vlan_name, vlan_id),
                format!("set firewall family inet filter ACL_{}_ISOLATION term allow-operator from destination-address {}/32", vlan_name, safe_operator_ip),
                format!("set firewall family inet filter ACL_{}_ISOLATION term allow-operator then accept", vlan_name),
                format!("set firewall family inet filter ACL_{}_ISOLATION term deny-rfc1918 from destination-address 10.0.0.0/8", vlan_name),
                format!("set firewall family inet filter ACL_{}_ISOLATION term deny-rfc1918 from destination-address 172.16.0.0/12", vlan_name),
                format!("set firewall family inet filter ACL_{}_ISOLATION term deny-rfc1918 from destination-address 192.168.0.0/16", vlan_name),
                format!("set firewall family inet filter ACL_{}_ISOLATION term deny-rfc1918 then reject", vlan_name),
                format!("set firewall family inet filter ACL_{}_ISOLATION term default-allow then accept", vlan_name),
                format!("set interfaces irb unit {} family inet filter input ACL_{}_ISOLATION", vlan_id, vlan_name),
                "set protocols rstp bpdu-block-on-edge".to_string(),
                "delete system services telnet".to_string(),
                "delete system services web-management http".to_string(),
                "set system services ssh protocol-version v2".to_string(),
                "commit confirmed 2".to_string(),
                "commit and-quit".to_string(),
            ]);
            rollback.extend(vec![
                "configure exclusive".to_string(),
                format!("delete vlans {}", vlan_name),
                format!("delete interfaces irb unit {}", vlan_id),
                format!(
                    "delete firewall family inet filter ACL_{}_ISOLATION",
                    vlan_name
                ),
                "commit and-quit".to_string(),
            ]);
        }
        _ => {
            // Default: Cisco IOS-XE / Catalyst / Arista EOS / ArubaOS-CX / Ubiquiti Enterprise Switch
            cmds.extend(vec![
                "configure terminal".to_string(),
                // 1. Control Plane Lockdown
                "ip ssh version 2".to_string(),
                "no ip http server".to_string(),
                "no ip http secure-server".to_string(),
                "service password-encryption".to_string(),
                // 2. Global DHCP Snooping & Dynamic ARP Inspection
                "ip dhcp snooping".to_string(),
                format!("ip dhcp snooping vlan {}", vlan_id),
                "no ip dhcp snooping information option".to_string(),
                format!("ip arp inspection vlan {}", vlan_id),
                "ip arp inspection validate src-mac dst-mac ip".to_string(),
                "spanning-tree portfast bpduguard default".to_string(),
                // 3. Provision Dead Blackhole Parking VLAN 999
                format!("vlan {}", blackhole_vlan),
                "name CN_BLACKHOLE_DEAD_VLAN".to_string(),
                "state suspend".to_string(),
                "exit".to_string(),
                // 4. Provision Military-Grade Secure Enclave VLAN
                format!("vlan {}", vlan_id),
                format!("name {}", vlan_name),
                "exit".to_string(),
                // 5. Default-Deny Inter-VLAN Segregation ACL
                format!("ip access-list extended ACL_{}_ISOLATION", vlan_name),
                format!(
                    "permit ip 10.240.{}.0 0.0.0.255 host {}",
                    third_octet, safe_operator_ip
                ),
                format!(
                    "deny ip 10.240.{}.0 0.0.0.255 10.0.0.0 0.255.255.255 log",
                    third_octet
                ),
                format!(
                    "deny ip 10.240.{}.0 0.0.0.255 172.16.0.0 0.15.255.255 log",
                    third_octet
                ),
                format!(
                    "deny ip 10.240.{}.0 0.0.0.255 192.168.0.0 0.0.255.255 log",
                    third_octet
                ),
                "permit ip any any".to_string(),
                "exit".to_string(),
                // 6. Hardened SVI Layer 3 Interface
                format!("interface Vlan{}", vlan_id),
                format!(
                    "description [NESTPATCH-MIL-SEC] Hardened Enclave VLAN {}",
                    vlan_id
                ),
                format!("ip address {} 255.255.255.0", gateway_ip),
                "no ip redirects".to_string(),
                "no ip proxy-arp".to_string(),
                "no ip unreachables".to_string(),
                format!("ip access-group ACL_{}_ISOLATION in", vlan_name),
                "no shutdown".to_string(),
                "exit".to_string(),
                // 7. Edge Port Hardening Template (DAI rate limit + Sticky MAC + Storm Control + BPDU Guard)
                "interface range GigabitEthernet1/0/2 - 24".to_string(),
                "switchport mode access".to_string(),
                format!("switchport access vlan {}", vlan_id),
                "switchport nonegotiate".to_string(),
                "switchport port-security".to_string(),
                "switchport port-security maximum 2".to_string(),
                "switchport port-security violation restrict".to_string(),
                "switchport port-security mac-address sticky".to_string(),
                "ip arp inspection limit rate 15".to_string(),
                "ip dhcp snooping limit rate 15".to_string(),
                "storm-control broadcast level 10.00 5.00".to_string(),
                "storm-control multicast level 10.00 5.00".to_string(),
                "spanning-tree portfast".to_string(),
                "spanning-tree bpduguard enable".to_string(),
                "no cdp enable".to_string(),
                "no lldp transmit".to_string(),
                "exit".to_string(),
            ]);

            if req.medium_type == "WIRELESS_802_11" {
                controls.push(
                    "NSA-WL-007: Wireless WLAN Client Isolation & PMF 802.11w Mandatory"
                        .to_string(),
                );
                cmds.extend(vec![
                    format!("wlan {} {} {}", vlan_name, vlan_id, vlan_name),
                    "client-isolation enable".to_string(),
                    "security wpa wpa3".to_string(),
                    "security pmf mandatory".to_string(),
                    "no shutdown".to_string(),
                    "exit".to_string(),
                ]);
            }

            cmds.push("end".to_string());
            cmds.push("write memory".to_string());

            rollback.extend(vec![
                "configure terminal".to_string(),
                format!("no interface Vlan{}", vlan_id),
                format!("no vlan {}", vlan_id),
                format!("no ip access-list extended ACL_{}_ISOLATION", vlan_name),
                "end".to_string(),
                "write memory".to_string(),
            ]);
        }
    }

    VlanSynthesisResponse {
        allocated_vlan_id: vlan_id,
        blackhole_vlan_id: blackhole_vlan,
        vlan_name,
        isolated_subnet_cidr: subnet_cidr,
        gateway_address: gateway_ip,
        commands: cmds,
        rollback_commands: rollback,
        enforced_controls: controls,
    }
}
