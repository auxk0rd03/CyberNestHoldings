@echo off
rem ==============================================================================
rem NestPatch Standardized Windows Entrypoint (launcher.bat)
rem Delegates to dev.bat per CN-DIR-2026-004 Bi-Launcher Specification
rem ==============================================================================
call "%~dp0dev.bat" %*
exit /b %ERRORLEVEL%
