#!/usr/bin/env bash
# ==============================================================================
# NestPatch Standardized RPGS TUI Bootloader & Process Supervisor
# CyberNest Holdings LLC — Authorized Security Engineering Standard
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="nestpatch"
LOG_DIR="${HOME}/.cache/${APP_NAME}"
mkdir -p -m 700 "$LOG_DIR"
LOG_FILE="${LOG_DIR}/session.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE"
chmod 600 "$LOG_FILE"

APP_PID=""

cleanup() {
    local exit_code=$?
    trap - EXIT INT TERM
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        echo "[INFO] Dispatching SIGTERM to tracked child PID: $APP_PID" >> "$LOG_FILE"
        kill -TERM "$APP_PID" 2>/dev/null || true
        local count=0
        while kill -0 "$APP_PID" 2>/dev/null && [ $count -lt 10 ]; do
            sleep 0.2
            count=$((count + 1))
        done
        if kill -0 "$APP_PID" 2>/dev/null; then
            echo "[WARN] Child PID $APP_PID did not terminate cleanly; escalating to SIGKILL." >> "$LOG_FILE"
            kill -KILL "$APP_PID" 2>/dev/null || true
        fi
        wait "$APP_PID" 2>/dev/null || true
    fi
    # Restore terminal line discipline, cursor, and screen buffer cleanly
    stty sane 2>/dev/null || true
    tput cnorm 2>/dev/null || true
    echo "[INFO] NestPatch terminal session closed cleanly (Exit Code: $exit_code)." >> "$LOG_FILE"
    exit "$exit_code"
}
trap cleanup EXIT INT TERM

detect_python() {
    if command -v python3 &>/dev/null; then
        echo "python3"
    elif command -v python &>/dev/null; then
        echo "python"
    else
        echo "[ERROR] Python 3.11+ is required but not found in PATH." >&2
        echo "[ERROR] Please install Python manually via your system package manager." >&2
        exit 1
    fi
}

setup_environment() {
    local py_bin
    py_bin=$(detect_python)

    if [ ! -d ".venv" ] || [ ! -x ".venv/bin/python" ] || ! grep -q "$SCRIPT_DIR/.venv" ".venv/bin/activate" 2>/dev/null; then
        echo "[INFO] Initializing isolated virtual environment (.venv)..."
        rm -rf .venv
        "$py_bin" -m venv .venv
    fi
    # shellcheck disable=SC1091
    source .venv/bin/activate

    if [ -f "requirements.txt" ]; then
        if ! .venv/bin/python -c "import textual, rich, aiosqlite, pydantic" &>/dev/null; then
            echo "[INFO] Installing required TUI libraries from requirements.txt..."
            .venv/bin/python -m pip install -q --upgrade pip
            .venv/bin/python -m pip install -q -r requirements.txt
        fi
    fi
}

build_engines() {
    mkdir -p bin

    # 1. Compile Go Batch Dispatcher (Static, zero-CGO, GOFIPS=1)
    if [ ! -f "bin/batch_dispatcher" ] && [ -d "engines/batch_dispatcher" ]; then
        if command -v go &>/dev/null; then
            echo "[INFO] Compiling Go batch_dispatcher engine (Static, zero-CGO, GOFIPS=1)..." | tee -a "$LOG_FILE"
            if (cd engines/batch_dispatcher && GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0 go build -ldflags="-s -w" -o ../../bin/batch_dispatcher . 2>>"$LOG_FILE"); then
                chmod 700 bin/batch_dispatcher
            else
                echo "[WARN] Go compilation failed. Pure-Python dispatcher fallback will be active." | tee -a "$LOG_FILE"
            fi
        else
            echo "[WARN] Go compiler absent. Pure-Python dispatcher fallback will be active." | tee -a "$LOG_FILE"
        fi
    fi

    # 2. Compile Rust Patch Auditor & VLAN Synthesizer (Release LTO)
    if [ ! -f "bin/patch_auditor" ] && [ -d "engines/patch_auditor" ]; then
        if command -v cargo &>/dev/null; then
            echo "[INFO] Compiling Rust patch_auditor engine (Release LTO)..." | tee -a "$LOG_FILE"
            if (cd engines/patch_auditor && cargo build --release 2>>"$LOG_FILE"); then
                cp engines/patch_auditor/target/release/patch_auditor bin/patch_auditor
                chmod 700 bin/patch_auditor
            else
                echo "[WARN] Rust compilation failed. Pure-Python auditor fallback will be active." | tee -a "$LOG_FILE"
            fi
        else
            echo "[WARN] Cargo/Rust compiler absent. Pure-Python auditor fallback will be active." | tee -a "$LOG_FILE"
        fi
    fi

    # 3. Generate CycloneDX 1.5, SPDX 2.3 & CISA SBOM manifests
    if [ -f "../../NestSBOM/sbom_cli.py" ]; then
        python3 ../../NestSBOM/sbom_cli.py --repo . --out-dir . >/dev/null 2>&1 || true
        python3 ../../NestSBOM/sbom_cli.py --repo .. --out-dir .. >/dev/null 2>&1 || true
    fi
}

run_tui() {
    setup_environment
    build_engines

    echo "[INFO] Launching NestPatch Terminal User Interface..." >> "$LOG_FILE"
    # Execute directly attached to current TTY foreground.
    # NOTE: Do NOT redirect stderr (2>>), as Textual's LinuxDriver writes all
    # TUI frames and terminal control sequences to sys.__stderr__ (FD 2).
    python -u -m app.main "$@"
}

case "${1:-run}" in
    run)
        shift || true
        run_tui "$@"
        ;;
    build)
        setup_environment
        rm -f bin/batch_dispatcher bin/patch_auditor
        build_engines
        echo "[INFO] Native engines compiled into ./bin/"
        ;;
    test)
        setup_environment
        build_engines
        if command -v go &>/dev/null && [ -d "engines/batch_dispatcher" ]; then
            echo "[INFO] Executing Go batch_dispatcher security & compliance tests..."
            (cd engines/batch_dispatcher && go test -v .)
        fi
        if command -v cargo &>/dev/null && [ -d "engines/patch_auditor" ]; then
            echo "[INFO] Executing Rust patch_auditor FIPS 140-3 & CWE-22 unit tests..."
            (cd engines/patch_auditor && cargo test)
        fi
        echo "[INFO] Executing NestPatch Python & Headless TUI verification suite..."
        .venv/bin/python -m unittest discover -s tests -v
        ;;
    help|--help|-h)
        echo "Usage: ./launcher.sh [run|build|test] [options]"
        echo "  run   - Initialize environment, compile missing engines, and launch the Textual TUI (default)"
        echo "  build - Force clean rebuild of Go (batch_dispatcher) and Rust (patch_auditor) binaries"
        echo "  test  - Execute the automated unit and headless TUI test suite"
        ;;
    *)
        run_tui "$@"
        ;;
esac
