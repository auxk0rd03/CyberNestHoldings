"""
Unit Tests for NestPatch Boundary-Aware Subprocess IPC Bridge & Fallbacks.
"""
import tempfile
import unittest
from pathlib import Path

from app.core.engine_bridge import (
    extract_outermost_json,
    invoke_go_dispatcher,
    invoke_rust_auditor,
)


class TestEngineBridge(unittest.TestCase):
    def test_extract_outermost_json_ignores_noise(self) -> None:
        noisy_stdout = (
            "[COMPILER WARN] debug banner line 1\n"
            "some diagnostic trace\n"
            '{"status": "OK", "allocated_vlan_id": 410, "nested": {"a": 1}}\n'
            "trailing stderr leak\n"
        )
        parsed = extract_outermost_json(noisy_stdout)
        self.assertEqual(parsed["status"], "OK")
        self.assertEqual(parsed["allocated_vlan_id"], 410)

    def test_extract_outermost_json_raises_on_invalid(self) -> None:
        with self.assertRaises(ValueError):
            extract_outermost_json("no json braces here at all")

    def test_automatic_fallback_when_binaries_absent(self) -> None:
        with tempfile.TemporaryDirectory() as empty_bin_dir:
            empty_path = Path(empty_bin_dir)

            # 1. Test Rust Auditor fallback
            rust_res = invoke_rust_auditor(
                {
                    "target_ip": "192.168.1.1",
                    "vendor_platform": "cisco_ios",
                    "medium_type": "WIRED_802_3",
                    "operator_source_ip": "192.168.1.44",
                    "existing_vlans": [1, 10, 400],
                    "running_config": "hostname TEST-SW\nenable password 7 0822455D0A16\n",
                },
                bin_dir_override=empty_path,
            )
            self.assertEqual(rust_res["status"], "OK")
            self.assertEqual(rust_res["allocated_vlan_id"], 401)
            self.assertEqual(rust_res["blackhole_vlan_id"], 999)
            self.assertGreaterEqual(len(rust_res["entropy_findings"]), 1)

            # 2. Test Go Dispatcher fallback
            go_res = invoke_go_dispatcher(
                {
                    "action": "deploy",
                    "target_ip": "192.168.1.1",
                    "medium_type": "WIRELESS_802_11",
                    "vendor_platform": "openwrt_wireless",
                    "allocated_vlan_id": 401,
                    "commands": ["uci set wireless.sec_enclave.isolate='1'", "uci commit"],
                    "revert_timer_secs": 120,
                },
                bin_dir_override=empty_path,
            )
            self.assertEqual(go_res["status"], "SUCCESS_LOCKED")
            self.assertTrue(go_res["rollback_armed"])
            self.assertEqual(go_res["reachability_check"], "PASSED_NO_LOCKOUT")


if __name__ == "__main__":
    unittest.main()
