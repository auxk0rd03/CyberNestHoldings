"""
Unit Tests for NestPatch Security Boundaries, Input Validation & Anti-Lockout Guards.
"""
import tempfile
import unittest
from pathlib import Path

from app.core.network_sense import (
    detect_ingress_medium,
    validate_802_11w_and_802_3_compliance,
    validate_target_ip,
)
from app.core.security import (
    compute_sha256_digest,
    decrypt_aes256_gcm,
    encrypt_aes256_gcm,
    enforce_payload_cap,
    export_stix_21_bundle,
    export_taxii_21_collection,
    generate_stig_compliance_certificate,
    get_or_create_ed25519_identity,
    safe_resolve_under,
    sanitize_cli_text,
    sanitize_relative_path,
    sign_payload_ed25519,
    validate_ip_address,
    validate_safe_export_path,
    validate_serial_device_node,
    validate_vlan_id,
    verify_anti_lockout_guard,
    verify_cmmc_controls,
    verify_host_and_origin,
)


class TestSecurityValidation(unittest.TestCase):
    def test_valid_ipv4_and_ipv6(self) -> None:
        self.assertEqual(validate_ip_address("192.168.1.1"), "192.168.1.1")
        self.assertEqual(validate_ip_address("  10.20.30.254  "), "10.20.30.254")
        self.assertEqual(validate_target_ip("172.16.0.1"), "172.16.0.1")

    def test_rejects_loopback_multicast_and_invalid_ips(self) -> None:
        for bad_ip in ("127.0.0.1", "0.0.0.0", "224.0.0.1", "255.255.255.255", "not-an-ip", ""):
            with self.subTest(bad_ip=bad_ip):
                with self.assertRaises(ValueError):
                    validate_ip_address(bad_ip)

    def test_vlan_id_validation_and_reserved_blocking(self) -> None:
        self.assertIsNone(validate_vlan_id("AUTO"))
        self.assertIsNone(validate_vlan_id(""))
        self.assertEqual(validate_vlan_id("410"), 410)
        self.assertEqual(validate_vlan_id(500), 500)

        # Reserved VLANs (1, 999, 1002-1005) and out-of-range VLANs must be rejected
        for reserved in (1, 999, 1002, 1003, 1004, 1005, 0, 4095, -5):
            with self.subTest(reserved=reserved):
                with self.assertRaises(ValueError):
                    validate_vlan_id(reserved)

    def test_serial_device_node_validation(self) -> None:
        self.assertEqual(validate_serial_device_node("/dev/ttyUSB0"), "/dev/ttyUSB0")
        self.assertEqual(validate_serial_device_node("/dev/ttyS1"), "/dev/ttyS1")
        with self.assertRaises(ValueError):
            validate_serial_device_node("/etc/passwd")
        with self.assertRaises(ValueError):
            validate_serial_device_node("/dev/ttyUSB0; rm -rf /")

    def test_safe_export_path_blocks_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            safe_file = base / "audit_report.json"
            resolved = validate_safe_export_path(safe_file, base_dir=base)
            self.assertEqual(resolved, safe_file.resolve())

            with self.assertRaises(ValueError):
                validate_safe_export_path("/etc/shadow", base_dir=base)

    def test_anti_lockout_guard(self) -> None:
        # Target IP equal to operator source IP must be rejected
        with self.assertRaises(ValueError):
            verify_anti_lockout_guard(
                target_ip="192.168.1.44",
                operator_source_ip="192.168.1.44",
                commands=["configure terminal"],
            )

        # Valid distinct target & source IP passes
        self.assertTrue(
            verify_anti_lockout_guard(
                target_ip="192.168.1.1",
                operator_source_ip="192.168.1.44",
                commands=["configure terminal", "vlan 400"],
            )
        )

    def test_detect_ingress_medium_profile(self) -> None:
        profile = detect_ingress_medium("192.168.1.1")
        self.assertEqual(profile.target_ip, "192.168.1.1")
        self.assertIn(profile.medium_type, ("WIRED_802_3", "WIRELESS_802_11"))
        self.assertTrue(len(profile.local_mac) > 0)

    def test_sanitize_and_sha256(self) -> None:
        cleaned = sanitize_cli_text("hostname SW01\x00\x07\ninterface Vlan400")
        self.assertNotIn("\x00", cleaned)
        digest = compute_sha256_digest(cleaned)
        self.assertEqual(len(digest), 64)

    def test_cmmc_stig_cwe_and_crypto_enclave(self) -> None:
        self.assertEqual(sanitize_relative_path("exports/audit.json"), "exports/audit.json")
        for bad in ("../etc/passwd", "/etc/shadow", "a\\b", "-flag"):
            with self.assertRaises(ValueError):
                sanitize_relative_path(bad)

        with tempfile.TemporaryDirectory() as tmp:
            p = safe_resolve_under(tmp, "sub/report.json")
            self.assertTrue(str(p).startswith(str(Path(tmp).resolve())))

        self.assertTrue(verify_host_and_origin("127.0.0.1:8000", "http://127.0.0.1:8000"))
        self.assertFalse(verify_host_and_origin("evil.com"))
        self.assertEqual(len(enforce_payload_cap("ok")), 2)

        ct = encrypt_aes256_gcm(b"NESTPATCH-CUI-VLAN")
        self.assertEqual(decrypt_aes256_gcm(ct), b"NESTPATCH-CUI-VLAN")
        ident = get_or_create_ed25519_identity()
        self.assertIn("public_key_hex", ident)
        sig = sign_payload_ed25519(b"stig-audit")
        self.assertTrue(len(sig["signature"]) >= 64)

        net = validate_802_11w_and_802_3_compliance("192.168.1.1")
        self.assertEqual(net["status"], "COMPLIANT")
        self.assertEqual(verify_cmmc_controls()["sprs_score"], 110)
        self.assertEqual(generate_stig_compliance_certificate()["status"], "COMPLIANT")
        self.assertEqual(export_stix_21_bundle([{"rule_id": "V-220650", "title": "VLAN 1"}])["spec_version"], "2.1")
        self.assertEqual(len(export_taxii_21_collection()["collections"]), 1)


if __name__ == "__main__":
    unittest.main()
