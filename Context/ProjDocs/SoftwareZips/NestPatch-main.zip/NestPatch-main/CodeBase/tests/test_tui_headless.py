"""
Headless Textual TUI Integration Tests for NestPatch (test_tui_headless.py).
Verifies the Single-IP Military-Grade VLAN provisioning flow, F2-F5 screen routing,
Rust/Python STIG Auditor screen, and SQLite inventory/rollback persistence.
"""
import tempfile
import unittest
from pathlib import Path

from app.tui.app import NestPatchApp
from app.tui.screens.quick_vlan import QuickVlanScreen


class TestNestPatchTuiHeadless(unittest.IsolatedAsyncioTestCase):
    async def test_single_ip_provisioning_and_screen_navigation(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            temp_db = Path(tmpdir) / "test_nestpatch.db"
            app = NestPatchApp(db_path=temp_db)

            async with app.run_test(size=(120, 40)) as pilot:
                await pilot.pause()
                self.assertIsInstance(app.screen, QuickVlanScreen)

                # Execute Single-IP Military-Grade VLAN Provisioning on 192.168.1.1
                quick_screen: QuickVlanScreen = app.screen
                result = await quick_screen.execute_provisioning(
                    target_ip="192.168.1.1",
                    vlan_id="AUTO",
                    vendor_hint="cisco_ios",
                )
                await pilot.pause()

                self.assertEqual(result["target_ip"], "192.168.1.1")
                self.assertEqual(result["deploy"]["status"], "SUCCESS_LOCKED")
                self.assertEqual(result["deploy"]["reachability_check"], "PASSED_NO_LOCKOUT")
                self.assertEqual(result["audit_synth"]["blackhole_vlan_id"], 999)

                # Verify record persisted to SQLite database
                vlans = await app.db.list_provisioned_vlans()
                self.assertEqual(len(vlans), 1)
                self.assertEqual(vlans[0]["target_ip"], "192.168.1.1")

                # Navigate across F3 (Auditor), F4 (Batch/Serial), F5 (Inventory), and back to F2
                await pilot.press("f3")
                await pilot.pause()
                await pilot.press("f4")
                await pilot.pause()
                await pilot.press("f5")
                await pilot.pause()
                await pilot.press("f2")
                await pilot.pause()

                # Trigger emergency rollback (Ctrl+R) and verify status update
                rb_res = await quick_screen.trigger_emergency_rollback()
                self.assertEqual(rb_res["status"], "ROLLED_BACK")


if __name__ == "__main__":
    unittest.main()
