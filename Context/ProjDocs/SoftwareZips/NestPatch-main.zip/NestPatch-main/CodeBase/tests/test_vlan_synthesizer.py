"""
Unit Tests for DISA STIG / NSA Military-Grade VLAN Synthesis & Shannon Entropy Auditing.
Verifies Wired (802.3) and Wireless (802.11) parity across Cisco IOS-XE, Juniper JunOS,
and OpenWrt Enterprise Wireless platforms.
"""
import unittest

from app.core.engine_bridge import invoke_rust_auditor
from app.fallbacks.python_auditor import (
    calculate_shannon_entropy,
    select_safe_vlan_id,
    synthesize_military_grade_vlan_py,
)


class TestVlanSynthesizer(unittest.TestCase):
    def test_collision_free_vlan_selection(self) -> None:
        # Must skip occupied 400, 401 and reserved 1, 999
        vid = select_safe_vlan_id(None, [1, 10, 400, 401])
        self.assertEqual(vid, 402)
        # Desired VLAN 999 (reserved blackhole) must be rejected in favor of safe pool
        vid_reserved = select_safe_vlan_id(999, [1, 10])
        self.assertEqual(vid_reserved, 400)

    def test_shannon_entropy_calculation(self) -> None:
        low_h = calculate_shannon_entropy("aaaaaaaaaa")
        high_h = calculate_shannon_entropy("Wk9#mP2$vL8@nQ5!zR4xT7wB")
        self.assertEqual(low_h, 0.0)
        self.assertGreater(high_h, 4.0)

    def test_wired_cisco_stig_synthesis(self) -> None:
        payload = {
            "target_ip": "192.168.1.1",
            "vendor_platform": "cisco_ios",
            "medium_type": "WIRED_802_3",
            "operator_source_ip": "192.168.1.50",
            "existing_vlans": [1, 10, 20, 400],
            "running_config": (
                "hostname CAT9300\n"
                "snmp-server community public RO\n"
                "interface GigabitEthernet1/0/2\n"
                " switchport mode access\n"
                " switchport access vlan 1\n"
                "exit\n"
            ),
        }
        res = invoke_rust_auditor(payload)
        self.assertEqual(res["allocated_vlan_id"], 401)
        self.assertEqual(res["blackhole_vlan_id"], 999)
        joined_cmds = "\n".join(res["commands"])
        self.assertIn("ip dhcp snooping vlan 401", joined_cmds)
        self.assertIn("ip arp inspection vlan 401", joined_cmds)
        self.assertIn("vlan 999", joined_cmds)
        self.assertIn("state suspend", joined_cmds)
        self.assertIn("spanning-tree bpduguard enable", joined_cmds)
        self.assertIn("permit ip 10.240.151.0 0.0.0.255 host 192.168.1.50", joined_cmds)

    def test_wireless_openwrt_isolation_and_pmf_synthesis(self) -> None:
        payload = {
            "target_ip": "192.168.1.254",
            "vendor_platform": "openwrt_wireless",
            "medium_type": "WIRELESS_802_11",
            "operator_source_ip": "192.168.1.77",
            "wireless_ssid": "TACTICAL-OPS",
            "existing_vlans": [1, 10],
            "running_config": "uci set wireless.default_radio0.key='Wk9#mP2$vL8@nQ5!zR4xT7wB'\n",
        }
        res = synthesize_military_grade_vlan_py(payload)
        self.assertEqual(res["allocated_vlan_id"], 400)
        joined_cmds = "\n".join(res["commands"])
        self.assertIn("uci set wireless.sec_enclave.encryption='sae'", joined_cmds)
        self.assertIn("uci set wireless.sec_enclave.ieee80211w='2'", joined_cmds)
        self.assertIn("uci set wireless.sec_enclave.isolate='1'", joined_cmds)


if __name__ == "__main__":
    unittest.main()
