# BackEndGuide.md

Universal Architectural Specification & Language Allocation Matrix for the **RPGS** (Rust, Python, Go, Shell) Technology Stack.

This guide defines strict language boundaries, inter-process communication (IPC) contracts, runtime security baselines, and daemon lifecycle management for any tool developed within the RPGS ecosystem—spanning distributed P2P networking, security auditing engines, systems programming, and local web GUIs powered by HTMX (`StyleGuideHTMX.md`).

---

## 1. System Philosophy & Architecture

The RPGS architecture decouples tasks across four distinct operational dimensions: **Host Lifecycle Supervision (Shell)**, **Compute & Resilient Systems (Rust)**, **Network Topologies & Distributed Concurrency (Go)**, and **Orchestration, Storage, & View Synthesis (Python)**.

### Architectural Core Topologies

Depending on whether your application is an **Auditing / Batch Tool** or a **Daemon / Distributed Node**, RPGS standardizes on two primary structural patterns:

#### Pattern A: Orchestrator Pipeline (e.g., Security Scanners, Data Compactors, Offline Engines)
Python acts as the centralized Web UI server and workflow controller, delegating heavy computation and concurrent mapping to standalone Rust and Go sub-engines through a boundary-aware IPC bridge.

```
+----------------------------------------------------------------------------------+
| Shell (launcher.sh): venv, deps, non-privileged checks, port lifecycle, safe trap|
+----------------------------------------------------------------------------------+
                                         │
                                         ▼
+----------------------------------------------------------------------------------+
| Python Controller (FastAPI / Starlette)                                          |
| - Serves HTMX fragments per StyleGuideHTMX.md & streams telemetry via SSE        |
| - Relational SQLite persistence, SSRF boundaries, & dynamic PoC/report synthesis |
| - Boundary-Aware Subprocess IPC Adapter (engine_bridge.py) with Python Fallbacks |
+----------------------------------------------------------------------------------+
                  │                                                │
                  ▼ (JSON over STDIN/STDOUT)                       ▼ (JSON over STDIN/STDOUT)
+---------------------------------------+        +---------------------------------------+
| Rust Engine (bin/*)                   |        | Go Engine (bin/*)                     |
| - Deterministic memory & LTO          |        | - Bounded Goroutine workpools         |
| - High-throughput AST / Regex parsing |        | - Surface topology & fingerprinting   |
| - Chunk extraction & Shannon entropy  |        | - High-concurrency network operations |
+---------------------------------------+        +---------------------------------------+
```

#### Pattern B: Distributed Node / Tunneling Daemon (e.g., P2P Messaging, Mesh Proxies, VPN Bridges)
Go acts as the primary networking engine and local HTTP daemon (managing libp2p, Kademlia DHTs, hole punching, and encrypted storage), Rust acts as a companion supervisor monitoring socket health, and Shell acts as the hardened environment bootstrap.

```
+----------------------------------------------------------------------------------+
| Shell (launcher.sh): strict umask 077, symlink-hardened logs, port reservation   |
+----------------------------------------------------------------------------------+
                                         │
                                         ▼
+----------------------------------------------------------------------------------+
| Rust Daemon Supervisor (daemon/src/main.rs)                                      |
| - Dual-Mode execution: Standalone Manager vs. Companion Socket Monitor           |
| - Non-blocking TCP readiness probing & cross-platform browser launch             |
| - Hardware-level signal traps (SIGINT/SIGTERM) ensuring child PID termination    |
+----------------------------------------------------------------------------------+
                                         │
                                         ▼ (Local Socket Proxy & HTMX Web UI)
+----------------------------------------------------------------------------------+
| Go Network Engine & Local Server (backend/main.go)                               |
| - libp2p Host, Kademlia DHT, Noise Protocol encryption, dynamic Ed25519 identity |
| - Local Host/Origin firewall, session token gating, & AES-256-GCM secure enclave  |
| - Serves HTMX dashboard with minimal, unstyled fragments (StyleGuideHTMX.md)     |
+----------------------------------------------------------------------------------+
```

---

## 2. Language Allocation Matrix

| Tier | Primary Operational Domain | Anti-Patterns (STRICTLY PROHIBITED) | Key Runtime Standards |
| :--- | :--- | :--- | :--- |
| **Shell** (`bash`) | Bootstrap coordination, virtual environments, non-privileged dependency detection, dynamic ephemeral port binding, explicit PID tracking, signal traps. | Writing core business logic, complex string/JSON manipulation, persistent daemon execution, automated `sudo` or package installations. | `set -euo pipefail`, `IFS=$'\n\t'`, `umask 077`, non-destructive logging (`[ -L "$LOG" ] && rm -f "$LOG"`). |
| **Python** (3.11+) | Master API routing, HTMX fragment rendering (`StyleGuideHTMX.md`), SSE event broadcasting, SQLite relational persistence, report/artifact synthesis, fallback routines. | Synchronous CPU-bound parsing of massive binaries/bundles, raw unbuffered socket crawling, unmanaged global thread leaks. | FastAPI/Starlette, Uvicorn, Jinja2, aiofiles, Pydantic. Heavy tasks offloaded to `run_in_executor()`. |
| **Rust** | Deep CPU compute, memory-safe data harvesting, Thompson NFA regex engines, chunk manifest resolution, binary de-obfuscation, native process supervision. | Serving high-turnover UI view templates, dynamic schema migrations, network operations better suited to runtime garbage collection. | Pure static compilation: `cargo build --release` with LTO (`lto = true`, `codegen-units = 1`, `panic = "abort"`, `strip = true`). |
| **Go** | Distributed networking, P2P mesh architectures, libp2p streams, DHT routing, concurrent network probing, topology trees, high-fanout TCP/UDP proxies. | Monolithic frontends, heavily dynamic reflection-based architectures, mathematical models requiring foreign-function interfaces (FFI). | Static binaries: `go build -ldflags="-s -w"`. Explicit socket timeouts (`ReadTimeout`, `WriteTimeout`), bounded goroutine workpools. |

---

## 3. Tier Details & Implementation Standards

### 3.1 Shell: The Bootloader, Environment Manager, & Guardian

Every application must provide a root-level `launcher.sh` adhering to the following rules:

1. **Non-Privileged Execution**: Never execute automated `sudo apt-get` or modify system libraries. If dependencies (`python3`, `go`, `cargo`) are missing, halt immediately with actionable installation directives.
2. **Explicit PID Tracking (CWE-114 Defenses)**: Never use global process killers (e.g., `fuser -k`, `killall`). Explicitly capture child process IDs (`APP_PID=$!`) and dispatch `SIGTERM` exclusively to tracked PIDs during exit traps.
3. **Symlink-Hardened Logging (CWE-377 Defenses)**: Log directories must be user-scoped (`$HOME/.cache/<app>` or `scripts/logs/`) with `0700` permissions. Scripts must assert `[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"` before writing, and enforce `umask 077`.
4. **Dynamic Port Collision Avoidance**: Probe target ports via `/dev/tcp/127.0.0.1/$PORT`. If occupied, dynamically allocate an ephemeral port using an inline Python socket probe before booting the server.
5. **Deterministic Readiness Verification**: Probe the assigned socket in a timed loop (up to 6–10 seconds) to ensure the server is accepting requests before triggering the default OS browser.

#### Standard Reference: `launcher.sh`
```bash
#!/usr/bin/env bash
# RPGS Standardized Bootloader & Process Manager
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="rpgs_app"
DEFAULT_PORT=8000
MAX_PORT=8100
HOST="127.0.0.1"
TARGET_PORT=""
APP_PID=""

# Secure user-scoped logging (mitigates CWE-377 TOCTOU symlink hijacking)
LOG_DIR="${HOME}/.cache/${APP_NAME}"
mkdir -p -m 700 "$LOG_DIR"
LOG_FILE="${LOG_DIR}/session.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE"
chmod 600 "$LOG_FILE"

# Lifecycle signal trap for deterministic teardown
cleanup() {
    local exit_code=$?
    trap - EXIT INT TERM
    echo ""
    echo "[INFO] Commencing clean lifecycle shutdown..."
    
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        echo "[INFO] Dispatching SIGTERM to tracked child PID: $APP_PID"
        kill -TERM "$APP_PID" 2>/dev/null || true
        
        # Wait up to 5 seconds before escalating
        local count=0
        while kill -0 "$APP_PID" 2>/dev/null && [ $count -lt 10 ]; do
            sleep 0.5
            count=$((count + 1))
        done
        
        if kill -0 "$APP_PID" 2>/dev/null; then
            echo "[WARN] Process did not terminate. Escalating to SIGKILL..."
            kill -KILL "$APP_PID" 2>/dev/null || true
        fi
    fi
    echo "[INFO] Port $TARGET_PORT released. Teardown complete."
    exit $exit_code
}
trap cleanup EXIT INT TERM

# Non-privileged runtime verification
detect_python() {
    if command -v python3 &>/dev/null; then
        echo "python3"
    elif command -v python &>/dev/null; then
        echo "python"
    else
        echo "[ERROR] Python 3.11+ is required but not found in PATH." >&2
        echo "[ERROR] Please install Python manually via your system package manager." >&2
        exit 1
    fi
}

setup_environment() {
    local py_bin
    py_bin=$(detect_python)
    
    if [ ! -d ".venv" ] || [ ! -f ".venv/bin/activate" ]; then
        echo "[INFO] Initializing isolated virtual environment (.venv)..."
        rm -rf .venv
        "$py_bin" -m venv .venv
    fi
    source .venv/bin/activate
    
    if [ -f "requirements.txt" ]; then
        if ! python -c "import fastapi, uvicorn" &>/dev/null; then
            echo "[INFO] Installing required libraries from requirements.txt..."
            python -m pip install -q --upgrade pip
            python -m pip install -q -r requirements.txt
        fi
    fi
}

allocate_port() {
    local port=$DEFAULT_PORT
    while [ "$port" -le "$MAX_PORT" ]; do
        if ! (echo > /dev/tcp/"$HOST"/"$port") 2>/dev/null; then
            TARGET_PORT=$port
            return 0
        fi
        port=$((port + 1))
    done
    
    # Fallback to dynamic loopback allocation via ephemeral socket
    echo "[WARN] Standard port range occupied. Probing ephemeral socket..."
    TARGET_PORT=$(python -c 'import socket; s=socket.socket(); s.bind(("", 0)); print(s.getsockname()[1]); s.close()')
}

wait_for_server() {
    local retries=30
    local count=0
    echo -n "[INFO] Waiting for application to accept connections on http://${HOST}:${TARGET_PORT}"
    while [ $count -lt $retries ]; do
        if (echo > /dev/tcp/"$HOST"/"$TARGET_PORT") 2>/dev/null; then
            echo " [ONLINE]"
            return 0
        fi
        echo -n "."
        sleep 0.2
        count=$((count + 1))
    done
    echo " [FAILED]"
    echo "[ERROR] Server failed to bind within the allotted timeout." >&2
    exit 1
}

launch_browser() {
    local target_url="http://${HOST}:${TARGET_PORT}"
    if command -v xdg-open &>/dev/null; then
        xdg-open "$target_url" &>/dev/null &
    elif command -v open &>/dev/null; then
        open "$target_url" &>/dev/null &
    elif command -v python3 &>/dev/null; then
        python3 -m webbrowser "$target_url" &>/dev/null &
    fi
}

run_app() {
    setup_environment
    allocate_port
    
    export APP_HOST="$HOST"
    export APP_PORT="$TARGET_PORT"
    
    echo "[INFO] Launching server on ${HOST}:${TARGET_PORT}..."
    python -u app/main.py >> "$LOG_FILE" 2>&1 &
    APP_PID=$!
    
    wait_for_server
    launch_browser
    
    echo "[INFO] Application active (PID: $APP_PID). Press Ctrl+C to terminate."
    wait "$APP_PID"
}

run_app
```

---

### 3.2 Rust: Compute Ingestion, Parsing, & Companion Supervision

Rust engines are leveraged in two specific modes: **Compiled Compute Engines** (Pattern A) or **Companion Daemon Monitors** (Pattern B).

#### Rust as a Compute Engine (`engines/<name>/src/main.rs`)
* **Execution Rule**: Standalone static binary. Accepts inputs via CLI parameters or structured JSON on `stdin`. Emits strictly valid JSON to `stdout`. All diagnostic logs, telemetry, and debugging banners must route to `stderr`.
* **Zero Panic Policy**: Never invoke `unwrap()` or `expect()` on user-supplied parameters, dynamic paths, or network buffers. Propagate errors gracefully using `Result<T, E>`.

#### Rust as a Companion Supervisor (`daemon/src/main.rs`)
* **Dual-Mode Pattern**: If the target port is free, the supervisor boots the backend binary as a tracked child process and waits for socket readiness. If the port is already active (e.g., launched via `launcher.sh`), the supervisor enters **Companion Monitoring Mode**, avoiding socket collisions and monitoring the health of the backend until shutdown.

#### Standard Reference: `daemon/src/main.rs` (Dual-Mode Supervisor)
```rust
use std::env;
use std::net::TcpStream;
use std::process::{Child, Command};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

static RUNNING: AtomicBool = AtomicBool::new(true);

fn is_port_active(host: &str, port: u16) -> bool {
    TcpStream::connect(format!("{}:{}", host, port)).is_ok()
}

fn open_browser(url: &str) {
    #[cfg(target_os = "linux")]
    let _ = Command::new("xdg-open").arg(url).spawn();
    #[cfg(target_os = "windows")]
    let _ = Command::new("cmd").args(["/C", "start", url]).spawn();
    #[cfg(target_os = "macos")]
    let _ = Command::new("open").arg(url).spawn();
}

fn main() {
    let host = env::var("APP_HOST").unwrap_or_else(|_| "127.0.0.1".to_string());
    let port: u16 = env::var("APP_PORT")
        .unwrap_or_else(|_| "8080".to_string())
        .parse()
        .unwrap_or(8080);
    let app_url = format!("http://{}:{}", host, port);

    // Setup graceful signal handling
    let r = Arc::new(AtomicBool::new(true));
    let r_clone = r.clone();
    ctrlc::set_handler(move || {
        r_clone.store(false, Ordering::SeqCst);
    }).expect("Error setting signal handler");

    let mut child_proc: Option<Child> = None;

    if is_port_active(&host, port) {
        println!("[SUPERVISOR] Backend detected on {}. Entering Companion Mode...", app_url);
        open_browser(&app_url);
    } else {
        println!("[SUPERVISOR] Port free. Launching managed backend engine...");
        let backend_bin = env::current_exe()
            .unwrap()
            .parent()
            .unwrap()
            .join("backend");

        match Command::new(&backend_bin).spawn() {
            Ok(child) => {
                child_proc = Some(child);
                
                // Poll readiness
                let mut attempts = 0;
                while !is_port_active(&host, port) && attempts < 30 {
                    thread::sleep(Duration::from_millis(200));
                    attempts += 1;
                }
                
                if is_port_active(&host, port) {
                    println!("[SUPERVISOR] Backend ready. Launching interface...");
                    open_browser(&app_url);
                } else {
                    eprintln!("[SUPERVISOR] Timeout waiting for backend initialization.");
                }
            }
            Err(e) => eprintln!("[SUPERVISOR] Failed to spawn backend binary: {}", e),
        }
    }

    // Health monitoring loop
    while r.load(Ordering::SeqCst) {
        thread::sleep(Duration::from_millis(500));
        if let Some(ref mut child) = child_proc {
            if let Ok(Some(status)) = child.try_wait() {
                println!("[SUPERVISOR] Managed child process exited with status: {}", status);
                break;
            }
        }
    }

    // Clean teardown
    if let Some(mut child) = child_proc {
        println!("[SUPERVISOR] Dispatching termination signal to managed child process...");
        let _ = child.kill();
        let _ = child.wait();
    }
    println!("[SUPERVISOR] Teardown complete.");
}
```

---

### 3.3 Go: Distributed P2P, Stream Multiplexing, & Network Topology

Go is the chosen runtime when the application must handle concurrent network connections, P2P mesh protocols (libp2p), raw socket multiplexing, or distributed state synchronization without CGO dependencies.

#### Core Rules
1. **Host & Origin Firewall**: All local HTTP listeners must validate `r.Host` strictly against `localhost` and `127.0.0.1` and ensure the `Origin` header matches local origins. This mitigates DNS rebinding and cross-site execution attacks from external browser tabs.
2. **Cryptographic Identity**: Node IDs must never be static. Generate dynamic Ed25519 keypairs via `crypto/rand`, persisting keys atomically to encrypted local enclaves (AES-256-GCM) with `0600` permissions.
3. **Bounded Stream & Memory Allocation**: Always wrap request bodies with `http.MaxBytesReader` (e.g., 64KB) and configure explicit socket timeouts (`ReadTimeout: 5s`, `WriteTimeout: 10s`, `IdleTimeout: 120s`) to prevent connection exhaustion.
4. **Offline Store-and-Forward Queuing**: In distributed messaging architectures, outbound messages failing synchronous stream delivery must be encrypted and queued to an atomic local store (`queue.enc`), retried using an exponential backoff worker (`1s, 2s, 4s, 8s... max 300s`).

#### Standard Reference: Go Secure Local Server & HTMX Adapter (`backend/main.go`)
```go
package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

var (
	sessionToken string
	tokenOnce    sync.Once
)

func getSessionToken() string {
	tokenOnce.Do(func() {
		bytes := make([]byte, 16)
		_, _ = rand.Read(bytes)
		sessionToken = hex.EncodeToString(bytes)
	})
	return sessionToken
}

// Host & Origin Firewall: Blocks DNS rebinding attacks
func securityMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		host := r.Host
		if colon := strings.Index(host, ":"); colon != -1 {
			host = host[:colon]
		}
		if host != "localhost" && host != "127.0.0.1" {
			http.Error(w, "Access Denied: Invalid Host Header", http.StatusForbidden)
			return
		}

		origin := r.Header.Get("Origin")
		if origin != "" && !strings.HasPrefix(origin, "http://localhost:") && !strings.HasPrefix(origin, "http://127.0.0.1:") {
			http.Error(w, "Access Denied: Cross-Origin Request Blocked", http.StatusForbidden)
			return
		}

		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline' https://unpkg.com;")
		
		next(w, r)
	}
}

func handleAction(w http.ResponseWriter, r *http.Request) {
	// Restrict payload to prevent memory exhaustion
	r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
	if err := r.ParseForm(); err != nil {
		http.Error(w, "Payload Too Large", http.StatusRequestEntityTooLarge)
		return
	}

	// Verify session token on state-mutating requests
	if r.Header.Get("X-Session-Token") != getSessionToken() && r.FormValue("token") != getSessionToken() {
		http.Error(w, "Unauthorized: Invalid Session Token", http.StatusUnauthorized)
		return
	}

	target := r.FormValue("target")
	
	// Return semantic HTML fragment per StyleGuideHTMX.md
	w.Header().Set("Content-Type", "text/html")
	fmt.Fprintf(w, `
		<div class="mono" style="border: var(--border-inner); background: #08040d; padding: 14px; border-radius: 4px; font-size: 0.9em;">
			<div style="color: var(--accent-magenta); margin-bottom: 6px;">[OK] Target Registered: %s</div>
			<div style="color: var(--text-muted);">P2P libp2p Stream Initialized across DHT</div>
		</div>
	`, target)
}

func main() {
	port := os.Getenv("APP_PORT")
	if port == "" {
		port = "8080"
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/api/action", securityMiddleware(handleAction))

	server := &http.Server{
		Addr:         "127.0.0.1:" + port,
		Handler:      mux,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	fmt.Printf("[INFO] Server listening on http://127.0.0.1:%s (Session Token: %s)\n", port, getSessionToken())
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		fmt.Fprintf(os.Stderr, "[ERROR] Server terminated: %v\n", err)
	}
}
```

---

### 3.4 Python: Controller, Storage, & View Synthesis

Python is the application coordinator for complex, multi-stage workflows. It handles request dispatching, Server-Sent Events (SSE) telemetry broadcasts, SQLite transactions, and the generation of interactive HTML fragments adhering strictly to `StyleGuideHTMX.md`.

#### Core Rules
1. **HTMX Fragment Generation**: Server endpoints responding to HTMX requests must return minimal semantic fragments matching CSS variables (`--bg-surface`, `--accent-magenta`, etc.) without outer `<!DOCTYPE>` or `<body>` wrappers.
2. **Boundary-Aware Subprocess IPC**: Never invoke shell commands directly (`shell=True` is prohibited). Execute binaries using explicit argument lists. Parse JSON outputs using outermost boundary extractors, ignoring foreign debug outputs or panic text.
3. **Non-Blocking IO**: Compute-heavy artifact generation (such as PDF compiling or image manipulation) must be offloaded to worker threads via `loop.run_in_executor()`.

#### Standard Reference: Boundary-Aware IPC Adapter (`app/core/engine_bridge.py`)
```python
import subprocess
import json
import os
import re
from typing import Any, Callable, Dict, List

def extract_outermost_json(raw_text: str) -> Any:
    """
    Scans stdout for the outermost valid JSON structure ({...} or [...]),
    ignoring preceding compiler warnings, debug lines, or panic traces.
    """
    match = re.search(r'(\{.*\}|\[.*\])', raw_text, re.DOTALL)
    if not match:
        raise ValueError("No valid JSON payload detected in stdout stream.")
    return json.loads(match.group(1))

def run_engine_binary(
    binary_name: str,
    args: List[str],
    fallback_handler: Callable[..., Dict[str, Any]],
    timeout_secs: int = 45,
    *fallback_args,
    **fallback_kwargs
) -> Dict[str, Any]:
    """
    Executes compiled binary engines with automatic transparent fallback
    to pure Python implementations if binaries are missing, exit non-zero, or fail JSON parsing.
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    bin_path = os.path.join(base_dir, "../../bin", binary_name)

    if not os.path.isfile(bin_path) or not os.access(bin_path, os.X_OK):
        # Binary absent or not executable; trigger immediate fallback
        return fallback_handler(*fallback_args, **fallback_kwargs)

    cmd = [bin_path] + args
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout_secs,
            check=True
        )
        return extract_outermost_json(proc.stdout)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError) as err:
        # Log failure and gracefully transition to Python fallback routine
        return fallback_handler(*fallback_args, **fallback_kwargs)
```

---

## 4. HTMX UI Synthesis & SSE Streaming Protocols

All user interfaces within the RPGS ecosystem rely on HTMX for state swapping and native SSE for real-time log telemetry. Components must conform to `StyleGuideHTMX.md`.

### Real-Time EventSource (SSE) Integration
When a backend process takes longer than 500ms to complete, the server must decouple the response:
1. The initiating POST request returns an active HTMX component with a loading indicator.
2. Telemetry and terminal logs stream asynchronously over an SSE connection (`/api/stream-logs-sse`).
3. Upon task completion, the server streams an SSE swap event that updates the target DOM container with the final results grid.

```html
<!-- Client Initiator Component (per StyleGuideHTMX.md) -->
<div class="aero-window" style="max-width: 800px; margin: 20px auto;">
    <div class="aero-header">
        <span class="win-title">[ROUTINE // DISPATCHER]</span>
    </div>
    <div class="aero-body">
        <form hx-post="/api/jobs/trigger" hx-target="#job-status" hx-indicator="#job-spinner">
            <input type="text" name="target" placeholder="Enter target parameters..." required style="width: 70%;" />
            <button type="submit">Execute Routine</button>
            <span id="job-spinner" class="htmx-indicator">[PROCESSING]</span>
        </form>
        <div id="job-status" style="margin-top: 15px;"></div>
    </div>
</div>
```

---

## 5. Security & Threat Mitigation Ledger

Every RPGS codebase must satisfy the following architectural hardening criteria:

| Threat Category | CWE | Risk Profile | Enforced Mitigation Pattern |
| :--- | :--- | :--- | :--- |
| **Symlink Attacks** | CWE-377 | Local file hijacking and arbitrary log overwrites via `/tmp`. | Use `$HOME/.cache/<app>` or local directories (`0700`). Enforce `[ -L "$LOG" ] && rm -f "$LOG"` and `umask 077`. |
| **Process Collisions** | CWE-114 | Destructive cleanup commands (`fuser -k`) killing unintended system services. | Track explicit child PIDs (`APP_PID=$!`). Issue targeted `SIGTERM` exclusively to tracked process trees. |
| **Host/Origin Spoofing** | CWE-346 | Malicious browser tabs triggering local endpoints via DNS rebinding. | Implement `securityMiddleware` validating `r.Host` against `localhost`/`127.0.0.1` and rejecting foreign origins. |
| **CSRF Manipulation** | CWE-352 | Unauthorized local state mutations via cross-origin requests. | Cryptographically generated session tokens (`crypto/rand`) verified on all POST/PUT/DELETE mutations. |
| **Resource Exhaustion** | CWE-400 | Denial of service via unbounded incoming request payloads or dangling sockets. | Enforce `http.MaxBytesReader(64KB)` and explicit server timeouts (`Read: 5s`, `Write: 10s`, `Idle: 120s`). |
| **Memory / ReDoS** | CWE-1333 | Engine panics or catastrophic backtracking on regex/text processing. | Offload complex parsing to compiled Rust engines utilizing linear-time Thompson NFA algorithms. |

---

## 6. Project Checklist & Verification Protocol

Before releasing an RPGS project or promoting code to master, verify compliance with this operational checklist:

- [ ] **Launcher Hardening**: `launcher.sh` executes with `set -euo pipefail`, contains zero instances of `fuser` or unprompted `sudo`, tracks explicit child PIDs, and removes symlinks prior to logging.
- [ ] **Dynamic Socket Allocation**: Application detects port collisions gracefully and binds to an open port without crashing.
- [ ] **Dual-Execution Resilience**: Every compiled engine in `engines/` or `bin/` has an associated, functional pure-Python fallback routine in `engine_bridge.py`.
- [ ] **Aero-Sunset Aesthetic**: All returned HTML fragments consume native CSS custom variables defined in `StyleGuideHTMX.md` without inline hex color overrides.
- [ ] **Origin Verification**: Backend endpoints validate `Host` and `Origin` headers before evaluating request arguments.
- [ ] **Deterministic Teardown**: Pressing `Ctrl+C` in the terminal cleanly releases all loopback sockets and terminates all child engines within 2 seconds.