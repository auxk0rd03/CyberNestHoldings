# CISA-COMPLIANT SOFTWARE BILL OF MATERIALS (SBOM) // NESTPATCH

## 1. Executive Order 14028 & CISA Minimum Elements Attestation

| CISA Mandatory Metadata Field | Verified Value |
| :--- | :--- |
| **SBOM Document Title** | `NestPatch - CyberNest CISA SBOM Ledger` |
| **SBOM Serial / Namespace UUID** | `urn:uuid:610802ff-a902-5b7d-84a3-56c67ac5af06` |
| **Author of SBOM Data** | `CyberNest Holdings LLC - William Ray Moore (President & Chief Architect) & James Dwayne Jarrell (CEO)` |
| **Timestamp (UTC)** | `2026-10-31T02:21:38Z` |
| **Primary Supplier Name** | `CyberNest Holdings LLC (Internal Department: CyberNest Labs)` |
| **Corporate Jurisdiction & Registration** | `Commonwealth of Pennsylvania LLC // SAM.gov UEI & CAGE: Not Yet Assigned (Pre-Registration)` |
| **Target Repository / Source** | `./NestPatch` |
| **Ingestion & Parse Engines** | `go_repo_ingestor + rust_sbom_scanner` |
| **Supported Machine Formats** | `CycloneDX 1.5 JSON (SBOM.cyclonedx.json)` & `SPDX 2.3 JSON (SBOM.spdx.json)` |
| **Zero External Runtime Dependency Guarantee** | `ENFORCED (100% Air-Gapped Autonomous Execution)` |
| **FIPS 140-3 Cryptographic Validation** | `ENABLED (GOFIPS=1 / AWS-LC-FIPS / SHA-256 & AES-256-GCM KAT Passed)` |
| **CMMC 2.0 Compliance Posture** | `CMMC Level 1 (FAR 52.204-21) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110)` |
| **Enforced CWE Mitigations** | `CWE-377, CWE-114, CWE-22, CWE-346, CWE-400, CWE-1333` |
| **Ed25519 Signer Key ID** | `CN-ED25519-99AC51E14879E456` |
| **Ed25519 Signature** | `39ff8248a3d323228838933b1b4b9cf435a479dccf7695c3...` |

---

## 2. Component Inventory & Unique Identifiers (NTIA / CISA Minimum Elements)

| # | Component Name | Version | Ecosystem | Supplier | PURL (Unique ID) | License | Source Manifest | SHA-256 Digest |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `001` | `patch_auditor` | `1.0.0` | `cargo-root` | CyberNest Holdings LLC (CyberNest Labs Department) | `pkg:cargo/patch_auditor@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `CodeBase/engines/patch_auditor/Cargo.toml` | `72bf420c15f04751...` |
| `002` | `cybernest.local/nestpatch/batch_dispatcher` | `1.0.0` | `golang-root` | CyberNest Holdings LLC (CyberNest Labs Department) | `pkg:golang/cybernest.local/nestpatch/batch_dispatcher@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `CodeBase/engines/batch_dispatcher/go.mod` | `ee16b159adbf6680...` |
| `003` | `textual` | `0.79.0,<2.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/textual@0.79.0,<2.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |
| `004` | `rich` | `13.7.1,<14.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/rich@13.7.1,<14.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |
| `005` | `aiosqlite` | `0.20.0,<1.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/aiosqlite@0.20.0,<1.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |
| `006` | `pydantic` | `2.7.0,<3.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/pydantic@2.7.0,<3.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |

---

## 3. Dependency Relationship Graph

* **Root Application Node**: `pkg:generic/cybernest/NestPatch@1.0.0`
  * `DEPENDS_ON` -> `pkg:cargo/patch_auditor@1.0.0` (`cpe:2.3:a:cybernest:patch_auditor:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/cybernest.local/nestpatch/batch_dispatcher@1.0.0` (`cpe:2.3:a:cybernest:cybernest.local_nestpatch_batch_dispatcher:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/textual@0.79.0,<2.0.0` (`cpe:2.3:a:pypi:textual:0.79.0,<2.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/rich@13.7.1,<14.0.0` (`cpe:2.3:a:pypi:rich:13.7.1,<14.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/aiosqlite@0.20.0,<1.0.0` (`cpe:2.3:a:pypi:aiosqlite:0.20.0,<1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/pydantic@2.7.0,<3.0.0` (`cpe:2.3:a:pypi:pydantic:2.7.0,<3.0.0:*:*:*:*:*:*:*`)

---

## 4. Cryptographic Integrity & CWE Hardening Attestation

* **Files Cryptographically Hashed (SHA-256)**: `54`
* **Shannon Entropy High-Risk Secret Alerts**: `0`
* **Ed25519 Public Key**: `99ac51e14879e456c9747f49ff458f77e3fb3d60ec822762e6ac5ef5438f6315`
* **Full Ed25519 Signature**: `39ff8248a3d323228838933b1b4b9cf435a479dccf7695c3454a0c4fbb1ab7a0a3686d6b66fc60a9c95a4e25142fc597b92893bdb0e4200a111f17c3cb007c49`

*Generated automatically by CyberNest Labs NestSBOM RPGS Engine.*
