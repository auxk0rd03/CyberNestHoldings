# CISA-COMPLIANT SOFTWARE BILL OF MATERIALS (SBOM) // NESTPATCH

## 1. Executive Order 14028 & CISA Minimum Elements Attestation

| CISA Mandatory Metadata Field | Verified Value |
| :--- | :--- |
| **SBOM Document Title** | `NestPatch - CyberNest CISA SBOM Ledger` |
| **SBOM Serial / Namespace UUID** | `urn:uuid:e78dacad-45f5-51e7-b2e6-d11ab1de8756` |
| **Author of SBOM Data** | `CyberNest Holdings LLC - William Ray Moore (President & Chief Architect) & James Dwayne Jarrell (CEO)` |
| **Timestamp (UTC)** | `2026-10-29T19:51:22Z` |
| **Primary Supplier Name** | `CyberNest Holdings LLC (Internal Department: CyberNest Labs)` |
| **Corporate Jurisdiction & Registration** | `Commonwealth of Pennsylvania LLC // SAM.gov UEI & CAGE: Not Yet Assigned (Pre-Registration)` |
| **Target Repository / Source** | `.` |
| **Ingestion & Parse Engines** | `go_repo_ingestor + rust_sbom_scanner` |
| **Supported Machine Formats** | `CycloneDX 1.5 JSON (SBOM.cyclonedx.json)` & `SPDX 2.3 JSON (SBOM.spdx.json)` |
| **Zero External Runtime Dependency Guarantee** | `ENFORCED (100% Air-Gapped Autonomous Execution)` |
| **FIPS 140-3 Cryptographic Validation** | `ENABLED (GOFIPS=1 / AWS-LC-FIPS / SHA-256 & AES-256-GCM KAT Passed)` |
| **CMMC 2.0 Compliance Posture** | `CMMC Level 1 (FAR 52.204-21) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110)` |
| **Enforced CWE Mitigations** | `CWE-377, CWE-114, CWE-22, CWE-346, CWE-400, CWE-1333` |
| **Ed25519 Signer Key ID** | `CN-ED25519-99AC51E14879E456` |
| **Ed25519 Signature** | `4743a4e4b06559cd13838beed39294a4df0a7a27523c7af9...` |

---

## 2. Component Inventory & Unique Identifiers (NTIA / CISA Minimum Elements)

| # | Component Name | Version | Ecosystem | Supplier | PURL (Unique ID) | License | Source Manifest | SHA-256 Digest |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `001` | `patch_auditor` | `1.0.0` | `cargo-root` | CyberNest Holdings LLC (Auxk0rd) | `pkg:cargo/patch_auditor@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `CodeBase/engines/patch_auditor/Cargo.toml` | `72bf420c15f04751...` |
| `002` | `cybernest.local/nestpatch/batch_dispatcher` | `1.0.0` | `golang-root` | CyberNest Holdings LLC (Auxk0rd) | `pkg:golang/cybernest.local/nestpatch/batch_dispatcher@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `CodeBase/engines/batch_dispatcher/go.mod` | `ee16b159adbf6680...` |
| `003` | `textual` | `0.79.0,<2.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/textual@0.79.0,<2.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |
| `004` | `rich` | `13.7.1,<14.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/rich@13.7.1,<14.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |
| `005` | `aiosqlite` | `0.20.0,<1.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/aiosqlite@0.20.0,<1.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |
| `006` | `pydantic` | `2.7.0,<3.0.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/pydantic@2.7.0,<3.0.0` | `MIT OR BSD-3-Clause` | `CodeBase/requirements.txt` | `dc0e9243d1a396f9...` |

---

## 3. Dependency Relationship Graph

* **Root Application Node**: `pkg:generic/cybernest/NestPatch@1.0.0`
  * `DEPENDS_ON` -> `pkg:cargo/patch_auditor@1.0.0` (`cpe:2.3:a:cybernest:patch_auditor:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/cybernest.local/nestpatch/batch_dispatcher@1.0.0` (`cpe:2.3:a:cybernest:cybernest.local_nestpatch_batch_dispatcher:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/textual@0.79.0,<2.0.0` (`cpe:2.3:a:pypi:textual:0.79.0,<2.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/rich@13.7.1,<14.0.0` (`cpe:2.3:a:pypi:rich:13.7.1,<14.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/aiosqlite@0.20.0,<1.0.0` (`cpe:2.3:a:pypi:aiosqlite:0.20.0,<1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/pydantic@2.7.0,<3.0.0` (`cpe:2.3:a:pypi:pydantic:2.7.0,<3.0.0:*:*:*:*:*:*:*`)

---

## 4. Cryptographic Integrity & CWE Hardening Attestation

* **Files Cryptographically Hashed (SHA-256)**: `48`
* **Shannon Entropy High-Risk Secret Alerts**: `0`
* **Ed25519 Public Key**: `99ac51e14879e456c9747f49ff458f77e3fb3d60ec822762e6ac5ef5438f6315`
* **Full Ed25519 Signature**: `4743a4e4b06559cd13838beed39294a4df0a7a27523c7af9eb5f0082885697dc413e9e31b22e913163f65caaac180e0b1817a7e8351dbcfb014854b4d2e14601`

*Generated automatically by CyberNest Labs NestSBOM RPGS Engine.*
