@echo off
rem ==============================================================================
rem NestPatch Root Unified Launcher — Windows 10/11 (dev.bat)
rem Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
rem ==============================================================================
set SCRIPT_DIR=%~dp0
call "%SCRIPT_DIR%CodeBase\dev.bat" %*
exit /b %ERRORLEVEL%
