#!/usr/bin/env bash
# ==============================================================================
# NestPatch Root Unified Launcher — Linux / Pop!_OS (dev.sh)
# Standard: CN-DIR-2026-004 (Bi-Launcher Specification)
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/CodeBase/dev.sh" "$@"
