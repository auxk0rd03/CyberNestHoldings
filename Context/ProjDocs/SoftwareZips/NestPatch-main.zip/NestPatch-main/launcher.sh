#!/usr/bin/env bash
# ==============================================================================
# NestPatch Root Unified Launcher — Linux / Pop!_OS
# CyberNest Holdings LLC — Authorized Security Engineering Standard
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/CodeBase/launcher.sh" "$@"
