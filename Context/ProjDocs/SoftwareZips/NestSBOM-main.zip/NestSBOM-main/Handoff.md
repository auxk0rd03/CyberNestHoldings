# CyberNest Labs: NestSBOM Developer Handoff & Architecture Manual

## 1. Overview & Corporate Attribution
**NestSBOM** is the official **CyberNest Holdings LLC** (Commonwealth of Pennsylvania Manager-Managed Operating LLC; Internal Department: **CyberNest Labs**) CISA-Compliant Software Bill of Materials (SBOM) Ingestion, Synthesis, and Visualization platform.
* **Leadership Attribution**:
  * **William Ray Moore (Auxk0rd)** — President and Chief Architect
  * **James Dwayne Jarrell (JD)** — Chief Executive Officer
* **Federal Registration Status**: SAM.gov UEI & DLA CAGE Code in Pre-Registration (`NOT_YET_ASSIGNED`); SPRS 110/110 Internal Self-Assessment complete.

## 2. RPGS Tier Allocation & Security Hardening
* **Shell (`launcher.sh`)**:
  * CWE-377 symlink-hardened logging (`~/.cache/nestsbom/session.log`, `umask 077`, `0700` dir, `0600` file).
  * CWE-114 explicit child process lifecycle management (`APP_PID=$!`, zero `fuser -k`).
  * `GOFIPS=1 GODEBUG=fips140=on` Go compilation and automated SBOM generation.
* **Rust (`engines/sbom_scanner/`)**:
  * Zero-panic (`Result<T, E>`, zero `.unwrap()`/`.expect()` in production paths) linear-time $O(n)$ manifest parser (`Cargo.toml`, `go.mod`, `requirements.txt`).
  * Built-in FIPS 140-3 SHA-256 Known-Answer Test (KAT), CWE-22/CWE-377 path & symlink guards, and Shannon Entropy $H(X)$ secret detection.
* **Go (`engines/repo_ingestor/`)**:
  * Compiled with `GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0`.
  * Ingests GitHub URLs or local repositories with CWE-22 (`SanitizeRelativePath`, `SafeResolveUnder`), CWE-377 symlink rejection, and FIPS 140-3 SHA-256 + AES-256-GCM KAT self-tests.
* **Python (`app/` & `sbom_cli.py`)**:
  * FastAPI + HTMX cockpit (`synth-ledger.css` SYS.01 Nocturnal Synth-Ledger), CWE-346 Host/Origin loopback firewall, and CWE-400 64KB request body cap.
  * AES-256-GCM encrypted SQLite WAL storage (`0600`), dynamic Ed25519 keypair generation & artifact signing, IEEE 802.3 / 802.11w PMF medium sensing, and CMMC Level 1 & Level 2 + DISA STIG verification.
