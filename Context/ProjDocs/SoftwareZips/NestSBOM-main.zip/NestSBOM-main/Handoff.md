# CyberNest Labs: NestSBOM Developer Handoff & Architecture Manual

## 1. Overview & Corporate Attribution
**NestSBOM** is the official **CyberNest Holdings LLC** (Commonwealth of Pennsylvania Manager-Managed Operating LLC; Internal Department: **CyberNest Labs**) CISA-Compliant Software Bill of Materials (SBOM) Ingestion, Synthesis, and Visualization platform.
* **Leadership Attribution**:
  * **William Ray Moore (Auxk0rd)** — President and Chief Architect
  * **James Dwayne Jarrell (JD)** — Chief Executive Officer
* **Federal Registration Status**: SAM.gov UEI & DLA CAGE Code in Pre-Registration (`NOT_YET_ASSIGNED`); SPRS 110/110 Internal Self-Assessment complete.
* **Architectural Mandate**: Fully conforms to **CyberNest Labs Architecture Specification // Standard 004 (`CN-DIR-2026-004`)**: Dual-Native Orchestration Architecture (Bi-Launcher Pattern).

## 2. Dual-Native Orchestration Strategy (`CN-DIR-2026-004`)
* **POSIX Orchestration (`dev.sh` & `launcher.sh`)**:
  * Hardened for Linux/Pop!_OS with `umask 077`, `0700` `~/.cache/nestsbom/`, `0600` `session.log`, symlink rejection, non-root user cache preservation under `sudo`, and `CWE-114` `APP_PID` signal trap termination.
* **Windows Orchestration (`dev.bat` & `launcher.bat`)**:
  * Hardened for Windows 10/11 with `setlocal enabledelayedexpansion`, `cd /d "%~dp0"`, Administrator elevation cache preservation (`CARGO_HOME`, `RUSTUP_HOME`, `GOPATH`, `GOMODCACHE`, `GOCACHE`), `%LOCALAPPDATA%\nestsbom\session.log` with `icacls` strict ACLs, symlink/reparse-point defense, and `Wait-Process`/`taskkill` PID termination.
* **Universal Command Parity Contract**:
  * Supports identical subcommands across Linux and Windows: `setup`, `build`, `run`, `serve`, `cli`, `simulate`, `test`, `fmt`, and `sbom`.

## 3. RPGS Tier Allocation & Security Hardening
* **Rust Engine (`engines/sbom_scanner/`)**:
  * Zero-panic (`Result<T, E>`, zero `.unwrap()`/`.expect()` in production paths) linear-time $O(n)$ manifest parser (`Cargo.toml`, `go.mod`, `requirements.txt`).
  * Built-in FIPS 140-3 SHA-256 Known-Answer Test (KAT), CWE-22/CWE-377 path & symlink guards, and Shannon Entropy $H(X)$ secret detection.
  * Outputs native ELF (`bin/sbom_scanner`) on Linux and PE (`bin\sbom_scanner.exe`) on Windows.
* **Go Engine (`engines/repo_ingestor/`)**:
  * Compiled with `GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0`.
  * Ingests GitHub URLs or local repositories with CWE-22 (`SanitizeRelativePath`, `SafeResolveUnder`), CWE-377 symlink rejection, and FIPS 140-3 SHA-256 + AES-256-GCM KAT self-tests.
  * Outputs native ELF (`bin/repo_ingestor`) on Linux and PE (`bin\repo_ingestor.exe`) on Windows.
* **Python Engine (`app/` & `sbom_cli.py`)**:
  * FastAPI + HTMX cockpit (`synth-ledger.css` SYS.01 Nocturnal Synth-Ledger), CWE-346 Host/Origin loopback firewall, and CWE-400 64KB request body cap.
  * AES-256-GCM encrypted SQLite WAL storage (`0600`), dynamic Ed25519 keypair generation & artifact signing, IEEE 802.3 / 802.11w PMF cross-platform medium sensing, and CMMC Level 1 & Level 2 + DISA STIG verification.
  * Single-sweep non-interactive CLI audit (`--cli`) and fault-injection simulation (`--simulate --export`).
