# CyberNest Labs: NestSBOM — CISA-Compliant SBOM Ingestion & Visualization Platform

* **Organization**: CyberNest Holdings LLC (Pennsylvania Manager-Managed Operating LLC)
* **Internal Department**: CyberNest Labs (Internal Research & Engineering Department)
* **Leadership**: William Ray Moore (Auxk0rd) — President & Chief Architect | James Dwayne Jarrell (JD) — Chief Executive Officer
* **Architecture**: RPGS (Rust + Python + Go + POSIX Shell) + Native Windows Batch + HTMX (`synth-ledger.css` SYS.01 Nocturnal Synth-Ledger)
* **Governance Standard**: Implements **CyberNest Labs Architecture Specification // Standard 004 (`CN-DIR-2026-004`)**: Dual-Native Orchestration Architecture (Bi-Launcher Specification).
* **Compliance & Security Posture**:
  * **Executive Order 14028 & CISA Minimum Elements**: Automated synthesis of CycloneDX 1.5 JSON (`SBOM.cyclonedx.json`), SPDX 2.3 JSON (`SBOM.spdx.json`), CISA Attestation Ledger (`SBOM.md`), and STIX 2.1 / TAXII 2.1 Supply-Chain Threat Intelligence bundles.
  * **CMMC 2.0**: Level 1 (FAR 52.204-21 — 17/17 controls) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110 controls, Internal Self-Assessment SPRS Score: 110).
  * **Cryptographic Assurance**: FIPS 140-3 (`GOFIPS=1`, SHA-256 & AES-256-GCM Known-Answer Tests), dynamic Ed25519 artifact signing, and AES-256-GCM encrypted SQLite WAL persistence (`0600`).
  * **Enforced CWE Hardening**: CWE-377 (Symlink-hardened user enclave & `icacls` Windows ACLs), CWE-114 (Explicit PID lifecycle tracking), CWE-22 (Multi-stage path traversal sanitization), CWE-346 (Loopback Host/Origin firewall), CWE-400 (64KB payload cap), and CWE-1333 (Zero-panic linear-time $O(n)$ parsing).
  * **DISA STIG & IEEE 802 Sensing**: Programmatic IEEE 802.3 (Wired) & IEEE 802.11w (Protected Management Frames) medium validation across both Linux and Windows 10/11 platforms.

---

## Universal Command Parity Contract (`CN-DIR-2026-004`)

NestSBOM provides identical operational commands across both Linux / Pop!_OS (`./dev.sh` or `./launcher.sh`) and Windows 10/11 (`.\dev.bat` or `.\launcher.bat`):

| Subcommand | Linux / Pop!_OS (`./dev.sh` / `./launcher.sh`) | Windows 10/11 (`.\dev.bat` / `.\launcher.bat`) | Operational Behavior |
| :--- | :--- | :--- | :--- |
| `setup` | `./dev.sh setup` | `.\dev.bat setup` | Verifies Go, Cargo, and Python 3 runtimes and runtime path boundaries. |
| `build` | `./dev.sh build` | `.\dev.bat build` | Compiles Rust `sbom_scanner[.exe]` & Go `repo_ingestor[.exe]` (`GOFIPS=1`) + generates CISA SBOMs. |
| `run` / `serve` | `./dev.sh serve` | `.\dev.bat serve` | Launches local Nocturnal Synth-Ledger WebGUI on `http://127.0.0.1:8090` with `CWE-114` PID tracking. |
| `cli` | `./dev.sh cli` | `.\dev.bat cli` | Executes a single-sweep diagnostic & CISA SBOM audit and emits JSON report to stdout. |
| `simulate` | `./dev.sh simulate` | `.\dev.bat simulate` | Executes fault-injection & supply-chain simulation sweep and exports report to `exports/`. |
| `test` | `./dev.sh test` | `.\dev.bat test` | Executes polyglot automated test suite (Rust unit tests, Go tests, and Python unittest suite). |
| `fmt` | `./dev.sh fmt` | `.\dev.bat fmt` | Formats all Go (`go fmt ./...`) and Rust (`cargo fmt`) source code. |
| `sbom` | `./dev.sh sbom <path_or_url>` | `.\dev.bat sbom <path_or_url>` | Generates CycloneDX, SPDX, and CISA Markdown SBOMs for any repository or URL. |

---

## Quick Start Examples

### 1. Build Native Engines & Generate CISA SBOMs
```bash
# Pop!_OS / Linux:
./dev.sh build        # or: ./launcher.sh build

# Windows 10/11 (CMD or PowerShell):
.\dev.bat build       # or: .\launcher.bat build
```

### 2. Single-Sweep CLI Diagnostic & Audit
```bash
./dev.sh cli          # Windows: .\dev.bat cli
```

### 3. Fault-Injection Simulation Audit
```bash
./dev.sh simulate     # Windows: .\dev.bat simulate
```

### 4. Run Polyglot Test Suite
```bash
./dev.sh test         # Windows: .\dev.bat test
```

### 5. Launch Interactive Web Dashboard
```bash
./dev.sh serve        # Windows: .\dev.bat serve (http://127.0.0.1:8090)
```
