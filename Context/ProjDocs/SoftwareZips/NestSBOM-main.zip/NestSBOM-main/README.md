# CyberNest Labs: NestSBOM — CISA-Compliant SBOM Ingestion & Visualization Platform

* **Organization**: CyberNest Holdings LLC (Pennsylvania Manager-Managed Operating LLC)
* **Internal Department**: CyberNest Labs (Internal Research & Engineering Department)
* **Leadership**: William Ray Moore (Auxk0rd) — President & Chief Architect | James Dwayne Jarrell (JD) — Chief Executive Officer
* **Architecture**: RPGS (Rust + Python + Go + POSIX Shell) + HTMX (`synth-ledger.css` SYS.01 Nocturnal Synth-Ledger)
* **Compliance & Security Posture**:
  * **Executive Order 14028 & CISA 2026 Minimum Elements**: Automated synthesis of CycloneDX 1.5 JSON (`SBOM.cyclonedx.json`), SPDX 2.3 JSON (`SBOM.spdx.json`), CISA Attestation Ledger (`SBOM.md`), and STIX 2.1 / TAXII 2.1 Supply-Chain Threat Intelligence bundles.
  * **CMMC 2.0**: Level 1 (FAR 52.204-21 — 17/17 controls) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110 controls, Internal Self-Assessment SPRS Score: 110).
  * **Cryptographic Assurance**: FIPS 140-3 (`GOFIPS=1`, SHA-256 & AES-256-GCM Known-Answer Tests), dynamic Ed25519 artifact signing, and AES-256-GCM encrypted SQLite WAL persistence (`0600`).
  * **Enforced CWE Hardening**: CWE-377 (Symlink-hardened user enclave), CWE-114 (Explicit PID lifecycle tracking), CWE-22 (Multi-stage path traversal sanitization), CWE-346 (Loopback Host/Origin firewall), CWE-400 (64KB payload cap), and CWE-1333 (Zero-panic linear-time $O(n)$ parsing).
  * **DISA STIG & IEEE 802 Sensing**: Programmatic IEEE 802.3 (Wired) & IEEE 802.11w (Protected Management Frames) medium validation.

## Quick Start

```bash
chmod +x launcher.sh

# 1. Compile Rust (sbom_scanner) and Go (repo_ingestor) engines + generate SBOMs
./launcher.sh build

# 2. Run automated unit & security verification tests
./launcher.sh test

# 3. Generate CycloneDX 1.5, SPDX 2.3 & CISA SBOM Markdown for any repo or GitHub URL
./launcher.sh sbom .

# 4. Launch the local Nocturnal Synth-Ledger HTMX Cockpit (http://127.0.0.1:8090)
./launcher.sh run
```
