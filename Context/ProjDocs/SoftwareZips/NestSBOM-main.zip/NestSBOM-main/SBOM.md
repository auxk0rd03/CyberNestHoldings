# CISA-COMPLIANT SOFTWARE BILL OF MATERIALS (SBOM) // NESTSBOM

## 1. Executive Order 14028 & CISA Minimum Elements Attestation

| CISA Mandatory Metadata Field | Verified Value |
| :--- | :--- |
| **SBOM Document Title** | `NestSBOM - CyberNest CISA SBOM Ledger` |
| **SBOM Serial / Namespace UUID** | `urn:uuid:5f50adf7-066d-5027-bdbb-fb397c308cec` |
| **Author of SBOM Data** | `CyberNest Holdings LLC - William Ray Moore (President & Chief Architect) & James Dwayne Jarrell (CEO)` |
| **Timestamp (UTC)** | `2026-10-30T22:48:34Z` |
| **Primary Supplier Name** | `CyberNest Holdings LLC (Internal Department: CyberNest Labs)` |
| **Corporate Jurisdiction & Registration** | `Commonwealth of Pennsylvania LLC // SAM.gov UEI & CAGE: Not Yet Assigned (Pre-Registration)` |
| **Target Repository / Source** | `./NestSBOM` |
| **Ingestion & Parse Engines** | `go_repo_ingestor + rust_sbom_scanner` |
| **Supported Machine Formats** | `CycloneDX 1.5 JSON (SBOM.cyclonedx.json)` & `SPDX 2.3 JSON (SBOM.spdx.json)` |
| **Zero External Runtime Dependency Guarantee** | `ENFORCED (100% Air-Gapped Autonomous Execution)` |
| **FIPS 140-3 Cryptographic Validation** | `ENABLED (GOFIPS=1 / AWS-LC-FIPS / SHA-256 & AES-256-GCM KAT Passed)` |
| **CMMC 2.0 Compliance Posture** | `CMMC Level 1 (FAR 52.204-21) & Level 2 (NIST SP 800-171 Rev. 2 — 110/110)` |
| **Enforced CWE Mitigations** | `CWE-377, CWE-114, CWE-22, CWE-346, CWE-400, CWE-1333` |
| **Ed25519 Signer Key ID** | `CN-ED25519-99AC51E14879E456` |
| **Ed25519 Signature** | `f8ca1e147ae71a3276919800281e13f12e7804b02a7d7f3d...` |

---

## 2. Component Inventory & Unique Identifiers (NTIA / CISA Minimum Elements)

| # | Component Name | Version | Ecosystem | Supplier | PURL (Unique ID) | License | Source Manifest | SHA-256 Digest |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `001` | `sbom_scanner` | `1.0.0` | `cargo-root` | CyberNest Holdings LLC (CyberNest Labs Department) | `pkg:cargo/sbom_scanner@1.0.0` | `Proprietary` | `engines/sbom_scanner/Cargo.toml` | `53772b40a4dd63cc...` |
| `002` | `cybernest/repo_ingestor` | `1.0.0` | `golang-root` | CyberNest Holdings LLC (CyberNest Labs Department) | `pkg:golang/cybernest/repo_ingestor@1.0.0` | `LicenseRef-CyberNest-Proprietary` | `engines/repo_ingestor/go.mod` | `3a5545f1acb7b364...` |
| `003` | `fastapi` | `0.110.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/fastapi@0.110.0` | `MIT OR BSD-3-Clause` | `requirements.txt` | `87885d9dc3138de5...` |
| `004` | `uvicorn` | `0.27.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/uvicorn@0.27.0` | `MIT OR BSD-3-Clause` | `requirements.txt` | `87885d9dc3138de5...` |
| `005` | `jinja2` | `3.1.3` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/jinja2@3.1.3` | `MIT OR BSD-3-Clause` | `requirements.txt` | `87885d9dc3138de5...` |
| `006` | `python-multipart` | `0.0.9` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/python-multipart@0.0.9` | `MIT OR BSD-3-Clause` | `requirements.txt` | `87885d9dc3138de5...` |
| `007` | `httpx` | `0.27.0` | `pypi` | PyPI / Python Packaging Authority | `pkg:pypi/httpx@0.27.0` | `MIT OR BSD-3-Clause` | `requirements.txt` | `87885d9dc3138de5...` |

---

## 3. Dependency Relationship Graph

* **Root Application Node**: `pkg:generic/cybernest/NestSBOM@1.0.0`
  * `DEPENDS_ON` -> `pkg:cargo/sbom_scanner@1.0.0` (`cpe:2.3:a:cybernest:sbom_scanner:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:golang/cybernest/repo_ingestor@1.0.0` (`cpe:2.3:a:cybernest:cybernest_repo_ingestor:1.0.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/fastapi@0.110.0` (`cpe:2.3:a:pypi:fastapi:0.110.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/uvicorn@0.27.0` (`cpe:2.3:a:pypi:uvicorn:0.27.0:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/jinja2@3.1.3` (`cpe:2.3:a:pypi:jinja2:3.1.3:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/python-multipart@0.0.9` (`cpe:2.3:a:pypi:python-multipart:0.0.9:*:*:*:*:*:*:*`)
  * `DEPENDS_ON` -> `pkg:pypi/httpx@0.27.0` (`cpe:2.3:a:pypi:httpx:0.27.0:*:*:*:*:*:*:*`)

---

## 4. Cryptographic Integrity & CWE Hardening Attestation

* **Files Cryptographically Hashed (SHA-256)**: `18`
* **Shannon Entropy High-Risk Secret Alerts**: `0`
* **Ed25519 Public Key**: `99ac51e14879e456c9747f49ff458f77e3fb3d60ec822762e6ac5ef5438f6315`
* **Full Ed25519 Signature**: `f8ca1e147ae71a3276919800281e13f12e7804b02a7d7f3d038e1392ada0c1685eeb203d1c87ac232e5e27c95c5cf1faf558821db7aede3901d73fd23d22c108`

*Generated automatically by CyberNest Labs NestSBOM RPGS Engine.*
