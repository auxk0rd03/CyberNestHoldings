"""
CyberNest Labs — NestSBOM Encrypted SQLite WAL Persistence (`database.py`)
Enforces MP.L2-3.8.1: All persistent records in SQLite WAL are encrypted with
authenticated AES-256-GCM and restricted to `0600` POSIX permissions.
"""

from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.core.security import decrypt_aes256_gcm, encrypt_aes256_gcm, get_enclave_dir


def get_db_path() -> Path:
    custom = os.environ.get("NESTSBOM_DB_PATH")
    if custom:
        p = Path(custom)
        p.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        return p
    return get_enclave_dir() / "nestsbom_enclave.db"


def init_db() -> Path:
    db_path = get_db_path()
    if db_path.is_symlink():
        db_path.unlink()
    conn = sqlite3.connect(str(db_path))
    try:
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sbom_ledgers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                repo_name TEXT NOT NULL,
                source TEXT NOT NULL,
                timestamp_utc TEXT NOT NULL,
                components_count INTEGER NOT NULL,
                signer_key_id TEXT NOT NULL,
                encrypted_bundle_b64 TEXT NOT NULL
            );
            """
        )
        conn.commit()
    finally:
        conn.close()
    try:
        os.chmod(db_path, 0o600)
    except OSError:
        pass
    return db_path


def save_sbom_bundle(bundle: Dict[str, Any]) -> int:
    db_path = init_db()
    encrypted_payload = encrypt_aes256_gcm(json.dumps(bundle).encode("utf-8"))
    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO sbom_ledgers (
                repo_name, source, timestamp_utc, components_count, signer_key_id, encrypted_bundle_b64
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                bundle["repo_name"],
                bundle["source"],
                bundle["timestamp"],
                len(bundle["components"]),
                bundle["signature"]["key_id"],
                encrypted_payload,
            ),
        )
        conn.commit()
        return int(cur.lastrowid or 1)
    finally:
        conn.close()


def get_latest_sbom_bundle(repo_name: Optional[str] = None) -> Optional[Dict[str, Any]]:
    db_path = init_db()
    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.cursor()
        if repo_name:
            cur.execute(
                "SELECT encrypted_bundle_b64 FROM sbom_ledgers WHERE repo_name = ? ORDER BY id DESC LIMIT 1",
                (repo_name,),
            )
        else:
            cur.execute("SELECT encrypted_bundle_b64 FROM sbom_ledgers ORDER BY id DESC LIMIT 1")
        row = cur.fetchone()
        if not row:
            return None
        decrypted = decrypt_aes256_gcm(row[0])
        return json.loads(decrypted.decode("utf-8"))
    finally:
        conn.close()


def list_recent_ledgers(limit: int = 10) -> List[Dict[str, Any]]:
    db_path = init_db()
    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT id, repo_name, source, timestamp_utc, components_count, signer_key_id FROM sbom_ledgers ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        return [
            {
                "id": r[0],
                "repo_name": r[1],
                "source": r[2],
                "timestamp": r[3],
                "components_count": r[4],
                "signer_key_id": r[5],
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()
