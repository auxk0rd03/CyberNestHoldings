"""
CyberNest Labs — NestSBOM FastAPI + HTMX Server (`app/main.py`)
Enforces:
- CWE-346 Host/Origin Firewall (`127.0.0.1` / `localhost`)
- CWE-400 64KB Request Body Cap (`MAX_REQUEST_BYTES = 65536`)
- Style_Specification_FrontEnd.md ("NOCTURNAL SYNTH-LEDGER" `synth-ledger.css`)
- Rule 1: HTMX swap triggers (`/api/ingest`, `/api/compliance/view`) return semantic HTML fragments.
- Machine-readable export routes (`/api/export/cyclonedx`, `/api/export/spdx`, `/api/export/cisa-md`, `/api/export/stix`, `/api/export/taxii`, `/api/export/stig`).
"""

from __future__ import annotations

import html
import json
import os
import sys
from pathlib import Path
from typing import Optional

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.core.database import get_latest_sbom_bundle, init_db, save_sbom_bundle
from app.core.sbom_synthesizer import (
    generate_complete_sbom_bundle,
    render_cisa_sbom_html_fragment,
    render_synth_step_meter,
)
from app.core.security import (
    MAX_REQUEST_BYTES,
    get_or_create_ed25519_identity,
    sense_network_medium_802,
    verify_cmmc_and_stig_controls,
    verify_host_and_origin,
)

app = FastAPI(
    title="CyberNest NestSBOM — CISA SBOM Ingestion & Visualization Platform",
    version="1.0.0",
)

STATIC_DIR = ROOT_DIR / "app" / "static"
TEMPLATES_DIR = ROOT_DIR / "app" / "templates"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@app.middleware("http")
async def cwe_security_middleware(request: Request, call_next):
    # CWE-346: Host & Origin validation
    host = request.headers.get("host", "127.0.0.1")
    origin = request.headers.get("origin", "")
    if not verify_host_and_origin(host, origin):
        return PlainTextResponse("CWE-346 Access Denied: Untrusted Host or Origin Header", status_code=403)

    # CWE-400: 64KB request body cap
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_REQUEST_BYTES:
        return PlainTextResponse("CWE-400 Payload Too Large: Exceeds 64KB Cap", status_code=413)
    body = await request.body()
    if len(body) > MAX_REQUEST_BYTES:
        return PlainTextResponse("CWE-400 Payload Too Large: Exceeds 64KB Cap", status_code=413)

    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Cache-Control"] = "no-store"
    return response


def _resolve_target_source(raw_source: str) -> str:
    src = raw_source.strip()
    if src.startswith("https://github.com/") or src.startswith("http://github.com/"):
        return src
    candidate = (ROOT_DIR / src).resolve() if not os.path.isabs(src) else Path(src).resolve()
    return str(candidate)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    init_db()
    identity = get_or_create_ed25519_identity()
    bundle = get_latest_sbom_bundle()
    if not bundle:
        bundle = generate_complete_sbom_bundle(str(ROOT_DIR))
        save_sbom_bundle(bundle)
    fragment = render_cisa_sbom_html_fragment(bundle)
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "signer_key_id": identity["key_id"],
            "default_source": ".",
            "initial_fragment": fragment,
        },
    )


@app.post("/api/ingest", response_class=HTMLResponse)
async def ingest_repo_htmx(source: str = Form(...)):
    resolved = _resolve_target_source(source)
    bundle = generate_complete_sbom_bundle(resolved, allow_clone=True)
    save_sbom_bundle(bundle)
    return HTMLResponse(render_cisa_sbom_html_fragment(bundle))


@app.get("/api/compliance/view", response_class=HTMLResponse)
async def view_compliance_htmx():
    rep = verify_cmmc_and_stig_controls()
    meter = render_synth_step_meter(100)
    rows = []
    for idx, ctrl in enumerate(rep["controls"], start=1):
        rows.append(
            f"""<tr>
                <td>#CTRL-{idx:02d}</td>
                <td>{html.escape(ctrl['control_id'])}</td>
                <td>{html.escape(ctrl['family'])}</td>
                <td>{html.escape(ctrl['evidence'])}</td>
                <td class="val-pos">[{html.escape(ctrl['status'])}]</td>
            </tr>"""
        )
    html_out = f"""
    <section class="panel" id="bank-compliance">
        <div class="panel-header">
            <span>CH_02 // CMMC_L2_AND_DISA_STIG_VERIFICATION</span>
            <span class="val-pos">[SPRS_SCORE: {rep['sprs_score']} / 110]</span>
        </div>
        <div class="param-block">
            <div class="param-meta">
                <span>NIST SP 800-171 REV 2 &amp; FAR 52.204-21 CONTROL SATISFACTION</span>
                <span class="val-pos">100% [VERIFIED]</span>
            </div>
            <div class="step-meter">{meter}</div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>SEQ</th>
                    <th>CONTROL_ID</th>
                    <th>DOMAIN</th>
                    <th>TECHNICAL_EVIDENCE</th>
                    <th>STATE</th>
                </tr>
            </thead>
            <tbody>{"".join(rows)}</tbody>
        </table>
    </section>
    """
    return HTMLResponse(html_out)


def _get_or_build_bundle(repo: Optional[str] = None):
    bundle = get_latest_sbom_bundle(repo)
    if not bundle:
        bundle = generate_complete_sbom_bundle(str(ROOT_DIR))
        save_sbom_bundle(bundle)
    return bundle


@app.get("/api/export/cyclonedx")
async def export_cyclonedx(repo: Optional[str] = None):
    bundle = _get_or_build_bundle(repo)
    return JSONResponse(bundle["cyclonedx_json"])


@app.get("/api/export/spdx")
async def export_spdx(repo: Optional[str] = None):
    bundle = _get_or_build_bundle(repo)
    return JSONResponse(bundle["spdx_json"])


@app.get("/api/export/cisa-md")
async def export_cisa_markdown(repo: Optional[str] = None):
    bundle = _get_or_build_bundle(repo)
    return PlainTextResponse(bundle["cisa_markdown"], media_type="text/markdown")


@app.get("/api/export/stix")
async def export_stix(repo: Optional[str] = None):
    bundle = _get_or_build_bundle(repo)
    return JSONResponse(bundle["stix_bundle"])


@app.get("/api/export/taxii")
async def export_taxii(repo: Optional[str] = None):
    bundle = _get_or_build_bundle(repo)
    return JSONResponse(bundle["taxii_collection"])


@app.get("/api/export/stig")
async def export_stig():
    return JSONResponse(verify_cmmc_and_stig_controls())


@app.get("/api/network-sense")
async def network_sense_endpoint():
    return JSONResponse(sense_network_medium_802())


if __name__ == "__main__":
    import uvicorn
    host = os.environ.get("APP_HOST", "127.0.0.1")
    port = int(os.environ.get("APP_PORT", "8090"))
    uvicorn.run(app, host=host, port=port, timeout_keep_alive=30)
