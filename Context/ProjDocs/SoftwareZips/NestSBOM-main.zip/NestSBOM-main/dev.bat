@echo off
REM ==============================================================================
REM CyberNest Labs // NestSBOM Windows 10/11 Orchestration Runner (dev.bat)
REM Standard: CN-DIR-2026-004 (Dual-Native Orchestration Architecture)
REM Security: CWE-377 (Symlink/Reparse Defense, Strict ACLs) & CWE-114 (PID Control)
REM ==============================================================================
setlocal enabledelayedexpansion

REM --- 1. Path Hijacking Defense (CWE-377) ---
cd /d "%~dp0"
set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

REM --- 2. User Cache Preservation Under Admin Elevation ---
set "REAL_USERPROFILE=%USERPROFILE%"
echo "%REAL_USERPROFILE%" | findstr /I "System32" >nul 2>&1
if not errorlevel 1 (
    for /f "usebackq delims=" %%U in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "[Environment]::GetFolderPath('UserProfile')"`) do (
        if not "%%U"=="" set "REAL_USERPROFILE=%%U"
    )
)
if "%LOCALAPPDATA%"=="" (
    set "REAL_LOCALAPPDATA=%REAL_USERPROFILE%\AppData\Local"
) else (
    set "REAL_LOCALAPPDATA=%LOCALAPPDATA%"
)

set "CARGO_HOME=%REAL_USERPROFILE%\.cargo"
set "RUSTUP_HOME=%REAL_USERPROFILE%\.rustup"
set "GOPATH=%REAL_USERPROFILE%\go"
set "GOMODCACHE=%REAL_USERPROFILE%\go\pkg\mod"
set "GOCACHE=%REAL_LOCALAPPDATA%\go-build"
set "PATH=%CARGO_HOME%\bin;%GOPATH%\bin;%PATH%"

REM --- 3. Hardened Local Enclave Logging & ACLs (CWE-377) ---
set "CACHE_DIR=%REAL_LOCALAPPDATA%\nestsbom"
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
icacls "%CACHE_DIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1

set "LOG_FILE=%CACHE_DIR%\session.log"
if exist "%LOG_FILE%" (
    fsutil reparsepoint query "%LOG_FILE%" >nul 2>&1 && del /f /q "%LOG_FILE%"
)
type nul >> "%LOG_FILE%"
icacls "%LOG_FILE%" /inheritance:r /grant:r "%USERNAME%:F" >nul 2>&1

set "CMD=%~1"
if "%CMD%"=="" set "CMD=run"

if /I "%CMD%"=="setup" goto :cmd_setup
if /I "%CMD%"=="build" goto :cmd_build
if /I "%CMD%"=="run" goto :cmd_run
if /I "%CMD%"=="serve" goto :cmd_run
if /I "%CMD%"=="cli" goto :cmd_cli
if /I "%CMD%"=="simulate" goto :cmd_simulate
if /I "%CMD%"=="test" goto :cmd_test
if /I "%CMD%"=="fmt" goto :cmd_fmt
if /I "%CMD%"=="sbom" goto :cmd_sbom

echo Usage: %~nx0 {setup^|build^|run^|serve^|cli^|simulate^|test^|fmt^|sbom ^<repo_path^>}
exit /b 1

:cmd_setup
echo ==^> [SETUP] Verifying Windows 10/11 polyglot toolchains...
where go >nul 2>&1 || (echo [ERROR] Go compiler not found in PATH. & exit /b 1)
where cargo >nul 2>&1 || (echo [ERROR] Rust/Cargo toolchain not found in PATH. & exit /b 1)
where python >nul 2>&1 || (echo [ERROR] Python 3 not found in PATH. & exit /b 1)
go version
cargo --version
python --version
echo ==^> [SETUP] Toolchains verified successfully.
exit /b 0

:do_build
if not exist "bin" mkdir "bin"
echo ==^> [1/3] Compiling Rust Engine (bin\sbom_scanner.exe)...
pushd engines\sbom_scanner
cargo build --release --quiet --offline 2>nul || cargo build --release --quiet
if errorlevel 1 (popd & exit /b 1)
popd
copy /y engines\sbom_scanner\target\release\sbom_scanner.exe bin\sbom_scanner.exe >nul
if errorlevel 1 exit /b 1

echo ==^> [2/3] Compiling Go Engine (bin\repo_ingestor.exe with GOFIPS=1)...
set "GOFIPS=1"
set "GODEBUG=fips140=on"
set "CGO_ENABLED=0"
pushd engines\repo_ingestor
go build -ldflags="-s -w" -o ..\..\bin\repo_ingestor.exe main.go
if errorlevel 1 (popd & exit /b 1)
popd

echo ==^> [3/3] Generating CycloneDX 1.5, SPDX 2.3 ^& CISA SBOM manifests...
python sbom_cli.py --repo . --out-dir . >nul
exit /b 0

:cmd_build
call :do_build
exit /b %ERRORLEVEL%

:cmd_run
call :do_build
if errorlevel 1 exit /b 1

set "APP_PORT=8090"
netstat -ano | findstr /R /C:":!APP_PORT! .*LISTENING" >nul 2>&1
if not errorlevel 1 (
    for /f "usebackq" %%P in (`powershell -NoProfile -Command "$l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0); $l.Start(); $p = $l.LocalEndpoint.Port; $l.Stop(); Write-Output $p"`) do (
        set "APP_PORT=%%P"
    )
)

echo ==^> Starting NestSBOM Web Server on http://127.0.0.1:!APP_PORT! ...
echo ==^> Session Log: %LOG_FILE%
set "APP_HOST=127.0.0.1"
set "APP_PID="
for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$env:APP_HOST='127.0.0.1'; $env:APP_PORT='!APP_PORT!'; $p = Start-Process -FilePath 'python' -ArgumentList 'app/main.py' -NoNewWindow -PassThru -RedirectStandardOutput '%LOG_FILE%'; Write-Output $p.Id"`) do (
    set "APP_PID=%%P"
)
if defined APP_PID (
    echo [INFO] Tracked child PID: !APP_PID! ^(Press Ctrl+C to terminate^)
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Wait-Process -Id !APP_PID! } finally { Stop-Process -Id !APP_PID! -Force -ErrorAction SilentlyContinue }"
    taskkill /PID !APP_PID! /T /F >nul 2>&1
) else (
    python app/main.py >> "%LOG_FILE%" 2>&1
)
exit /b 0

:cmd_cli
call :do_build
if errorlevel 1 exit /b 1
echo ==^> Running NestSBOM CLI Diagnostic ^& SBOM Audit...
python sbom_cli.py --cli --repo .
exit /b %ERRORLEVEL%

:cmd_simulate
call :do_build
if errorlevel 1 exit /b 1
echo ==^> Running NestSBOM Fault-Injection ^& Supply-Chain Simulation...
python sbom_cli.py --cli --simulate --export --repo .
exit /b %ERRORLEVEL%

:cmd_test
call :do_build
if errorlevel 1 exit /b 1
echo ==^> Running polyglot test suite...
pushd engines\sbom_scanner
cargo test --quiet --offline 2>nul || cargo test --quiet
if errorlevel 1 (popd & exit /b 1)
popd
pushd engines\repo_ingestor
set "GOFIPS=1"
set "GODEBUG=fips140=on"
go test -v ./...
if errorlevel 1 (popd & exit /b 1)
popd
python -m unittest discover -s tests -p "test_*.py" -v
exit /b %ERRORLEVEL%

:cmd_fmt
echo ==^> Formatting Go and Rust source code...
pushd engines\repo_ingestor
go fmt ./...
popd
pushd engines\sbom_scanner
cargo fmt
popd
exit /b 0

:cmd_sbom
set "TARGET=%~2"
if "%TARGET%"=="" set "TARGET=."
python sbom_cli.py --repo "%TARGET%"
exit /b %ERRORLEVEL%
