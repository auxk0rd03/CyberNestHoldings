#!/usr/bin/env bash
# ==============================================================================
# CyberNest Labs // NestSBOM POSIX Orchestration Runner (dev.sh)
# Standard: CN-DIR-2026-004 (Dual-Native Orchestration Architecture)
# Security: CWE-377 (Symlink Defense, umask 077, 0700/0600 permissions),
#           CWE-114 (Explicit APP_PID tracking), FIPS 140-3 (GOFIPS=1)
# ==============================================================================
set -euo pipefail
IFS=$'\n\t'
umask 077

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

APP_NAME="nestsbom"
DEFAULT_PORT=8090
MAX_PORT=8150
HOST="127.0.0.1"
TARGET_PORT="${APP_PORT:-}"
APP_PID=""

# When invoked via `sudo ./dev.sh`, preserve non-root operator's Cargo & Go caches
REAL_USER="${SUDO_USER:-${USER:-auxk0rd}}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6 || echo "/home/$REAL_USER")"
export CARGO_HOME="${REAL_HOME}/.cargo"
export RUSTUP_HOME="${REAL_HOME}/.rustup"
export GOPATH="${REAL_HOME}/go"
export GOMODCACHE="${REAL_HOME}/go/pkg/mod"
export GOCACHE="${REAL_HOME}/.cache/go-build"
export PATH="${REAL_HOME}/.cargo/bin:/usr/local/go/bin:/usr/bin:/bin:${PATH}"

LOG_DIR="${REAL_HOME}/.cache/${APP_NAME}"
mkdir -p -m 700 "$LOG_DIR"
LOG_FILE="${LOG_DIR}/session.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE"
chmod 600 "$LOG_FILE"

cleanup() {
    local exit_code=$?
    trap - EXIT INT TERM
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        echo "[INFO] Dispatching SIGTERM to tracked child PID: $APP_PID" >> "$LOG_FILE"
        kill -TERM "$APP_PID" 2>/dev/null || true
        local count=0
        while kill -0 "$APP_PID" 2>/dev/null && [ $count -lt 10 ]; do
            sleep 0.2
            count=$((count + 1))
        done
        if kill -0 "$APP_PID" 2>/dev/null; then
            echo "[WARN] Force-killing PID $APP_PID..." >> "$LOG_FILE"
            kill -KILL "$APP_PID" 2>/dev/null || true
        fi
        wait "$APP_PID" 2>/dev/null || true
    fi
    exit "$exit_code"
}
trap cleanup EXIT INT TERM

detect_python() {
    if command -v python3 &>/dev/null; then
        echo "python3"
    elif command -v python &>/dev/null; then
        echo "python"
    else
        echo "[ERROR] Python 3 not found in PATH." >&2
        exit 1
    fi
}

PYTHON_BIN="$(detect_python)"

build_engines() {
    mkdir -p -m 700 "$ROOT_DIR/bin"
    echo "==> [1/3] Compiling Rust engine (sbom_scanner) in Zero-Panic Release mode..."
    if command -v cargo &>/dev/null; then
        (cd "$ROOT_DIR/engines/sbom_scanner" && (cargo build --release --quiet --offline 2>/dev/null || cargo build --release --quiet))
        cp -f "$ROOT_DIR/engines/sbom_scanner/target/release/sbom_scanner" "$ROOT_DIR/bin/sbom_scanner"
        chmod 750 "$ROOT_DIR/bin/sbom_scanner"
    else
        echo "[WARN] Cargo not detected; pure-Python scanner fallback will be active."
    fi

    echo "==> [2/3] Compiling Go engine (repo_ingestor) with FIPS 140-3 (GOFIPS=1)..."
    if command -v go &>/dev/null; then
        (cd "$ROOT_DIR/engines/repo_ingestor" && GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0 go build -ldflags="-s -w" -o "$ROOT_DIR/bin/repo_ingestor" main.go)
        chmod 750 "$ROOT_DIR/bin/repo_ingestor"
    else
        echo "[WARN] Go compiler not detected; pure-Python ingestor fallback will be active."
    fi

    echo "==> [3/3] Generating CycloneDX 1.5, SPDX 2.3 & CISA SBOM manifests..."
    "$PYTHON_BIN" "$ROOT_DIR/sbom_cli.py" --repo "$ROOT_DIR" --out-dir "$ROOT_DIR" >/dev/null
}

run_tests() {
    build_engines
    echo "==> Running Rust unit tests..."
    if command -v cargo &>/dev/null; then
        (cd "$ROOT_DIR/engines/sbom_scanner" && (cargo test --quiet --offline 2>/dev/null || cargo test --quiet))
    fi
    echo "==> Running Go unit tests..."
    if command -v go &>/dev/null; then
        (cd "$ROOT_DIR/engines/repo_ingestor" && GOFIPS=1 GODEBUG=fips140=on go test -v ./...)
    fi
    echo "==> Running NestSBOM Python unit & integration tests..."
    "$PYTHON_BIN" -m unittest discover -s tests -p "test_*.py" -v
}

allocate_port() {
    if [ -n "$TARGET_PORT" ]; then
        return 0
    fi
    local port=$DEFAULT_PORT
    while [ "$port" -le "$MAX_PORT" ]; do
        if ! (echo > /dev/tcp/"$HOST"/"$port") 2>/dev/null; then
            TARGET_PORT=$port
            return 0
        fi
        port=$((port + 1))
    done
    TARGET_PORT=$("$PYTHON_BIN" -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1]); s.close()')
}

cmd="${1:-run}"
case "$cmd" in
    setup)
        echo "==> [SETUP] Verifying polyglot toolchains & runtime environment..."
        go version 2>/dev/null || echo "[!] Go compiler not in PATH"
        cargo --version 2>/dev/null || echo "[!] Cargo not in PATH"
        "$PYTHON_BIN" --version
        echo "==> Toolchains verified."
        ;;
    build)
        build_engines
        ;;
    run|serve)
        build_engines
        allocate_port
        export APP_HOST="$HOST"
        export APP_PORT="$TARGET_PORT"
        echo "[INFO] Launching NestSBOM WebGUI on http://${HOST}:${TARGET_PORT} ..."
        "$PYTHON_BIN" -u app/main.py 2>&1 | tee -a "$LOG_FILE" &
        APP_PID=$!
        wait "$APP_PID"
        ;;
    cli)
        build_engines
        echo "==> Running NestSBOM CLI Diagnostic & SBOM Audit..."
        "$PYTHON_BIN" "$ROOT_DIR/sbom_cli.py" --cli --repo "$ROOT_DIR"
        ;;
    simulate)
        build_engines
        echo "==> Running NestSBOM Fault-Injection & Supply-Chain Simulation..."
        "$PYTHON_BIN" "$ROOT_DIR/sbom_cli.py" --cli --simulate --export --repo "$ROOT_DIR"
        ;;
    test)
        run_tests
        ;;
    fmt)
        echo "==> Formatting Go and Rust source code..."
        if command -v go &>/dev/null; then
            (cd "$ROOT_DIR/engines/repo_ingestor" && go fmt ./...)
        fi
        if command -v cargo &>/dev/null; then
            (cd "$ROOT_DIR/engines/sbom_scanner" && cargo fmt)
        fi
        ;;
    sbom)
        target_repo="${2:-$ROOT_DIR}"
        "$PYTHON_BIN" "$ROOT_DIR/sbom_cli.py" --repo "$target_repo"
        ;;
    *)
        echo "Usage: $0 {setup|build|run|serve|cli|simulate|test|fmt|sbom <path_or_url>}"
        exit 1
        ;;
esac
