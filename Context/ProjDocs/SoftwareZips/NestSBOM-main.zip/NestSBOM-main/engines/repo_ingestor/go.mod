module cybernest/repo_ingestor

go 1.22
