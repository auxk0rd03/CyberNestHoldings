@echo off
REM CyberNest Labs // NestSBOM Standardized Windows Entrypoint (launcher.bat)
REM Delegates to dev.bat per CN-DIR-2026-004 Bi-Launcher Specification
call "%~dp0dev.bat" %*
exit /b %ERRORLEVEL%
