#!/usr/bin/env bash
# CyberNest Labs — NestSBOM RPGS Standardized Bootloader, Compiler & SBOM Generator
# Enforces CWE-377 (Symlink-hardened logging, umask 077, 0700 dir, 0600 file),
# CWE-114 (Explicit APP_PID tracking, zero fuser -k), and FIPS 140-3 (GOFIPS=1).

set -euo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="nestsbom"
DEFAULT_PORT=8090
MAX_PORT=8150
HOST="127.0.0.1"
TARGET_PORT="${APP_PORT:-}"
APP_PID=""

LOG_DIR="${HOME}/.cache/${APP_NAME}"
mkdir -p -m 700 "$LOG_DIR"
LOG_FILE="${LOG_DIR}/session.log"
[ -L "$LOG_FILE" ] && rm -f "$LOG_FILE"
touch "$LOG_FILE"
chmod 600 "$LOG_FILE"

cleanup() {
    local exit_code=$?
    trap - EXIT INT TERM
    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        echo "[INFO] Dispatching SIGTERM to tracked child PID: $APP_PID"
        kill -TERM "$APP_PID" 2>/dev/null || true
        local count=0
        while kill -0 "$APP_PID" 2>/dev/null && [ $count -lt 10 ]; do
            sleep 0.3
            count=$((count + 1))
        done
        if kill -0 "$APP_PID" 2>/dev/null; then
            kill -KILL "$APP_PID" 2>/dev/null || true
        fi
    fi
    exit "$exit_code"
}
trap cleanup EXIT INT TERM

build_engines() {
    mkdir -p -m 700 "$SCRIPT_DIR/bin"
    echo "[INFO] Compiling Rust engine (sbom_scanner) in Zero-Panic Release mode..."
    if command -v cargo &>/dev/null; then
        (cd "$SCRIPT_DIR/engines/sbom_scanner" && cargo build --release --quiet)
        cp -f "$SCRIPT_DIR/engines/sbom_scanner/target/release/sbom_scanner" "$SCRIPT_DIR/bin/sbom_scanner"
        chmod 750 "$SCRIPT_DIR/bin/sbom_scanner"
    fi

    echo "[INFO] Compiling Go engine (repo_ingestor) with FIPS 140-3 (GOFIPS=1)..."
    if command -v go &>/dev/null; then
        (cd "$SCRIPT_DIR/engines/repo_ingestor" && GOFIPS=1 GODEBUG=fips140=on CGO_ENABLED=0 go build -ldflags="-s -w" -o "$SCRIPT_DIR/bin/repo_ingestor" main.go)
        chmod 750 "$SCRIPT_DIR/bin/repo_ingestor"
    fi

    echo "[INFO] Generating CycloneDX 1.5, SPDX 2.3 & CISA SBOM manifests..."
    python3 "$SCRIPT_DIR/sbom_cli.py" --repo "$SCRIPT_DIR" --out-dir "$SCRIPT_DIR" >/dev/null
}

run_tests() {
    build_engines
    echo "[INFO] Running Rust unit tests..."
    (cd "$SCRIPT_DIR/engines/sbom_scanner" && cargo test --quiet)
    echo "[INFO] Running NestSBOM Python unit & integration tests..."
    python3 -m unittest discover -s tests -p "test_*.py" -v
}

allocate_port() {
    if [ -n "$TARGET_PORT" ]; then
        return 0
    fi
    local port=$DEFAULT_PORT
    while [ "$port" -le "$MAX_PORT" ]; do
        if ! (echo > /dev/tcp/"$HOST"/"$port") 2>/dev/null; then
            TARGET_PORT=$port
            return 0
        fi
        port=$((port + 1))
    done
    TARGET_PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1]); s.close()')
}

cmd="${1:-run}"
case "$cmd" in
    build)
        build_engines
        ;;
    test)
        run_tests
        ;;
    sbom)
        target_repo="${2:-$SCRIPT_DIR}"
        python3 "$SCRIPT_DIR/sbom_cli.py" --repo "$target_repo"
        ;;
    run)
        build_engines
        allocate_port
        export APP_HOST="$HOST"
        export APP_PORT="$TARGET_PORT"
        echo "[INFO] Launching NestSBOM on http://${HOST}:${TARGET_PORT}..."
        python3 -u app/main.py >> "$LOG_FILE" 2>&1 &
        APP_PID=$!
        wait "$APP_PID"
        ;;
    *)
        echo "Usage: ./launcher.sh [build|test|sbom <path_or_url>|run]"
        exit 1
        ;;
esac
