#!/usr/bin/env python3
"""
CyberNest Labs — Universal CISA-Compliant SBOM Generator & Diagnostic CLI (`sbom_cli.py`)
Standard: CN-DIR-2026-004 (Dual-Native Orchestration Architecture)
Generates:
- `SBOM.cyclonedx.json` (CycloneDX 1.5 JSON)
- `SBOM.spdx.json` (SPDX 2.3 JSON)
- `SBOM.md` (Full Formatted CISA-Compliant SBOM Document)

Can be invoked in ANY codebase build script (`launcher.sh` / `dev.sh` / `dev.bat` / `Makefile`):
  python3 /path/to/NestSBOM/sbom_cli.py --repo <dir_or_github_url> [--out-dir <dir>]
  python3 /path/to/NestSBOM/sbom_cli.py --cli [--repo .]
  python3 /path/to/NestSBOM/sbom_cli.py --cli --simulate [--export] [--repo .]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict

NESTSBOM_ROOT = Path(__file__).resolve().parent
if str(NESTSBOM_ROOT) not in sys.path:
    sys.path.insert(0, str(NESTSBOM_ROOT))

from app.core.sbom_synthesizer import generate_complete_sbom_bundle
from app.core.security import verify_cmmc_and_stig_controls


def generate_sbom_files(repo_source: str, out_dir: Path, allow_clone: bool = False) -> Dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    bundle = generate_complete_sbom_bundle(repo_source, allow_clone=allow_clone)

    cdx_path = out_dir / "SBOM.cyclonedx.json"
    spdx_path = out_dir / "SBOM.spdx.json"
    md_path = out_dir / "SBOM.md"

    cdx_path.write_text(json.dumps(bundle["cyclonedx_json"], indent=2) + "\n", encoding="utf-8")
    spdx_path.write_text(json.dumps(bundle["spdx_json"], indent=2) + "\n", encoding="utf-8")
    md_path.write_text(bundle["cisa_markdown"], encoding="utf-8")

    return {
        "repo_name": bundle["repo_name"],
        "components_count": len(bundle["components"]),
        "cyclonedx_path": str(cdx_path),
        "spdx_path": str(spdx_path),
        "cisa_md_path": str(md_path),
        "signer_key_id": bundle["signature"]["key_id"],
    }


def run_cli_audit(repo_source: str, out_dir: Path, simulate: bool = False, export: bool = False, allow_clone: bool = False) -> Dict[str, Any]:
    sbom_summary = generate_sbom_files(repo_source, out_dir, allow_clone=allow_clone)
    compliance = verify_cmmc_and_stig_controls()

    audit_payload: Dict[str, Any] = {
        "mode": "SIMULATED_FAULT_INJECTION" if simulate else "LIVE_CLI_AUDIT",
        "standard": "CN-DIR-2026-004",
        "sbom_summary": sbom_summary,
        "compliance_posture": {
            "cmmc_level_1": compliance["cmmc_level_1_status"],
            "cmmc_level_2": compliance["cmmc_level_2_status"],
            "sprs_score": compliance["sprs_score"],
            "fips_140_3_mode": compliance["fips_140_3_mode"],
            "ieee_802_medium_status": compliance["network_medium"]["status"],
            "signer_key_id": compliance["signature"]["key_id"],
        },
    }

    if simulate:
        audit_payload["simulated_fault_scenarios"] = [
            {
                "scenario_id": "SIM-SBOM-ENTROPY-001",
                "category": "SECRET_EXPOSURE_GUARD",
                "injected_stimulus": "Synthetic high-entropy token (H(X) = 4.21 bits/byte > 3.3 threshold)",
                "mitigation_result": "BLOCKED_AND_FLAGGED_BY_RUST_SCANNER",
            },
            {
                "scenario_id": "SIM-SBOM-TRAVERSAL-002",
                "category": "CWE-22_CWE-377_BOUNDARY",
                "injected_stimulus": "Relative traversal '../etc/shadow' and symlink manifest injection",
                "mitigation_result": "REJECTED_BY_SAFE_RESOLVE_UNDER",
            },
            {
                "scenario_id": "SIM-SBOM-SUPPLYCHAIN-003",
                "category": "STIX_2.1_VULN_CORRELATION",
                "injected_stimulus": "Unpinned transitive dependency version drift simulation",
                "mitigation_result": "FLAGGED_IN_CISA_ATTESTATION_LEDGER",
            },
        ]
        if export:
            export_dir = NESTSBOM_ROOT / "exports"
            export_dir.mkdir(parents=True, exist_ok=True)
            export_file = export_dir / "simulated_sbom_audit.json"
            export_file.write_text(json.dumps(audit_payload, indent=2) + "\n", encoding="utf-8")
            audit_payload["exported_report_path"] = str(export_file)

    return audit_payload


def main() -> int:
    parser = argparse.ArgumentParser(description="CyberNest CISA-Compliant SBOM Generator & CLI Auditor")
    parser.add_argument("--repo", default=".", help="Local repository directory or GitHub URL (defaults to current directory)")
    parser.add_argument("--out-dir", default="", help="Output directory for SBOM files (defaults to --repo if local)")
    parser.add_argument("--allow-clone", action="store_true", help="Allow shallow git clone for GitHub URLs")
    parser.add_argument("--cli", action="store_true", help="Run single-sweep CLI diagnostic & compliance audit")
    parser.add_argument("--simulate", action="store_true", help="Run fault-injection & supply-chain degradation simulation")
    parser.add_argument("--export", action="store_true", help="Export offline simulation report to exports/simulated_sbom_audit.json")
    args = parser.parse_args()

    repo = args.repo.strip() or "."
    if args.out_dir:
        out_dir = Path(args.out_dir).resolve()
    elif repo.startswith("http://") or repo.startswith("https://"):
        out_dir = Path.cwd()
    else:
        out_dir = Path(repo).resolve()

    if args.cli or args.simulate:
        report = run_cli_audit(
            repo,
            out_dir,
            simulate=args.simulate,
            export=args.export or args.simulate,
            allow_clone=args.allow_clone,
        )
        print(json.dumps(report, indent=2))
        return 0

    summary = generate_sbom_files(repo, out_dir, allow_clone=args.allow_clone)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
