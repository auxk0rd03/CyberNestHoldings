#!/usr/bin/env python3
"""
CyberNest Labs — Universal CISA-Compliant SBOM Generator CLI (`sbom_cli.py`)
Generates:
- `SBOM.cyclonedx.json` (CycloneDX 1.5 JSON)
- `SBOM.spdx.json` (SPDX 2.3 JSON)
- `SBOM.md` (Full Formatted CISA-Compliant SBOM Document)

Can be invoked in ANY codebase build script (`launcher.sh` / `dev.sh` / `Makefile`):
  python3 /path/to/NestSBOM/sbom_cli.py --repo <dir_or_github_url> [--out-dir <dir>]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

NESTSBOM_ROOT = Path(__file__).resolve().parent
if str(NESTSBOM_ROOT) not in sys.path:
    sys.path.insert(0, str(NESTSBOM_ROOT))

from app.core.sbom_synthesizer import generate_complete_sbom_bundle


def generate_sbom_files(repo_source: str, out_dir: Path, allow_clone: bool = False) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    bundle = generate_complete_sbom_bundle(repo_source, allow_clone=allow_clone)

    cdx_path = out_dir / "SBOM.cyclonedx.json"
    spdx_path = out_dir / "SBOM.spdx.json"
    md_path = out_dir / "SBOM.md"

    cdx_path.write_text(json.dumps(bundle["cyclonedx_json"], indent=2) + "\n", encoding="utf-8")
    spdx_path.write_text(json.dumps(bundle["spdx_json"], indent=2) + "\n", encoding="utf-8")
    md_path.write_text(bundle["cisa_markdown"], encoding="utf-8")

    return {
        "repo_name": bundle["repo_name"],
        "components_count": len(bundle["components"]),
        "cyclonedx_path": str(cdx_path),
        "spdx_path": str(spdx_path),
        "cisa_md_path": str(md_path),
        "signer_key_id": bundle["signature"]["key_id"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="CyberNest CISA-Compliant SBOM Generator")
    parser.add_argument("--repo", required=True, help="Local repository directory or GitHub URL")
    parser.add_argument("--out-dir", default="", help="Output directory for SBOM files (defaults to --repo if local)")
    parser.add_argument("--allow-clone", action="store_true", help="Allow shallow git clone for GitHub URLs")
    args = parser.parse_args()

    repo = args.repo.strip()
    if args.out_dir:
        out_dir = Path(args.out_dir).resolve()
    elif repo.startswith("http://") or repo.startswith("https://"):
        out_dir = Path.cwd()
    else:
        out_dir = Path(repo).resolve()

    summary = generate_sbom_files(repo, out_dir, allow_clone=args.allow_clone)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
