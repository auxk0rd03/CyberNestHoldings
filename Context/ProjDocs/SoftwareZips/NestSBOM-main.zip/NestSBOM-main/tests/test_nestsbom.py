"""
CyberNest Labs — NestSBOM Automated Security, CWE & CISA SBOM Verification Suite
"""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

from app.core.database import get_latest_sbom_bundle, init_db, save_sbom_bundle
from app.core.sbom_synthesizer import (
    generate_complete_sbom_bundle,
    render_cisa_sbom_html_fragment,
    render_synth_step_meter,
)
from app.core.security import (
    decrypt_aes256_gcm,
    encrypt_aes256_gcm,
    enforce_payload_cap,
    get_or_create_ed25519_identity,
    safe_resolve_under,
    sanitize_relative_path,
    sense_network_medium_802,
    sign_payload_ed25519,
    verify_cmmc_and_stig_controls,
    verify_host_and_origin,
)

ROOT_DIR = Path(__file__).resolve().parent.parent


class TestNestSBOMSecurityAndSynthesis(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp_dir = tempfile.TemporaryDirectory(prefix="nestsbom_test_")
        os.environ["NESTSBOM_CACHE_DIR"] = cls.tmp_dir.name
        os.environ["NESTSBOM_DB_PATH"] = str(Path(cls.tmp_dir.name) / "test_enclave.db")

    @classmethod
    def tearDownClass(cls):
        cls.tmp_dir.cleanup()

    def test_cwe_22_path_sanitization(self):
        self.assertEqual(sanitize_relative_path("engines/sbom_scanner/Cargo.toml"), "engines/sbom_scanner/Cargo.toml")
        with self.assertRaises(ValueError):
            sanitize_relative_path("../../etc/passwd")
        with self.assertRaises(ValueError):
            sanitize_relative_path("/etc/shadow")
        with self.assertRaises(ValueError):
            sanitize_relative_path("bad\x00path.txt")

        resolved = safe_resolve_under(ROOT_DIR, "engines/sbom_scanner/Cargo.toml")
        self.assertTrue(str(resolved).startswith(str(ROOT_DIR.resolve())))

    def test_cwe_346_host_and_origin_firewall(self):
        self.assertTrue(verify_host_and_origin("127.0.0.1:8090", "http://127.0.0.1:8090"))
        self.assertTrue(verify_host_and_origin("localhost:8090", "http://localhost:8090"))
        self.assertFalse(verify_host_and_origin("evil.attacker.com", ""))
        self.assertFalse(verify_host_and_origin("127.0.0.1:8090", "https://evil.attacker.com"))

    def test_cwe_400_payload_cap(self):
        self.assertEqual(len(enforce_payload_cap(b"A" * 1024)), 1024)
        with self.assertRaises(ValueError):
            enforce_payload_cap(b"A" * (65 * 1024))

    def test_cwe_1333_zero_unwrap_in_rust_engine(self):
        rust_src = (ROOT_DIR / "engines" / "sbom_scanner" / "src" / "main.rs").read_text(encoding="utf-8")
        prod_code = rust_src.split("#[cfg(test)]")[0]
        self.assertNotIn(".unwrap()", prod_code)
        self.assertNotIn(".expect(", prod_code)

    def test_aes256_gcm_and_ed25519_auth(self):
        secret = b"CyberNest CUI Classified SBOM Ledger Record"
        ct = encrypt_aes256_gcm(secret)
        pt = decrypt_aes256_gcm(ct)
        self.assertEqual(pt, secret)

        identity = get_or_create_ed25519_identity()
        self.assertTrue(identity["key_id"].startswith("CN-ED25519-"))
        sig = sign_payload_ed25519(secret)
        self.assertEqual(sig["algorithm"], "Ed25519")
        self.assertTrue(len(sig["signature"]) >= 64)

    def test_cisa_sbom_generation_local_and_github(self):
        # 1. Local repository ingestion
        bundle = generate_complete_sbom_bundle(str(ROOT_DIR))
        self.assertEqual(bundle["cyclonedx_json"]["bomFormat"], "CycloneDX")
        self.assertEqual(bundle["cyclonedx_json"]["specVersion"], "1.5")
        self.assertEqual(bundle["spdx_json"]["spdxVersion"], "SPDX-2.3")
        self.assertIn("CISA-COMPLIANT SOFTWARE BILL OF MATERIALS", bundle["cisa_markdown"])
        self.assertEqual(bundle["stix_bundle"]["type"], "bundle")
        self.assertEqual(bundle["taxii_collection"]["x_spec_version"], "TAXII-2.1")

        # Save and retrieve from AES-256-GCM SQLite WAL enclave
        row_id = save_sbom_bundle(bundle)
        self.assertGreater(row_id, 0)
        loaded = get_latest_sbom_bundle(bundle["repo_name"])
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded["repo_name"], bundle["repo_name"])

        # 2. GitHub repository URL ingestion
        gh_bundle = generate_complete_sbom_bundle("https://github.com/cybernest-labs/nestsbom", allow_clone=False)
        self.assertEqual(gh_bundle["repo_name"], "nestsbom")
        self.assertGreaterEqual(len(gh_bundle["components"]), 1)

        # 3. Nocturnal Synth-Ledger HTML fragment verification
        frag = render_cisa_sbom_html_fragment(bundle)
        self.assertIn('class="panel"', frag)
        self.assertIn('class="step-meter"', frag)
        self.assertEqual(len(render_synth_step_meter(50)), 20)

    def test_cmmc_stig_and_network_sensing(self):
        medium = sense_network_medium_802()
        self.assertEqual(medium["status"], "VALIDATED")
        comp = verify_cmmc_and_stig_controls()
        self.assertEqual(comp["sprs_score"], 110)
        self.assertIn("signature", comp)


if __name__ == "__main__":
    unittest.main()
